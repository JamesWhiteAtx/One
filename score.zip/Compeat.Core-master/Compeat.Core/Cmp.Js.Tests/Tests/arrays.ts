﻿/// <reference path="../common-refs.d.ts" />﻿

// typescript doesn't allow for this to be defined in the testing function
class CustomArraysTestClass {
    constructor(public Id: number, public Description: string) { }
}

describe("Cmp.Js.Arrays", function () {

    describe("Equals", function () {

        var strComparerFunc: Cmp.Js.Types.IEqualityFunc<string> = function (value1: string, value2: string) {
            return value1 === value2;
        };

        it("NullArraysAreEqual", function (done) {
            var array1: Array<string> = null;
            var array2: Array<string> = null;
            expect(Cmp.Js.Arrays.Equals(array1, array2, strComparerFunc))
                .toBe(true);
            done();
        });

        it("EmptyArraysAreEqual", function (done) {
            var array1: Array<string> = [];
            var array2: Array<string> = [];
            expect(Cmp.Js.Arrays.Equals(array1, array2, strComparerFunc))
                .toBe(true);
            done();
        });

        it("LengthsAreNotEqual", function (done) {
            var array1: Array<string> = ['one', 'two'];
            var array2: Array<string> = ['one'];
            expect(Cmp.Js.Arrays.Equals(array1, array2, strComparerFunc))
                .toBe(false);
            done();
        });

        it("OneArrayIsNull", function (done) {
            var array1: Array<string> = ['one', 'two'];
            var array2: Array<string> = null;
            expect(Cmp.Js.Arrays.Equals(array1, array2, strComparerFunc))
                .toBe(false);
            done();
        });

        it("ArraysAreOutOfOrder", function (done) {
            var array1: Array<string> = ['one', 'two'];
            var array2: Array<string> = ['two', 'one'];
            expect(Cmp.Js.Arrays.Equals(array1, array2, strComparerFunc))
                .toBe(false);
            done();
        });

        it("ArraysAreEqual", function (done) {
            var array1: Array<string> = ['one', 'two'];
            var array2: Array<string> = ['one', 'two'];
            expect(Cmp.Js.Arrays.Equals(array1, array2, strComparerFunc))
                .toBe(true);
            done();
        });

        it("UndefinedsAreEqual", function (done) {
            var array1: Array<string> = undefined;
            var array2: Array<string> = undefined;
            expect(Cmp.Js.Arrays.Equals(array1, array2, strComparerFunc))
                .toBe(true);
            done();
        });

        it("NullAndUndefinedAreEqual", function (done) {
            var array1: Array<string> = null;
            var array2: Array<string> = undefined;
            expect(Cmp.Js.Arrays.Equals(array1, array2, strComparerFunc))
                .toBe(true);
            done();
        });

        var customArraysTestClassComparerFunc: Cmp.Js.Types.IEqualityFunc<CustomArraysTestClass> = function (value1: CustomArraysTestClass, value2: CustomArraysTestClass) {
            return value1.Id === value2.Id
                && value1.Description === value2.Description;
        };

        it("ArraysOfCustomAreEqual", function (done) {
            var array1: Array<CustomArraysTestClass> = [
                new CustomArraysTestClass(1, 'one'),
                new CustomArraysTestClass(2, 'two')
            ];
            var array2: Array<CustomArraysTestClass> = [
                new CustomArraysTestClass(1, 'one'),
                new CustomArraysTestClass(2, 'two')
            ];
            expect(Cmp.Js.Arrays.Equals(array1, array2, customArraysTestClassComparerFunc))
                .toBe(true);
            done();
        });

        it("ArraysOfCustomNotEqual", function (done) {
            var array1: Array<CustomArraysTestClass> = [
                new CustomArraysTestClass(1, 'one'),
                new CustomArraysTestClass(2, 'two')
            ];
            var array2: Array<CustomArraysTestClass> = [
                new CustomArraysTestClass(2, 'two'),
                new CustomArraysTestClass(1, 'one')
            ];
            expect(Cmp.Js.Arrays.Equals(array1, array2, customArraysTestClassComparerFunc))
                .toBe(false);
            done();
        });

    });

    describe("First", function () {

        it("FirstAtStartOfArray", function (done) {
            var source: Array<CustomArraysTestClass> = [
                new CustomArraysTestClass(1, 'one'),
                new CustomArraysTestClass(2, 'two'),
                new CustomArraysTestClass(3, 'three')
            ];

            expect(Cmp.Js.Arrays.First(source, (item: CustomArraysTestClass) => { return item.Id === 1; }).Description)
                .toBe('one');
            done();
        });

        it("FirstAtEndOfArray", function (done) {
            var source: Array<CustomArraysTestClass> = [
                new CustomArraysTestClass(1, 'one'),
                new CustomArraysTestClass(2, 'two'),
                new CustomArraysTestClass(3, 'three')
            ];

            expect(Cmp.Js.Arrays.First(source, (item: CustomArraysTestClass) => { return item.Id === 3; }).Description)
                .toBe('three');
            done();
        });

        it("FirstOfMoreThanOne", function (done) {
            var source: Array<CustomArraysTestClass> = [
                new CustomArraysTestClass(1, 'one'),
                new CustomArraysTestClass(2, 'two'),
                new CustomArraysTestClass(3, 'three-a'),
                new CustomArraysTestClass(3, 'three-b'),
            ];

            expect(Cmp.Js.Arrays.First(source, (item: CustomArraysTestClass) => { return item.Id === 3; }).Description)
                .toBe('three-a');
            done();
        });

        it("NotFoundIsNull", function (done) {
            var source: Array<CustomArraysTestClass> = [
                new CustomArraysTestClass(1, 'one'),
                new CustomArraysTestClass(2, 'two')
            ];

            expect(Cmp.Js.Arrays.First(source, (item: CustomArraysTestClass) => { return item.Id === 3; }))
                .toBe(null);
            done();
        });

        it("NullSourceIsNull", function (done) {
            var source: Array<CustomArraysTestClass> = null;

            expect(Cmp.Js.Arrays.First(source, (item: CustomArraysTestClass) => { return item.Id === 3; }))
                .toBe(null);
            done();
        });

    });

    describe("Remove", function () {

        it("RemoveOnly", function (done) {
            var source: Array<CustomArraysTestClass> = [
                new CustomArraysTestClass(1, 'one')
            ];
            var result = Cmp.Js.Arrays.Remove(source, (item: CustomArraysTestClass) => { return item.Id === 1; });
            expect(source.length).toBe(0);
            expect(result).toBe(1);
            done();
        });

        it("RemoveMoreThanOnly", function (done) {
            var source: Array<CustomArraysTestClass> = [
                new CustomArraysTestClass(1, 'one'),
                new CustomArraysTestClass(2, 'two'),
                new CustomArraysTestClass(1, 'one')
            ];

            var result = Cmp.Js.Arrays.Remove(source, (item: CustomArraysTestClass) => { return item.Id === 1; });
            expect(source.length).toBe(1);
            expect(source[0].Description).toBe('two');
            expect(result).toBe(2);
            done();
        });

        it("RemoveFromNull", function (done) {
            var source: Array<CustomArraysTestClass> = null;
            var result = Cmp.Js.Arrays.Remove(source, (item: CustomArraysTestClass) => { return item.Id === 1; });
            expect(source).toBe(null);
            expect(result).toBe(0);
            done();
        });

        it("RemoveFromUndefined", function (done) {
            var source: Array<CustomArraysTestClass> = undefined;
            var result = Cmp.Js.Arrays.Remove(source, (item: CustomArraysTestClass) => { return item.Id === 1; });
            expect(source).toBe(undefined);
            expect(result).toBe(0);
            done();
        });

    });

    describe("Min", function () {
		var minner = (obj: any): number => {
			return obj.val;
		};

        it("In Order", function (done) {
			var source = [
				{ val: 1 },
				{ val: 2 },
				{ val: 3 },
			];

            var result = Cmp.Js.Arrays.Min(source, minner);
            expect(result).toBeTruthy();
			expect(result.val).toBe(1);
            done();
        });

        it("out of Order", function (done) {
			var source = [
				{ val: 3 },
				{ val: 1 },
				{ val: 2 },
			];

            var result = Cmp.Js.Arrays.Min(source, minner);
            expect(result).toBeTruthy();
			expect(result.val).toBe(1);
            done();
        });

        it("falsey", function (done) {
            expect(Cmp.Js.Arrays.Min(null, minner)).toBeFalsy();
            expect(Cmp.Js.Arrays.Min(undefined, minner)).toBeFalsy();
            expect(Cmp.Js.Arrays.Min([], minner)).toBeFalsy();
            done();
        });

    });

});