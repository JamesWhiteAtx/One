﻿/// <reference path="../common-refs.d.ts" />﻿

describe("Cmp.Js", function () {

	describe("Boolify", function () {

		it("UndefinedIsFalse", function (done) {
			expect(Cmp.Js.Boolify(undefined)).toBe(false);
			done();
		});

		it("NullIsFalse", function (done) {
			expect(Cmp.Js.Boolify(null)).toBe(false);
			done();
		});

		it("NotNullIsTrue", function (done) {
			expect(Cmp.Js.Boolify({})).toBe(true);
			done();
		});

		it("EmptyStringIsFalse", function (done) {
			expect(Cmp.Js.Boolify('')).toBe(false);
			done();
		});

		it("NotEmptyStringIsTrue", function (done) {
			expect(Cmp.Js.Boolify('not empty')).toBe(true);
			done();
		});

		it("ZeroIsFalse", function (done) {
			expect(Cmp.Js.Boolify(0)).toBe(false);
			done();
		});

		it("PositiveIsTrue", function (done) {
			expect(Cmp.Js.Boolify(823)).toBe(true);
			done();
		});

		it("NegativeIsTrue", function (done) {
			expect(Cmp.Js.Boolify(-723)).toBe(true);
			done();
		});

		it("FalseStringIsFalse", function (done) {
			expect(Cmp.Js.Boolify('false')).toBe(false);
			expect(Cmp.Js.Boolify('False')).toBe(false);
			expect(Cmp.Js.Boolify(' False ')).toBe(false);
			done();
		});
	});

	describe("EqualsStrict", function () {

		it("NullNotEqualsNull", function (done) {
			expect(Cmp.Js.EqualsStrict(null, null)).toBe(false);
			done();
		});

		it("UndefinedNotEqualsUndefined", function (done) {
			expect(Cmp.Js.EqualsStrict(undefined, undefined)).toBe(false);
			done();
		});

		it("NullNotEqualsObject", function (done) {
			expect(Cmp.Js.EqualsStrict(null, {})).toBe(false);
			done();
		});

		it("UndefinedNotEqualsObject", function (done) {
			expect(Cmp.Js.EqualsStrict(undefined, {})).toBe(false);
			done();
		});

		it("TwoDifferentObjects", function (done) {
			expect(Cmp.Js.EqualsStrict({}, {})).toBe(false);
			done();
		});

		it("SameObject", function (done) {
			var objA = { name: "test" };
			var objB = objA;
			expect(Cmp.Js.EqualsStrict(objA, objB)).toBe(true);
			done();
		});

		it("SameNumber", function (done) {
			var val1: number = 32;
			var val2: number = 32;
			expect(Cmp.Js.EqualsStrict(val1, val2)).toBe(true);
			done();
		});

		it("DifferentNumber", function (done) {
			var val1: number = 32;
			var val2: number = 14;
			expect(Cmp.Js.EqualsStrict(val1, val2)).toBe(false);
			done();
		});

		it("SameString", function (done) {
			var val1: string = 'abc';
			var val2: string = 'abc';
			expect(Cmp.Js.EqualsStrict(val1, val2)).toBe(true);
			done();
		});

		it("DifferentStringCasing", function (done) {
			var val1: string = 'abc';
			var val2: string = 'aBc';
			expect(Cmp.Js.EqualsStrict(val1, val2)).toBe(false);
			done();
		});

		it("DifferentString", function (done) {
			var val1: string = 'abc';
			var val2: string = 'abc';
			expect(Cmp.Js.EqualsStrict(val1, val2)).toBe(true);
			done();
		});

	});

    describe("GetValue", function () {

        it("SourceIsUndefined", function () {
            expect(Cmp.Js.GetValue(undefined, 'doesnotmatter')).toBeUndefined();
        });

        it("SourceIsNull", function () {
            expect(Cmp.Js.GetValue(null, 'doesnotmatter')).toBeUndefined();
        });

        it("Simple", function () {
            expect(Cmp.Js.GetValue({ notId: -32, id: 99 }, 'id')).toBe(99);
        });

        it("PropertyDoesNotExist", function () {
            expect(Cmp.Js.GetValue({ notId: -32, id: 99 }, 'someOtherProperty')).toBeUndefined();
        });

    });

    describe("SetValue", function () {

        var simpleSource = (): Object => {
            return {
                prop1: 3,
                prop2: 'strVal'
            };
        };

        it("Simple", function () {
            var test = simpleSource();
            Cmp.Js.SetValue(test, 'prop1', 99);
            expect(test['prop1']).toBe(99);
            expect(test['prop2']).toBe('strVal');
        });

        it("CreateValue", function () {
            var test = simpleSource();
            Cmp.Js.SetValue(test, 'prop3', -1);
            expect(test['prop3']).toBe(-1);
        });
    });

    describe("Jsonify", function () {

        var simpleSource = (): Object => {
            return {
                prop1: 3,
                prop2: 'strVal',
                prop3: ['one', 'two']
            };
        };

        it("Simple", function () {
            var result = Cmp.Js.Jsonify(simpleSource(), ['prop1', 'prop3']);
            expect(result['prop1']).toBe(3);
            expect(result['prop2']).toBeUndefined();
            expect(result['prop3']).toBeDefined();
            expect(result['prop3'].length).toBe(2);
            expect(result['prop3'][0]).toBe('one');
            expect(result['prop3'][1]).toBe('two');
        });
        

    });

    describe("DatesAreEqual", function () {

        it("NullsAreEqual", function () {
            expect(Cmp.Js.DatesAreEqual(null, null)).toBe(true);
        });

        it("UndefinedsAreEqual", function () {
            expect(Cmp.Js.DatesAreEqual(undefined, undefined)).toBe(true);
        });

        it("UndefinedAndNullAreEqual", function () {
            expect(Cmp.Js.DatesAreEqual(undefined, null)).toBe(true);
        });

        it("NullAndUndefinedAreEqual", function () {
            expect(Cmp.Js.DatesAreEqual(null, undefined)).toBe(true);
        });

        it("DatesAreEqual", function () {
            var dateA = new Date(2015, 5, 6, 10, 44, 3);
            var dateB = new Date(2015, 5, 6, 10, 44, 3);
            expect(Cmp.Js.DatesAreEqual(dateA, dateB)).toBe(true);
        });

        it("DatesAreNotEqual", function () {
            var dateA = new Date(2015, 5, 6, 10, 44, 3);
            var dateB = new Date(2015, 5, 6, 10, 44, 7);
            expect(Cmp.Js.DatesAreEqual(dateA, dateB)).toBe(false);
        });

        it("DatesNotEqualNull", function () {
            var dateA = new Date(2015, 5, 6, 10, 44, 3);
            expect(Cmp.Js.DatesAreEqual(dateA, null)).toBe(false);
        });

        it("DatesNotEqualUndefined", function () {
            var dateA = new Date(2015, 5, 6, 10, 44, 3);
            expect(Cmp.Js.DatesAreEqual(dateA, undefined)).toBe(false);
        });
    });
});