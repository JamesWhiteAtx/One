﻿/// <reference path="../common-refs.d.ts" />﻿

describe("Cmp.Js.Strings", function () {

	describe("IsEmpty", function () {

		it("StringIsUndefined", function (done) {
			expect(Cmp.Js.Strings.IsEmpty(undefined)).toBe(true);
			done();
		});

		it("StringIsNull", function (done) {
			expect(Cmp.Js.Strings.IsEmpty(null)).toBe(true);
			done();
		});

		it("StringIsEmpty", function (done) {
			expect(Cmp.Js.Strings.IsEmpty('')).toBe(true);
			done();
		});

		it("StringIsNotEmpty", function (done) {
			expect(Cmp.Js.Strings.IsEmpty('1')).toBe(false);
			done();
		});

	});

	describe("IsInteger", function () {

		it("Decimal", function (done) {
			expect(Cmp.Js.Strings.IsInteger("1.43")).toBe(false);
			done();
		});

		it("Alphanumeric", function (done) {
			expect(Cmp.Js.Strings.IsInteger("1a")).toBe(false);
			done();
		});
        
		// currently unsupported
		it("WithSeparator", function (done) {
			expect(Cmp.Js.Strings.IsInteger("1,000")).toBe(false);
			done();
		});

		it("NoSign", function (done) {
			expect(Cmp.Js.Strings.IsInteger("66")).toBe(true);
			done();
		});

		it("Positive", function (done) {
			expect(Cmp.Js.Strings.IsInteger("+8")).toBe(true);
			done();
		});

		it("Negative", function (done) {
			expect(Cmp.Js.Strings.IsInteger("-4")).toBe(true);
			done();
		});

	});

	describe("IsIntegerOrEmpty", function () {

		it("Null", function (done) {
			expect(Cmp.Js.Strings.IsIntegerOrEmpty(null)).toBe(true);
			done();
		});

		it("Undefined", function (done) {
			expect(Cmp.Js.Strings.IsIntegerOrEmpty(undefined)).toBe(true);
			done();
		});

		it("Alphanumeric", function (done) {
			expect(Cmp.Js.Strings.IsIntegerOrEmpty("1a")).toBe(false);
			done();
		});

		it("NoSign", function (done) {
			expect(Cmp.Js.Strings.IsIntegerOrEmpty("6634")).toBe(true);
			done();
		});

	});

    describe("MakeIntegerString", function () {

        it("Null", function (done) {
            expect(Cmp.Js.Strings.MakeIntegerString(null)).toBe(null);
            done();
        });
        it("undefined", function (done) {
            expect(Cmp.Js.Strings.MakeIntegerString(undefined)).toBe(undefined);
            done();
        });

        it("", function (done) {
            expect(Cmp.Js.Strings.MakeIntegerString('')).toBe('');
            done();
        });
        it("0", function (done) {
            expect(Cmp.Js.Strings.MakeIntegerString(0)).toBe('0');
            done();
        });

        it("05", function (done) {
            expect(Cmp.Js.Strings.MakeIntegerString('05')).toBe('05');
            done();
        });

        it("123", function (done) {
            expect(Cmp.Js.Strings.MakeIntegerString('123')).toBe('123');
            done();
        });
        it("123 as num", function (done) {
            expect(Cmp.Js.Strings.MakeIntegerString(123)).toBe('123');
            done();
        });
        it("-", function (done) {
            expect(Cmp.Js.Strings.MakeIntegerString('-')).toBe('-');
            done();
        });
        it("-1", function (done) {
            expect(Cmp.Js.Strings.MakeIntegerString('-1')).toBe('-1');
            done();
        });
    });

    describe("MakeDecimalString", function () {

        it("Null", function (done) {
            expect(Cmp.Js.Strings.MakeDecimalString(null)).toBe(null);
            done();
        });
        it("undefined", function (done) {
            expect(Cmp.Js.Strings.MakeDecimalString(undefined)).toBe(undefined);
            done();
        });

        it("", function (done) {
            expect(Cmp.Js.Strings.MakeDecimalString('')).toBe('');
            done();
        });
        it("0", function (done) {
            expect(Cmp.Js.Strings.MakeDecimalString(0)).toBe('0');
            done();
        });

        it("0.5", function (done) {
            expect(Cmp.Js.Strings.MakeDecimalString('0.5')).toBe('0.5');
            done();
        });

        it("123", function (done) {
            expect(Cmp.Js.Strings.MakeDecimalString('123')).toBe('123');
            done();
        });
        it("123 as num", function (done) {
            expect(Cmp.Js.Strings.MakeDecimalString(123)).toBe('123');
            done();
        });
        it("-", function (done) {
            expect(Cmp.Js.Strings.MakeDecimalString('-')).toBe('-');
            done();
        });
        it("-1", function (done) {
            expect(Cmp.Js.Strings.MakeDecimalString('-1')).toBe('-1');
            done();
        });
        it(".", function (done) {
            expect(Cmp.Js.Strings.MakeDecimalString('.')).toBe('0.');
            done();
        });
        it(".1", function (done) {
            expect(Cmp.Js.Strings.MakeDecimalString('.1')).toBe('0.1');
            done();
        });
        it("-.1", function (done) {
            expect(Cmp.Js.Strings.MakeDecimalString('-.1')).toBe('-0.1');
            done();
        });
    });


    describe("KebabCase", function () {
        it("empty", function (done) {
            expect(Cmp.Js.Strings.KebabCase('')).toBe('');
            done();
        });
        it("null", function (done) {
            expect(Cmp.Js.Strings.KebabCase(null)).toBe(null);
            done();
        });
        it("undef", function (done) {
            expect(Cmp.Js.Strings.KebabCase(undefined)).toBe(undefined);
            done();
        });
        it("FooBar", function (done) {
            expect(Cmp.Js.Strings.KebabCase('FooBar')).toBe('foo-bar');
            done();
        });
        it("fooBar", function (done) {
            expect(Cmp.Js.Strings.KebabCase('fooBar')).toBe('foo-bar');
            done();
        });
        it("foo-bar", function (done) {
            expect(Cmp.Js.Strings.KebabCase('foo-bar')).toBe('foo-bar');
            done();
        });
    });

    describe("Format", function () {

        it("Simple", function () {
            var result = Cmp.Js.Strings.Format("val={0}", "test");
            expect(result).toBe("val=test");
        });

        it("2 vals", function () {
            var result = Cmp.Js.Strings.Format("val1={0}, val2={1}", "test1", "test2");
            expect(result).toBe("val1=test1, val2=test2");
        });
        it("2 vals out of order", function () {
            var result = Cmp.Js.Strings.Format("val2={1}, val1={0}", "test1", "test2");
            expect(result).toBe("val2=test2, val1=test1");
        });
        it("No vals", function () {
            var result = Cmp.Js.Strings.Format("val={0}");
            expect(result).toBe("val={0}");
        });
        it("Many of Same", function () {
            var result = Cmp.Js.Strings.Format("{0}, {0}, {0}", "test");
            expect(result).toBe("test, test, test");
        });
    });


    describe("FormatSecondsAsHourMinute", function () {
        it("null", function () {
            var result = Cmp.Js.Strings.FormatSecondsAsHourMinute(null);
            expect(result).toBe('');
        });
        it("undefined", function () {
            var result = Cmp.Js.Strings.FormatSecondsAsHourMinute(undefined);
            expect(result).toBe('');
        });
        it("Zero", function () {
            var result = Cmp.Js.Strings.FormatSecondsAsHourMinute(0);
            expect(result).toBe('0:00');
        });
        it("~Zero", function () {
            var result = Cmp.Js.Strings.FormatSecondsAsHourMinute(29);
            expect(result).toBe('0:00');
        });
        it("9 minutes, double digit", function () {
            var result = Cmp.Js.Strings.FormatSecondsAsHourMinute(540);
            expect(result).toBe('0:09');
        });
        it("10 minutes, double digit", function () {
            var result = Cmp.Js.Strings.FormatSecondsAsHourMinute(600);
            expect(result).toBe('0:10');
        });
        it("60 minutes, hours place started", function () {
            var result = Cmp.Js.Strings.FormatSecondsAsHourMinute(3600);
            expect(result).toBe('1:00');
        });
        it("61 minutes, minutes still exist", function () {
            var result = Cmp.Js.Strings.FormatSecondsAsHourMinute(3660);
            expect(result).toBe('1:01');
        });
        it("100 hours, hours place 3 digits", function () {
            var result = Cmp.Js.Strings.FormatSecondsAsHourMinute(360000);
            expect(result).toBe('100:00');
        });
        it("rounding and floors", function () {
            var result = Cmp.Js.Strings.FormatSecondsAsHourMinute(7140);
            expect(result).toBe('1:59');
        });
    });
    describe("FormatSecondsAsDayHourMinute", function () {
        it("null", function () {
            var result = Cmp.Js.Strings.FormatSecondsAsDayHourMinute(null);
            expect(result).toBe('');
        });
        it("undefined", function () {
            var result = Cmp.Js.Strings.FormatSecondsAsDayHourMinute(undefined);
            expect(result).toBe('');
        });
        it("Zero", function () {
            var result = Cmp.Js.Strings.FormatSecondsAsDayHourMinute(0);
            expect(result).toBe('0:00:00');
        });
        it("~Zero", function () {
            var result = Cmp.Js.Strings.FormatSecondsAsDayHourMinute(29);
            expect(result).toBe('0:00:00');
        });
        it("9 minutes, double digit", function () {
            var result = Cmp.Js.Strings.FormatSecondsAsDayHourMinute(540);
            expect(result).toBe('0:00:09');
        });
        it("10 minutes, double digit", function () {
            var result = Cmp.Js.Strings.FormatSecondsAsDayHourMinute(600);
            expect(result).toBe('0:00:10');
        });
        it("60 minutes, hours place started", function () {
            var result = Cmp.Js.Strings.FormatSecondsAsDayHourMinute(3600);
            expect(result).toBe('0:01:00');
        });
        it("61 minutes, minutes still exist", function () {
            var result = Cmp.Js.Strings.FormatSecondsAsDayHourMinute(3660);
            expect(result).toBe('0:01:01');
        });
        it("9 hours, double digit", function () {
            var result = Cmp.Js.Strings.FormatSecondsAsDayHourMinute(32400);
            expect(result).toBe('0:09:00');
        });
        it("10 hours, double digit", function () {
            var result = Cmp.Js.Strings.FormatSecondsAsDayHourMinute(36000);
            expect(result).toBe('0:10:00');
        });
        it("24 hours, days place started", function () {
            var result = Cmp.Js.Strings.FormatSecondsAsDayHourMinute(86400);
            expect(result).toBe('1:00:00');
        });
        it("25 hours, hours still exist", function () {
            var result = Cmp.Js.Strings.FormatSecondsAsDayHourMinute(90000);
            expect(result).toBe('1:01:00');
        });
        it("25 hours and 1 minute, hours and minutes still exist", function () {
            var result = Cmp.Js.Strings.FormatSecondsAsDayHourMinute(90060);
            expect(result).toBe('1:01:01');
        });
        it("100 days, days place 3 digits", function () {
            var result = Cmp.Js.Strings.FormatSecondsAsDayHourMinute(8640000);
            expect(result).toBe('100:00:00');
        });
        it("rounding and floors", function () {
            var result = Cmp.Js.Strings.FormatSecondsAsDayHourMinute(136860);
            expect(result).toBe('1:14:01');
        });
    });
});