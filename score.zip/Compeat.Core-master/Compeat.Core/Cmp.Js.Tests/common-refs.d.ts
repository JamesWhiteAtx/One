﻿/// <reference path="../../../Resources/TypeScriptDefs/jasmine-2.2.d.ts" />﻿
/// <reference path="../../../BuildOutputs/Compeat.Core/Scripts/cmp-js.d.ts" />﻿