var gulp = require('gulp');
var karma = require('karma');
var gutil = require('gulp-util');

gulp.task('test', function (done) {

	var server = new karma.Server({
		configFile: __dirname + '/karma.conf.js',
		singleRun: true
	}, done);

	server.start();
});