﻿using Compeat.Mvc.BaseControllers;
using Compeat.Service;
using Compeat.Service.Authentication;
using Compeat.Service.Interfaces;
using FakeItEasy;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace Compeat.Mvc.Tests
{
	[TestClass]
	public class BaseAuthenticationControllerTests
	{

		[TestMethod]
		public void authenticationController_login_InvalidModel()
		{
			var controller = getTestController();

			var result = controller.Login(new TestAuthenticationModel() { expectedResultType = AuthResultTypes.InvalidCustomer }) as JsonResult;
			var typedResult = (AuthResult)result.Data;

			Assert.AreEqual((int)AuthResultTypes.InvalidCustomer, typedResult.Result);
		}

		[TestMethod]
		public void authenticationController_login_ValidModel()
		{
			var controller = getTestController();

			var model = new TestAuthenticationModel()
			{
				expectedResultType = AuthResultTypes.Authenticated,
				expectedCsrfToken = "test token"
			};

			var result = controller.Login(model) as JsonResult;
			var typedResult = (AuthResult)result.Data;

			Assert.AreEqual((int)AuthResultTypes.Authenticated, typedResult.Result);
			Assert.AreNotEqual(null, typedResult.Token);
			Assert.AreNotEqual(string.Empty, typedResult.Token);
		}

		[TestMethod]
		public void authenticationController_getToken_Authenticated()
		{
			var controller = getTestController(true, "test token");
			var result = (ContentResult)controller.GetToken();
			Assert.AreEqual("test token", result.Content);
		}

		[TestMethod]
		public void authenticationController_getToken_NotAuthenticated()
		{
			var controller = getTestController(false, "test token");
			var result = controller.GetToken();
			Assert.IsInstanceOfType(result, typeof(HttpUnauthorizedResult));
		}

		private TestAuthenticationController getTestController(bool expectedIsAuthenticated = false, string expectedCsrfToken = null)
		{
			var _inject = A.Fake<IInjectionContainer>();
			var _identityManager = A.Fake<IIdentityManager>();
			A.CallTo(() => _identityManager.IsAuthenticated).Returns(expectedIsAuthenticated);
			A.CallTo(() => _identityManager.CsrfToken).Returns(expectedCsrfToken);
			var fakedController = new TestAuthenticationController(_inject, _identityManager);
			return fakedController;
		}

		#region Dummy Test Classes

		public class TestAuthenticationModel
		{
			public virtual AuthResultTypes expectedResultType { get; set; }
			public virtual string expectedCsrfToken { get; set; }
		}

		public class TestAuthenticationController : BaseAuthenticationController<TestAuthenticationModel>
		{
			public TestAuthenticationController(IInjectionContainer injection, IIdentityManager identityManager)
				: base(injection, identityManager)
			{ }
			protected override AuthResultTypes ProcessLogin(TestAuthenticationModel model)
			{
				return model.expectedResultType;
			}
			protected override string GetCsrfToken(TestAuthenticationModel model)
			{
				return model.expectedCsrfToken;
			}
		}

		#endregion
	}
}
