﻿
using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Web.Mvc;
using System.Web.Routing;
using FakeItEasy;
using System.Net;
using Compeat.Mvc;

namespace Compeat.Mvc.Tests {

    [TestClass]
    public class JsonHelperTests {

        [TestMethod]
		public void JsonHelper_deserialize_string() {
			
			var json = "{" + "\"strProp\":\"strVal\"" + "}";

			var result = new JsonHelper().Deserialize<TestClass>(json);

			Assert.IsNotNull(result);
			Assert.AreEqual(new TestClass() { strProp = "strVal" }, result);
        }

		[TestMethod]
		public void JsonHelper_deserialize_int() {

			var json = "{" + "\"intProp\":100" + "}";

			var result = new JsonHelper().Deserialize<TestClass>(json);

			Assert.IsNotNull(result);
			Assert.AreEqual(new TestClass() { intProp = 100 }, result);
		}

		[TestMethod]
		public void JsonHelper_deserialize_intNull() {

			var jsonNotNullVal = "{" + "\"intNullProp\":100" + "}";

			var notNullResult = new JsonHelper().Deserialize<TestClass>(jsonNotNullVal);

			Assert.IsNotNull(notNullResult);
			Assert.AreEqual(new TestClass() { intNullProp = 100 }, notNullResult);


			var jsonNullVal = "{" + "\"intNullProp\":\"\"" + "}";

			var nullResult = new JsonHelper().Deserialize<TestClass>(jsonNullVal);

			Assert.IsNotNull(nullResult);
			Assert.AreEqual(new TestClass() { intNullProp = null }, nullResult);
		}

		[TestMethod]
		public void JsonHelper_deserialize_decimal() {

			var json = "{" + "\"decimalProp\":6.788" + "}";

			var result = new JsonHelper().Deserialize<TestClass>(json);

			Assert.IsNotNull(result);
			Assert.AreEqual(new TestClass() { decimalProp = 6.788m }, result);
		}

		[TestMethod]
		public void JsonHelper_deserialize_decimalNull() {

			var jsonNotNullVal = "{" + "\"decimalNullProp\":10.458" + "}";

			var notNullResult = new JsonHelper().Deserialize<TestClass>(jsonNotNullVal);

			Assert.IsNotNull(notNullResult);
			Assert.AreEqual(new TestClass() { decimalNullProp = 10.458m }, notNullResult);


			var jsonNullVal = "{" + "\"decimalNullProp\":\"\"" + "}";

			var nullResult = new JsonHelper().Deserialize<TestClass>(jsonNullVal);

			Assert.IsNotNull(nullResult);
			Assert.AreEqual(new TestClass() { decimalNullProp = null }, nullResult);
		}

		[TestMethod]
		public void JsonHelper_deserialize_byte() {

			var json = "{" + "\"byteProp\":8" + "}";

			var result = new JsonHelper().Deserialize<TestClass>(json);

			Assert.IsNotNull(result);
			Assert.AreEqual(new TestClass() { byteProp = 8 }, result);
		}

		[TestMethod]
		public void JsonHelper_deserialize_byteNull() {

			var jsonNotNullVal = "{" + "\"byteNullProp\":5" + "}";

			var notNullResult = new JsonHelper().Deserialize<TestClass>(jsonNotNullVal);

			Assert.IsNotNull(notNullResult);
			Assert.AreEqual(new TestClass() { byteNullProp = 5 }, notNullResult);


			var jsonNullVal = "{" + "\"byteNullProp\":\"\"" + "}";

			var nullResult = new JsonHelper().Deserialize<TestClass>(jsonNullVal);

			Assert.IsNotNull(nullResult);
			Assert.AreEqual(new TestClass() { byteNullProp = null }, nullResult);
		}

		[TestMethod]
		public void JsonHelper_deserialize_dateTime() {

			var json = "{" + "\"dateTimeProp\":\"2010-02-01T10:20:30.000Z\"" + "}";

			var result = new JsonHelper().Deserialize<TestClass>(json);

			Assert.IsNotNull(result);
			Assert.AreEqual(new TestClass() { dateTimeProp = new DateTime(2010, 2, 1, 10, 20, 30) }, result);
		}

		[TestMethod]
		public void JsonHelper_deserialize_dateTimeNull() {

			var jsonNotNullVal = "{" + "\"dateTimeNullProp\":\"2010-02-01T10:20:30.000Z\"" + "}";

			var notNullResult = new JsonHelper().Deserialize<TestClass>(jsonNotNullVal);

			Assert.IsNotNull(notNullResult);
			Assert.AreEqual(new TestClass() { dateTimeNullProp = new DateTime(2010, 2, 1, 10, 20, 30) }, notNullResult);


			var jsonNullVal = "{" + "\"dateTimeNullProp\":\"\"" + "}";

			var nullResult = new JsonHelper().Deserialize<TestClass>(jsonNullVal);

			Assert.IsNotNull(nullResult);
			Assert.AreEqual(new TestClass() { dateTimeNullProp = null }, nullResult);
		}

		[TestMethod]
		public void JsonHelper_deserialize_bool() {

			var json = "{" + "\"boolProp\":true" + "}";

			var result = new JsonHelper().Deserialize<TestClass>(json);

			Assert.IsNotNull(result);
			Assert.AreEqual(new TestClass() { boolProp = true }, result);
		}

		[TestMethod]
		public void JsonHelper_deserialize_boolNull() {

			var jsonNotNullVal = "{" + "\"boolNullProp\":false" + "}";

			var notNullResult = new JsonHelper().Deserialize<TestClass>(jsonNotNullVal);

			Assert.IsNotNull(notNullResult);
			Assert.AreEqual(new TestClass() { boolNullProp = false }, notNullResult);


			var jsonNullVal = "{" + "\"boolNullProp\":\"\"" + "}";

			var nullResult = new JsonHelper().Deserialize<TestClass>(jsonNullVal);

			Assert.IsNotNull(nullResult);
			Assert.AreEqual(new TestClass() { boolNullProp = null }, nullResult);
		}

		[TestMethod]
		public void JsonHelper_deserialize_nestedClass() {

			var json = "{" +
				"\"nestedClassProp\":[{\"nestedProp1\":1, \"nestedProp2\":\"strVal1\"}, {\"nestedProp1\":2, \"nestedProp2\":\"strVal2\"}]" +
				"}";

			var result = new JsonHelper().Deserialize<TestClass>(json);

			Assert.IsNotNull(result);
			Assert.AreEqual(new TestClass() {
				nestedClassProp = new NestedTestClass[] { 
					new NestedTestClass() { nestedProp1 = 1, nestedProp2 = "strVal1" },
					new NestedTestClass() { nestedProp1 = 2, nestedProp2 = "strVal2" }
				}
			}, result);
		}

		[TestMethod]
		public void JsonHelper_deserialize_multiProperty() {

			var json = "{" +
				"\"strProp\":\"strVal\"," +
				"\"byteProp\":1," +
				"\"nestedClassProp\":[{\"nestedProp1\":1, \"nestedProp2\":\"strVal1\"}, {\"nestedProp1\":2, \"nestedProp2\":\"strVal2\"}]" +
				"}";

			var result = new JsonHelper().Deserialize<TestClass>(json);

			Assert.IsNotNull(result);
			Assert.AreEqual(new TestClass() {
				strProp = "strVal",
				byteProp = 1,
				nestedClassProp = new NestedTestClass[] { 
					new NestedTestClass() { nestedProp1 = 1, nestedProp2 = "strVal1" },
					new NestedTestClass() { nestedProp1 = 2, nestedProp2 = "strVal2" }
				}
			}, result);
		}

		private class TestClass : IEquatable<TestClass>
		{

			public string strProp { get; set;  }
			public int intProp { get; set;  }
			public int? intNullProp { get; set; }
			public decimal decimalProp { get; set; }
			public decimal? decimalNullProp { get; set; }
			public byte byteProp { get; set; }
			public byte? byteNullProp { get; set; }
			public DateTime dateTimeProp { get; set; }
			public DateTime? dateTimeNullProp { get; set;  }
			public bool boolProp { get; set; }
			public bool? boolNullProp { get; set; }

			public NestedTestClass[] nestedClassProp { get; set; }

			public bool Equals(TestClass other) {
				
				var propertiesAreEqual =  
					strProp == other.strProp
					&& intProp == other.intProp
					&& intNullProp == other.intNullProp
					&& decimalProp == other.decimalProp
					&& decimalNullProp == other.decimalNullProp
					&& byteProp == other.byteProp
					&& byteNullProp == other.byteNullProp
					&& dateTimeProp == other.dateTimeProp
					&& dateTimeNullProp == other.dateTimeNullProp
					&& boolProp == other.boolProp
					&& boolNullProp == other.boolNullProp;

				if (propertiesAreEqual) {

					if (nestedClassProp == null && other.nestedClassProp == null) {
						return true;
					}
					else if ((nestedClassProp != null && other.nestedClassProp != null)
						&& (nestedClassProp.Length == other.nestedClassProp.Length)) {

						for (int i = 0; i < nestedClassProp.Length; i++) {
							if (!nestedClassProp[i].Equals(other.nestedClassProp[i])) {
								return false;
							}
						}

						return true;
					}
					else {
						return false;
					}
				}
				else {
					return false;
				}

			}

			public override bool Equals(object obj) {
				return Equals(obj as TestClass);
			}

			public override int GetHashCode() {
				return base.GetHashCode();
			}
		}

		private class NestedTestClass : IEquatable<NestedTestClass>
		{

			public int nestedProp1 { get; set; }
			public string nestedProp2 { get; set; }

			public bool Equals(NestedTestClass other) {
				return nestedProp1 == other.nestedProp1
					&& nestedProp2 == other.nestedProp2;
			}
		}

	}
}
