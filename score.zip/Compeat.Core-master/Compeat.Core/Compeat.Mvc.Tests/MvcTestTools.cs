﻿using Compeat.Data;
using FakeItEasy;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Compeat.Mvc.Tests
{
	public static class MvcTestTools
	{

		internal static IConnectionManager GetMockConnectionManager()
		{
			var connectionManager = A.Fake<IConnectionManager>();
			A.CallTo(() => connectionManager.ExecuteCommand(null, true, null, null))
				.WithAnyArguments()
				.Invokes((Action<SqlConnection> command, bool runInTransaction, int? transactionTimeout, string customer) =>
				{
					command(null);
				});
			return connectionManager;
		}

		internal static HttpContextBase GetMockHttpContext()
		{
			var request = A.Fake<HttpRequestBase>();
			A.CallTo(() => request.AppRelativeCurrentExecutionFilePath).Returns("/");
			A.CallTo(() => request.ApplicationPath).Returns("/");
			A.CallTo(() => request.ServerVariables).Returns(new NameValueCollection());
			A.CallTo(() => request.Url).Returns(new Uri("http://localhost", UriKind.Absolute));

			var response = A.Fake<HttpResponseBase>();
			A.CallTo(() => response.ApplyAppPathModifier(A<string>.Ignored))
				.ReturnsLazily((string s) => s);

			var server = A.Fake<HttpServerUtilityBase>();

			var session = A.Fake<HttpSessionStateBase>();

			var context = A.Fake<HttpContextBase>();
			A.CallTo(() => context.Request).Returns(request);
			A.CallTo(() => context.Response).Returns(response);
			A.CallTo(() => context.Session).Returns(session);
			A.CallTo(() => context.Server).Returns(server);

			return context;
		}

	}
}
