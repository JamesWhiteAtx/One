﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FakeItEasy;
using Compeat.Mvc.Razor;
using System.Web.Mvc;
using System.Web.Routing;
using System.Web;

namespace Compeat.Mvc.Tests
{
	[TestClass]
	public class RazorExtensionsTests
	{
		private HtmlHelper CreateHelper()
		{
			var fakeRequest = A.Fake<HttpRequestBase>();

			var fakeHttpContext = A.Fake<HttpContextBase>();
			A.CallTo(() => fakeHttpContext.Request).Returns(fakeRequest);

			var fakeViewDataContainer = A.Fake<IViewDataContainer>();
			var viewContext = new ViewContext();
			viewContext.HttpContext = fakeHttpContext;

			return new HtmlHelper(viewContext, fakeViewDataContainer);
		}

		#region Script Tag Extension

		[TestMethod]
		public void Script_tag_not_min_debug()
		{
			// arrange
			var helper = CreateHelper();
			var basePath = "the/test/path.js";

			//act
			var tag = RazorExtensions.VersionScriptTag(helper, basePath, false, true);

			//assert
			Assert.AreEqual("<script type='text/javascript' src='the/test/path.js'></script>", tag.ToString());
		}

		[TestMethod]
		public void Script_tag_use_min_debug()
		{
			// arrange
			var helper = CreateHelper();
			var basePath = "the/test/path.js";

			// act
			var tag = RazorExtensions.VersionScriptTag(helper, basePath, true, true);

			//assert
			Assert.AreEqual("<script type='text/javascript' src='the/test/path.js'></script>", tag.ToString());
		}

		[TestMethod]
		public void Script_tag_use_min_not_debug()
		{
			// arrange
			var helper = CreateHelper();

			var basePath = "the/test/path.js";
			var version = helper.AssemblyVersion();
			var expectedTag = "<script type='text/javascript' src='the/test/path.min.js?v="+ version + "'></script>";
			
			//act
			var tag = RazorExtensions.VersionScriptTag(helper, basePath, true, false);

			//assert
			Assert.AreEqual(expectedTag, tag.ToString());
		}

		[TestMethod]
		public void Script_tag_use_not_min_not_debug()
		{
			// arrange
			var helper = CreateHelper();

			var basePath = "the/test/path.js";
			var version = helper.AssemblyVersion();
			var expectedTag = "<script type='text/javascript' src='the/test/path.js?v=" + version + "'></script>";

			//act
			var tag = RazorExtensions.VersionScriptTag(helper, basePath, false, false);

			//assert
			Assert.AreEqual(expectedTag, tag.ToString());
		}

		#endregion


		#region Style Tag Extension

		[TestMethod]
		public void Stype_tag_not_min_debug()
		{
			// arrange
			var helper = CreateHelper();
			var basePath = "the/test/path.css";

			//act
			var tag = RazorExtensions.VersionStyleTag(helper, basePath, false, true);

			//assert
			Assert.AreEqual("<link href='the/test/path.css' rel='stylesheet'>", tag.ToString());
		}

		[TestMethod]
		public void Stype_tag_use_min_debug()
		{
			// arrange
			var helper = CreateHelper();
			var basePath = "the/test/path.css";

			// act
			var tag = RazorExtensions.VersionStyleTag(helper, basePath, true, true);

			//assert
			Assert.AreEqual("<link href='the/test/path.css' rel='stylesheet'>", tag.ToString());
		}

		[TestMethod]
		public void Stype_tag_use_min_not_debug()
		{
			// arrange
			var helper = CreateHelper();

			var basePath = "the/test/path.css";
			var version = helper.AssemblyVersion();
			var expectedTag = "<link href='the/test/path.min.css?v=" + version + "' rel='stylesheet'>";

			//act
			var tag = RazorExtensions.VersionStyleTag(helper, basePath, true, false);

			//assert
			Assert.AreEqual(expectedTag, tag.ToString());
		}

		[TestMethod]
		public void Stype_tag_use_not_min_not_debug()
		{
			// arrange
			var helper = CreateHelper();

			var basePath = "the/test/path.css";
			var version = helper.AssemblyVersion();
			var expectedTag = "<link href='the/test/path.css?v=" + version + "' rel='stylesheet'>";

			//act
			var tag = RazorExtensions.VersionStyleTag(helper, basePath, false, false);

			//assert
			Assert.AreEqual(expectedTag, tag.ToString());
		}

		#endregion

	}

}
