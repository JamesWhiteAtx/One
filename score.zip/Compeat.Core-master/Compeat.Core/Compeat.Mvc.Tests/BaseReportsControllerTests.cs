﻿using Compeat.Mvc.BaseControllers;
using Compeat.Mvc.Reports.Models;
using Compeat.Service;
using Compeat.Service.Authentication;
using Compeat.Service.BaseServices;
using Compeat.Service.Interfaces;
using Compeat.Service.Models;
using Compeat.SharedLib.DevExpress;
using DevExpress.XtraReports.UI;
using FakeItEasy;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using System.Web.Routing;

namespace Compeat.Mvc.Tests
{
	[TestClass]
	public class BaseReportsControllerTests
	{

		private string _report1 = "{" +
			"\"reportName\":\"BaseReportsTestReport1\"," +
			"\"reportParameters\":[{\"name\":\"toId\",\"value\":2}, {\"name\":\"fromId\",\"value\":1}]," +
			"\"csrfToken\":\"TestToken\"" +
			"}";

		private string _report2 = "{" +
			"\"reportName\":\"BaseReportsTestReport2\"," +
			"\"reportParameters\":[{\"name\":\"toId\",\"value\":2}, {\"name\":\"fromId\",\"value\":1}]," +
			"\"drillThroughTag\":\"drth_~|~1\"," +
			"\"csrfToken\":\"TestToken\"" +
			"}";

		private string _report3 = "{" +
			"\"reportName\":\"BaseReportsTestReport3\"," +
			"\"reportParameters\":[]," +
			"\"csrfToken\":\"TestToken\"" +
			"}";

		[TestMethod]
		public void ReportsController_Report_ValidRequest()
		{

			var result = GetTestController().Report(_report1);
			Assert.IsNotNull(result);
			Assert.IsInstanceOfType(result, typeof(ViewResult));

			var reportModel = (result as ViewResult).Model as ReportModel<TestReportBase>;
			Assert.IsNotNull(reportModel);

			Assert.AreEqual("TestToken", reportModel.CsrfToken);
			Assert.AreEqual("BaseReportsTestReport1", reportModel.ReportName);
		}

		[TestMethod]
		public void ReportsController_Report_InvalidToken()
		{

			var result = GetTestController(true, null).Report(_report1);
			Assert.IsNotNull(result);
			Assert.IsInstanceOfType(result, typeof(HttpUnauthorizedResult));
		}

		[TestMethod]
		public void ReportsController_Report_UnknownReport()
		{

			var unknownReportRequest = "{" +
				"\"reportName\":\"UnknownReport\"," +
				"\"csrfToken\":\"TestToken\"" +
				"}";

			var result = GetTestController().Report(unknownReportRequest);
			Assert.IsNotNull(result);
			Assert.IsInstanceOfType(result, typeof(HttpNotFoundResult));
		}

		[TestMethod]
		public void ReportsController_DrillThrough_ValidRequest()
		{

			var result = GetTestController().DrillThrough(_report2);
			Assert.IsNotNull(result);
			Assert.IsInstanceOfType(result, typeof(ViewResult));

			var reportModel = (result as ViewResult).Model as ReportModel<TestReportBase>;
			Assert.IsNotNull(reportModel);

			Assert.AreEqual("TestToken", reportModel.CsrfToken);
			Assert.AreEqual("BaseReportsTestReport1", reportModel.ReportName);
		}

		[TestMethod]
		public void ReportsController_DrillThrough_InvalidToken()
		{

			var result = GetTestController(true, null).DrillThrough(_report2);
			Assert.IsNotNull(result);
			Assert.IsInstanceOfType(result, typeof(HttpUnauthorizedResult));
		}

		[TestMethod]
		public void ReportsController_DrillThrough_UnknownReport()
		{

			var unknownReportRequest = "{" +
				"\"reportName\":\"UnknownReport\"," +
				"\"drillThroughTag\":\"drth_~|~1\"," +
				"\"csrfToken\":\"TestToken\"" +
				"}";

			var result = GetTestController().DrillThrough(unknownReportRequest);
			Assert.IsNotNull(result);
			Assert.IsInstanceOfType(result, typeof(HttpNotFoundResult));
		}

		private TestReportsController GetTestController(bool expectedIsAuthenticated = true, string expectedCsrfToken = "TestToken")
		{
			var _identityManager = A.Fake<IIdentityManager>();
			A.CallTo(() => _identityManager.IsAuthenticated).Returns(expectedIsAuthenticated);
			A.CallTo(() => _identityManager.CsrfToken).Returns(expectedCsrfToken);
			var _cacheService = new TestReportCacheService();
			return new TestReportsController(_identityManager, _cacheService);
		}

		[TestMethod]
		public void ReportsController_Report_NoRights()
		{

			var result = GetTestController().Report(_report3);
			Assert.IsNotNull(result);
			Assert.IsInstanceOfType(result, typeof(HttpUnauthorizedResult));
		}

		[TestMethod]
		public void ReportsController_DrillThrough_NoRights()
		{
			var result = GetTestController().DrillThrough(_report3);
			Assert.IsNotNull(result);
			Assert.IsInstanceOfType(result, typeof(HttpUnauthorizedResult));
		}

		[TestMethod]
		public void ReportsController_DocumentViewerPartial_NoRights()
		{
			var result = GetTestController().DocumentViewerPartial("BaseReportsTestReport3");
            Assert.IsNotNull(result);
			Assert.IsInstanceOfType(result, typeof(HttpUnauthorizedResult));
		}

		[TestMethod]
		public void ReportsController_ExportDocumentViewer_NoRights()
		{
            var result = GetTestController().ExportDocumentViewer("BaseReportsTestReport3");
			Assert.IsNotNull(result);
			Assert.IsInstanceOfType(result, typeof(HttpUnauthorizedResult));
		}

		#region Dummy Test Classes

		public abstract class TestReportBase : XtraReport, IDrillThroughXtraReport<TestReportBase>
		{
			public virtual Compeat.Mvc.Tests.BaseReportsControllerTests.TestReportBase GetDrillThroughReport(string tag)
			{
				return null;
			}
		}

		public class BaseReportsTestReport1 : Compeat.Mvc.Tests.BaseReportsControllerTests.TestReportBase { }
		public class BaseReportsTestReport2 : Compeat.Mvc.Tests.BaseReportsControllerTests.TestReportBase
		{
			public override Compeat.Mvc.Tests.BaseReportsControllerTests.TestReportBase GetDrillThroughReport(string tag)
			{
				return new BaseReportsTestReport1();
			}
		}
		public class BaseReportsTestReport3 : Compeat.Mvc.Tests.BaseReportsControllerTests.TestReportBase { }

		public class TestReportCacheService : IReportCacheService
		{
			public CachedReportModel GetCachedReport(Guid id)
			{
				return null;
			}
			public void CacheReport(CachedReportModel model) { }

		}

		public enum TestRightsEnum
		{
			BaseReportsTestReport1,
			BaseReportsTestReport2,
			BaseReportsTestReport3
		}

		public class TestReportsController : BaseReportsController<TestReportBase, TestRightsEnum>
		{
			public TestReportsController(IIdentityManager identityManager, TestReportCacheService cacheService)
				: base(identityManager, cacheService)
			{ }

			protected override bool HasRight(TestRightsEnum right)
			{
				return right == TestRightsEnum.BaseReportsTestReport1
					|| right == TestRightsEnum.BaseReportsTestReport2;
			}

			protected override FileResult GetExportFileResult(ReportModel<TestReportBase> reportModel)
			{
				return null;
			}

			protected override Dictionary<string, ReportRegistration> RegisteredReports
			{
				get
				{
					return new Dictionary<string, ReportRegistration>()
					{
						{ "BaseReportsTestReport1", new ReportRegistration(typeof(BaseReportsTestReport1), TestRightsEnum.BaseReportsTestReport1) },
						{ "BaseReportsTestReport2", new ReportRegistration(typeof(BaseReportsTestReport2), TestRightsEnum.BaseReportsTestReport2) },
						{ "BaseReportsTestReport3", new ReportRegistration(typeof(BaseReportsTestReport3), TestRightsEnum.BaseReportsTestReport3) }
					};
				}
			}

		}
		
		#endregion
	}
}
