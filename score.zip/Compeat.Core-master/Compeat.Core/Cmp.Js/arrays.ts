﻿/// <reference path="./types.ts" />﻿
/// <reference path="./js.ts" />﻿

namespace Cmp.Js.Arrays {

	/** Returns the first element found in the array where equalityComparer returns a true result, null if no items are found. */
	export function First<T>(source: Array<T>, evaluatorComparer: Cmp.Js.Types.IEvaluatorFunc<T>): T {

		var foundItem: T = null;
        if (source && evaluatorComparer) {
			for (var i = 0; i < source.length; i++) {
                if (evaluatorComparer(source[i])) {
					foundItem = source[i];
					break;
				}
			}
		}
		return foundItem;
	}
    
	/** Compares two arrays and returns true if they contain all of the same members in the same order as determined by equalityComparer */
	export function Equals<T>(array1: Array<T>, array2: Array<T>, equalityComparer: Cmp.Js.Types.IEqualityFunc<T>): boolean {

		if (array1 && array2 && array1.length && array2.length && array1.length === array2.length) {
			//both have same positive number of values values
			for (var _arrCounter = 0; _arrCounter < array1.length; _arrCounter++) {
				if (!equalityComparer(array1[_arrCounter], array2[_arrCounter])) {
					return false;
				}
			}
			return true;
		} else {
			//if one has a value and the other doesnt then they arent equal
			// both undefined or null are considered equal
			// both with length 0 are considered equal
			// will always return a boolean, rather than a falsy
			return (!array1 && !array2) || Cmp.Js.Boolify(array1 && array2 && array1.length === array2.length);
		}
	}

	/** Removes all indexes in an array that evaluate to true by the EvaluatorFunc
			changes original array
        Returns the number of items removed
	*/
    export function Remove<T>(source: Array<T>, equalityComparer: Cmp.Js.Types.IEvaluatorFunc<T>): number {
        var retVal = 0;
		if (source && source.length) {
			var originalLength = source.length;
			for (var i = originalLength - 1; i >= 0; i--) {
				if (equalityComparer(source[i])) {
                    source.splice(i, 1);
                    retVal++;
				}
			}
        }
        return retVal;
	}
	
	/** 
		traverses an array(assumed to not be sorted) for the minimum object based on the return val of the min function(the second arg)
	*/
	export function Min<TItemType, TPropertyToMin>(source: Array<TItemType>, getValToMin: (item: TItemType) => TPropertyToMin): TItemType {
        var retVal: TItemType = undefined;
		var currMin: TPropertyToMin = undefined;
		if (source && source.length) {
			retVal = source[0];
			if (source.length > 1) {
				currMin = getValToMin(retVal);
				for (var counter = 1; counter < source.length; counter++) {
					var newCurr = getValToMin(source[counter]);
					if (newCurr < currMin) {
						retVal = source[counter];
						currMin = newCurr;
					}
				}
			}
		}
		return retVal;
	}



}