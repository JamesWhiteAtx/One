﻿/// <reference path="js.ts" />

namespace Cmp.Js.Strings {

    var _isNullOrUndefined = Cmp.Js.IsNullOrUndefined;//for minify

	var _integerTestExpression: RegExp = /^(\+|-)?\d+$/;
	var _decimalTestExpression: RegExp = /^(\+|-)?(\d+)(\.)?(\d+)?$/;

	var _integerReplaceExpression: RegExp = /[^\d-]+/g;
	var _decimalReplaceExpression: RegExp = /[^\d-.]+/g;

	/** return true if the string is empty */
	export function IsEmpty(data: string): boolean {
		return typeof (data) === 'undefined'
			|| data === null
			|| data.toString().trim().length === 0;
	}

	/** returns true if the provided string can be parsed as an integer */
	export function IsInteger(data: string): boolean {
		return !IsEmpty(data)
			&& data.toString().search(_integerTestExpression) != -1;
	}

	/** returns true if the provided string can be parsed as an decimal number */
	export function IsDecimal(data: string): boolean {
		return !IsEmpty(data)
			&& data.toString().search(_decimalTestExpression) != -1;
	}

	/** returns true if the provided string can be parsed as an integer or the value is empty */
	export function IsIntegerOrEmpty(data: string): boolean {
		return IsEmpty(data)
			|| IsInteger(data);
	}

	/** returns true if the provided string can be parsed as an decimal or the value is empty */
	export function IsDecimalOrEmpty(data: string): boolean {
		return IsEmpty(data)
			|| IsDecimal(data);
	}

	/** cleans the value passed in until its a valid integer, return value is a string */
	export function MakeIntegerString(data: any): string {
		if (!_isNullOrUndefined(data)) {
			var dataAsString: string = data.toString();
			if (dataAsString.length) {
				var clean: string = dataAsString.replace(_integerReplaceExpression, '');
				if (!_isNullOrUndefined(clean) && clean.length > 1) {
					var firstDash = clean.indexOf('-');
					if (firstDash >= 0) {
						//only 1 neg allowed
						var nextDash = clean.lastIndexOf('-');
						while (nextDash >= 0 && nextDash != firstDash) {
							clean = clean.substring(0, nextDash) + ((nextDash + 1 < clean.length) ? clean.substring(nextDash + 1) : '');
							nextDash = clean.lastIndexOf('-');
						}
						//neg can only be first
						if (firstDash > 0) {
							clean = clean.substring(0, firstDash) + ((firstDash + 1 < clean.length) ? clean.substring(firstDash + 1) : '');
						}
					}
				}
				return clean;
			} else {
				return data;
			}
		} else {
			return data;
		}
	}

	/** cleans the value passed in until its a valid decimal number, return value is a string */
	export function MakeDecimalString(data: any): string {
		if (!_isNullOrUndefined(data)) {
			var dataAsString: string = data.toString();
			if (dataAsString.length) {
				var clean: string = dataAsString.replace(_decimalReplaceExpression, '');
				if (!_isNullOrUndefined(clean)) {
					var firstDash = clean.indexOf('-');
					if (firstDash >= 0) {
						//only 1 neg allowed
						var nextDash = clean.lastIndexOf('-');
						while (nextDash >= 0 && nextDash != firstDash) {
							clean = clean.substring(0, nextDash) + ((nextDash + 1 < clean.length) ? clean.substring(nextDash + 1) : '');
							nextDash = clean.lastIndexOf('-');
						}
						//neg can only be first
						if (firstDash > 0) {
							clean = clean.substring(0, firstDash) + ((firstDash + 1 < clean.length) ? clean.substring(firstDash + 1) : '');
						}
					}
					var firstDec = clean.indexOf('.');
					if (firstDec >= 0) {
						//only 1 decimal allowed
						var nextDec = clean.lastIndexOf('.');
						while (nextDec >= 0 && nextDec != firstDec) {
							clean = clean.substring(0, nextDec) + ((nextDec + 1 < clean.length) ? clean.substring(nextDec + 1) : '');
							nextDec = clean.lastIndexOf('.');
						}
					}
					if (clean.charAt(0) === '.') {
						clean = '0' + clean;
					} else if (clean.substring(0, 2) === '-.') {
						clean = '-0.' + clean.substring(2);
					}
				}
				return clean;
			} else {
				return data;
			}
		} else {
			return data;
		}
	}

	/** parses the format string for {0..n} positions and applies additional arguments */
	export function Format(formatString: string, ...args: any[]): string {

		return formatString.replace(/{(\d+)}/g,
			(match: string, matchNum: number) => {
				return typeof args[matchNum] != 'undefined' ? args[matchNum] : match;
			});
	};

    /** converts strings to kebab case:  fooBarTest => foo-bar-test , taken and modified from string.js */
    export function KebabCase(str: string) {
        if (str && str.length) {
            //see if there are any caps
            var anyMatch = str.match(/([A-Z])/g);
            if (anyMatch && anyMatch.length) {
                //make sure first char is lower case already since the replace wont do it right
                var first = str.charAt(0).match(/([A-Z])/g);
                if (first && first.length) {
                    if (str.length > 1) {
                        str = str.charAt(0).toLowerCase() + str.substring(1, str.length);
                    } else {
                        str = str.toLowerCase();
                    }
                }
                return str.trim().replace(/[_\s]+/g, '-').replace(/([A-Z])/g, '-$1').replace(/-+/g, '-').toLowerCase();
            } else {
                return str;
            }
        } else {
            return str;
        }
    }

    /** converts seconds to a string in the form of hhh:mm */
    export function FormatSecondsAsHourMinute(totalSeconds: number): string {
        var retVal: string = '';
        var math = Math; //for min
        if (!_isNullOrUndefined(totalSeconds)) {
            var wasNegative = Cmp.Js.Boolify(totalSeconds < 0);
            var totalSeconds = math.abs(totalSeconds);
            if (totalSeconds == 0 || totalSeconds < 30) {
                //simple case
                retVal = '0:00';
            } else {
                var minutes = math.round(totalSeconds / 60);
                var hours = math.floor(minutes / 60);
                minutes = minutes - (hours * 60);
                retVal = (hours ? hours : '0') + ':' + (minutes ? (minutes >= 10 ? minutes : '0' + minutes) : '00');
            }
        }
        return retVal;
    };

    /** converts seconds to a string in the form of D:hh:mm */
    export function FormatSecondsAsDayHourMinute(totalSeconds: number): string {
        var retVal: string = '';
        var math = Math; //for min
        if (!_isNullOrUndefined(totalSeconds)) {
            var wasNegative = Cmp.Js.Boolify(totalSeconds < 0);
            var totalSeconds = math.abs(totalSeconds);
            if (totalSeconds == 0 || totalSeconds < 30) {
                //simple case
                retVal = '0:00:00';
            } else {
                var minutes = math.round(totalSeconds / 60);
                var hours = math.floor(minutes / 60);
                minutes = minutes - (hours * 60);
                var days = math.floor(hours / 24);
                hours = hours - (days * 24);
                retVal = (days ? days : '0') + ':' + (hours ? (hours >= 10 ? hours : '0' + hours) : '00') + ':' + (minutes ? (minutes >= 10 ? minutes : '0' + minutes) : '00');
            }

        }
        return retVal;
    };
}
