﻿namespace Cmp.Js.Interfaces {

	/** Describes an object that knows how to serialize itself to json */
	export interface INotifyPropertyChanged {
		LoadProperty(propertyName: string, propertyValue: any): void;
	}

}