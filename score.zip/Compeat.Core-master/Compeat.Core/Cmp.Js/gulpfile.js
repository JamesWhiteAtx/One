/// <binding ProjectOpened='watch:startup' />
// gulp modules
var gulp = require('gulp');
var batch = require('gulp-batch');

// node modules
var del = require('del');
var merge = require('merge2');
var runSequence = require('run-sequence');

// custom modules
var tsCompile = require('gulp-internal-ts-compile');

var defs = {
	outputDir: '_output',
	outputFiles: ['_output/*.*', '!_output/.gitignore'],
	typeScripts: ['**/*.ts', '!node_modules', '!node_modules/**', '!**/*.d.ts'],
	moduleName: 'cmp-js',
	jsBuildOutputsDir: '../../../BuildOutputs/Compeat.Core/Scripts/'
};

var compileTs = function (isRelease) {
	var result = tsCompile(defs.typeScripts, defs.moduleName, isRelease, true, false);
	return merge([
		result.js.pipe(gulp.dest(defs.outputDir)),
		result.js.pipe(gulp.dest(defs.jsBuildOutputsDir)),
		result.dts.pipe(gulp.dest(defs.jsBuildOutputsDir))
	]);
};

gulp.task('compileTs:dev', function () {
	return compileTs(false);
});

gulp.task('compileTs:release', function () {
	return compileTs(true);
});

gulp.task('clean:output', function (cb) {
	del(defs.outputFiles, cb);
});

gulp.task('all:dev', function (cb) {
	runSequence('clean:output', 'compileTs:dev', cb);
});

gulp.task('all:release', function (cb) {
	runSequence('clean:output', 'compileTs:release', cb);
});


gulp.task('watch:startup', ['all:dev'], function () {

	gulp.watch(defs.typeScripts, batch({ timeout: 2000 }, function (events, done) {
		gulp.start('compileTs:dev', done);
	}));

});
