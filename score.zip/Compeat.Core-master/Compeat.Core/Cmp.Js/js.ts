﻿/// <reference path="./types.ts" />﻿

namespace Cmp.Js {

	/** Added to guarantee boolean logic returns a boolean. 
	Example of situation:
	e.log('<br>' + (null && false));
	e.log('<br>' + (null && true));
	*/
	export function Boolify<T>(object: T): boolean {
		if (object) {
			var asString = object.toString().trim().toLowerCase();
			return asString !== 'false';
		} else {
			return false;
		}
	}

	/**
	returns true if object passed in is undefined or null
	*/
	export function IsNullOrUndefined<T>(object: T): boolean {
		return typeof (object) === 'undefined' || object === null;
	}

	/**
	returns true if object passed in is undefined 
	*/
	export function IsUndefined<T>(object: T): boolean {
		return typeof (object) === 'undefined';
	}


	/** null and undefined will never equal another value (even null or undefined)
	otherwise evaluates to ===
	*/
	export function EqualsStrict<T>(val1: T, val2: T): boolean {
		return Boolify(typeof (val1) !== 'undefined'
			&& val1 !== null
			&& typeof (val2) !== 'undefined'
			&& val2 !== null
			&& val1 === val2);
	}


	var TYPE_MAP: Cmp.Js.Types.IStringMap<string> = {};
	var types = ["Boolean", "Number", "String", "Function", "Array", "Date", "RegExp", "Object"];
	types.forEach(function (name) {
		TYPE_MAP["[object " + name + "]"] = name.toLowerCase();
	});
	/** returns the string type of a javascript any.
	*/
	export function TypeOf(item: any): string {

		var ret: string = (item === null || item === undefined) ? String(item) : TYPE_MAP[Object.prototype.toString.call(item)] || 'object';

		if (item instanceof Error) {
			ret = 'error';
		} else if (item instanceof Date) {
			ret = 'date';
		}

		return ret;
	}

	/**
	checks if the propertyName is defined on the sourceObject, if it is then it sets that property on the destinationObject
	*/
	export function MapIfUndef(sourceObject: any, destinationObject: any, propertyName: string) {
		if (!IsNullOrUndefined(sourceObject) && !IsUndefined(sourceObject[propertyName])) {
			destinationObject[propertyName] = sourceObject[propertyName];
		}
	}

	/**
	checks if the propertyName is defined on the sourceObject, if it is then it sets that property on the destinationObject
	*/
	export function MapPropertyIfUndef(sourceObject: any, destinationObject: Cmp.Js.Interfaces.INotifyPropertyChanged, propertyName: string) {
		if (!IsNullOrUndefined(sourceObject) && !IsUndefined(sourceObject[propertyName])) {
			destinationObject.LoadProperty(propertyName, sourceObject[propertyName]);
		}
	}

	/** A wrapper for easy typescript retreival of values from an object in a non-type-safe way */
	export function GetValue<T>(sourceObject: any, propertyName: string): T {
		if (sourceObject) {
			return <T>sourceObject[propertyName];
		}
		else {
			return undefined;
		}
	}

	/** A wrapper for easy typescript set of values from an object in a non-type-safe way */
	export function SetValue(sourceObject: any, propertyName: string, value: any): void {
		sourceObject[propertyName] = value;
	}

	/** Creates a json object with only the properties matching the given filter */
	export function Jsonify(sourceObject: any, properties: string[]): Cmp.Js.Types.IStringMap<any> {
		var result: Cmp.Js.Types.IStringMap<any> = {};

		for (var i = 0; i < properties.length; i++) {
			var testProp = GetValue<any>(sourceObject, properties[i]);

			// check to see if this property is a detail table
			if (testProp && testProp.length && (testProp.length > 0) && (testProp[0].ToJson)) {
				// it is, so we need to serialize each record in the detail table using it's field list
				var newArr: any[] = [];
				for (var ii = 0; ii < testProp.length; ii++) {
					var rec = testProp[ii];
					// check to see if this detail record should not be saved
					if (rec.ChildRecordShouldNotBeSaved && rec.ChildRecordShouldNotBeSaved()) {
						// it shouldn't be saved, so if' it's new, just don't add it to the list
						if (!rec.CmpNew) {
							// it's not new, so mark it for deletion
							rec.CmpDel = true;
							newArr.push(Jsonify(rec, rec.FieldMembers));
						}
					} else {
						newArr.push(Jsonify(rec, rec.FieldMembers));
					}
				}
				result[properties[i]] = newArr;
			} else {
				result[properties[i]] = testProp;
			}
		}

		return result;
	}

	export function OnMobile(): boolean {
		if (window.innerWidth < 992) {
			return true;
		} else {
			return false;
		}
	}

	/** This procedure fixes rounding errors with JavaScript floating point values */
	export function NumDecimals(val: number): number {
		var self = this;

		if (!val) {
			return 0;
		}

		for (var i = 0; i <= 2; i++) {
			if (i > 0) {
				val = self.FixPrecision(val * 10);
			}

			if (val == Math.floor(val)) {
				return i;
			}
		}

		return 3;
	}

	/** This procedure fixes rounding errors with JavaScript floating point values */
	export function FixPrecision(val: number): number {
		return parseFloat(val.toPrecision(12));
	}

	// http://guid.us/GUID/JavaScript
	function S4() {
		return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
	}

	/** http://guid.us/GUID/JavaScript */
	export function NewGuid(): string {
		// stitch in '4' in the third group to make it a real guid
		return (S4() + S4() + "-" + S4() + "-4" + S4().substr(0, 3) + "-" + S4() + "-" + S4() + S4() + S4()).toLowerCase();
	}

	/**
	 * This is called when a calculator button is pressed.
		 It is currently used by the Item Counts page and the Receipts page in Enterprise.
	 * @param val The key that was pressed (0..9, ., <-)
	 * @param self The controller where the key was pressed
	 */
	export function PressCalcBtn(val: string, self: any): void {
		if (self.CurrentItem != null) {
			if (val == "<") {
				var numDecimals = Cmp.Js.NumDecimals(self.CurrentItem[self.CurrentFocusFld]);
				if (numDecimals > 0) {
					var power = Math.pow(10, (numDecimals - 1));
					self.CurrentItem[self.CurrentFocusFld] = Cmp.Js.FixPrecision(Math.floor(self.CurrentItem[self.CurrentFocusFld] * power) / power);
					if (numDecimals <= 1) {
						self.DecimalPressed = false;
					}
				} else {
					if (self.CurrentItem[self.CurrentFocusFld]) {
						self.CurrentItem[self.CurrentFocusFld] = Cmp.Js.FixPrecision(Math.floor(self.CurrentItem[self.CurrentFocusFld] / 10));
					} else {
						self.CurrentItem[self.CurrentFocusFld] = null;
					}
				}
			} else if (val == ".") {
				self.DecimalPressed = true;
			} else {
				var newVal = parseFloat(val);
				if (self.NewQtyField) {
					self.CurrentItem[self.CurrentFocusFld] = newVal;
					self.NewQtyField = false;
				} else if (self.DecimalPressed) {
					var numDecimals = Cmp.Js.NumDecimals(self.CurrentItem[self.CurrentFocusFld]);
					self.CurrentItem[self.CurrentFocusFld] = Cmp.Js.FixPrecision(self.CurrentItem[self.CurrentFocusFld] + (newVal / Math.pow(10, (numDecimals + 1))));
				} else {
					if (!self.CurrentItem[self.CurrentFocusFld]) {
						self.CurrentItem[self.CurrentFocusFld] = newVal;
					} else {
						self.CurrentItem[self.CurrentFocusFld] = Cmp.Js.FixPrecision(self.CurrentItem[self.CurrentFocusFld] * 10) + newVal;
					}
				}
			}
		}
	}

    /**
     * Strictly compares two javascript dates
     */
    export function DatesAreEqual(a: Date, b: Date) {
        var aIsNothing= IsNullOrUndefined(a);
        var bIsNothing = IsNullOrUndefined(b);
        return (aIsNothing && bIsNothing)
            || (!aIsNothing
                && !bIsNothing
                && a.getTime() === b.getTime());
    }

}
