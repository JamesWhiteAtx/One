﻿/// <reference path="enums.ts" />

namespace Cmp.Js.Types {

	/** Describes a function that compares to values and returns a boolean */
	export interface IEqualityFunc<T> {
		(value1: T, value2: T): boolean;
	}

	/** Describes a function that evaluates a single value to a boolean */
	export interface IEvaluatorFunc<T> {
		(value: T): boolean;
	}

	/** An interface for simple hash objects that use a string (property name) key for the provided value type. */
	export interface IStringMap<T> {
		[index: string]: T;
	}

	export class ByteLookupLI {
		Id: number;
		Description: string;
	}
    
    /** items to be displayed using the base find controller need to implment this interface. */
    export interface ICmpIdable {
        id: number | string;
        [index: string]: any;
    }

}