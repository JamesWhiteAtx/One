﻿namespace Cmp.Js.Enums {

	/** 1 = Find Only, 2 = Edit Only, 3 = Find & Edit */
	export enum PageModes {
		/** 1 = Only show the Find page */
		FindOnly = 1,
		/** 2 = Only show the Edit page */
		EditOnly = 2,
		/** 3 = Show the Find page on the left and the Edit page on the right */
		FindAndEdit = 3
	};

    /** The type of aggregation a column value can use */
    export enum CmpGridAggregateType {
        None,
        Count,
        Sum,
        Average,
        Min,
        Max
    }

    /** An enum to represent the data type in the column and help determine the template needed to display and group it */
    export enum CmpGridPropertyType {
        String,
        Number,
        DateTime,
        DurationSeconds,
        Number2Decimal,
        Boolean,
        Currency,
		/** meant for columns that have a large text value, when in edit mode it will have a textarea */
		LargeString,

    }
}
