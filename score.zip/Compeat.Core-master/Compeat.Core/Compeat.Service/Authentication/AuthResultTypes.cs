﻿namespace Compeat.Service.Authentication
{

	/// <summary>
	/// Must match the results returned by Login
	/// </summary>
	public enum AuthResultTypes
	{
		UsernameNotFound = 1,
		InvalidPassword = 2,
		AccountDisabled = 3,
		AccountLocked = 4,
		Authenticated = 5,
		AuthenticatedMustChangePassword = 6,
		InvalidCustomer = 7
	}


}
