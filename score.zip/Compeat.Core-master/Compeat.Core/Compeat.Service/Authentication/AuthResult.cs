﻿namespace Compeat.Service.Authentication
{

	/// <summary>
	/// Wrapper for the authentication result and the csrf token
	/// </summary>
	public class AuthResult
	{
		private AuthResultTypes _resultType { get; set; }
		public int Result
		{
			get
			{
				return (int)_resultType;
			}
		}
		public string Token { get; set; }

		public AuthResult(AuthResultTypes resultType, string token = "")
		{
			this._resultType = resultType;
			this.Token = token;
		}

		public static bool IsResultAuthenticated(AuthResultTypes resultType)
		{
			return (resultType == AuthResultTypes.Authenticated)
				|| (resultType == AuthResultTypes.AuthenticatedMustChangePassword);
		}
	}
}
