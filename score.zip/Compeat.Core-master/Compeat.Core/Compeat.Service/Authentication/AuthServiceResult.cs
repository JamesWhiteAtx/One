﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Service.Authentication
{

	/// <summary>
	/// A result wrapper class for an authentication attempt.
	/// </summary>
	public class AuthServiceResult
	{

		/// <summary>
		/// The found user id of the authentication attempt, will be null if no user was found.
		/// </summary>
		public int? UserId { get; set; }

		/// <summary>
		/// The security token originated by the login request.  This token may be invalided by other operations
		/// such as disabling a user account or changing it's password.
		/// </summary>
		public Guid? SecurityToken { get; set; }

		/// <summary>
		/// The result type of the authentication attempt.
		/// </summary>
		public AuthResultTypes AuthResult { get; set; }

	}
}
