﻿using Compeat.Data;
using Compeat.Data.Framework.InternalUtils;
using Compeat.Service.BaseModels;
using Compeat.Service.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Compeat.SharedLib.Utilities;
namespace Compeat.Service.BaseServices
{
	public abstract class BaseSavableService<TModel, TDtoType> : BaseService, ISavableService<TModel, TDtoType>
		where TModel : BaseSavableBo<TDtoType>
		where TDtoType : SqlBase, new()
	{
		public IIdentityManager IdentityManager { get; set; }
		public IConnectionManager ConnectionManager { get; set; }
		public IInjectionContainer InjectionContainer { get; set; }
		public ISavableRepository SavableRepository { get; set; }
		public IApplicationLevelCrudService ApplicationCrudService { get; set; }
		public BaseSavableService(IInjectionContainer injection, ISavableRepository repository)
		{
			this.InjectionContainer = injection;
			this.IdentityManager = injection.GetInstance<IIdentityManager>();
			this.ConnectionManager = injection.GetInstance<IConnectionManager>();
			this.ApplicationCrudService = injection.GetInstance<IApplicationLevelCrudService>();
			this.SavableRepository = repository;
		}

		public TModel Model { get; set; }
		public abstract bool IsValid(SqlConnection conn);

		/// <summary>
		/// Saves the bo passed in and returns the bo after save, which will include error messages
		/// </summary>
		public TModel Save(TModel _model)
		{
			Model = _model;//set at service level

			if (Model != null)
			{
				ConnectionManager.ExecuteCommand(
					(conn) =>
					{
						BeforeValidate(Model);
						ApplicationCrudService.BeforeValidate<TModel, TDtoType>(Model, conn);
						if (Model.CmpDel.GetValueOrDefault(false) || IsValid(conn))
						{
							BeforeSave(Model);
							ApplicationCrudService.BeforeSave<TModel, TDtoType>(Model, conn);
							if (UseCustomSave)
							{
								CustomSave(conn, Model);
							}
							else
							{
								var dto = Model.ToDto();
								SavableRepository.SaveObject(conn, dto);
								Model.FromDto(this.InjectionContainer, dto);
							}

							ApplicationCrudService.AfterSave<TModel, TDtoType>(Model, conn);
							AfterSave(Model);
						}
					}, true);
			}
			return Model;
		}

		/// <summary>
		/// override to return true if implementing the CustomSave function
		/// </summary>
		protected virtual bool UseCustomSave { get { return false; } }

		/// <summary>
		/// override to implement own save function, change as needed to return end result
		/// </summary>
		protected virtual void CustomSave(SqlConnection conn, TModel modelToSave) { }

		protected virtual void BeforeValidate(TModel model) { }
		protected virtual void BeforeSave(TModel model) { }
		protected virtual void AfterSave(TModel model) { }

	}
}
