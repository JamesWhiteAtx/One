﻿using Compeat.Service.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Compeat.SharedLib.Utilities;

namespace Compeat.Service.BaseServices
{
	public abstract class BaseSessionService<T> : ISessionService<T>
		 where T : struct, IConvertible // attempts to restrict to an enum type
	{
		// the lazy cache of user rights
		private Dictionary<T, bool> _userRights = new Dictionary<T, bool>();

		/// <summary>
		/// Override to provide the implementation for determining if a user has a specific right
		/// </summary>
		/// <returns></returns>
		protected abstract bool GetUserRight(T right);

		/// <summary>
		/// Resets the user rights container and loads it with the provided rights
		/// </summary>
		public void InitializeRights(IEnumerable<T> grantedRights, IEnumerable<T> allRights)
		{
			_userRights.Clear();

			var grantedRightsHash = new HashSet<T>(grantedRights);
			foreach (var right in allRights)
			{
				_userRights.Add(right, grantedRightsHash.Contains(right));
			}
		}

		/// <summary>
		/// Adds a new user right to the session
		/// </summary>
		public void GrantRight(T right)
		{
			SetRight(right, true);
        }

		/// <summary>
		/// Adds a removes user right to the session
		/// </summary>
		public void RevokeRight(T right)
		{
			SetRight(right, false);
		}

		// Writes the value to the rights cache
		private void SetRight(T right, bool hasRight)
		{
			if (!_userRights.ContainsKey(right))
			{
				_userRights.Add(right, hasRight);
			}
			else
			{
				_userRights[right] = hasRight;
			}
		}

		/// <summary>
		/// Lazy: Returns true if the user has been assigned the specified right.  If the right has
		/// not been loaded, it will be retrieved with GetUserRight
		/// </summary>
		public bool HasRight(T right)
		{
			if (!_userRights.ContainsKey(right))
			{
				_userRights.Add(right, GetUserRight(right));
			}

			return _userRights[right];
		}

		/// <summary>
		/// Rights true if the user has all of the specified rights
		/// </summary>
		public bool HasAllRights(IEnumerable<T> rights)
		{
			var allRightsFound = true;

			foreach (var right in rights)
			{
				if (!HasRight(right))
				{
					allRightsFound = false;
					break;
				}
			}

			return allRightsFound;
		}

		/// <summary>
		/// Rights true if the user has one of the specified rights
		/// </summary>
		public bool HasSomeRights(IEnumerable<T> rights)
		{
			var rightFound = false;

			foreach (var right in rights)
			{
				if (HasRight(right))
				{
					rightFound = true;
					break;
				}
			}

			return rightFound;
		}

		/// <summary>
		/// Returns the list of all granted user rights
		/// </summary>
		public IEnumerable<T> GetGrantedRights()
		{
			return _userRights
				.Where(x => x.Value)
				.Select(x => x.Key);
		}

		/// <summary>
		/// A helper class for serializing client related session information
		/// </summary>
		public class ClientUserSession
		{
			/// <summary>
			/// The user id of the currently logged in user
			/// </summary>
			public int? UserId { get; set; }
			
			/// <summary>
			/// The user name associated with the authenticated user
			/// </summary>
			public string UserDisplayName { get; set; }

			/// <summary>
			/// The localized language preference
			/// </summary>
			public string Language { get; set; }

			/// <summary>
			/// Application specific rights associated with the authenticated user
			/// </summary>
			public string[] UserRights { get; set; }

			/// <summary>
			/// The user's current menu
			/// </summary>
			public MenuNode[] UserMenu { get; set; }

			/// <summary>
			/// A list of remote appliations to which the user has been granted access
			/// </summary>
			public ExternalApp[] ExternalApps { get; set; }

            /// <summary>
            /// A list of user account links like Profile etc
            /// </summary>
            public UserLink[] UserLinks { get; set; }

            /// <summary>
            /// Messages display option
            /// </summary>
            public MessageLink MessagesLink { get; set; }

            /// <summary>
            /// Describes the different type of menu nodes
            /// </summary>
            public enum MenuNodeTypes : byte
			{
				/// <summary>
				/// 1 - Item is a root menu or submenu depending on if parentid is self-referencing id
				/// </summary>
				MenuNode = 1,
				/// <summary>
				/// 2 - Item is a base building block feature
				/// </summary>
				Feature = 2,
				/// <summary>
				/// 3 - Item is a user defined workflow unit
				/// </summary>
				WorkflowUnit = 3,
				/// <summary>
				/// 4 - Item is a user defined workflow
				/// </summary>
				Workflow = 4,
				/// <summary>
				/// 5 - Item is a custom report
				/// </summary>
				CustomReport = 5
			}

			/// <summary>
			/// A serialization class for the current user's menu tree
			/// </summary>
			public class MenuNode
			{
				public MenuNode()
				{
					Children = new List<MenuNode>();
				}

				public MenuNodeTypes NodeType { get; set; }

				public string Description { get; set; }

				public int? ActionId { get; set; }

				public List<MenuNode> Children { get; set; }

			}

			/// <summary>
			/// A helper class for serializing external URLs that should be available to the user.
			/// </summary>
			public class ExternalApp
			{
				/// <summary>
				/// The user-friendly display name of the link
				/// </summary>
				public string DisplayName { get; set; }
				/// <summary>
				/// The url of the resource.  This may be absolute or relative to the current application.
				/// </summary>
				public string Url { get; set; }

			}

            /// <summary>
            /// A helper class for serializing User Account links that should be available to the user.
            /// </summary>
            public class UserLink
            {
                /// <summary>
                /// The user-friendly display name of the link
                /// </summary>
                public string DisplayName { get; set; }
                /// <summary>
                /// The Action type of the Internal Menu Click function
                /// </summary>
                public int ActionType { get; set; }
                /// <summary>
                /// The Action Id of the Internal Menu Click function
                /// </summary>
                public int ActionId { get; set; }
            }

            /// <summary>
            /// A helper class for serializing Message link
            /// </summary>
            public class MessageLink
            {
                /// <summary>
                /// Display the messages or not
                /// </summary>
                public string DisplayName { get; set; }
                /// <summary>
                /// The Action type of the Internal Menu Click function
                /// </summary>
                public int ActionType { get; set; }
                /// <summary>
                /// The Action Id of the Internal Menu Click function
                /// </summary>
                public int ActionId { get; set; }
                /// <summary>
                /// Unread messages count
                /// </summary>
                public string Count { get; set; }
            }
        }
    }
}
