﻿using Compeat.Service.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Service.BaseServices
{
	public abstract class BaseResourceService : BaseService
	{
		public abstract IEnumerable<ResourcesCollection> GetResources(string languageCode);

		/// <summary>
		/// Gets the resources for the given localiation for the resource manager
		/// </summary>
		/// <typeparam name="T">The resource container that should be inspected for resource strings</typeparam>
		/// <param name="culture">The culture that should be used to determine resource values</param>
		protected static IEnumerable<ResourceValue> GetResourceStrings<T>(CultureInfo culture)
		{
			Type resourceType = typeof(T);
			var resourceManager = new ResourceManager(resourceType);
			var properties = resourceType.GetProperties(BindingFlags.Public | BindingFlags.Static);
			return properties
					.Where(x => x.PropertyType == typeof(string))
					.Select(x =>
							new ResourceValue()
							{
								Name = x.Name,
								Value = resourceManager.GetString(x.Name, culture)
							});
		}
	}
}
