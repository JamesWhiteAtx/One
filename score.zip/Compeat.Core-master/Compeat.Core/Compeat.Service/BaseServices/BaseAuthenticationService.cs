﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Compeat.Service.Authentication;

namespace Compeat.Service.BaseServices
{
	public abstract class BaseAuthenticationService : BaseService
	{
		/// <summary>
		/// Validates the provided credetials against the data store.
		/// </summary>
		public abstract AuthServiceResult AuthenticateUser(string userName, string password, string customer, bool rememberMe);

		/// <summary>
		/// Tests the current security token against that in the data store.  Returns true if they match, false if
		/// there have been changes that require the user to re-authenticate.
		/// </summary>
		public abstract bool ValidateSecurityToken(int? userid, Guid securityToken, string customer);

	}
}
