﻿using Compeat.Service.BaseModels;
using Compeat.Service.Interfaces;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Service.BaseServices
{
	public abstract class BaseSavableServiceValidator<TService, TModelBo, TDtoType, TBoValidator> : AbstractValidator<TService>
		where TService : BaseService, ISavableService<TModelBo, TDtoType>
		where TModelBo : BaseSavableBo<TDtoType>, ISavableBo
		where TDtoType : new()
		where TBoValidator : BaseSavableBoValidator<TDtoType, TModelBo>
	{
		public IInjectionContainer InjectionContainer { get; set; }

		public BaseSavableServiceValidator(IInjectionContainer injection)
		{
			this.InjectionContainer = injection;
		}
		/// <summary>
		/// setup the validator for the service and hook in the validator for the BO as well
		/// </summary>
		public void PrepValidator(SqlConnection conn)
		{
			var boValidator = InjectionContainer.GetInstance<TBoValidator>();
			boValidator.PrepValidator(conn); //setup model's generated rules
			boValidator.SetupRules(conn); //setup model's rules
			RuleFor(service => service.Model).SetValidator(boValidator);
			SetupServiceRules(conn); //setup service rules
		}
		/// <summary>
		/// setup the service rules for validation
		/// </summary>
		public abstract void SetupServiceRules(SqlConnection conn);

	}
}
