﻿using Compeat.Data;
using Compeat.Data.Framework.InternalUtils;
using Compeat.Service.BaseModels;
using Compeat.Service.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Compeat.SharedLib.Utilities;
namespace Compeat.Service.BaseServices
{
	public abstract class BaseCrudService<TModel, TModelKeyType, TDtoType> : BaseSavableService<TModel, TDtoType>, ICrudService<TModel, TModelKeyType, TDtoType>
		where TModel : BaseCrudBo<TDtoType, TModelKeyType>
		where TDtoType : SqlBase, new()
	{
		public BaseCrudService(IInjectionContainer injection, ISavableRepository repository)
			: base(injection, repository)
		{ }
	
		/// <summary>
		/// should return the dto so it can further be turned into a bo later
		/// </summary>
		public abstract TDtoType LoadFromId(SqlConnection conn, TModelKeyType id, string[] collectionsToLoad, bool loadAllCollections, int loadAllCollectionsDepth);

		/// <summary>
		/// returns a bo for the id passed in
		/// </summary>
		public TModel GetById(TModelKeyType id, string[] collectionsToLoad, bool loadAllCollections, int loadAllCollectionsDepth)
		{
			TModel retVal = null;

			ConnectionManager.ExecuteCommand(
					command: (conn) =>
					{
						retVal = InjectionContainer.GetInstance<TModel>();
						retVal.FromDto(InjectionContainer, LoadFromId(conn, id, collectionsToLoad, loadAllCollections, loadAllCollectionsDepth));
						BeforeGetByIdReturn(retVal, conn);
					});

			return retVal;
		}

		/// <summary>
		/// deletes the id passed in
		/// </summary>
		public TModel Delete(TModelKeyType id)
		{
			TModel _model = InjectionContainer.GetInstance<TModel>();
			_model.SetKey(id);
			return DeleteModel(_model);
		}

		private TModel DeleteModel(TModel _model)
		{
			// note: any detail records should normally be deleted via cascading delete triggers
			Model = _model;//set at service level
			ConnectionManager.ExecuteCommand(
				(conn) =>
				{
					var dto = Model.ToDto();
					BeforeDelete(Model);
					dto.Delete();
					SavableRepository.SaveObject(conn, dto);
					AfterDelete(Model);
					Model.FromDto(InjectionContainer, dto);
				}, true);
			return Model;
		}

		protected virtual void BeforeGetByIdReturn(TModel model, SqlConnection conn) { }

		/// <summary>
		/// This is called before the record is flagged as deleted.
		/// </summary>
		/// <param name="model">The record to delete</param>
		protected virtual void BeforeDelete(TModel model) { }

		/// <summary>
		/// This is called after the record has been deleted.
		/// </summary>
		/// <param name="model">The record to delete</param>
		protected virtual void AfterDelete(TModel model) { }

	}
}
