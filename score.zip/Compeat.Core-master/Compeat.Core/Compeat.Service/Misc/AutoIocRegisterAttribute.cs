﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Service
{
	[System.AttributeUsage(System.AttributeTargets.Class, AllowMultiple = false)]
	/// <summary>
	/// Mark an class to be registered with the injector during startup
	/// </summary>
	public class AutoIocRegisterAttribute : System.Attribute
	{
	}
}
