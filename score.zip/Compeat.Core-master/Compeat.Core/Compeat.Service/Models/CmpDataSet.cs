﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Service.Models
{
	/// <summary>
	/// Something to wrap a collection of data and contain the total amount of data available.
	/// </summary>
	public class CmpDataSet<TDataType>
	{
		/// <summary>
		/// total pages available from source data set(all pages)
		/// </summary>
		public int RowCount
		{
			get; set;
		}

		public TDataType Data
		{
			get;
			set;
		}
	}
}
