﻿using Compeat.SharedLib.Notifications;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Service.Models
{
	/// <summary>
	/// A stock implementation of Compeat.SharedLib.Notifications.NotificationsList
	/// </summary>
	public class NotificationsList : List<Notification>, INotificationList
	{
		public new IEnumerator<INotification> GetEnumerator()
		{
			return base.GetEnumerator();
		}
	}

	/// <summary>
	/// A stock implementation of Compeat.SharedLib.Notifications.Notification
	/// </summary>
	public class Notification : INotification
	{
		public Notification()
		{ }

		public Notification(int sendingStoreNum, NotificationEnums.NotificationTypes notificationType, int recipientID,
			string msgSubject, string msgBody, bool msgBodyIsHtml, bool forceSend)
		{
			SendingStoreNum = sendingStoreNum;
			NotificationType = notificationType;
			RecipientID = recipientID;
			MsgSubject = msgSubject;
			MsgBody = msgBody;
			MsgBodyIsHtml = msgBodyIsHtml;
			ForceSend = forceSend;
		}

		public bool ForceSend { get; set; }

		public string MsgBody { get; set; }

		public bool MsgBodyIsHtml { get; set; }

		public string MsgSubject { get; set; }

		public NotificationEnums.NotificationTypes NotificationType { get; set; }

		public int RecipientID { get; set; }

		public int SendingStoreNum { get; set; }

	}
}
