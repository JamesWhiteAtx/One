﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Service.Models
{
	/// <summary>
	/// A wrapper for the key value pairs stored in the resource definition file.
	/// </summary>
	public class ResourceValue
	{
		public string Name { get; set; }
		public string Value { get; set; }
	}

	/// <summary>
	/// A wrapper for sets of resource values with a given set name
	/// </summary>
	public class ResourcesCollection
	{
		public string Name { get; set; }
		public ResourceValue[] Resources { get; set; }

	}
}
