﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Service.Models
{

	public class CachedReportModel
	{

		public bool CachedReportFound
		{
			get { return Id != Guid.Empty; }
		}
		public Guid Id { get; set; }
		public byte[] CacheContents { get; set; }

		public CachedReportModel()
		{
			Id = Guid.Empty;
		}
	}
}
