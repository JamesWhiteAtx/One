﻿using Compeat.Data;
using Compeat.Service.Interfaces;
using Elmah;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Service
{
	public class ErrorLogger
	{
		private IConnectionStringProvider _connectionStringProvider;
		private IApplicationInfo _applicationInfo;
		private IIdentityManager _identityManager;

		public ErrorLogger(IIdentityManager identityManager, IApplicationInfo applicationInfo, 
			IConnectionStringProvider connectionStringProvider)
		{
			_applicationInfo = applicationInfo;
			_connectionStringProvider = connectionStringProvider;
			_identityManager = identityManager;
		}

		/// <summary>
		/// Logs an exception to the current customer's elmah_log.
		/// </summary>
		public virtual void LogError(Exception ex)
		{
			try
			{
				new CmpSqlErrorLog(_applicationInfo, _identityManager, _connectionStringProvider).Log(new Error(ex));
			}
			catch
			{}
		}

		/// <summary>
		/// Logs a message to the current customer's elmah_log.
		/// </summary>
		public virtual void LogError(string error)
		{
			LogError(new Exception(error));
		}
	}
}
