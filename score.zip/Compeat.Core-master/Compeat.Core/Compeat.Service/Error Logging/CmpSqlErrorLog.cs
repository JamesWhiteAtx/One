﻿using Elmah;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.Composition;
using Compeat.Service.Interfaces;
using Compeat.SharedLib.Utilities;
using Compeat.Data;

namespace Compeat.Service
{
	public class CmpSqlErrorLog : SqlErrorLog
	{
		private IApplicationInfo _applicationInfo { get; set; }
		private IIdentityManager _identityManager { get; set; }
		private IConnectionStringProvider _connectionStringProvider { get; set; }

		public override string Name
		{
			get { return "CmpSqlErrorLog"; }
		}

		public override string ConnectionString
		{
			get
			{
				return _connectionStringProvider.GetConnectionString(_applicationInfo.ErrorLoggingConnectionStringKey);
			}
		}

		public override string Log(Error error)
		{
			if (_identityManager != null
				&& !_identityManager.Customer.IsEmpty())
			{
				error.Source = _identityManager.Customer;
			}

			return base.Log(error);
		}

		public CmpSqlErrorLog(IApplicationInfo applicationInfo, IIdentityManager identityManager, IConnectionStringProvider connectionStringProvider)
			// no empty values allowed
			: base("BLANK")
		{
			_identityManager = identityManager;
			_applicationInfo = applicationInfo;
			_connectionStringProvider = connectionStringProvider;

			ApplicationName = applicationInfo.ErrorLoggingApplicationName;
		}
	}
}
