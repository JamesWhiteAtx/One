﻿using Compeat.Service.Interfaces;
using FluentValidation.Results;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Service.BaseModels
{
	public abstract class BaseSavableBo<TDtoType> : IReflectBo, ISavableBo
		where TDtoType: new()
	{

		public bool? CmpDel { get; set; }
		public bool? CmpNew { get; set; }
		public ValidationResult ValidationResults { get; set; }

		/// <summary>
		/// the internal stack for type conversion from DTO to BO
		/// </summary>
		public void FromDto(IInjectionContainer injection, TDtoType dto)
		{
			if (dto != null)
			{
				BeforeFromDto(dto);
				BoFromDto(injection, dto);
				AfterFromDto(dto);
			}
		}

		/// <summary>
		/// the internal stack for type conversion from BO to DTO 
		/// </summary>
		public TDtoType ToDto()
		{
			BeforeToDto();
			var dto = new TDtoType();
			BoToDto(dto);
			AfterToDto(dto);
			return dto;
		}

		/// <summary>
		/// will do the actual conversion from a BO to a DTO
		/// </summary>
		protected abstract void BoFromDto(IInjectionContainer injection, TDtoType dto);
		/// <summary>
		/// will do the actual conversion from a DTO to a BO
		/// </summary>
		protected abstract void BoToDto(TDtoType newDto);

		protected virtual void BeforeFromDto(TDtoType dto) { }
		protected virtual void AfterFromDto(TDtoType dto) { }
		protected virtual void BeforeToDto() { }
		protected virtual void AfterToDto(TDtoType dto) { }

		/// <summary>
		/// Test whether or not the object contains the specified property
		/// </summary>
		/// <param name="propertyName">The name of the property to search for</param>
		/// <returns></returns>
		public bool HasProperty(string propertyName)
		{
			Type t = GetType();

			PropertyInfo propInfo = t.GetProperty(propertyName, BindingFlags.Public | BindingFlags.Instance);

			return propInfo != null;
		}

		/// <summary>
		/// This will set the value of the specified data field.
		/// This method is declared at this level because it makes use of the 
		/// "this" keyword to get the correct type.
		/// </summary>
		/// <param name="fldName">The name of the data field</param>
		/// <param name="value">The value to set the data field to</param>
		public void SetFieldValue(string fldName, object value)
		{
			Type t = GetType();

			PropertyInfo propInfo = t.GetProperty(fldName, BindingFlags.Public | BindingFlags.Instance);

			try
			{
				propInfo.SetValue(this, value, null);
			}
			catch (Exception ex)
			{
				throw new Exception("The field " + fldName + " does not exist in the " +
					GetType().ToString() + " class.\n\n" + ex.Message);
			}
		}

		/// <summary>
		/// Protected list of children lists associated with this bo. 
		/// This will be overriden by the scripts generating the bo code. 
		/// The child collections defined in AUTOGEN_Table.json will be returned by the overriden version.
		/// </summary>
		protected virtual IEnumerable<IEnumerable<IReflectBo>> StockChildCollections()
		{
			yield break;
		}

		/// <summary>
		/// Protected list of children lists associated with this bo.
		/// This can be overriden in the editable bo definition file.
		/// This is intended for custom child collections not defined in AUTOGEN_Table.json.
		/// </summary>
		protected virtual IEnumerable<IEnumerable<IReflectBo>> ChildCollections()
		{
			yield break;
		}

		/// <summary>
		/// Publicly exposed list of children lists associated with this bo.
		/// This will return the child collections defined in AUTOGEN_Table.json returned by StockChildCollections,
		/// as well custom child collections not defined in AUTOGEN_Table.json by ChildCollections.
		/// </summary>
		public IEnumerable<IEnumerable<IReflectBo>> AllChildCollections()
		{
			foreach (var child in StockChildCollections())
			{
				yield return child;
			}
			foreach (var child in ChildCollections())
			{
				yield return child;
			}
		}

	}
}
