﻿using Compeat.Service.Interfaces;
using FluentValidation.Results;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Service.BaseModels
{
	public abstract class BaseCrudBo<TDtoType, TModelKeyType> : BaseSavableBo<TDtoType>, ICrudBo
		where TDtoType: new()
	{
		/// <summary>
		/// sets the pk value on the BO, its used when deleting a crud item by id only
		/// </summary>
		public abstract void SetKey(TModelKeyType id);
	}
}
