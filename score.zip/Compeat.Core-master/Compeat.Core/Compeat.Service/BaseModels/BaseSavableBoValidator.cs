﻿using Compeat.Service.Interfaces;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Service.BaseModels
{
	public abstract class BaseSavableBoValidator<TDtoType, TModelBo> : AbstractValidator<TModelBo>
		where TModelBo : BaseSavableBo<TDtoType>, ISavableBo
		where TDtoType : new()
	{
		public IInjectionContainer InjectionContainer { get; set; }

		public BaseSavableBoValidator(IInjectionContainer injection)
		{
			this.InjectionContainer = injection;
		}

		/// <summary>
		/// setup generated rules
		/// </summary>
		public virtual void PrepValidator(SqlConnection conn) { }

		/// <summary>
		/// setup the validation rules for the BO
		/// </summary>
		public abstract void SetupRules(SqlConnection conn);
	}
}
