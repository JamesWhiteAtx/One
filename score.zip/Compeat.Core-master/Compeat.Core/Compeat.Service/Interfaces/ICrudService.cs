﻿using Compeat.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Service.Interfaces
{
	/// <summary>
	/// Describes the signature of a service built for a typical CRUD style data entry screen.
	/// </summary>
	/// <typeparam name="TModel">The type of the model being operated upon</typeparam>
	/// <typeparam name="TModelKeyType">The type of the key for the primary model's underlying data.</typeparam>
	public interface ICrudService<TModel, TModelKeyType, TDtoType> : ISavableService<TModel, TDtoType>
		where TModel : ICrudBo
	{
		TModel GetById(TModelKeyType id, string[] collectionsToLoad, bool loadAllCollections, int loadAllCollectionsDepth);
		TModel Delete(TModelKeyType id);
	}
}
