﻿using Compeat.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Service.Interfaces
{
	public interface ISavableService<TModel, TDtoType>
		where TModel : ISavableBo
	{

		IIdentityManager IdentityManager { get; set; }
		IConnectionManager ConnectionManager { get; set; }
		IInjectionContainer InjectionContainer { get; set; }
		TModel Model { get; set; }
		TModel Save(TModel model);

	}
}
