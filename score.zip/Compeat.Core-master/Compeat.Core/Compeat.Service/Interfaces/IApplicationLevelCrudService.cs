﻿using Compeat.Data.Framework.InternalUtils;
using Compeat.Service.BaseModels;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Service.Interfaces
{
	public interface IApplicationLevelCrudService
	{
		/// <summary>
		/// will run before validate on all bos
		/// </summary>
		void BeforeValidate<TModel, TDtoType>(TModel model, SqlConnection conn)
			where TModel : BaseSavableBo<TDtoType>
			where TDtoType : SqlBase, new();
		/// <summary>
		/// will run before save on all bos
		/// </summary>
		void BeforeSave<TModel, TDtoType>(TModel model, SqlConnection conn)
			where TModel : BaseSavableBo<TDtoType>
			where TDtoType : SqlBase, new();
		/// <summary>
		/// will run after save on all bos
		/// </summary>
		void AfterSave<TModel, TDtoType>(TModel model, SqlConnection conn)
			where TModel : BaseSavableBo<TDtoType>
			where TDtoType : SqlBase, new();
	}
}
