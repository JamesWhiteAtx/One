﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Service.Interfaces
{
	public interface IApplicationInfo
	{
		/// <summary>
		/// This value should match the application name specified in the error log's web.config file setup
		/// if you wish to manually logged errors in the elmah error viewer route (/elmah)
		/// </summary>
		string ErrorLoggingApplicationName { get; }

		/// <summary>
		/// The connection string key that should be used for logging errors to SQL server
		/// </summary>
		string ErrorLoggingConnectionStringKey { get; }
	}
}
