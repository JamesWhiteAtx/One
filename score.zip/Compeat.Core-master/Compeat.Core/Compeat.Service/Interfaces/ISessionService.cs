﻿using System;
using System.Collections.Generic;

namespace Compeat.Service.Interfaces
{
	public interface ISessionService<T>
	{
		void InitializeRights(IEnumerable<T> grantedRights, IEnumerable<T> allRights);

		void GrantRight(T right);
		
		void RevokeRight(T right);
		
		bool HasRight(T right);

		bool HasAllRights(IEnumerable<T> rights);
		
		bool HasSomeRights(IEnumerable<T> rights);

		IEnumerable<T> GetGrantedRights();
    }
}
