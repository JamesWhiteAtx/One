﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Service.Interfaces
{	
	/// <summary>
	/// This interface describes the refelction methods and prperties of a business object.
	/// It allows read and writre access to a business object without knowledge of the descendant bo type.
	/// </summary>
	public interface IReflectBo
	{
		/// <summary>
		/// Test whether or not the object contains the specified property
		/// </summary>
		/// <param name="propertyName">The name of the property to search for</param>
		/// <returns></returns>
		bool HasProperty(string propertyName);

		/// <summary>
		/// This will set the value of the specified data field.
		/// This method is declared at this level because it makes use of the 
		/// "this" keyword to get the correct type.
		/// </summary>
		/// <param name="fldName">The name of the data field</param>
		/// <param name="value">The value to set the data field to</param>
		void SetFieldValue(string fldName, object value);

		/// <summary>
		/// Publicly exposed list of children lists associated with this bo.
		/// This will return all lists of child bos implementing IReflectBo.
		/// </summary>
		IEnumerable<IEnumerable<IReflectBo>> AllChildCollections();
    }
}
