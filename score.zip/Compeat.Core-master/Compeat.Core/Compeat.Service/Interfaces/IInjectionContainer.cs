﻿using SimpleInjector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Service.Interfaces
{
	public interface IInjectionContainer
	{
		Container Container { get; }
		TService GetInstance<TService>() where TService : class;
		object GetInstance(Type serviceType);
	}
}
