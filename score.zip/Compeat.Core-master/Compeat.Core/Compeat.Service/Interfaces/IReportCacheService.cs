﻿using Compeat.Service.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Service.Interfaces
{
	public interface IReportCacheService
	{
		/// <summary>
		/// Gets a rendered cached report for the given report identifier
		/// </summary>
		CachedReportModel GetCachedReport(Guid id);

		/// <summary>
		/// Saves the cached report to the cache source
		/// </summary>
		void CacheReport(CachedReportModel model);
	}
}
