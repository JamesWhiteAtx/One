﻿using System;

namespace Compeat.Service.Interfaces
{
	public interface IIdentityManager
	{
		string CsrfToken { get; }
		bool IsAuthenticated { get; }
		Guid SecurityToken { get; }
		void SignOut();

		int? UserId { get; }
		string Customer { get; }

		/// <summary>
		/// Indicates that the identity manager is in a ready state
		/// </summary>
		bool IsInitialized { get;  }
	}
}
