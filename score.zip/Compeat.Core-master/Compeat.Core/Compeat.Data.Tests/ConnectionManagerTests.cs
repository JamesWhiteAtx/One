﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FakeItEasy;
using System.Data.SqlClient;
using System.Diagnostics;

namespace Compeat.Data.Tests
{
	[TestClass]
	public class ConnectionManagerTests
	{
		private const string _testConnectionString = "Data Source=(local);Initial Catalog=CompeatDev;uid=sa;pwd=c0mpeat;MultipleActiveResultSets=True";

		private const string _dropTableCmd = "IF EXISTS (SELECT TOP 1 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE' AND TABLE_NAME = 'TestTableA') " +
			"DROP TABLE TestTableA; ";
		private const string _createTableCmd = "CREATE TABLE TestTableA (Id INT, Description VARCHAR(50)); ";
		private const string _insertRow1 = "INSERT INTO TestTableA (Id, Description) VALUES (1, 'Row #1'); ";
		private const string _insertRow2 = "INSERT INTO TestTableA (Id, Description) VALUES (2, 'Row #2'); ";
		private const string _insertRow3 = "INSERT INTO TestTableA (Id, Description) VALUES (3, 'Row #3'); ";

		[ClassInitialize]
		public static void Initialize(TestContext context)
		{
			using (var conn = new SqlConnection(_testConnectionString))
			{
				conn.Open();
				using (var cmd = new SqlCommand(_dropTableCmd + _createTableCmd + _insertRow1, conn))
				{
					cmd.ExecuteNonQuery();
				}
			}
		}

		[ClassCleanup]
		public static void CleanUp()
		{
			using (var conn = new SqlConnection(_testConnectionString))
			{
				conn.Open();
				using (var cmd = new SqlCommand(_dropTableCmd, conn))
				{
					cmd.ExecuteNonQuery();
				}
			}
		}

		[TestMethod]
		public void ConnectionManager_Simple()
		{
			var connStringProvider = A.Fake<IConnectionStringProvider>();
			A.CallTo(() => connStringProvider.GetConnectionString("testCustomer")).Returns(_testConnectionString);

			var cm = new ConnectionManager(connStringProvider);
			cm.ExecuteCommand((conn) =>
			{
				var cnt = GetRowCount(conn);
				Assert.AreEqual(1, cnt, "Bad row count");
			}, customer: "testCustomer");

		}

		[TestMethod]
		public void ConnectionManager_Nested()
		{
			var connStringProvider = A.Fake<IConnectionStringProvider>();
			A.CallTo(() => connStringProvider.GetConnectionString("testCustomer")).Returns(_testConnectionString);

			var cm = new ConnectionManager(connStringProvider);
			cm.ExecuteCommand((conn) =>
			{
				var cnt = GetRowCount(conn);
				Assert.AreEqual(1, cnt, "Bad row count");

				cm.ExecuteCommand((conn2) =>
				{
					Assert.AreEqual(conn, conn2, "Connection not re-used in nesting");
					var cnt2 = GetRowCount(conn);
					Assert.AreEqual(1, cnt2, "Bad row count");
				}, customer: "testCustomer");

				cm.ExecuteCommand((conn3) =>
				{
					Assert.AreEqual(conn, conn3, "Connection not re-used in nesting");
					var cnt2 = GetRowCount(conn);
					Assert.AreEqual(1, cnt2, "Bad row count");
				}, customer: "testCustomer");

			}, customer: "testCustomer");
		}

		/// <summary>
		/// This is an outer transaction that has two inner commands that are not marked as in a transaction.
		/// </summary>
		[TestMethod]
		public void ConnectionManager_TransactionNested1()
		{
			var connStringProvider = A.Fake<IConnectionStringProvider>();
			A.CallTo(() => connStringProvider.GetConnectionString("testCustomer")).Returns(_testConnectionString);

			var cm = new ConnectionManager(connStringProvider);
			cm.ExecuteCommand((conn) =>
			{
				var cnt = GetRowCount(conn);
				Assert.AreEqual(1, cnt, "Bad row count");

				cm.ExecuteCommand((conn2) =>
				{
					Assert.AreEqual(conn, conn2, "Connection not re-used in nesting");
					var cnt2 = GetRowCount(conn);
					Assert.AreEqual(1, cnt2, "Bad row count");
				}, customer: "testCustomer");

				cm.ExecuteCommand((conn3) =>
				{
					Assert.AreEqual(conn, conn3, "Connection not re-used in nesting");
					var cnt3 = GetRowCount(conn);
					Assert.AreEqual(1, cnt3, "Bad row count");
				}, customer: "testCustomer");

			}, true, customer: "testCustomer");
		}

		/// <summary>
		/// This is an outer transaction that has two inner commands that are marked as in a transaction.
		/// </summary>
		[TestMethod]
		public void ConnectionManager_TransactionNested2()
		{
			var connStringProvider = A.Fake<IConnectionStringProvider>();
			A.CallTo(() => connStringProvider.GetConnectionString("testCustomer")).Returns(_testConnectionString);

			var cm = new ConnectionManager(connStringProvider);
			cm.ExecuteCommand((conn) =>
			{
				var cnt = GetRowCount(conn);
				Assert.AreEqual(1, cnt, "Bad row count");

				cm.ExecuteCommand((conn2) =>
				{
					Assert.AreEqual(conn, conn2, "Connection not re-used in nesting");
					var cnt2 = GetRowCount(conn);
					Assert.AreEqual(1, cnt2, "Bad row count");
				}, true, customer: "testCustomer");

				cm.ExecuteCommand((conn3) =>
				{
					Assert.AreEqual(conn, conn3, "Connection not re-used in nesting");
					var cnt3 = GetRowCount(conn);
					Assert.AreEqual(1, cnt3, "Bad row count");
				}, true, customer: "testCustomer");

			}, true, customer: "testCustomer");
		}

		/// <summary>
		/// Outer transaction, inner transactions, failure
		/// </summary>
		[TestMethod]
		public void ConnectionManager_TransactionRollback1()
		{
			var connStringProvider = A.Fake<IConnectionStringProvider>();
			A.CallTo(() => connStringProvider.GetConnectionString("testCustomer")).Returns(_testConnectionString);

			var cm = new ConnectionManager(connStringProvider);
			try
			{
				cm.ExecuteCommand((conn) =>
				{
					cm.ExecuteCommand((conn2) =>
					{
						using (var cmd = new SqlCommand(_insertRow2, conn2))
						{
							cmd.ExecuteNonQuery();
						}
						var cntA = GetRowCount(conn);
						Assert.AreEqual(2, cntA, "Bad row count");
					}, runInTransaction: true, customer: "testCustomer");

					cm.ExecuteCommand((conn2) =>
					{
						Assert.AreEqual(conn, conn2, "Connection not re-used in nesting");
						using (var cmd = new SqlCommand(_insertRow3, conn2))
						{
							cmd.ExecuteNonQuery();
						}
						var cntB = GetRowCount(conn2);
						Assert.AreEqual(3, cntB, "Bad row count");

						throw new Exception("rollback");
					}, runInTransaction: true, customer: "testCustomer");
				}, runInTransaction: true, customer: "testCustomer");
			}
			catch (Exception) { }

			cm.ExecuteCommand((conn) =>
			{
				var cnt = GetRowCount(conn);
				Assert.AreEqual(1, cnt, "Bad row count");
			}, customer: "testCustomer");
		}

		/// <summary>
		/// Outer transaction, inner (non-specified) transactions, failure
		/// </summary>
		[TestMethod]
		public void ConnectionManager_TransactionRollback2()
		{
			var connStringProvider = A.Fake<IConnectionStringProvider>();
			A.CallTo(() => connStringProvider.GetConnectionString("testCustomer")).Returns(_testConnectionString);

			var cm = new ConnectionManager(connStringProvider);
			try
			{
				cm.ExecuteCommand((conn) =>
				{
					cm.ExecuteCommand((conn2) =>
					{
						using (var cmd = new SqlCommand(_insertRow2, conn2))
						{
							cmd.ExecuteNonQuery();
						}
						var cntA = GetRowCount(conn);
						Assert.AreEqual(2, cntA, "Bad row count");
					}, runInTransaction: false, customer: "testCustomer");

					cm.ExecuteCommand((conn2) =>
					{
						Assert.AreEqual(conn, conn2, "Connection not re-used in nesting");
						using (var cmd = new SqlCommand(_insertRow3, conn2))
						{
							cmd.ExecuteNonQuery();
						}
						var cntB = GetRowCount(conn2);
						Assert.AreEqual(3, cntB, "Bad row count");

						throw new Exception("rollback");
					}, runInTransaction: false, customer: "testCustomer");
				}, runInTransaction: true, customer: "testCustomer");
			}
			catch (Exception) { }

			cm.ExecuteCommand((conn) =>
			{
				var cnt = GetRowCount(conn);
				Assert.AreEqual(1, cnt, "Bad row count");
			}, customer: "testCustomer");
		}

		/// <summary>
		/// Outer non-transaction, inner transaction, failure
		/// </summary>
		[TestMethod]
		public void ConnectionManager_TransactionRollback3()
		{
			var connStringProvider = A.Fake<IConnectionStringProvider>();
			A.CallTo(() => connStringProvider.GetConnectionString("testCustomer")).Returns(_testConnectionString);

			var cm = new ConnectionManager(connStringProvider);
			try
			{
				cm.ExecuteCommand((conn) =>
				{
					cm.ExecuteCommand((conn2) =>
					{
						using (var cmd = new SqlCommand(_insertRow2, conn2))
						{
							cmd.ExecuteNonQuery();
						}
						var cntA = GetRowCount(conn);
						Assert.AreEqual(2, cntA, "Bad row count");
					}, runInTransaction: false, customer: "testCustomer");

					cm.ExecuteCommand((conn2) =>
					{
						Assert.AreEqual(conn, conn2, "Connection not re-used in nesting");
						using (var cmd = new SqlCommand(_insertRow3, conn2))
						{
							cmd.ExecuteNonQuery();
						}
						var cntB = GetRowCount(conn2);
						Assert.AreEqual(3, cntB, "Bad row count");

						throw new Exception("rollback");
					}, runInTransaction: true, customer: "testCustomer");
				}, runInTransaction: false, customer: "testCustomer");
			}
			catch (Exception) { }

			cm.ExecuteCommand((conn) =>
			{
				var cnt = GetRowCount(conn);
				Assert.AreEqual(2, cnt, "Bad row count");
			}, customer: "testCustomer");
		}

		private int GetRowCount(SqlConnection conn)
		{
			using (var cmd = new SqlCommand("SELECT COUNT(*) FROM TestTableA;", conn))
			{
				var result = cmd.ExecuteScalar();
				if (result == null
					|| result == DBNull.Value)
				{
					return 0;
				}
				else
				{
					return (int)result;
				}
			}
		}
	}
}
