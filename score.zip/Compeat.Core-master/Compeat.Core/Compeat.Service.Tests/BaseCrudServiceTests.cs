﻿using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Compeat.Data.Framework.InternalUtils;
using Compeat.Service.BaseModels;
using Compeat.Service.Interfaces;
using Compeat.Service.BaseServices;
using System.Data.SqlClient;
using Compeat.Data;
using FakeItEasy;

namespace Compeat.Service.Tests
{
	[TestClass]
	public class BaseCrudServiceTests
	{

		[TestMethod]
		public void BaseCrudService_Save_nullModel()
		{

			var identityManager = A.Fake<IIdentityManager>();
			var connectionManager = ServiceTestTools.GetMockConnectionManager();
			var savableRepository = A.Fake<ISavableRepository>();
			var container = A.Fake<IInjectionContainer>();
			var applicationCrud = A.Fake<IApplicationLevelCrudService>();
			

			A.CallTo(() => container.GetInstance<IIdentityManager>()).Returns(identityManager);
			A.CallTo(() => container.GetInstance<IConnectionManager>()).Returns(connectionManager);
			A.CallTo(() => container.GetInstance<IApplicationLevelCrudService>()).Returns(applicationCrud);

			var service = new TestService(container, savableRepository);
			var retVal = service.Save(null);
			Assert.IsNull(retVal);
		}

		[TestMethod]
		public void BaseCrudService_Save_flaggedForDelete()
		{
			TestDto dtoSentForSave = null;
			var identityManager = A.Fake<IIdentityManager>();
			var connectionManager = ServiceTestTools.GetMockConnectionManager();
			var savableRepository = A.Fake<ISavableRepository>();
			var container = A.Fake<IInjectionContainer>();
			var applicationCrud = A.Fake<IApplicationLevelCrudService>();

			A.CallTo(() => container.GetInstance<IIdentityManager>()).Returns(identityManager);
			A.CallTo(() => container.GetInstance<IConnectionManager>()).Returns(connectionManager);
			A.CallTo(() => container.GetInstance<IApplicationLevelCrudService>()).Returns(applicationCrud);

			A.CallTo(() => savableRepository.SaveObject(A<SqlConnection>.Ignored, A<TestDto>.Ignored))
				.WithAnyArguments().Invokes(
                (callObj) => {
					dtoSentForSave = (TestDto)callObj.Arguments[1];
					dtoSentForSave.testSet = true;
				}
            );

			var service = new TestService(container, savableRepository);
			var retVal = service.Save(new TestBo() { CmpDel = true, id = 1 });
			Assert.IsNotNull(dtoSentForSave);
			Assert.IsTrue(retVal.CmpDel.GetValueOrDefault(false));
			Assert.IsTrue(retVal.testSet.GetValueOrDefault(false));
		}

		[TestMethod]
		public void BaseCrudService_Save_notValid()
		{
			TestDto dtoSentForSave = null;
			var identityManager = A.Fake<IIdentityManager>();
			var connectionManager = ServiceTestTools.GetMockConnectionManager();
			var savableRepository = A.Fake<ISavableRepository>();
			var container = A.Fake<IInjectionContainer>();
			var applicationCrud = A.Fake<IApplicationLevelCrudService>();

			A.CallTo(() => container.GetInstance<IIdentityManager>()).Returns(identityManager);
			A.CallTo(() => container.GetInstance<IConnectionManager>()).Returns(connectionManager);
			A.CallTo(() => container.GetInstance<IApplicationLevelCrudService>()).Returns(applicationCrud);

			A.CallTo(() => savableRepository.SaveObject(A<SqlConnection>.Ignored, A<TestDto>.Ignored))
				.WithAnyArguments().Invokes(
								(callObj) =>
								{
									dtoSentForSave = (TestDto)callObj.Arguments[1];
									dtoSentForSave.testSet = true;
                                }
						);

			var service = new TestService(container, savableRepository, false);

			var retVal = service.Save(new TestBo() { id = 1 });
			Assert.IsNull(dtoSentForSave);//save should not have been called

		}
		[TestMethod]
		public void BaseCrudService_Save_isValid()
		{
			TestDto dtoSentForSave = null;
			var identityManager = A.Fake<IIdentityManager>();
			var connectionManager = ServiceTestTools.GetMockConnectionManager();
			var savableRepository = A.Fake<ISavableRepository>();
			var container = A.Fake<IInjectionContainer>();
			var applicationCrud = A.Fake<IApplicationLevelCrudService>();

			A.CallTo(() => container.GetInstance<IIdentityManager>()).Returns(identityManager);
			A.CallTo(() => container.GetInstance<IConnectionManager>()).Returns(connectionManager);
			A.CallTo(() => container.GetInstance<IApplicationLevelCrudService>()).Returns(applicationCrud);

			A.CallTo(() => savableRepository.SaveObject(A<SqlConnection>.Ignored, A<TestDto>.Ignored))
				.WithAnyArguments().Invokes(
								(callObj) =>
								{
									dtoSentForSave = (TestDto)callObj.Arguments[1];
									dtoSentForSave.testSet = true;
								}
						);

			var service = new TestService(container, savableRepository, true);

			var retVal = service.Save(new TestBo() { id = 5 });
			Assert.IsNotNull(dtoSentForSave);//save should have been called
			Assert.AreEqual(retVal.id, 5);
			Assert.IsTrue(retVal.testSet.GetValueOrDefault(false));

		}

		[TestMethod]
		public void BaseCrudService_Delete()
		{
			TestDto dtoSentForSave = null;
			var identityManager = A.Fake<IIdentityManager>();
			var connectionManager = ServiceTestTools.GetMockConnectionManager();
			var savableRepository = A.Fake<ISavableRepository>();
			var container = A.Fake<IInjectionContainer>();
			var applicationCrud = A.Fake<IApplicationLevelCrudService>();

			A.CallTo(() => container.GetInstance<IIdentityManager>()).Returns(identityManager);
			A.CallTo(() => container.GetInstance<IConnectionManager>()).Returns(connectionManager);
			A.CallTo(() => container.GetInstance<IApplicationLevelCrudService>()).Returns(applicationCrud);

			A.CallTo(() => savableRepository.SaveObject(A<SqlConnection>.Ignored, A<TestDto>.Ignored))
				.WithAnyArguments().Invokes(
								(callObj) =>
								{
									dtoSentForSave = (TestDto)callObj.Arguments[1];
									dtoSentForSave.testSet = true;
								}
						);

			var service = new TestService(container, savableRepository);

			var retVal = service.Delete(5);
			Assert.IsNotNull(dtoSentForSave);//save should have been called
			Assert.AreEqual(retVal.id, 5);
			Assert.IsTrue(retVal.testSet.GetValueOrDefault(false));

		}

		[TestMethod]
		public void BaseCrudService_GetById_BasicStackCheck()
		{
			var identityManager = A.Fake<IIdentityManager>();
			var connectionManager = ServiceTestTools.GetMockConnectionManager();
			var savableRepository = A.Fake<ISavableRepository>();
			var container = A.Fake<IInjectionContainer>();
			var applicationCrud = A.Fake<IApplicationLevelCrudService>();

			A.CallTo(() => container.GetInstance<IIdentityManager>()).Returns(identityManager);
			A.CallTo(() => container.GetInstance<IConnectionManager>()).Returns(connectionManager);
			A.CallTo(() => container.GetInstance<IApplicationLevelCrudService>()).Returns(applicationCrud);

			var service = new TestService(container, savableRepository);

			var retVal = service.GetById(5, null, false, 0);
			Assert.IsNotNull(retVal);
			Assert.AreEqual(retVal.id, 5);
		}

		#region Dummy Test Classes

		private class TestDto : TableBase<TestDto, int?>
		{
			public virtual int? id { get; set; }
			public bool? testSet { get; set; }
			protected override int? MyPk { get; set; }
			protected override bool RequireTimeStamp { get { return false; } }
			protected override string MyTimeStamp { get; set; }
			public override string GetTableName() { return "test"; }
			protected override int ColumnCount { get { return 1; } }
		}

		private class TestBo : BaseCrudBo<TestDto, int?>
		{
			public int? id { get; set; }
			public bool? testSet { get; set; }
			protected override void BoFromDto(IInjectionContainer injection, TestDto dto)
			{
				this.id = dto.id;
				this.testSet = dto.testSet;
				
            }

			protected override void BoToDto(TestDto newDto)
			{
				newDto.CmpDel = this.CmpDel;
				newDto.CmpNew = this.CmpNew;

				newDto.id = this.id;
				newDto.testSet = this.testSet;
			}
			public override void SetKey(int? id)
			{
				this.id = id;
			}
		}

		private class TestService : BaseCrudService<TestBo, int?, TestDto>
		{
			private bool expectedValidationResult { get; set; }
			public TestService(IInjectionContainer injectionContainer, ISavableRepository repository, bool expectedValidationResult = true)
				: base(injectionContainer, repository)
			{
				this.expectedValidationResult = expectedValidationResult;
			}
			public override TestDto LoadFromId(SqlConnection conn, int? id, string[] collectionsToLoad, bool loadAllCollections, int loadAllCollectionsDepth)
			{
				return new TestDto() { id = id };
			}
			public override bool IsValid(SqlConnection conn)
			{
				return expectedValidationResult;
			}
		}

		#endregion
	}
}
