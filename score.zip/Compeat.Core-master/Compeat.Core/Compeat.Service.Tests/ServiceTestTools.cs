﻿using Compeat.Data;
using FakeItEasy;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Service.Tests
{
	public static class ServiceTestTools
	{

		internal static IConnectionManager GetMockConnectionManager()
		{
			var connectionManager = A.Fake<IConnectionManager>();
			A.CallTo(() => connectionManager.ExecuteCommand(null, true, null, null))
				.WithAnyArguments()
				.Invokes((Action<SqlConnection> command, bool runInTransaction, int? transactionTimeout, string customer) =>
				{
					command(null);
				});
			return connectionManager;
		}
	}
}
