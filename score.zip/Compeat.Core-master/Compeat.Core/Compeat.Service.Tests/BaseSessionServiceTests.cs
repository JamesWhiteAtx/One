﻿using Compeat.Service.BaseServices;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Service.Tests
{
	[TestClass]
	public class BaseSessionServiceTests
	{

		[TestMethod]
		public void BaseSessionService_HasRight_Uninitialized()
		{
			var session = new TestSessionService();
			Assert.AreEqual(session.HasRight(TestRights.TestRight1), false);
		}

		[TestMethod]
		public void BaseSessionService_HasRight_UserHasRight()
		{
			var session = new TestSessionService();
			session.InitGrantedTestRights(new TestRights[] { TestRights.TestRight2 });
			Assert.AreEqual(session.HasRight(TestRights.TestRight2), true);
		}

		[TestMethod]
		public void BaseSessionService_HasRight_UserHasSomeOtherRight()
		{
			var session = new TestSessionService();
			session.InitGrantedTestRights(new TestRights[] { TestRights.TestRight3 });
			Assert.AreEqual(session.HasRight(TestRights.TestRight4), false);
		}

		[TestMethod]
		public void BaseSessionService_InitializeRights_Simple()
		{
			var session = new TestSessionService();
			session.InitializeRights(new TestRights[]{ TestRights.TestRight5, TestRights.TestRight6 }, AllRights);
            Assert.AreEqual(session.HasRight(TestRights.TestRight5), true);
			Assert.AreEqual(session.HasRight(TestRights.TestRight6), true);
		}

		[TestMethod]
		public void BaseSessionService_InitializeRights_ClearsPriorRights()
		{
			var session = new TestSessionService();
			session.GrantRight(TestRights.TestRight7);
			session.InitializeRights(new TestRights[] { TestRights.TestRight8 }, AllRights);
			Assert.AreEqual(session.HasRight(TestRights.TestRight7), false);
			Assert.AreEqual(session.HasRight(TestRights.TestRight8), true);
		}

		[TestMethod]
		public void BaseSessionService_GrantRight_Simple()
		{
			var session = new TestSessionService();
			Assert.AreEqual(session.HasRight(TestRights.TestRight9), false);
			session.GrantRight(TestRights.TestRight9);
			Assert.AreEqual(session.HasRight(TestRights.TestRight9), true);
		}

		[TestMethod]
		public void BaseSessionService_HasAllRights_Yes()
		{
			var session = new TestSessionService();
			session.InitializeRights(new TestRights[] { TestRights.TestRight10, TestRights.TestRight11 }, AllRights);
			Assert.AreEqual(session.HasAllRights(new TestRights[] { TestRights.TestRight10, TestRights.TestRight11 }), true);
		}

		[TestMethod]
		public void BaseSessionService_HasAllRights_No_LastMissing()
		{
			var session = new TestSessionService();
			session.InitializeRights(new TestRights[] { TestRights.TestRight12, TestRights.TestRight13 }, AllRights);
			Assert.AreEqual(session.HasAllRights(new TestRights[] { TestRights.TestRight12, TestRights.TestRight13, TestRights.TestRight14 }), false);
		}

		[TestMethod]
		public void BaseSessionService_HasAllRights_No_FirstMissing()
		{
			var session = new TestSessionService();
			session.InitializeRights(new TestRights[] { TestRights.TestRight16, TestRights.TestRight17 }, AllRights);
			Assert.AreEqual(session.HasAllRights(new TestRights[] { TestRights.TestRight15, TestRights.TestRight16, TestRights.TestRight17 }), false);
		}

		[TestMethod]
		public void BaseSessionService_HasSomeRights_Yes_LastFound()
		{
			var session = new TestSessionService();
			session.InitializeRights(new TestRights[] { TestRights.TestRight19, TestRights.TestRight20 }, AllRights);
			Assert.AreEqual(session.HasSomeRights(new TestRights[] { TestRights.TestRight18, TestRights.TestRight19 }), true);
		}

		[TestMethod]
		public void BaseSessionService_HasSomeRights_Yes_FirstFound()
		{
			var session = new TestSessionService();
			session.InitializeRights(new TestRights[] { TestRights.TestRight21, TestRights.TestRight22 }, AllRights);
			Assert.AreEqual(session.HasSomeRights(new TestRights[] { TestRights.TestRight22, TestRights.TestRight23 }), true);
		}

		[TestMethod]
		public void BaseSessionService_HasSomeRights_No()
		{
			var session = new TestSessionService();
			session.InitializeRights(new TestRights[] { TestRights.TestRight24, TestRights.TestRight25 }, AllRights);
			Assert.AreEqual(session.HasSomeRights(new TestRights[] { TestRights.TestRight26 }), false);
		}

		[TestMethod]
		public void BaseSessionService_RevokeRight_Simple()
		{
			var session = new TestSessionService();
			session.GrantRight(TestRights.TestRight27);
			Assert.AreEqual(session.HasRight(TestRights.TestRight27), true);
			session.RevokeRight(TestRights.TestRight27);
			Assert.AreEqual(session.HasRight(TestRights.TestRight27), false);
		}

		[TestMethod]
		public void BaseSessionService_GetGrantedRights_Simple()
		{
			var session = new TestSessionService();
			session.GrantRight(TestRights.TestRight28);
			session.GrantRight(TestRights.TestRight29);
			session.GrantRight(TestRights.TestRight30);
			session.RevokeRight(TestRights.TestRight29);

			var grantedRights = session.GetGrantedRights();
			Assert.AreEqual(grantedRights.Contains(TestRights.TestRight28), true);
			Assert.AreEqual(grantedRights.Contains(TestRights.TestRight29), false);
			Assert.AreEqual(grantedRights.Contains(TestRights.TestRight30), true);
		}	

		public enum TestRights
		{
			TestRight1,
			TestRight2,
			TestRight3,
			TestRight4,
			TestRight5,
			TestRight6,
			TestRight7,
			TestRight8,
			TestRight9,
			TestRight10,
			TestRight11,
			TestRight12,
			TestRight13,
			TestRight14,
			TestRight15,
			TestRight16,
			TestRight17,
			TestRight18,
			TestRight19,
			TestRight20,
			TestRight21,
			TestRight22,
			TestRight23,
			TestRight24,
			TestRight25,
			TestRight26,
			TestRight27,
			TestRight28,
			TestRight29,
			TestRight30
		}

		private IEnumerable<TestRights> AllRights
		{
			get { return Enum.GetValues(typeof(TestRights)).Cast<TestRights>(); }
		}

		private class TestSessionService : BaseSessionService<TestRights>
		{

			private HashSet<TestRights> _grantedTestRights = new HashSet<TestRights>();

			public void InitGrantedTestRights(IEnumerable<TestRights> grantedRights)
			{
				_grantedTestRights = new HashSet<TestRights>(grantedRights);
			}

			// only the HasRights tests 
			protected override bool GetUserRight(TestRights right)
			{
				return _grantedTestRights.Contains(right);
			}
		}

	}
}
