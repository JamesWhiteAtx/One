﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Data.Framework
{

	public class SqlParamHolder
	{
		public SqlParamHolder()
		{
			IsPrimaryKey = false;
			IsTimestamp = false;
			IsIdentity = false;
		}
		public bool IsPrimaryKey { get; set; }
		public bool IsIdentity { get; set; }
		public bool IsTimestamp { get; set; }
		public string ColumnName { get; set; }
		public string ParameterName { get; set; }


		public string UpdateCombo
		{
			get
			{
				return string.Format("[{0}] = {1}", ColumnName, ParameterName);
			}
		}
		public Func<SqlParameter> MyParamGetter { get; set; }
	}
}
