﻿using Compeat.Data.Framework.InternalUtils;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Data.Framework
{
	public class ChildLoaderList<T> : List<Expression<Func<T, object>>> where T : SqlBase
	{
		public ChildLoaderList()
			: base()
		{

		}

		public static void LoadProperty(SqlConnection conn, IEnumerable<string> propertyList, System.Collections.Generic.IEnumerable<SavableMapper> childCollections) 
		{
			if (propertyList != null && propertyList.Count() > 0)
			{
				foreach (var prop in propertyList)
				{
					foreach (var loader in childCollections.Where(s => s.MyPropName == prop))
					{
						loader.MapLoadFromFk(conn);
					}
				}
			}
		}
	}
}
