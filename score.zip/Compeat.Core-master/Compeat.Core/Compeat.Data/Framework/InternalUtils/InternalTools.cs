﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Data.Framework.InternalUtils
{
	public static class InternalTools
	{



		#region Proc execution

		/// <summary>
		/// Execute only
		/// </summary>
		public static int ProcRun(string procName, SqlConnection conn, SqlParameter[] parameters, int sqlTimeout = 300)
		{
			if (conn == null)
			{
				throw new DbNoConnectionException(String.Format("DataTools.ProcRun attempting to call [{0}] ", procName));
			}
			if (conn.State != System.Data.ConnectionState.Open)
			{
				throw new DbClosedConnectionException(procName, conn, parameters);
			}
			try
			{
				using (var cm = conn.CreateCommand())
				{
					cm.CommandType = System.Data.CommandType.StoredProcedure;
					cm.CommandText = procName;
					cm.CommandTimeout = sqlTimeout;

					if (parameters != null && parameters.Length > 0)
					{
						cm.Parameters.AddRange(parameters);
					}

					return cm.ExecuteNonQuery();
				}
			}
			catch (SqlException sqlEx)
			{
				if (sqlEx.Number == DbFKException.FK_EXCEPTION_ERROR_NUMBER)
				{
					throw new DbFKException(SqlEnums.SqlActivityType.PROC, sqlEx, procName, conn, parameters);
				}
				else
				{
					throw new DbExecuteException(sqlEx, procName, conn, parameters);
				}
			}
			catch (Exception ex)
			{
				throw new DbExecuteException(ex, procName, conn, parameters);
			}
		}

		/// <summary>
		/// Execute reader
		/// </summary>
		public static void ProcRunReader(string procName, SqlConnection conn, SqlParameter[] parameters, Action<SqlDataReader> objFiller, int sqlTimeout = 300)
		{
			if (conn == null)
			{
				throw new DbNoConnectionException(String.Format("DataTools.ProcRunReader attempting to call [{0}] ", procName));
			}
			if (conn.State != System.Data.ConnectionState.Open)
			{
				throw new DbClosedConnectionException(procName, conn, parameters);
			}
			try
			{
				using (var cm = conn.CreateCommand())
				{
					cm.CommandType = System.Data.CommandType.StoredProcedure;
					cm.CommandText = procName;
					cm.CommandTimeout = sqlTimeout;


					if (parameters != null && parameters.Length > 0)
					{
						cm.Parameters.AddRange(parameters);
					}

					using (SqlDataReader sdr = cm.ExecuteReader())
					{
						objFiller(sdr);
					}
				}
			}
			catch (SqlException sqlEx)
			{
				if (sqlEx.Number == DbFKException.FK_EXCEPTION_ERROR_NUMBER)
				{
					throw new DbFKException(SqlEnums.SqlActivityType.PROC, sqlEx, procName, conn, parameters);
				}
				else
				{
					throw new DbExecuteException(sqlEx, procName, conn, parameters);
				}
			}
			catch (Exception ex)
			{
				throw new DbExecuteException(ex, procName, conn, parameters);
			}
		}

		/// <summary>
		/// Execute scalar
		/// </summary>
		public static RET ProcRunScalar<RET>(string procName, SqlConnection conn, SqlParameter[] parameters, int sqlTimeout = 300)
		{
			RET retVal;
			if (conn == null)
			{
				throw new DbNoConnectionException(String.Format("DataTools.ProcRunScalar attempting to call [{0}] ", procName));
			}
			if (conn.State != System.Data.ConnectionState.Open)
			{
				throw new DbClosedConnectionException(procName, conn, parameters);
			}
			try
			{
				using (var cm = conn.CreateCommand())
				{
					cm.CommandType = System.Data.CommandType.StoredProcedure;
					cm.CommandText = procName;
					cm.CommandTimeout = sqlTimeout;

					if (parameters != null && parameters.Length > 0)
					{
						cm.Parameters.AddRange(parameters);
					}
					var result = cm.ExecuteScalar();
					if (result == null || result == DBNull.Value)
					{
						retVal = default(RET);
                    }
					else
					{
						retVal = (RET)result;
                    }
				}
			}
			catch (SqlException sqlEx)
			{
				if (sqlEx.Number == DbFKException.FK_EXCEPTION_ERROR_NUMBER)
				{
					throw new DbFKException(SqlEnums.SqlActivityType.PROC, sqlEx, procName, conn, parameters);
				}
				else
				{
					throw new DbExecuteException(sqlEx, procName, conn, parameters);
				}
			}
			catch (Exception ex)
			{
				throw new DbExecuteException(ex, procName, conn, parameters);
			}
			return retVal;
		}

		#endregion

		#region Raw script calls

		/// <summary>
		/// Execute only
		/// </summary>
		public static int ScriptRun(SqlEnums.SqlActivityType activityType, string script, SqlConnection conn, SqlParameter[] parameters, int sqlTimeout = 300)
		{
			if (conn == null)
			{
				throw new DbNoConnectionException(String.Format("DataTools.ScriptRun attempting to execute [{0}] ", script));
			}
			if (conn.State != System.Data.ConnectionState.Open)
			{
				throw new DbClosedConnectionException(script, conn, parameters);
			}
			try
			{
				using (var cm = conn.CreateCommand())
				{
					cm.CommandType = System.Data.CommandType.Text;
					cm.CommandText = script;
					cm.CommandTimeout = sqlTimeout;

					if (parameters != null && parameters.Length > 0)
					{
						cm.Parameters.AddRange(parameters);
					}

					return cm.ExecuteNonQuery();
				}
			}
			catch (SqlException sqlEx)
			{
				if (sqlEx.Number == DbFKException.FK_EXCEPTION_ERROR_NUMBER)
				{
					throw new DbFKException(activityType, sqlEx, script, conn, parameters);
				}
				else
				{
					throw new DbExecuteException(sqlEx, script, conn, parameters);
				}
			}
			catch (Exception ex)
			{
				throw new DbExecuteException(ex, script, conn, parameters);
			}
		}

		/// <summary>
		/// Execute reader
		/// </summary>
		public static void ScriptRunReader(SqlEnums.SqlActivityType activityType, string script, SqlConnection conn, SqlParameter[] parameters, Action<SqlDataReader> objFiller, int sqlTimeout = 300)
		{
			if (conn == null)
			{
				throw new DbNoConnectionException(String.Format("DataTools.ScriptRunReader attempting to execute [{0}] ", script));
			}
			if (conn.State != System.Data.ConnectionState.Open)
			{
				throw new DbClosedConnectionException(script, conn, parameters);
			}
			try
			{
				using (var cm = conn.CreateCommand())
				{
					cm.CommandType = System.Data.CommandType.Text;
					cm.CommandText = script;
					cm.CommandTimeout = sqlTimeout;

					if (parameters != null && parameters.Length > 0)
					{
						cm.Parameters.AddRange(parameters);
					}

					using (SqlDataReader sdr = cm.ExecuteReader())
					{
						objFiller(sdr);
					}
				}
			}
			catch (SqlException sqlEx)
			{
				if (sqlEx.Number == DbFKException.FK_EXCEPTION_ERROR_NUMBER)
				{
					throw new DbFKException(activityType, sqlEx, script, conn, parameters);
				}
				else
				{
					throw new DbExecuteException(sqlEx, script, conn, parameters);
				}
			}
			catch (Exception ex)
			{
				throw new DbExecuteException(ex, script, conn, parameters);
			}
		}

		#endregion

		#region Param helpers


		/// <summary>
		/// can be used to create params for numerics
		/// </summary>
		public static SqlParameter MakeParam<P>(string parameterName, SqlDbType type, P value, bool isNullable, byte precision, byte scale, ParameterDirection direction = ParameterDirection.Input)
		{
			if (value == null)
			{
				return new SqlParameter(parameterName, type)
				{
					Value = DBNull.Value,
					IsNullable = isNullable,
					Direction = direction,
					Precision = precision,
					Scale = scale
				};
			}
			else
			{
				return new SqlParameter(parameterName, type)
				{
					Value = value,
					IsNullable = isNullable,
					Direction = direction,
					Precision = precision,
					Scale = scale
				};
			}
		}

		public static SqlParameter MakeParam(string parameterName, SqlDbType type, decimal value, bool isNullable, byte precision, byte scale, ParameterDirection direction = ParameterDirection.Input)
		{
			return NonNullableDecimalMakeParam(parameterName, type, value, isNullable, precision, scale, direction);
		}

		public static SqlParameter MakeParam(string parameterName, SqlDbType type, double value, bool isNullable, byte precision, byte scale, ParameterDirection direction = ParameterDirection.Input)
		{
			return NonNullableDecimalMakeParam(parameterName, type, value, isNullable, precision, scale, direction);
		}

		public static SqlParameter MakeParam(string parameterName, SqlDbType type, float value, bool isNullable, byte precision, byte scale, ParameterDirection direction = ParameterDirection.Input)
		{
			return NonNullableDecimalMakeParam(parameterName, type, value, isNullable, precision, scale, direction);
		}

		private static SqlParameter NonNullableDecimalMakeParam<P>(string parameterName, SqlDbType type, P value, bool isNullable, byte precision, byte scale, ParameterDirection direction = ParameterDirection.Input) where P : struct
		{
			return new SqlParameter(parameterName, type)
			{
				Value = value,
				IsNullable = isNullable,
				Direction = direction,
				Precision = precision,
				Scale = scale
			};
		}

		/// <summary>
		/// can be used to create params for simple types
		/// </summary>
		public static SqlParameter MakeParam<P>(string parameterName, SqlDbType type, P value, bool isNullable, ParameterDirection direction = ParameterDirection.Input)
		{
			if (value == null)
			{
				return new SqlParameter(parameterName, type)
				{
					Value = DBNull.Value,
					IsNullable = isNullable,
					Direction = direction
				};
			}
			else
			{
				return new SqlParameter(parameterName, type)
				{
					Value = value,
					IsNullable = isNullable,
					Direction = direction
				};
			}
		}

		/// <summary>
		/// can be used to create params for simple types
		/// </summary>
		public static SqlParameter MakeParam(string parameterName, SqlDbType type, byte value, bool isNullable, ParameterDirection direction = ParameterDirection.Input)
		{
			return NonNullableIntyMakeParam(parameterName, type, value, isNullable, direction);
		}
		/// <summary>
		/// can be used to create params for simple types
		/// </summary>
		public static SqlParameter MakeParam(string parameterName, SqlDbType type, sbyte value, bool isNullable, ParameterDirection direction = ParameterDirection.Input)
		{
			return NonNullableIntyMakeParam(parameterName, type, value, isNullable, direction);
		}
		/// <summary>
		/// can be used to create params for simple types
		/// </summary>
		public static SqlParameter MakeParam(string parameterName, SqlDbType type, char value, bool isNullable, ParameterDirection direction = ParameterDirection.Input)
		{
			return NonNullableIntyMakeParam(parameterName, type, value, isNullable, direction);
		}
		/// <summary>
		/// can be used to create params for simple types
		/// </summary>
		public static SqlParameter MakeParam(string parameterName, SqlDbType type, short value, bool isNullable, ParameterDirection direction = ParameterDirection.Input)
		{
			return NonNullableIntyMakeParam(parameterName, type, value, isNullable, direction);
		}
		/// <summary>
		/// can be used to create params for simple types
		/// </summary>
		public static SqlParameter MakeParam(string parameterName, SqlDbType type, ushort value, bool isNullable, ParameterDirection direction = ParameterDirection.Input)
		{
			return NonNullableIntyMakeParam(parameterName, type, value, isNullable, direction);
		}
		/// <summary>
		/// can be used to create params for simple types
		/// </summary>
		public static SqlParameter MakeParam(string parameterName, SqlDbType type, int value, bool isNullable, ParameterDirection direction = ParameterDirection.Input)
		{
			return NonNullableIntyMakeParam(parameterName, type, value, isNullable, direction);
		}
		/// <summary>
		/// can be used to create params for simple types
		/// </summary>
		public static SqlParameter MakeParam(string parameterName, SqlDbType type, uint value, bool isNullable, ParameterDirection direction = ParameterDirection.Input)
		{
			return NonNullableIntyMakeParam(parameterName, type, value, isNullable, direction);
		}
		/// <summary>
		/// can be used to create params for simple types
		/// </summary>
		public static SqlParameter MakeParam(string parameterName, SqlDbType type, long value, bool isNullable, ParameterDirection direction = ParameterDirection.Input)
		{
			return NonNullableIntyMakeParam(parameterName, type, value, isNullable, direction);
		}
		/// <summary>
		/// can be used to create params for simple types
		/// </summary>
		public static SqlParameter MakeParam(string parameterName, SqlDbType type, ulong value, bool isNullable, ParameterDirection direction = ParameterDirection.Input)
		{
			return NonNullableIntyMakeParam(parameterName, type, value, isNullable, direction);
		}
		/// <summary>
		/// can be used to create params for simple types
		/// </summary>
		public static SqlParameter MakeParam(string parameterName, SqlDbType type, bool value, bool isNullable, ParameterDirection direction = ParameterDirection.Input)
		{
			return NonNullableIntyMakeParam(parameterName, type, value, isNullable, direction);
		}
		/// <summary>
		/// can be used to create params for simple types
		/// </summary>
		public static SqlParameter MakeParam(string parameterName, SqlDbType type, Guid value, bool isNullable, ParameterDirection direction = ParameterDirection.Input)
		{
			return NonNullableIntyMakeParam(parameterName, type, value, isNullable, direction);
		}
		/// <summary>
		/// can be used to create params for simple types
		/// </summary>
		public static SqlParameter MakeParam(string parameterName, SqlDbType type, DateTime value, bool isNullable, ParameterDirection direction = ParameterDirection.Input)
		{
			return NonNullableIntyMakeParam(parameterName, type, value, isNullable, direction);
		}

		private static SqlParameter NonNullableIntyMakeParam<P>(string parameterName, SqlDbType type, P value, bool isNullable, ParameterDirection direction = ParameterDirection.Input) where P : struct
		{
			return new SqlParameter(parameterName, type)
			{
				Value = value,
				IsNullable = isNullable,
				Direction = direction
			};
		}


		/// <summary>
		/// can be used to create params structured Types
		/// </summary>
		public static SqlParameter MakeParam(string parameterName, SqlDbType type, string typeName, DataTable value, bool isNullable, ParameterDirection direction = ParameterDirection.Input)
		{
			if (value == null)
			{
				return new SqlParameter(parameterName, type)
				{
					Value = DBNull.Value,
					IsNullable = isNullable,
					Direction = direction,
					TypeName = typeName
				};
			}
			else
			{
				return new SqlParameter(parameterName, type)
				{
					Value = value,
					IsNullable = isNullable,
					Direction = direction,
					TypeName = typeName
				};
			}
		}

		/// <summary>
		/// can be used to create params for string 
		/// </summary>
		public static SqlParameter MakeParam(string parameterName, SqlDbType type, string value, bool isNullable, int size, ParameterDirection direction = ParameterDirection.Input)
		{
			if (value == null)
			{
				return new SqlParameter(parameterName, type, size)
				{
					Value = DBNull.Value,
					IsNullable = isNullable,
					Direction = direction
				};
			}
			else
			{
				return new SqlParameter(parameterName, type, size)
				{
					Value = value,
					IsNullable = isNullable,
					Direction = direction
				};
			}
		}


		/// <summary>
		/// used for situations where the generator is not used to create the param
		/// </summary>
		public static SqlParameter MakeObjectParam(string parameterName, object value)
		{
			if (value == null)
			{
				return new SqlParameter(parameterName, DBNull.Value);
			}
			else
			{
				return new SqlParameter(parameterName, value);
			}


		}

		/// <summary>
		/// used for situations where the generator is not used and types need to be more strict, for example sql server might not like comparing a '2' to an int field
		/// </summary>
		public static SqlParameter MakeObjectParam(string parameterName, Type typeToForce, object value)
		{
			if (value == null)
			{
				return new SqlParameter(parameterName, GetSqlDbType(typeToForce)) { Value = DBNull.Value };
			}
			else
			{
				return new SqlParameter(parameterName, GetSqlDbType(typeToForce)) { Value = value };
			}
		}

		public static SqlDbType GetSqlDbType(Type typeToForce)
		{

			if (typeToForce == typeof(byte) || typeToForce == typeof(sbyte))
			{
				return SqlDbType.TinyInt;
			}
			else if (typeToForce == typeof(bool))
			{
				return SqlDbType.Bit;
			}
			else if (typeToForce == typeof(short))
			{
				return SqlDbType.SmallInt;
			}
			else if (typeToForce == typeof(int) || typeToForce == typeof(ushort))
			{
				return SqlDbType.Int;
			}
			else if (typeToForce == typeof(long) || typeToForce == typeof(uint))
			{
				return SqlDbType.BigInt;
			}
			else if (typeToForce == typeof(decimal) || typeToForce == typeof(ulong))
			{
				return SqlDbType.Decimal;
			}
			else if (typeToForce == typeof(float) || typeToForce == typeof(double))
			{
				return SqlDbType.Float;
			}
			else if (typeToForce == typeof(Guid))
			{
				return SqlDbType.UniqueIdentifier;
			}
			else if (typeToForce == typeof(DateTime))
			{
				return SqlDbType.DateTime;
			}
			else if (typeToForce == typeof(string) || typeToForce == typeof(char))
			{
				return SqlDbType.NVarChar;
			}
			else
			{
				return SqlDbType.Variant;
			}
		}

		public static TableWhereParamsAndOrder ProcessLambda<SelfType>(string tableName, Expression<Func<SelfType, bool>> whereExpression, string whereClause = null, string orderBy = null, SqlParameter[] paramList = null)
		{
			List<SqlParameter> newParamList = new List<SqlParameter>();
			if (paramList != null && paramList.Count() > 0)
			{
				newParamList.AddRange(paramList);
			}
			string lambdaVariation = BasicLambdaToSqlProcessing.lambdaToString(newParamList, tableName, whereExpression);

			if (!string.IsNullOrWhiteSpace(whereClause))
			{
				lambdaVariation = string.Format("{0} and {1}", lambdaVariation, whereClause);
			}

			return new TableWhereParamsAndOrder()
			{
				WhereClause = lambdaVariation,
				OrderBy = orderBy,
				ParamList = newParamList.ToArray()
			};
		}

		#endregion
	}
}
