﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Data.Framework
{
	public abstract class CustomTableType : SqlDataRecord
	{

		/// <summary>
		/// This is a function we can override to set the defaults on an object. 
		/// </summary>
		public virtual void SetDefaults() { }

	}
}
