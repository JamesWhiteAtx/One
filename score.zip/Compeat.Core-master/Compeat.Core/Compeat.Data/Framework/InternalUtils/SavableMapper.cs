﻿using Compeat.Data.Framework.InternalUtils;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Data.Framework
{
	public class SavableMapper
	{
		public Func<IEnumerable<SqlBase>> Obj { get; set; }
		public string MyPropName { get; set; }
		public Action MapPk { get; set; }
		public Action<SqlConnection> MapLoadFromFk { get; set; }
	}
}
