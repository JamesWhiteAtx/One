﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Linq.Expressions;

namespace Compeat.Data.Framework.InternalUtils
{
	[Serializable]
	public abstract class TableBase<SelfType, PkType> : SqlBase, ITable<PkType> where SelfType : class
	{


		/// <summary>
		/// needed for local collection optimization
		/// </summary>
		protected abstract int ColumnCount { get; }

		public TableBase()
		{
			this.IsSkinnySafe = false;
			_updatedProperties = new List<SqlParamHolder>(ColumnCount);
		}

		/// <summary>
		/// This is a function we can override to set the defaults on an object. 
		/// </summary>
		public virtual void SetDefaults() { }



		#region Writing needs



		//keys
		protected abstract PkType MyPk { get; set; }
		protected abstract bool RequireTimeStamp { get; }
		protected abstract string MyTimeStamp { get; set; }

		protected override bool HasPkSet
		{
			get
			{
				return MyPk != null;
			}
		}
		protected override bool RequiresTimeStamp
		{
			get
			{
				return RequireTimeStamp;
			}
		}
		protected override bool HasTimeStampSet
		{
			get
			{
				return MyTimeStamp != null;
			}
		}

		//dirtiness
		internal override bool InSavableState
		{
			get
			{
				return !IsSkinnySafe || _updatedProperties.Count > 0 || CmpDel.GetValueOrDefault(false);
			}
		}

		[NonSerialized]
		private List<SqlParamHolder> _updatedProperties = null;
		protected List<SqlParamHolder> UpdatedProperties
		{
			get { return _updatedProperties; }
			set { _updatedProperties = value; }
		}


		private bool _isSkinnySafe = false;
		protected bool IsSkinnySafe
		{
			get
			{
				return _isSkinnySafe;
			}
			set
			{
				_isSkinnySafe = value;
			}
		}

		//generated objects will check the value of IsSkinnySafe first
		protected void AddChangedProperty(bool isPK, bool isIdentity, bool isTimestamp, string fieldName, string parameterName, Func<SqlParameter> myParamGetter)
		{
			if (!_updatedProperties.Any(s => s.ColumnName == fieldName))
			{
				_updatedProperties.Add(
					new SqlParamHolder()
					{
						IsPrimaryKey = isPK,
						IsIdentity = isIdentity,
						IsTimestamp = isTimestamp,
						ColumnName = fieldName,
						ParameterName = parameterName,
						MyParamGetter = myParamGetter
					}
				);
			}
		}

		protected override string ObjName
		{
			get
			{
				return GetTableName();
			}
		}

		#endregion

		public abstract string GetTableName();
	}
}
