﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Data.Framework.InternalUtils
{
	[Serializable]
	public abstract class ProcBase : SqlBase
	{

		protected virtual string StockSaveTableName
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		/// <summary>
		/// stored procs are always in a savable state
		/// </summary>
		internal override bool InSavableState
		{
			get
			{
				return true;
			}
		}


		protected virtual IEnumerable<SqlParamHolder> MyParameters
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		protected virtual void StockProcUpdate(SqlConnection conn)
		{
			var myPKGetter = MyParameters.FirstOrDefault(s => s.IsPrimaryKey);
			if (myPKGetter == null)
			{
				throw new Exception("Update was called on a savable stored proc, but no primary key was defined!");
			}
			else
			{
				SqlParameter[] parmList = MyParameters.Select(s => s.MyParamGetter()).ToArray();
				string formattedUpdate = string.Format(
												"update [dbo].[{0}] set {1} where [{2}] = {3};"
												, StockSaveTableName
												, string.Join(",", MyParameters.Where(s => !s.IsTimestamp && !s.IsIdentity).Select(s => s.UpdateCombo))
												, myPKGetter.ColumnName
												, myPKGetter.ParameterName
											);
				if (InternalTools.ScriptRun(SqlEnums.SqlActivityType.UPDATE, formattedUpdate, conn, parmList, GetTimeout()) <= 0)
				{
					throw new DbUpdateFailedNoChangesMade(formattedUpdate, conn, parmList);
				}
			}
		}

		protected virtual void StockProcInsert(SqlConnection conn)
		{
			SqlParameter[] parmList = MyParameters.Select(s => s.MyParamGetter()).ToArray();
			string formattedUpdate = string.Format(
											"insert into [dbo].[{0}] ({1}) values ({2});"
											, StockSaveTableName
											, string.Join(",", MyParameters.Where(s => !s.IsIdentity && !s.IsTimestamp).Select(s => s.ColumnName))
											, string.Join(",", MyParameters.Where(s => !s.IsIdentity && !s.IsTimestamp).Select(s => s.ParameterName))
										);
			if (InternalTools.ScriptRun(SqlEnums.SqlActivityType.INSERT, formattedUpdate, conn, parmList, GetTimeout()) <= 0)
			{
				throw new DbUpdateFailedNoChangesMade(formattedUpdate, conn, parmList);
			}
		}

		protected virtual void StockProcDelete(SqlConnection conn)
		{
			var myPKGetter = MyParameters.FirstOrDefault(s => s.IsPrimaryKey);
			if (myPKGetter == null)
			{
				throw new Exception("Delete was called on a savable stored proc, but no primary key was defined!");
			}
			else
			{
				InternalTools.ScriptRun(SqlEnums.SqlActivityType.DELETE,
					string.Format("delete from [dbo].[{0}] where [{1}] = {2};", StockSaveTableName, myPKGetter.ColumnName, myPKGetter.ParameterName)
					, conn, new[] { myPKGetter.MyParamGetter() }, GetTimeout());
			}
		}



	}
}
