﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Data.Framework.InternalUtils
{
	public class BasicLambdaToSqlProcessing
	{
		private static string getParamName(int currIndex)
		{
			return string.Format("@plambda{0}", currIndex);
		}

		public static string lambdaToString<T>(List<SqlParameter> parmeters, string tableName, Expression<Func<T, bool>> expression)
		{
			StringBuilder sb_expression = new StringBuilder();
			if (expression.CanReduce)
			{
				expression = (Expression<Func<T, bool>>)expression.Reduce();
			}
			walkExpression(expression.Parameters[0].Name, tableName, sb_expression, parmeters, expression, false);
			return sb_expression.ToString();
		}

		private static void walkExpression(string tableAlias, string tableName, StringBuilder sbExpression, List<SqlParameter> parmeters, Expression expression, bool rawValueNeeded)
		{
			string newParamName = null;
			switch (expression.NodeType)
			{
				case ExpressionType.MemberAccess:
					{
						string replacementExpression = expression.ToString();
						if (
							replacementExpression.Contains("value(")
							|| replacementExpression.Contains("DateTime")
						)
						{
							string replacementValue = Expression.Lambda(expression).Compile().DynamicInvoke().ToString();
							//setup replace for param and add param to list
							newParamName = getParamName(parmeters.Count());
							if (replacementValue == "False" || replacementValue == "True")
							{
								parmeters.Add(InternalTools.MakeParam(newParamName, System.Data.SqlDbType.Bit, Convert.ToBoolean(replacementValue), false));
								if (rawValueNeeded)
								{
									sbExpression.Append(string.Format("{0}", newParamName));
								}
								else
								{
									sbExpression.Append(string.Format(replacementValue == "True" ? "{0} = {0}" : "{0} != {0}", newParamName));
								}

							}
							else
							{
								parmeters.Add(InternalTools.MakeObjectParam(newParamName, replacementValue));
								sbExpression.Append(string.Format("{0}", newParamName));
							}

						}
						else
						{
							sbExpression.Append(expression.ToString().Replace(tableAlias, tableName));
						}
					}
					break;
				case ExpressionType.Constant:
					string repVal = expression
										.ToString()
										.Trim()
										.TrimEnd('"')
										.TrimStart('"')
										;
					newParamName = getParamName(parmeters.Count());

					if (repVal == "False" || repVal == "True")
					{
						parmeters.Add(InternalTools.MakeParam(newParamName, System.Data.SqlDbType.Bit, Convert.ToBoolean(repVal), false));
						if (rawValueNeeded)
						{
							sbExpression.Append(string.Format("{0}", newParamName));
						}
						else
						{
							sbExpression.Append(string.Format(repVal == "True" ? "{0} = {0}" : "{0} != {0}", newParamName));
						}
					}
					else
					{
						parmeters.Add(InternalTools.MakeObjectParam(newParamName, expression.Type, repVal));
						sbExpression.Append(string.Format("{0}", newParamName));
					}

					break;
				case ExpressionType.Coalesce:
					var coalExp = expression as BinaryExpression;
					sbExpression.Append(" isnull(");
					walkExpression(tableAlias, tableName, sbExpression, parmeters, coalExp.Left, true);
					sbExpression.Append(", ");
					walkExpression(tableAlias, tableName, sbExpression, parmeters, coalExp.Right, true);
					sbExpression.Append(")");
					break;
				case ExpressionType.Conditional:
					var cExp = expression as ConditionalExpression;
					sbExpression.Append(" (case when (");
					walkExpression(tableAlias, tableName, sbExpression, parmeters, cExp.Test, false);
					sbExpression.Append(") then (");
					walkExpression(tableAlias, tableName, sbExpression, parmeters, cExp.IfTrue, true);
					sbExpression.Append(") else (");
					walkExpression(tableAlias, tableName, sbExpression, parmeters, cExp.IfFalse, true);
					sbExpression.Append(") end) ");
					break;

				case ExpressionType.IsTrue:
					var trueExp = expression as UnaryExpression;
					sbExpression.Append("(");
					walkExpression(tableAlias, tableName, sbExpression, parmeters, trueExp.Operand, false);
					sbExpression.Append(")");
					break;
				case ExpressionType.IsFalse:
				case ExpressionType.Not:
					var notExp = expression as UnaryExpression;
					sbExpression.Append("( not(");
					walkExpression(tableAlias, tableName, sbExpression, parmeters, notExp.Operand, false);
					sbExpression.Append("))");
					break;
				case ExpressionType.OrElse:
				case ExpressionType.AndAlso:
					var groupingExp = expression as BinaryExpression;
					sbExpression.Append("(");
					walkExpression(tableAlias, tableName, sbExpression, parmeters, groupingExp.Left, false);
					sbExpression.AppendFormat(") {0} (", ToStr(expression.NodeType));
					walkExpression(tableAlias, tableName, sbExpression, parmeters, groupingExp.Right, false);
					sbExpression.Append(")");
					break;
				case ExpressionType.GreaterThan:
				case ExpressionType.GreaterThanOrEqual:
				case ExpressionType.LessThan:
				case ExpressionType.LessThanOrEqual:
				case ExpressionType.Equal:
				case ExpressionType.Assign:
				case ExpressionType.Add:
				case ExpressionType.AddChecked:
				case ExpressionType.Divide:
				case ExpressionType.Multiply:
				case ExpressionType.MultiplyChecked:
				case ExpressionType.Subtract:
				case ExpressionType.SubtractChecked:
				case ExpressionType.NotEqual:
				case ExpressionType.Modulo:
				case ExpressionType.Increment:
				case ExpressionType.Decrement:
				case ExpressionType.Power:
					var bExp = expression as BinaryExpression;
					sbExpression.Append("(");
					walkExpression(tableAlias, tableName, sbExpression, parmeters, bExp.Left, true);
					sbExpression.AppendFormat(" {0} ", ToStr(expression.NodeType));
					walkExpression(tableAlias, tableName, sbExpression, parmeters, bExp.Right, true);
					sbExpression.Append(")");
					break;
				case ExpressionType.ArrayLength:
				case ExpressionType.Convert:
				case ExpressionType.ConvertChecked:
				case ExpressionType.Extension:
				case ExpressionType.Index:
				case ExpressionType.New:
				case ExpressionType.PostDecrementAssign:
				case ExpressionType.PostIncrementAssign:
				case ExpressionType.PreDecrementAssign:
				case ExpressionType.PreIncrementAssign:
				case ExpressionType.ArrayIndex:
				case ExpressionType.Call:
				case ExpressionType.Negate:
				case ExpressionType.NegateChecked:
				case ExpressionType.UnaryPlus:
				case ExpressionType.Unbox:
					//normal evals
					string methCall = Expression.Lambda(expression).Compile().DynamicInvoke().ToString();
					newParamName = getParamName(parmeters.Count());
					if (methCall == "False" || methCall == "True")
					{
						parmeters.Add(InternalTools.MakeParam(newParamName, System.Data.SqlDbType.Bit, Convert.ToBoolean(methCall), false));
						if (rawValueNeeded)
						{
							sbExpression.Append(string.Format("{0}", newParamName));
						}
						else
						{
							sbExpression.Append(string.Format(methCall == "True" ? "{0} = {0}" : "{0} != {0}", newParamName));
						}

					}
					else
					{
						parmeters.Add(InternalTools.MakeObjectParam(newParamName, methCall));
						sbExpression.Append(string.Format("{0}", newParamName));
					}

					break;

				case ExpressionType.Lambda:
					var lExp = expression as LambdaExpression;
					walkExpression(tableAlias, tableName, sbExpression, parmeters, lExp.Body, false);
					break;
				default:
#if DEBUG
					Console.WriteLine("Unhandled {0}: {0} >>> {1}", expression.NodeType, expression.ToString());
#endif
					sbExpression.Append(expression.ToString());
					break;
			}

		}
		private static string ToStr(ExpressionType tp)
		{
			switch (tp)
			{
				case ExpressionType.GreaterThan:
					return ">";
				case ExpressionType.GreaterThanOrEqual:
					return ">=";
				case ExpressionType.LessThan:
					return "<";
				case ExpressionType.LessThanOrEqual:
					return "<=";
				case ExpressionType.OrElse:
					return "OR";
				case ExpressionType.AndAlso:
					return "AND";
				case ExpressionType.Equal:
				case ExpressionType.Assign:
					return "=";
				case ExpressionType.Add:
				case ExpressionType.AddChecked:
				case ExpressionType.Increment:
				case ExpressionType.UnaryPlus:
					return "+";
				case ExpressionType.Subtract:
				case ExpressionType.SubtractChecked:
				case ExpressionType.Decrement:
				case ExpressionType.Negate:
				case ExpressionType.NegateChecked:
					return "-";
				case ExpressionType.Divide:
					return "/";
				case ExpressionType.Multiply:
				case ExpressionType.MultiplyChecked:
					return "*";
				case ExpressionType.NotEqual:
					return "!=";
				case ExpressionType.Modulo:
					return "%";
				case ExpressionType.Power:
					return "^";
				default:
#if DEBUG
					Console.WriteLine("Unhandled ToString: {0}", tp);
#endif
					return "";
			}
		}



	}

}

