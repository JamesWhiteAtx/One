﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Data.Framework
{
	public class TableWhereParamsAndOrder
	{
		public string WhereClause { get; set; }
		public string OrderBy { get; set; }
		public SqlParameter[] ParamList { get; set; }

		public TableWhereParamsAndOrder()
		{
			WhereClause = null;
			OrderBy = null;
			ParamList = null;
		}

	}
}
