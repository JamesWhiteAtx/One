﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Data.Framework
{
	public class SqlEnums
	{

		public enum SqlActivityType
		{
			PROC,
			INSERT,
			UPDATE,
			DELETE,
			SELECT
		}


	}
}
