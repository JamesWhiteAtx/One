﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Data.Framework.InternalUtils
{
	[Serializable]
	public abstract class SqlBase : ISavable
	{

		internal const int DEFAULT_CONN_TIMEOUT = 300;

		/// <summary>
		/// If this is true, the Save function will delete this record. 
		/// </summary>
		public bool? CmpDel { get; set; }

		/// <summary>
		/// If this is true, insert gets called instead of update, even if hasPkSet is true
		/// </summary>
		public bool? CmpNew { get; set; }

		/// <summary>
		/// Override to change
		/// </summary>
		public virtual int GetTimeout()
		{
			return DEFAULT_CONN_TIMEOUT;
		}

		#region Writing
		/// <summary>
		/// Will flag this record for deletion, must Save to finalize though
		/// </summary>
		public void Delete()
		{
			CmpDel = true;
		}


		internal virtual bool InSavableState
		{
			get
			{
				return false;
			}
		}

		/// <summary>
		/// If this is true, update gets called instead of insert
		/// </summary>
		protected virtual bool HasPkSet
		{
			get
			{
				return false;
			}
		}

		/// <summary>
		/// updates will not be run if this is true and they dont have it set yet
		/// </summary>
		protected virtual bool RequiresTimeStamp
		{
			get
			{
				return false;
			}
		}
		/// <summary>
		/// an update will not run if this is not set and a timestamp is required
		/// </summary>
		protected virtual bool HasTimeStampSet
		{
			get
			{
				return false;
			}
		}

		protected virtual void Update(SqlConnection conn) { throw new NotImplementedException("This object does not override the Update function!"); }
		protected virtual void Insert(SqlConnection conn) { throw new NotImplementedException("This object does not override the Insert function!"); }
		protected virtual void Delete(SqlConnection conn) { throw new NotImplementedException("This object does not override the Delete function!"); }

		#endregion Writing

		#region Sub Collection handling
		public virtual bool HasChildrenCollections
		{
			get
			{
				return ChildCollections.Count() > 0 || StockChildCollections.Count() > 0;
			}
		}
		protected virtual System.Collections.Generic.IEnumerable<SavableMapper> ChildCollections
		{
			get
			{
				yield break;
			}
		}
		protected virtual System.Collections.Generic.IEnumerable<SavableMapper> StockChildCollections
		{
			get
			{
				yield break;
			}
		}
		protected System.Collections.Generic.IEnumerable<SavableMapper> AllChildCollections
		{
			get
			{
				foreach (var child in StockChildCollections)
				{
					yield return child;
				}
				foreach (var child in ChildCollections)
				{
					yield return child;
				}
				yield break;
			}
		}

		public void LoadChildren(SqlConnection conn, int depth = int.MaxValue)
		{
			if (!HasPkSet)
			{
				return;
			}
			--depth;

			if (HasChildrenCollections)
			{
				//save known child collections
				foreach (var mapper in this.AllChildCollections)
				{
					if (mapper.MapLoadFromFk != null)
					{
						mapper.MapLoadFromFk(conn);

						if (depth > 0 && mapper.Obj != null)
						{
							var children = mapper.Obj();
							if (children != null)
							{
								foreach (var _child in children)
								{
									_child.LoadChildren(conn, depth);
								}
							}
						}
					}
				}
			}

		}

		#endregion Sub Collection handling

		#region ISavable implementation
		protected abstract string ObjName { get; }


		/// <summary>
		/// Public save entry point, opens conn if its not opened and wraps the save in a transaction
		/// child objects are updated with their parent id if/when needed
		/// </summary>
		public void Save(ISavableRepository repo, SqlConnection conn)
		{
			repo.SaveObject(conn, this);
		}
		/// <summary>
		/// Public save entry point, opens conn if its not opened and wraps the save in a transaction
		/// child objects are updated with their parent id if/when needed
		/// </summary>
		public void DirectSave(SqlConnection conn)
		{
			if (InSavableState)
			{
				if (conn == null)
				{
					throw new DbNoConnectionException(String.Format("TableBase.Save attempting to save to [{0}] ", ObjName));
				}
				if (conn.State == System.Data.ConnectionState.Open)
				{
					var isDel = CmpDel.GetValueOrDefault(false);
					if (!isDel)
					{
						if (!CmpNew.GetValueOrDefault(false) && (HasPkSet && (!RequiresTimeStamp || HasTimeStampSet)))
						{
							//run update
							Update(conn);
						}
						else
						{
							//run insert
							Insert(conn);
							CmpNew = false;
						}

						if (HasChildrenCollections)
						{
							foreach (var mapper in this.AllChildCollections)
							{
								if (mapper.MapPk != null)
								{
									mapper.MapPk();
								}
							}
						}
					}
					if (HasChildrenCollections)
					{
						//save known child collections
						foreach (var mapper in this.AllChildCollections)
						{
							//mapper.Obj is the getter for this objects children list
							var children = mapper.Obj();
							if (children != null)
							{
								foreach (var child in children)
								{
									child.DirectSave(conn);
								}
							}
						}
					}
					if (isDel && HasPkSet)
					{
						//run delete
						Delete(conn);
					}
				}
				else
				{
					throw new DbClosedConnectionException(ObjName, conn, null);
				}

			}
		}
		#endregion

	}
}
