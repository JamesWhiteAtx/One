﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace Compeat.Data.Framework.InternalUtils
{
	public abstract class BaseRepositoryTableReader<TRepoType, TDtoType, PkType>
		where TDtoType : TableBase<TDtoType, PkType>
	{
		public BaseRepositoryTableReader(){}

		public abstract TDtoType Get(SqlConnection conn, PkType pkVal, ChildLoaderList<TDtoType> collectionsToLoad = null, IEnumerable<string> collectionToLoadUsingStrings = null, int recursiveDepth = 0);
		public abstract TDtoType GetFirst(SqlConnection conn, string whereClause = null, string orderBy = null, ChildLoaderList<TDtoType> collectionsToLoad = null, IEnumerable<string> collectionToLoadUsingStrings = null, SqlParameter[] paramList = null, int recursiveDepth = 0);
		public abstract List<TDtoType> GetList(SqlConnection conn, string whereClause = null, string orderBy = null, ChildLoaderList<TDtoType> collectionsToLoad = null, IEnumerable<string> collectionToLoadUsingStrings = null, SqlParameter[] paramList = null, int recursiveDepth = 0);
		public abstract List<TDtoType> GetList(SqlConnection conn, Expression<Func<TDtoType, bool>> whereExpression, string orderBy = null, string additionalWhereClause = null, ChildLoaderList<TDtoType> collectionsToLoad = null, IEnumerable<string> collectionToLoadUsingStrings = null, SqlParameter[] paramList = null, int recursiveDepth = 0);
	}

}
