﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace Compeat.Data.Framework.InternalUtils
{
	public class RepositoryBase : ISavableRepository
	{
		public void SaveObject(SqlConnection conn, ISavable savableObject)
		{
			if (savableObject != null)
			{
				savableObject.DirectSave(conn);
			}
		}

		public void SaveObjects(SqlConnection conn, IEnumerable<ISavable> savableObjects)
		{
			if (savableObjects != null)
			{
				foreach (var item in savableObjects)
				{
					SaveObject(conn, item);
				}
			}
		}
	}
}
