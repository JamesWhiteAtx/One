﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Compeat.Data.Framework.InternalUtils
{

	public abstract class TableDataReader<T> : IDataReader where T : class
	{

		private readonly IEnumerator<T> _enumerator;
		protected T Current;
		protected bool Closed;
		protected IEnumerable<T> Fields { get; private set; }

		protected TableDataReader()
		{

			Fields = null;
			Closed = false;
		}

		protected TableDataReader(IEnumerable<T> items)
		{

			Fields = items;
			Closed = false;
			_enumerator = items.GetEnumerator();
		}

		#region IDataReader Members

		public abstract object GetValue(int i);

		public bool Read()
		{
			bool returnValue = _enumerator.MoveNext();
			Current = returnValue ? _enumerator.Current : null;
			return returnValue;
		}

		#endregion

		#region Implementation of IDataRecord

		public abstract int FieldCount { get; }
		public abstract int GetOrdinal(string name);
		public abstract Type GetFieldType(int i);
		public abstract string GetName(int i);
		public abstract int GetValues(object[] values);

		public bool GetBoolean(int i)
		{
			return (bool)GetValue(i);
		}
		public byte GetByte(int i)
		{
			return (byte)GetValue(i);
		}
		public char GetChar(int i)
		{
			return (char)GetValue(i);
		}
		public DateTime GetDateTime(int i)
		{
			return (DateTime)GetValue(i);
		}
		public decimal GetDecimal(int i)
		{
			return (decimal)GetValue(i);
		}
		public double GetDouble(int i)
		{
			return (double)GetValue(i);
		}
		public float GetFloat(int i)
		{
			return (float)GetValue(i);
		}
		public Guid GetGuid(int i)
		{
			return (Guid)GetValue(i);
		}
		public short GetInt16(int i)
		{
			return (short)GetValue(i);
		}
		public int GetInt32(int i)
		{
			return (int)GetValue(i);
		}
		public long GetInt64(int i)
		{
			return (long)GetValue(i);
		}
		public string GetString(int i)
		{
			return (string)GetValue(i);
		}
		public long GetBytes(int i, long fieldOffset, byte[] buffer, int bufferoffset, int length)
		{
			long readLength = 0;
			//currently untested, couldnt find many implementations so made my own
			var val = (byte[])GetValue(i);
			if (val == null || val.Length <= fieldOffset)
			{
				return 0;
			}
			readLength = (val.Length <= fieldOffset + length) ? (fieldOffset + length - val.Length) : length;
			Array.Copy(val, fieldOffset, buffer, bufferoffset, readLength);
			return readLength;
		}
		public long GetChars(int i, long fieldOffset, char[] buffer, int bufferoffset, int length)
		{
			long readLength = 0;
			//currently untested, couldnt find many implementations so made my own
			var val = (char[])GetValue(i);
			if (val == null || val.Length <= fieldOffset)
			{
				return 0;
			}
			readLength = (val.Length <= fieldOffset + length) ? (fieldOffset + length - val.Length) : length;
			Array.Copy(val, fieldOffset, buffer, bufferoffset, readLength);
			return readLength;
		}


		object IDataRecord.this[int i]
		{
			get { return GetValue(i); }
		}
		object IDataRecord.this[string name]
		{
			get { return GetValue(GetOrdinal(name)); }
		}
		public IDataReader GetData(int i)
		{
			throw new NotImplementedException();
		}
		public bool IsDBNull(int i)
		{
			return GetValue(i) == null;
		}
		public string GetDataTypeName(int i)
		{
			return GetFieldType(i).Name;
		}

		#endregion

		#region Implementation of IDataReader

		public abstract DataTable GetSchemaTable();

		public void Close()
		{
			Closed = true;
		}
		public int Depth
		{
			get
			{
				return 0;
			}
		}
		public bool NextResult()
		{
			throw new NotImplementedException();
		}
		public bool IsClosed
		{
			get { return Closed; }
		}
		public int RecordsAffected
		{
			get
			{
				return -1;
			}
		}

		#endregion

		#region Implementation of IDisposable

		public virtual void Dispose()
		{
			Fields = null;
		}

		#endregion


	}
}
