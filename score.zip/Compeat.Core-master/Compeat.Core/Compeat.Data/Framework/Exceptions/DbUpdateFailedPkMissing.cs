﻿

using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Data.Framework
{
	public class DbUpdateFailedPkMissing : Exception
	{

		private string _message { get; set; }

		public DbUpdateFailedPkMissing(string name, SqlConnection conn, SqlParameter[] parameters)
			: base()
		{

			StringBuilder sbOut = new StringBuilder();
			sbOut.AppendFormat("A Pk is required for updates. Please provide the pk or identity value: [{0}]", name);
			if (parameters != null && parameters.Length > 0 && parameters.Any(s => s != null))
			{
				sbOut.AppendLine("Parameters:");
				sbOut.Append(String.Join(", ", parameters.Where(s => s != null).Select(s => String.Format("[{0}]=\"{1}\"", s.ParameterName, Convert.ToString(s.Value) ?? "null"))));
			}
#if DEBUG
			if (conn != null)
			{
				sbOut.AppendLine();
				sbOut.AppendFormat("VISIBLE IN DEBUG ONLY: ConnectionString:\"{0}\"", conn.ConnectionString);
			}
#endif
			_message = sbOut.ToString();
		}
		public override string Message
		{
			get
			{
				return _message;
			}
		}
	}
}

