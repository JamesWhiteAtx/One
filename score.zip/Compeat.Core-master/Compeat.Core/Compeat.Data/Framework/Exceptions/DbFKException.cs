﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Data.Framework
{
	public class DbFKException : Exception
	{
		public const int FK_EXCEPTION_ERROR_NUMBER = 547;
		public DbFKException(SqlEnums.SqlActivityType activityType, string message)
			: base(message, null)
		{
			this.ActivityType = activityType;
		}
		public DbFKException(SqlEnums.SqlActivityType activityType, SqlException ex, string name, SqlConnection conn, SqlParameter[] parameters)
			: base(ex.Message, ex)
		{
			this.ActivityType = activityType;
		}
		public SqlEnums.SqlActivityType ActivityType { get; set; }
	}
}
