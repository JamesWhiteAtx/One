﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Data.Framework
{
	public class DbClosedConnectionException : Exception
	{
		private string _message { get; set; }
		public DbClosedConnectionException(string name, SqlConnection conn, SqlParameter[] parameters)
			: base()
		{

			StringBuilder sbOut = new StringBuilder();
			sbOut.AppendFormat("Provided connection object was not open while excecuting: [{0}]", name);
			if (parameters != null && parameters.Length > 0 && parameters.Any(s => s != null))
			{
				sbOut.AppendLine("Parameters:");
				sbOut.Append(String.Join(", ", parameters.Where(s => s != null).Select(s => String.Format("[{0}]=\"{1}\"", s.ParameterName, Convert.ToString(s.Value) ?? "null"))));
			}
			if (conn != null)
			{

#if DEBUG
				sbOut.AppendLine();
				sbOut.AppendFormat("VISIBLE IN DEBUG ONLY: ConnectionString:\"{0}\"", conn.ConnectionString);
#endif
				sbOut.AppendLine();
				sbOut.AppendFormat("Connection State:\"{0}\"", Enum.GetName(typeof(System.Data.ConnectionState), conn.State));
			}
			_message = sbOut.ToString();
		}
		public override string Message
		{
			get
			{
				return _message;
			}
		}
	}
}
