﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Data.Framework
{
	public class DbNoConnectionException : Exception
	{
		private string _appendToMessage { get; set; }
		public DbNoConnectionException(string appendToMessage = "")
			: base()
		{
			_appendToMessage = appendToMessage;
		}
		public override string Message
		{
			get
			{
				if (string.IsNullOrWhiteSpace(_appendToMessage))
				{
					return "Provided connection object is null!";
				}
				else
				{
					return String.Format("Provided connection object is null! - {0}", _appendToMessage);
				}
			}
		}
	}
}
