﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Data
{
	public partial interface ISavableRepository
	{
		/// <summary>
		/// Writes a data object to the data store 
		/// </summary>
		void SaveObject(SqlConnection conn, ISavable savableObject);

		/// <summary>
		/// Writes data objects to the data store 
		/// </summary>
		void SaveObjects(SqlConnection conn, IEnumerable<ISavable> savableObjects);
	}
}
