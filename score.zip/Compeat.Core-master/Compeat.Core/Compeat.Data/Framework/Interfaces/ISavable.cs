﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Compeat.Data.Framework.InternalUtils;

namespace Compeat.Data
{
	public interface ISavable
	{
		void Save(ISavableRepository repo, SqlConnection conn);
		void DirectSave(SqlConnection conn);
	}
}
