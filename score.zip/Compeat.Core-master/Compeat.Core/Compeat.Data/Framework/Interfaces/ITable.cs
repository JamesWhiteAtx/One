﻿
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq.Expressions;
namespace Compeat.Data.Framework
{
	public interface ITable<PkType>
	{
	}
}
