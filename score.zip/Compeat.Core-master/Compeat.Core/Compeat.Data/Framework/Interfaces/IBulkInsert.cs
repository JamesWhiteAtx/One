﻿using System.Collections.Generic;
using System.Data;


namespace Compeat.Data.Framework
{
	public interface IBulkInsert
	{
		string GetTableName();
		IDataReader GetMyDataReader(IEnumerable<IBulkInsert> listOfItems);
	}
}
