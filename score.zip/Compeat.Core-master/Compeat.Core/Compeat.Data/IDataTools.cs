﻿using System.Collections.Generic;
using System.Data.SqlClient;

namespace Compeat.Data.Framework
{
	public interface IDataTools
	{
		/// <summary>
		/// Takes the list passed in, uses the T to determine the table name and does a bulk insert.  
		/// T must be a generated BO table!
		/// </summary>
		void RunBulkInsert(SqlConnection conn, IEnumerable<IBulkInsert> listOfItems);
		/// <summary>
		/// Takes the list passed in and a table name and uses reflection to determine how to dump it. 
		/// recommended to only be used for non-generator controlled tables as it will use reflection for the propeties before inserting so a bit less efficient
		/// </summary>
		void RunBulkInsertNoGen<T>(SqlConnection conn, string tableName, IEnumerable<T> listOfItems);
	}
}