﻿using System;
using System.Data.SqlClient;

namespace Compeat.Data
{
	public interface IConnectionManager
	{
		void ExecuteCommand(Action<SqlConnection> command, bool runInTransaction = false,
			int? transactionTimeout = null, string customer = null);
	}
}
