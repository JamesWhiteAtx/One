﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Transactions;

namespace Compeat.Data
{
	/// <summary>
	/// A connection manager intended to be used as a transient or web-request scopped.  It will re-use the last used connection if available.
	/// It is not save to use this class as a singleton.
	/// </summary>
	public class ConnectionManager : IConnectionManager
	{
		private const int _transactionTimeout = 120;
		private IConnectionStringProvider _connectionStringProvider = null;

		private string _currentCustomer = null;
		private SqlConnection _currentConnection = null;
		private object _connectionLock = new object();

		/// <summary>
		/// Runs the provided command after initializing the command's SqlConnection parameter.
		/// </summary>
		/// <param name="command">The delegate to execute.  The delegate's sql connection will be initialized.</param>
		/// <param name="runInTransaction">Determines if the command will be run within a transaction scope.</param>
		/// <param name="transactionTimeout">Overrides the default transaction timeout.</param>
		/// <param name="customer">Specifies a specific customer, no value will result in AppContext.Identity being used.</param>
		public void ExecuteCommand(Action<SqlConnection> command, bool runInTransaction = false,
			int? transactionTimeout = null, string customer = null)
		{
			if (runInTransaction)
			{
				ExecuteWithTransaction(command, customer, transactionTimeout ?? _transactionTimeout);
			}
			else
			{
				ExecuteWithoutTransaction(command, customer);
			}
		}

		private void ExecuteWithoutTransaction(Action<SqlConnection> command, string customer)
		{
			var result = GetOpenConnection(customer);

			if (result.Item1)
			{
				using (result.Item2)
				{
					command(result.Item2);
				}
			}
			else
			{
				command(result.Item2);
			}
		}

		private void ExecuteWithTransaction(Action<SqlConnection> command, string customer, int transactionTimeout)
		{
			if (Transaction.Current == null)
			{
				// if we are starting a new transaction, then we need to force a new connection in order for any rollback to work correctly
				_currentConnection = null;

				using (var trans = new TransactionScope(TransactionScopeOption.Required, TimeSpan.FromSeconds(transactionTimeout)))
				{
					ExecuteWithoutTransaction(command, customer);

					trans.Complete();
				}
			}
			else
			{
				ExecuteWithoutTransaction(command, customer);
			}
		}

		/// <summary>
		/// Gets an open SqlConnection
		/// </summary>
		/// <param name="customer"></param>
		/// <returns>1.) True if this is a new connection.  2.) The connection</returns>
		private Tuple<bool, SqlConnection> GetOpenConnection(string customer)
		{
			var newConnection = false;

			lock (_connectionLock)
			{
				if ((_currentConnection == null
				|| _currentConnection.State != System.Data.ConnectionState.Open
				|| (_currentCustomer != null
				&& !_currentCustomer.Equals(customer, StringComparison.CurrentCultureIgnoreCase))))
				{
					_currentCustomer = customer;
					_currentConnection = new SqlConnection(_connectionStringProvider.GetConnectionString(customer));
					_currentConnection.Open();
					newConnection = true;
				}

				return new Tuple<bool, SqlConnection>(newConnection, _currentConnection);
			}
		}

		public ConnectionManager(IConnectionStringProvider connectionStringProvider)
		{
			_connectionStringProvider = connectionStringProvider;
		}
	}
}
