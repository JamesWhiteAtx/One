﻿using Compeat.Data.Framework.BulkCopyTools;
using Compeat.Data.Framework.InternalUtils;
using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Transactions;
namespace Compeat.Data.Framework
{

	public class DataTools : IDataTools
	{
		public DataTools() { }


		#region Bulk insert calls

		/// <summary>
		/// Takes the list passed in, uses the T to determine the table name and does a bulk insert.  
		/// T must be a generated BO table!
		/// </summary>
		public virtual void RunBulkInsert(SqlConnection conn, IEnumerable<IBulkInsert> listOfItems)
		{
			if (listOfItems == null || listOfItems.Count() == 0)
			{
				return;
			}
			if (conn == null)
			{
				throw new DbNoConnectionException("DataTools.RunBulkInsert");
			}
			if (conn.State != System.Data.ConnectionState.Open)
			{
				throw new DbClosedConnectionException("DataTools.RunBulkInsert", conn, null);
			}

			try
			{
				using (SqlBulkCopy sbc = new SqlBulkCopy(conn))
				{
					sbc.DestinationTableName = listOfItems.First().GetTableName();
					sbc.WriteToServer(listOfItems.First().GetMyDataReader(listOfItems));
				}
			}
			catch (Exception ex)
			{
				throw new DbExecuteException(ex, "DataTools.RunBulkInsert", conn, null);
			}
		}

		/// <summary>
		/// Takes the list passed in and a table name and uses reflection to determine how to dump it. 
		/// recommended to only be used for non-generator controlled tables as it will use reflection for the propeties before inserting so a bit less efficient
		/// </summary>
		public virtual void RunBulkInsertNoGen<T>(SqlConnection conn, string tableName, IEnumerable<T> listOfItems)
		{
			if (conn == null)
			{
				throw new DbNoConnectionException("DataTools.RunBulkInsertNoGen");
			}
			if (conn.State != System.Data.ConnectionState.Open)
			{
				throw new DbClosedConnectionException("DataTools.RunBulkInsertNoGen", conn, null);
			}

			EnumerableDataReader edr = new EnumerableDataReader(listOfItems);
			try
			{
				using (SqlBulkCopy sbc = new SqlBulkCopy(conn))
				{
					sbc.DestinationTableName = tableName;
					sbc.WriteToServer(edr);
				}
			}
			catch (Exception ex)
			{
				throw new DbExecuteException(ex, "DataTools.RunBulkInsertNoGen", conn, null);
			}
		}

		#endregion

	}
}
