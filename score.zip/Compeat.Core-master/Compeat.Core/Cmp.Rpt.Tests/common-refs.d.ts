﻿/// <reference path="../../../Resources/TypeScriptDefs/angular-1.4.0.d.ts" />﻿ 
/// <reference path="../../../Resources/TypeScriptDefs/angular-ui-router.d.ts" />﻿
/// <reference path="../../../Resources/TypeScriptDefs/jasmine-2.2.d.ts" />﻿
/// <reference path="../../../Resources/TypeScriptDefs/observe-polyfill-0.5.6.d.ts" />﻿
/// <reference path="../../../Resources/TypeScriptDefs/es6-promise.d.ts" />﻿
/// <reference path="../../../Resources/TypeScriptDefs/CompeatTypes-1.0.d.ts" />
/// <reference path="../../../BuildOutputs/Compeat.Core/Scripts/cmp-js.d.ts" />﻿
/// <reference path="../../../BuildOutputs/Compeat.Core/Scripts/cmp-rpt.d.ts" />﻿