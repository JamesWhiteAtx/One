﻿/// <reference path="../common-refs.d.ts" />﻿

describe("Cmp.Ui.ReportParameter-rpt", function () {

	it("Constructor", function (done) {
		var testParam = new Cmp.Ui.ReportModels.ReportParameter("test", "testVal");
		expect(testParam.Name).toBe("test");
		expect(testParam.Value).toBe("testVal");
		done();
	});

});