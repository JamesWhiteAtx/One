﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Compeat.Mvc.Reports
{
	public class InvalidDrillThroughException : Exception
	{

		public InvalidDrillThroughException()
			: base("Unrecognized drill-through report selection.")
		{

		}
	}
}
