﻿using Compeat.SharedLib.DevExpress;
using DevExpress.XtraReports.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Compeat.Mvc.Reports.Models
{
	public class ReportModel<TReportBase>
		where TReportBase : XtraReport, IDrillThroughXtraReport<TReportBase>
	{

		/// <summary>
		/// The class name of the report to render
		/// </summary>
		public string ReportName { get; set; }

		/// <summary>
		/// The report created by the model consturctor
		/// </summary>
		public TReportBase Report { get; set; }

		/// <summary>
		/// The title of the report
		/// </summary>
		public string ReportTitle { get; set; }

		public string CsrfToken { get; set; }

		/// <summary>
		/// Creates a report and sets it's parameters based on the supplied collection
		/// </summary>
		public ReportModel(ReportRequestModel request, Type reportType)
			: this(request.ReportName, reportType)
		{
			this.CsrfToken = request.CsrfToken;
			if (Report != null)
			{
				// initialize the available parameters on the report from those supplied through the request
				foreach (var parameter in Report.Parameters)
				{
					if (request.ReportParameters != null)
					{
						var providedParam = request.ReportParameters.FirstOrDefault(x => x.Name.Equals(parameter.Name, StringComparison.InvariantCultureIgnoreCase));
						if (providedParam != null)
						{
							parameter.Value = providedParam.Value;
						}
					}
					// hide all parameters to ensure the parameter chooser is not presented.
					parameter.Visible = false;
				}
			}
		}

		/// <summary>
		/// Creates an uninitialized report based on the provided type
		/// </summary>
		public ReportModel(string reportName, Type reportType)
		{
			this.ReportName = reportName;
			this.Report = (TReportBase)Activator.CreateInstance(reportType);
			this.ReportTitle = (Report != null) ? Report.DisplayName : string.Empty;
		}

		/// <summary>
		/// Creates an uninitialized model, for externally building the page model (drill-through)
		/// </summary>
		public ReportModel() { }

	}
}
