﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Compeat.Mvc.Reports.Models
{

	public class ReportRequestModel
	{

		public string ReportName { get; set; }
		public ReportParameter[] ReportParameters { get; set; }
		public string CsrfToken { get; set; }
	}
}
