﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Compeat.Mvc.Reports.Models
{

	public class DrillThroughReportRequestModel : ReportRequestModel
	{
		public string DrillThroughTag { get; set; }
	}
}
