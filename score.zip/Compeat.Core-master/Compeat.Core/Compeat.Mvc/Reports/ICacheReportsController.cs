﻿using DevExpress.XtraReports.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Mvc.Reports
{
	public interface ICacheReportsController
	{
		/// <summary>
		/// Writes a rendered XtraReport to the database.
		/// </summary>
		void CacheReportDocument(CacheReportDocumentEventArgs args);

		/// <summary>
		/// Restores a rendered XtraReport from the database.
		/// </summary>
		void RestoreReportDocumentFromCache(RestoreReportDocumentFromCacheEventArgs args);
	}
}
