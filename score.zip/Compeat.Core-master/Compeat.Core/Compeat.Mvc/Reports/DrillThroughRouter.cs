﻿using Compeat.Mvc.Reports.Models;
using Compeat.SharedLib.DevExpress;
using DevExpress.XtraReports.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Compeat.Mvc.Reports
{

	public class DrillThroughRouter<TReportBase>
		where TReportBase : XtraReport, IDrillThroughXtraReport<TReportBase>
	{

		/// <summary>
		/// The drill through request is the source report's information, the destination drill through
		/// will be determined by drillThroughRequest.drillThroughTag
		/// </summary>
		public virtual ReportModel<TReportBase> GetDrillThroughRequest(DrillThroughReportRequestModel drillThroughRequest, Type reportType)
		{

			if ((drillThroughRequest != null))
			{
				// will create the model with initialized parameters
				var sourceReportModel = new ReportModel<TReportBase>(drillThroughRequest, reportType);

				var newReport = sourceReportModel.Report.GetDrillThroughReport(drillThroughRequest.DrillThroughTag);
				if (newReport != null)
				{

					return new ReportModel<TReportBase>()
					{
						Report = newReport,
						ReportName = newReport.GetType().Name,
						ReportTitle = newReport.DisplayName,
						CsrfToken = drillThroughRequest.CsrfToken
					};
				}
			}

			throw new InvalidDrillThroughException();
		}
	}
}
