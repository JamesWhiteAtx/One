﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using Compeat.Service;
using System.ComponentModel.Composition;
using Compeat.Service.Interfaces;

namespace Compeat.Mvc
{
	/// <summary>
	/// A custom authorization attribute that inspects request headers for a csrf token and compares them to a hash
	/// of some components of the Owin auth cookie.
	/// </summary>
	[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, Inherited = true, AllowMultiple = true)]
	public class CmpAuthorizeAttribute : System.Web.Mvc.AuthorizeAttribute
	{

		[ImportAttribute]
		public IIdentityManager IdentityManager { get; set; }

		public CmpAuthorizeAttribute()
		{
			Order = 0;
		}

		public const string CSRF_KEY = "token";

		protected override bool AuthorizeCore(HttpContextBase httpContext)
		{

			var isAuthorized = base.AuthorizeCore(httpContext);

			if (isAuthorized)
			{
				if (httpContext != null)
				{
					var token = httpContext.Request.Headers[CSRF_KEY];
					if (token != null)
					{
						return IdentityManager.CsrfToken == token;
					}
				}
			}

			return false;
		}
	}
}
