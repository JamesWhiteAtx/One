﻿using System.Web.Mvc;
using Compeat.Service;
using Compeat.Service.Authentication;
using Compeat.Service.Interfaces;

namespace Compeat.Mvc.BaseControllers
{
	public abstract class BaseAuthenticationController<TModel> : BaseController
	{
		protected IIdentityManager IdentityManager { get; set; }
		public BaseAuthenticationController(IInjectionContainer injection, IIdentityManager _identityManager)
			: base(injection)
		{
			this.IdentityManager = _identityManager;
		}

		protected abstract AuthResultTypes ProcessLogin(TModel model);
		protected abstract string GetCsrfToken(TModel model);

		[HttpPost]
		[AllowAnonymous]
		public ActionResult Login(TModel model)
		{
			var authResult = ProcessLogin(model);
			AuthResult result = null;
			if (AuthResult.IsResultAuthenticated(authResult))
			{
				result = new AuthResult(authResult, GetCsrfToken(model));
			}
			else
			{
				result = new AuthResult(authResult);
			}

			return Json(result);
		}

		[HttpPost]
		[AllowAnonymous]
		public ActionResult LogOff()
		{
			IdentityManager.SignOut();
			return new EmptyResult();
		}

		[AllowAnonymous]
		public ActionResult GetToken()
		{
			// manually test the authorization state here to bypass AdvAuthorize
			if (IdentityManager.IsAuthenticated)
			{
				return Content(IdentityManager.CsrfToken);
			}
			else
			{
				return new HttpUnauthorizedResult();
			}
		}

	}
}
