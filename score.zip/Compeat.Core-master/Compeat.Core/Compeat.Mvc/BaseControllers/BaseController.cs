﻿using System;
using System.Web.Mvc;
using Compeat.Service;
using Compeat.Resources;
using Compeat.SharedLib.Utilities;
using SimpleInjector;
using Compeat.Service.Interfaces;

namespace Compeat.Mvc.BaseControllers
{
	[CmpAuthorize, CmpHeader]
	public abstract class BaseController : Controller
	{

		private CmpSqlErrorLog _cmpSqlErrorLog;

		public BaseController(IInjectionContainer injection)
		{
			_cmpSqlErrorLog = injection.GetInstance<CmpSqlErrorLog>();
		}

		/// <summary>
		/// This method will wrap a block of code with the standard AjaxPostResponse structures
		/// to return the correct Json result.
		/// </summary>
		/// <param name="codeToRun">The code to run</param>
		/// <returns>A JsonResult containing either the success or failure result</returns>
		protected JsonResult GetStandardJsonResult(Action<IAjaxPostResponse> codeToRun, bool displayGenericErrorMsg = true)
		{
			var response = AjaxPostResponse.StandardErrorResponse();

			try
			{
				response.Message = ResourceStrings.StandardAjaxSuccessMessage;
				response.Succeeded = true;

				codeToRun(response);
			}
			catch (Exception e)
			{
				// log this error to elmah
				_cmpSqlErrorLog.Log(new Elmah.Error(e));

				response.Succeeded = false;

				if (displayGenericErrorMsg)
					response.Message = ResourceStrings.StandardAjaxFailureMessage;
				else
					response.Message = e.GetInnerMostExceptionMessage();
			}

			return Json(response);
		}

	}
}
