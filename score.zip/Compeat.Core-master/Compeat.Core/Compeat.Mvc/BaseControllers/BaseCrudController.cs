﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using Compeat.Service;
using Compeat.SharedLib.Utilities;
using Compeat.Service.Interfaces;
namespace Compeat.Mvc.BaseControllers
{

	public abstract class BaseCrudController<TModel, TModelKeyType, TDtoType, TServiceType, TRightsType> : BaseSavableController<TModel, TDtoType, TServiceType, TRightsType>
		where TModel : ICrudBo
		where TServiceType : ICrudService<TModel, TModelKeyType, TDtoType>
		where TRightsType : struct, IConvertible
	{
		public BaseCrudController(IInjectionContainer injection, TServiceType service)
			: base(injection, service)
		{
		}

		/// <summary>
		/// Gets a single model for the provided record key value
		/// </summary>
		[HttpPost]
		public virtual ActionResult GetById(TModelKeyType id, string[] collectionsToLoad, bool? loadAllCollections, int? loadAllCollectionsDepth)
		{
			return GetResult(ReadRight, () => { return CrudService.GetById(id, 
				loadAllCollections.GetValueOrDefault(false) ? collectionsToLoad : null, 
				loadAllCollections.GetValueOrDefault(false), loadAllCollectionsDepth.GetValueOrDefault(1)); });
		}

		/// <summary>
		/// Deletes the record with the given record key value, returns error state back to the client.
		/// </summary>
		[HttpPost]
		public virtual ActionResult Delete(TModelKeyType id)
		{
			return GetResult(UpdateRight, () => { return CrudService.Delete(id); });
		}
	}
}
