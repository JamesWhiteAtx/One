﻿using Compeat.Mvc.Reports;
using Compeat.Mvc.Reports.Models;
using Compeat.Service;
using Compeat.Service.BaseServices;
using Compeat.Service.Interfaces;
using Compeat.Service.Models;
using Compeat.SharedLib.DevExpress;
using Compeat.SharedLib.Utilities;
using DevExpress.XtraReports.UI;
using DevExpress.XtraReports.Web;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace Compeat.Mvc.BaseControllers
{
	// The reports will be loaded into a new window and will not have access to the default parameters supplied through 
	// the ember http posts.  Data will instead be supplied through the reportParameters
	[Authorize]
	public abstract class BaseReportsController<TReportBase, TRights> : Controller, ICacheReportsController
		where TReportBase : XtraReport, IDrillThroughXtraReport<TReportBase>
		where TRights : struct, IConvertible // attempt to replicate 'enum' type
	{
		protected IIdentityManager IdentityManager { get; set; }
		protected IReportCacheService Cacheservice { get; set; }

		/// <summary>
		/// Override to provide the list of known reports and their security requirement
		/// </summary>
		protected abstract Dictionary<string, ReportRegistration> RegisteredReports { get; }

		/// <summary>
		/// Override to provide the security tests for the right
		/// </summary>
		protected abstract bool HasRight(TRights right);

		public BaseReportsController(IIdentityManager _identityManager, IReportCacheService _cacheservice)
		{
			this.IdentityManager = _identityManager;
			this.Cacheservice = _cacheservice;
		}

		[HttpPost]
		public ActionResult Report(string request)
		{
			try
			{

				var requestModel = new JsonHelper().Deserialize<ReportRequestModel>(request);

				if (requestModel != null
					&& IdentityManager.CsrfToken != requestModel.CsrfToken)
				{

					return new HttpUnauthorizedResult();
				}
				else
				{
					var registration = RegisteredReports[requestModel.ReportName];
					if (!registration.RequiredRight.HasValue || HasRight(registration.RequiredRight.Value))
					{
						var pageModel = new ReportModel<TReportBase>(requestModel, registration.ReportType);
						return View(pageModel);
					}
					else
					{
						return new HttpUnauthorizedResult();
					}
				}
			}
			catch (Exception ex)
			{
#if DEBUG
				System.Diagnostics.Debug.WriteLine(ex.GetInnerMostExceptionMessage());
#endif
				return new HttpNotFoundResult();
			}
		}

		public ActionResult DocumentViewerPartial(string reportName)
		{
			try
			{
				var registration = RegisteredReports[reportName];

				if (!registration.RequiredRight.HasValue || HasRight(registration.RequiredRight.Value))
				{
					var reportModel = new ReportModel<TReportBase>(reportName, registration.ReportType);
					return PartialView("documentViewerPartial", reportModel);
				}
				else
				{
					return new HttpUnauthorizedResult();
				}
				
			}
			catch
			{
				return new HttpNotFoundResult();
			}
		}

		public ActionResult ExportDocumentViewer(string reportName)
		{
			try
			{
				var registration = RegisteredReports[reportName];
				if (!registration.RequiredRight.HasValue || HasRight(registration.RequiredRight.Value))
				{
					var reportModel = new ReportModel<TReportBase>(reportName, registration.ReportType);
					return GetExportFileResult(reportModel);
				}
				else
				{
					return new HttpUnauthorizedResult();
				}
			}
			catch
			{
				return new HttpNotFoundResult();
			}
		}

		// DocumentViewerExtension is not testable, this allows for the unit test replacement of that component
		protected virtual FileResult GetExportFileResult(ReportModel<TReportBase> reportModel)
		{
			return DevExpress.Web.Mvc.DocumentViewerExtension.ExportTo(reportModel.Report);
		}

		[HttpPost]
		public ActionResult DrillThrough(string request)
		{
			try
			{
				var requestModel = new JsonHelper().Deserialize<DrillThroughReportRequestModel>(request);

				if (requestModel != null
					&& IdentityManager.CsrfToken != requestModel.CsrfToken)
				{
					return new HttpUnauthorizedResult();
				}
				else
				{
					var registration = RegisteredReports[requestModel.ReportName];
					if (!registration.RequiredRight.HasValue || HasRight(registration.RequiredRight.Value))
					{
						var drillThroughReportModel = (new DrillThroughRouter<TReportBase>()).GetDrillThroughRequest(requestModel, registration.ReportType);
						return View("report", drillThroughReportModel);
					}
					else
					{
						return new HttpUnauthorizedResult();
					}
				}
			}
			catch
			{
				return new HttpNotFoundResult();
			}
		}


		/// <summary>
		/// Writes a rendered XtraReport to the database.
		/// </summary>
		public void CacheReportDocument(CacheReportDocumentEventArgs args)
		{

			var cacheId = Guid.NewGuid();
			MemoryStream ms = null;
			try
			{
				ms = args.SaveDocumentToMemoryStream();

				var model = new CachedReportModel()
				{
					Id = cacheId,
					CacheContents = ms.ToArray()
				};

				Cacheservice.CacheReport(model);

				args.Key = cacheId.ToString();
			}
			finally
			{
				if (ms != null)
				{
					ms.Dispose();
				}
			}
		}

		/// <summary>
		/// Restores a rendered XtraReport from the database.
		/// </summary>
		public void RestoreReportDocumentFromCache(RestoreReportDocumentFromCacheEventArgs args)
		{

			if (!args.Key.IsEmpty())
			{
				var model = Cacheservice.GetCachedReport(new Guid(args.Key));

				if (model.CachedReportFound)
				{
					// memory stream needs to be left open here, RestoreDcoumentFromStream won't be done with it yet.
					var ms = new MemoryStream(model.CacheContents);
					args.RestoreDocumentFromStream(ms);
				}
			}
		}

		/// <summary>
		/// Describes a known report
		/// </summary>
		public class ReportRegistration
		{
			/// <summary>
			/// The type of the report that will be constructed on request
			/// </summary>
			public Type ReportType { get; set;  }

			/// <summary>
			/// The right that will be tested during report execution
			/// </summary>
			public TRights? RequiredRight { get; set; }

			public ReportRegistration(Type reportType, TRights? requiredRight)
			{
				ReportType = reportType;
				RequiredRight = requiredRight;
            }
		}
	}
}
