﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using Compeat.Service;
using Compeat.SharedLib.Utilities;
using Compeat.Service.Interfaces;
using Compeat.Service.BaseServices;

namespace Compeat.Mvc.BaseControllers
{

	public abstract class BaseSavableController<TModel, TDtoType, TServiceType, TRightType> : BaseController
		where TModel : ISavableBo
		where TServiceType : ISavableService<TModel, TDtoType>
		where TRightType : struct, IConvertible
	{
		protected ISessionService<TRightType> SessionService { get; set; }
		protected IIdentityManager BaseIdentityManager { get; set; }
		protected TServiceType CrudService { get; set; }

		public BaseSavableController(IInjectionContainer injection, TServiceType service)
			: base(injection)
		{
			BaseIdentityManager = injection.GetInstance<IIdentityManager>();
			SessionService = injection.GetInstance<ISessionService<TRightType>>();
			CrudService = service;
		}

		/// <summary>
		/// Override to provide a security option to be tested for read operations
		/// </summary>
		public virtual TRightType? ReadRight { get { return null; } }

		/// <summary>
		/// Override to provide a security opeion for write operations, will default to readRight
		/// </summary>
		public virtual TRightType? UpdateRight { get { return ReadRight; } }

		/// <summary>
		/// Saves the provided model, returns error state back to the client.
		/// </summary>
		[HttpPost]
		public virtual ActionResult Save(TModel model)
		{
			return GetResult(UpdateRight, () => { return CrudService.Save(model); });
		}

		protected ActionResult GetResult<TResultType>(TRightType? requiredRight, Func<TResultType> resultFetch)
		{
			if (!requiredRight.HasValue || SessionService.HasRight(requiredRight.Value))
			{
				var result = resultFetch();
				if (result != null)
				{
					return Json(result);
				}
				else
				{
					return new EmptyResult();
				}
			}
			else
			{
				return new HttpStatusCodeResult(HttpStatusCode.Forbidden);
			}
		}

	}
}
