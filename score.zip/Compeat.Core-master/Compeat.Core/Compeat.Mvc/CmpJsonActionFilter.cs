﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace Compeat.Mvc
{
	internal class CmpJsonActionFilter : ActionFilterAttribute
	{
		public override void OnActionExecuted(ActionExecutedContext filterContext)
		{
			if (filterContext.Result.GetType() == typeof(JsonResult))
			{
				// Get the standard result object with unserialized data
				JsonResult result = filterContext.Result as JsonResult;

				// Replace it with our new result object and transfer settings
				filterContext.Result = new CmpJsonResult
				{
					ContentEncoding = result.ContentEncoding,
					ContentType = result.ContentType,
					Data = result.Data,
					JsonRequestBehavior = result.JsonRequestBehavior
				};

				// Later on when ExecuteResult will be called it will be the
				// function in JsonNetResult instead of in JsonResult
			}
			base.OnActionExecuted(filterContext);
		}
	}
	internal class CmpJsonResult : JsonResult
	{
		private static readonly JsonSerializerSettings Settings = new JsonSerializerSettings
		{
			NullValueHandling = NullValueHandling.Ignore
		};

		public override void ExecuteResult(ControllerContext context)
		{
			if (this.JsonRequestBehavior == JsonRequestBehavior.DenyGet &&
					string.Equals(context.HttpContext.Request.HttpMethod, "GET", StringComparison.OrdinalIgnoreCase))
			{
				throw new InvalidOperationException("GET request not allowed");
			}

			var response = context.HttpContext.Response;

			response.ContentType = !string.IsNullOrEmpty(this.ContentType) ? this.ContentType : "application/json";

			if (this.ContentEncoding != null)
			{
				response.ContentEncoding = this.ContentEncoding;
			}

			if (this.Data == null)
			{
				return;
			}

			response.Write(JsonConvert.SerializeObject(this.Data, Settings));
		}
	}

}
