﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Mvc
{
	public class JsonHelper
	{

		/// <summary>
		/// Deserializes the string into the desired type.
		/// </summary>
		public T Deserialize<T>(string source)
		{

			using (var tr = new StringReader(source))
			{
				var serializer = JsonSerializer.Create();
				var obj = (T)serializer.Deserialize(tr, typeof(T));
				return obj;
			}
		}

	}
}
