﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compeat.Mvc.Interfaces
{
	public interface IHttpHeader
	{
		/// <summary>
		/// implemented by the consumer, takes the values from the name val collection and loads up a container object
		/// must be implemented by the consumer since their container object will differ
		/// </summary>
		void LoadFromRequest(System.Collections.Specialized.NameValueCollection headerValues);
		
	}
}
