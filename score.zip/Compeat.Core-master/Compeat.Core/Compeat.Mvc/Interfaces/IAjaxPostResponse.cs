﻿using System;
using System.Collections.Generic;

namespace Compeat.Mvc
{
	public interface IAjaxPostResponse
	{
		Dictionary<string, string> ColumnValues { get; set; }
		object Data { get; set; }
		string Message { get; set; }
		string ResponseData { get; set; }
		string RedirectUrl { get; set; }
		bool SessionExpired { get; set; }
		bool Succeeded { get; set; }

		/// <summary>
		/// Go to this angular relative path when the action succeeds
		/// </summary>
		string SuccessPath { get; set; }

		/// <summary>
		/// Go to this angular relative path when the action fails
		/// </summary>
		string FailurePath { get; set; }
	}
}
