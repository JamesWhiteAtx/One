﻿using System.IO;
using System.Web;
using System.Web.Mvc;

namespace Compeat.Mvc.Razor
{
	/// <summary>
	/// Heplper extensions to emit html in razor pages
	/// </summary>
	public static class RazorExtensions
	{
		/// <summary>
		/// Extension method to indicate if the application was built in debug mode
		/// </summary>
		/// <param name="helper"></param>
		/// <returns>bool</returns>
		public static bool IsDebug(this HtmlHelper helper)
		{
#if DEBUG
			return true;
#else
			return false;
#endif
		}

		/// <summary>
		/// Extension method to returns a string version of JavaScripts boolean indicating if application was built in debug mode
		/// </summary>
		/// <param name="helper"></param>
		/// <returns>HtmlString</returns>
		public static HtmlString IsDebugJsBool(this HtmlHelper helper)
		{
			return new HtmlString(helper.IsDebug() ? "true" : "false");
		}

		/// <summary>
		/// Extension method returning string version of the current assembly version
		/// </summary>
		/// <param name="helper"></param>
		/// <returns>HtmlString</returns>
		public static HtmlString AssemblyVersion(this HtmlHelper helper)
		{
			var appInstance = helper.ViewContext.HttpContext.ApplicationInstance;
			var assemblyVersion = appInstance.GetType().BaseType.Assembly.GetName().Version;
			return new HtmlString(assemblyVersion.ToString());
		}

		/// <summary>
		/// Extension method to convert a url based on if debug or not, and the current assembly version
		/// </summary>
		/// <param name="helper"></param>
		/// <param name="basePath"></param>
		/// <param name="extType"></param>
		/// <param name="useMinIfDebug"></param>
		/// <returns></returns>
		private static string urlVersionExt(this HtmlHelper helper, string basePath, string extType, bool useMinIfDebug, bool isDebug)
		{
			string ext = ((useMinIfDebug && !isDebug) ? ".min." : ".") + extType;

			var urlHelper = new UrlHelper(helper.ViewContext.RequestContext);

			string path = urlHelper.Content(Path.ChangeExtension(basePath, ext));

			if (!isDebug)
			{
				path = string.Format("{0}?v={1}", path, helper.AssemblyVersion());
			}

			return path;
		}

		/// <summary>
		/// Extension method provide a script tag based on if debug or not, and the current assembly version
		/// </summary>
		/// <param name="helper"></param>
		/// <param name="basePath"></param>
		/// <param name="useMinIfDebug"></param>
		/// <returns></returns>
		public static HtmlString VersionScriptTag(this HtmlHelper helper, string basePath, bool useMinIfDebug = true)
		{
			return VersionScriptTag(helper, basePath, useMinIfDebug, helper.IsDebug());
        }

		/// <summary>
		/// Testable Extension method provide a script tag based on if debug or not, and the current assembly version
		/// </summary>
		/// <param name="helper"></param>
		/// <param name="basePath"></param>
		/// <param name="useMinIfDebug"></param>
		/// <returns></returns>
		public static HtmlString VersionScriptTag(this HtmlHelper helper, string basePath, bool useMinIfDebug, bool isDebug)
		{
			var path = helper.urlVersionExt(basePath, "js", useMinIfDebug, isDebug);

			string scriptFormat = "<script type='text/javascript' src='{0}'></script>";

			return new HtmlString(string.Format(scriptFormat, path));
		}

		/// <summary>
		/// Extension method provide a style link tag based on if debug or not, and the current assembly version
		/// </summary>
		/// <param name="helper"></param>
		/// <param name="basePath"></param>
		/// <param name="useMinIfDebug"></param>
		/// <returns></returns>
		public static HtmlString VersionStyleTag(this HtmlHelper helper, string basePath, bool useMinIfDebug = true)
		{
			return VersionStyleTag(helper, basePath, useMinIfDebug, helper.IsDebug());
		}

		/// <summary>
		/// Testable Extension method provide a style link tag based on if debug or not, and the current assembly version
		/// </summary>
		/// <param name="helper"></param>
		/// <param name="basePath"></param>
		/// <param name="useMinIfDebug"></param>
		/// <returns></returns>
		public static HtmlString VersionStyleTag(this HtmlHelper helper, string basePath, bool useMinIfDebug, bool isDebug)
		{
			var path = helper.urlVersionExt(basePath, "css", useMinIfDebug, isDebug);

			string scriptFormat = "<link href='{0}' rel='stylesheet'>";

			return new HtmlString(string.Format(scriptFormat, path));
		}

		public static HtmlString Testy(this HtmlHelper helper, bool debug, string basePath, bool useMinIfDebug = true)
		{
			return new HtmlString(debug.ToString());
		}

		public static HtmlString Testy(this HtmlHelper helper, string basePath, bool useMinIfDebug = true)
		{
			return helper.Testy(helper.IsDebug(), basePath, useMinIfDebug);
        }

	}
}
