﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Compeat.SharedLib.Utilities;
using Compeat.Resources;

namespace Compeat.Mvc
{
	//used just to pass a result back to the ajax action with expected field names
	public class AjaxPostResponse : IAjaxPostResponse
	{
		public string Message { get; set; }
		public object Data { get; set; }
		public bool Succeeded { get; set; }
		public bool SessionExpired { get; set; }
		public string RedirectUrl { get; set; }

		/// <summary>
		/// Go to this angular relative path when the action succeeds
		/// </summary>
		public string SuccessPath { get; set; }

		/// <summary>
		/// Go to this angular relative path when the action fails
		/// </summary>
		public string FailurePath { get; set; }

		//used when there is a single object with a collection of column values to show
		public Dictionary<string, string> ColumnValues { get; set; }
		//used when there is a collection of values that are represented as a JSon object
		public string ResponseData { get; set; }

		public static string StandardSuccessMessage { get { return ResourceStrings.StandardAjaxSuccessMessage; } }
		public static string StandardFailureMessage { get { return ResourceStrings.StandardAjaxFailureMessage; } }

		public static IAjaxPostResponse StandardErrorResponse()
		{
			return new AjaxPostResponse
			{
				Message = StandardFailureMessage,
				Succeeded = false,
				SessionExpired = false
			};
		}

		public static IAjaxPostResponse StandardSuccessResponse(string msg = "", object data = null)
		{
			if (msg.IsEmpty())
				msg = StandardSuccessMessage;

			return new AjaxPostResponse
			{
				Message = msg,
				Data = data,
				Succeeded = true,
				SessionExpired = false
			};
		}

		public static IAjaxPostResponse StandardSessionExpiredResponse(string redirectUrl = null)
		{
			return new AjaxPostResponse
			{
				Message = ResourceStrings.SessionExpired,
				Succeeded = false,
				SessionExpired = true,
				RedirectUrl = redirectUrl
			};
		}
	}
}
