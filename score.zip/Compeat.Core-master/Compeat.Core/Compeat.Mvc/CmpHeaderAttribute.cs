﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using Compeat.Service;
using System.ComponentModel.Composition;
using Compeat.Service.Interfaces;
using Compeat.Mvc.Interfaces;
using System.Web.Mvc;

namespace Compeat.Mvc
{
	/// <summary>
	/// A custom authorization attribute that inspects request headers for a csrf token and compares them to a hash
	/// of some components of the Owin auth cookie.
	/// </summary>
	[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, Inherited = true, AllowMultiple = true)]
	public class CmpHeaderAttribute : System.Web.Mvc.ActionFilterAttribute
	{

		[ImportAttribute]
		public IHttpHeader HttpHeader { get; set; }

		public CmpHeaderAttribute()
		{ }

		public override void OnActionExecuting(ActionExecutingContext filterContext)
		{
			if (filterContext != null && 
				filterContext.RequestContext != null && 
				filterContext.RequestContext.HttpContext != null && 
				filterContext.RequestContext.HttpContext.Request != null)
			{
				HttpHeader.LoadFromRequest(filterContext.RequestContext.HttpContext.Request.Headers);
			}
		}
	}
}
