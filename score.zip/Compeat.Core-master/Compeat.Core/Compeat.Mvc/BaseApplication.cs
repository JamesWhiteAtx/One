﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using Compeat.Data;
using Compeat.Service;
using Microsoft.AspNet.Identity;
using Microsoft.Owin;
using Microsoft.Owin.Security.Cookies;
using Owin;
using SimpleInjector;
using SimpleInjector.Advanced;
using System.Reflection;
using System.ComponentModel.Composition;
using SimpleInjector.Integration.Web.Mvc;
using Compeat.Service.Interfaces;
using Elmah;
using System.Web;
using System.ComponentModel.Design;
using System.IO;
using System.Net;
using SimpleInjector.Integration.Web;
using Compeat.Mvc.Interfaces;

namespace Compeat.Mvc
{
	public class InjectionContainer<TApplicationInfo, TConnManager, TConnStringProvider, TIdentityManager, TReportCacheService, THttpHeader> : IInjectionContainer
		where TApplicationInfo : class, IApplicationInfo
		where TConnManager : class, IConnectionManager
		where TConnStringProvider : class, IConnectionStringProvider
		where TIdentityManager : class, IIdentityManager
		where TReportCacheService : class, IReportCacheService
		where THttpHeader : class, IHttpHeader
	{

		public Container Container
		{
			get
			{
				return BaseApplication<TApplicationInfo, TConnManager, TConnStringProvider, TIdentityManager, TReportCacheService, THttpHeader>.Container;
			}
		}

		/// <summary>
		/// shortcut to the simpleinjector call of the same signature
		/// </summary>
		public TService GetInstance<TService>()
			where TService : class
		{
			return Container.GetInstance<TService>();
		}

		/// <summary>
		/// shortcut to the simpleinjector call of the same signature
		/// </summary>
		public object GetInstance(Type serviceType)
		{
			return Container.GetInstance(serviceType);
		}
	}

	public abstract class BaseApplication<TApplicationInfo, TConnManager, TConnStringProvider, TIdentityManager, TReportCacheService, THttpHeader> : System.Web.HttpApplication
		where TApplicationInfo : class, IApplicationInfo
		where TConnManager : class, IConnectionManager
		where TConnStringProvider : class, IConnectionStringProvider
		where TIdentityManager : class, IIdentityManager
		where TReportCacheService : class, IReportCacheService
		where THttpHeader: class, IHttpHeader
	{
		public static Container Container { get; private set; }

		protected void Application_Start()
		{
			CmpPreInjection();

			Container = new Container();

			// property injection, this option must happen before anything is registered
			Container.Options.PropertySelectionBehavior = new ImportPropertySelectionBehavior();
			Container.Options.DefaultScopedLifestyle = new WebRequestLifestyle();

			//bases
			Container.Register<IApplicationInfo, TApplicationInfo>(Lifestyle.Singleton);

			Container.Register<IIdentityManager, TIdentityManager>(Lifestyle.Singleton);
			Container.Register<IConnectionStringProvider, TConnStringProvider>(Lifestyle.Singleton);

			// the connection manager should have a per-request scope
			Container.Register<IConnectionManager, TConnManager>(Lifestyle.Scoped);
			Container.Register<IReportCacheService, TReportCacheService>(Lifestyle.Scoped);
			Container.Register<IHttpHeader, THttpHeader>(Lifestyle.Scoped);

			Container.Register<IInjectionContainer, InjectionContainer<TApplicationInfo, TConnManager, TConnStringProvider, TIdentityManager, TReportCacheService, THttpHeader>>(Lifestyle.Singleton);

			//mvc stuff
			Container.RegisterMvcIntegratedFilterProvider();
			Container.RegisterMvcControllers(System.Reflection.Assembly.GetExecutingAssembly());

			// custom Elmah error logger
			Container.Register<CmpSqlErrorLog, CmpSqlErrorLog>(Lifestyle.Singleton);

			Container.Register<CmpModelBinder, CmpModelBinder>(Lifestyle.Transient);

			//custom
			CmpInjection();

			Container.Verify();
			//done
			//hook in simple injector
			DependencyResolver.SetResolver(new SimpleInjectorDependencyResolver(Container));

			//setup custom json deserialization hooks
			//***************** refer to CF-238 start
			//var existingJsonFactory = ValueProviderFactories.Factories.OfType<JsonValueProviderFactory>().FirstOrDefault();
			//if (existingJsonFactory != null)
			//{
			//	ValueProviderFactories.Factories.Remove(ValueProviderFactories.Factories.OfType<JsonValueProviderFactory>().FirstOrDefault());
			//}
			//ValueProviderFactories.Factories.Add(new CmpJsonValueProviderFactory());
			//***************** refer to CF-238 start


			//setup model binder so BOs can be injected
			ModelBinders.Binders.DefaultBinder = Container.GetInstance<CmpModelBinder>();

			//global filters
			GlobalFilters.Filters.Add(new HandleErrorAttribute());
			GlobalFilters.Filters.Add(new CmpJsonActionFilter());

			// Initialize the Elmah log provider, needs to be after the DependencyResolver is initialized
			ServiceCenter.Current = ElmahServiceProvider;

			CmpPostInjection();
		}


		protected abstract void CmpPreInjection();
		protected abstract void CmpInjection();
		protected abstract void CmpPostInjection();
		protected abstract bool CmpValidateCookie(CookieValidateIdentityContext context);

		//owin config
		public void Configuration(IAppBuilder app)
		{
			var provider = new CookieAuthenticationProvider();
			provider.OnValidateIdentity = (context) =>
			{
				var ret = Task.Run(() =>
				{

					// we'll re-validate the token ever 15 minutes and replace it with a new issue if it is still good.
					var retestSecurityToken = !context.Properties.IssuedUtc.HasValue
						|| context.Properties.IssuedUtc.Value.AddMinutes(15) < DateTime.UtcNow;

					if (retestSecurityToken)
					{
						var isValid = CmpValidateCookie(context);

						if (isValid)
						{
							context.OwinContext.Authentication.SignIn(context.Identity);
						}
						else
						{
							context.RejectIdentity();
							context.OwinContext.Authentication.SignOut(context.Options.AuthenticationType);
						}
					}
				});
				return ret;
			};


			app.UseCookieAuthentication(new CookieAuthenticationOptions
			{
				AuthenticationType = DefaultAuthenticationTypes.ApplicationCookie,
				ExpireTimeSpan = TimeSpan.FromHours(24),
				LoginPath = new PathString(""),
				Provider = provider
			});
		}

		private class ImportPropertySelectionBehavior : IPropertySelectionBehavior
		{
			public bool SelectProperty(Type type, PropertyInfo prop)
			{
				return prop.GetCustomAttributes(typeof(ImportAttribute)).Count() > 0;
			}
		}

		// elmah log provider, this is the only hook available for providing an injected service
		private static IServiceProvider ElmahServiceProvider(object context)
		{
			var container = new ServiceContainer(context as IServiceProvider);
			// the type really needs to be ErrorLog here, not the descendant class
			container.AddService(typeof(ErrorLog), DependencyResolver.Current.GetService<CmpSqlErrorLog>());
			return container;
		}

		/// <summary>
		/// Override to add additional errors that should be ignored by the Elmah logger.
		/// A true value indicates that the event should not be logged.
		/// </summary>
		protected virtual bool ErrorShouldBeFiltered(ExceptionFilterEventArgs e)
		{
			var baseException = e.Exception.GetBaseException();

			// ignored exception types
			if (baseException is HttpRequestValidationException
				|| baseException is FileNotFoundException)
			{
				return true;
			}
			// ignored http exception status codes
			else if (baseException is HttpException)
			{
				var code = (baseException as HttpException).GetHttpCode();
				if (code == (int)HttpStatusCode.NotFound
					|| code == (int)HttpStatusCode.Unauthorized)
				{
					return true;
				}
			}
			// exceptions ignored due to the context of the exception
			else if (e.Context != null
				&& e.Context is HttpContext)
			{
				var httpContext = e.Context as HttpContext;
				// ignore web crawlers
				if (httpContext.Request != null
					&& httpContext.Request.UserAgent != null
					&& httpContext.Request.UserAgent.ToLower().Contains("crawler"))
				{
					return true;
				}
			}
			else if (ErrorShouldBeFiltered(e))
			{
				return true;
			}

			return false;
		}

	}

}
