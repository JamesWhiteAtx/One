﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using Compeat.Service.Interfaces;
namespace Compeat.Mvc
{
	internal class CmpModelBinder : DefaultModelBinder
	{
		private IInjectionContainer InjectionContainer {get; set;}
		public CmpModelBinder(IInjectionContainer injection)
		{
			InjectionContainer = injection;
		}
		protected override object CreateModel(ControllerContext controllerContext, ModelBindingContext bindingContext, Type modelType)
		{
			if (typeof(ICrudBo).IsAssignableFrom(modelType) || typeof(ISavableBo).IsAssignableFrom(modelType))
			{
				var instance = Convert.ChangeType(InjectionContainer.Container.GetInstance(modelType), modelType);
				bindingContext.ModelMetadata = ModelMetadataProviders.Current.GetMetadataForType(() => instance, modelType);
				return instance;
			}
			else
			{
				return base.CreateModel(controllerContext, bindingContext, modelType);
			}
		}
	}
}
