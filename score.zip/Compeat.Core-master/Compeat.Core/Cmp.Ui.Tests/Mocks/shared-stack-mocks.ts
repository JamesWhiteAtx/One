﻿/// <reference path="../common-refs.d.ts" />

namespace Tests.StackMocks {
	export var DateFormat: string = 'M/D/YYYY';

    /** An empty mock BaseTools service */
    export function MockBaseTools() {
        var service: Cmp.Ui.Services.IBaseTools = {

            RefreshObservers: (): cmp.IPromise<any> => { return null },
            CreateInstance: <T>(classObj: Function): T => {
                return <T>{};
            },
            CmpPromise: Cmp.Ui.Services.PromiseService = null,
            GetInstance: <T>(name: string): T => { return null },
            ProcessAjaxResponse: (response: Cmp.Ui.Interfaces.IAjaxPostResponse, codeToRun?: Function) => { },
            ReturnAjaxResponse: <T>(response: Cmp.Ui.Interfaces.IAjaxPostResponse, codeToRun?: Function) => { return null; },
			GetFilledInstance<T>(url: string, rawData: any, classObj: Cmp.Ui.Interfaces.IConstructor) { return null; }
        };
        return service;
    }

    export function MockModalService() {
        var service: Cmp.Ui.Services.ICmpModalService = {
            OpenModal: (passedTemplateOptions?: Cmp.Ui.Services.ICmpModalControllerSettings,
                passedModalOptions?: angular.ui.bootstrap.IModalSettings): Cmp.Ui.Services.ICmpModalServiceInstance => { return null },
            Confirm: (message: string): Cmp.Ui.Services.ICmpModalServiceInstance => { return null },
            ConfirmUrl: (url: string): Cmp.Ui.Services.ICmpModalServiceInstance => { return null },
            Info: (message: string): Cmp.Ui.Services.ICmpModalServiceInstance => { return null },
            InfoUrl: (url: string): Cmp.Ui.Services.ICmpModalServiceInstance => { return null },
            YesNoCancel: (message: string, title?: string): cmp.IPromise<Cmp.Ui.Enums.Response> => { return null },
            Open: (...passedOptions: angular.ui.bootstrap.IModalSettings[]): angular.ui.bootstrap.IModalServiceInstance => {
                return null;
            }
        };

        return service;
	}

    export function MockModalFindService() {
		return <Cmp.Ui.Services.ICmpModalFindDialogService>{
			Modal: (): Cmp.Ui.Services.IModalFindFluentService => { return null}
		};
    }

	export function MockModalFindFluentService() {
		return <Cmp.Ui.Services.IModalFindFluentService>{
			Size: (size: string): Cmp.Ui.Services.IModalFindFluentService => { return null; },
			Title: (title: string): Cmp.Ui.Services.IModalFindFluentService => { return null; },

			SearchBox: (show: boolean): Cmp.Ui.Services.IModalFindFluentService => { return null; },
			ButtonText: (text: string): Cmp.Ui.Services.IModalFindFluentService => { return null; },
			CloseOnPick: (close: boolean): Cmp.Ui.Services.IModalFindFluentService => { return null; },
			DisplayOnly: (): Cmp.Ui.Services.IModalFindFluentService => { return null; },

			TemplateOptions: (settings: Cmp.Ui.Services.ICmpModalServiceSettings): Cmp.Ui.Services.IModalFindFluentService => { return null; },
			ModalOptions: (settings: ng.ui.bootstrap.IModalSettings): Cmp.Ui.Services.IModalFindFluentService => { return null; },

			AddFieldDefn: (fieldDefn: Cmp.Ui.Bases.IFindFieldDefinition): Cmp.Ui.Services.IModalFindFluentService => { return null; },
			StringField: (configParam: Cmp.Ui.Bases.IFindFieldConfig): Cmp.Ui.Services.IModalFindFluentService => { return null; },
			DateField: (configParam: Cmp.Ui.Bases.IFindFieldConfig): Cmp.Ui.Services.IModalFindFluentService => { return null; },
			DateTimeField: (configParam: Cmp.Ui.Bases.IFindFieldConfig): Cmp.Ui.Services.IModalFindFluentService => { return null; },
			NumberField: (configParam: Cmp.Ui.Bases.IFindNumberFieldConfig): Cmp.Ui.Services.IModalFindFluentService => { return null; },
			CurrencyField: (configParam: Cmp.Ui.Bases.IFindNumberFieldConfig): Cmp.Ui.Services.IModalFindFluentService => { return null; },
			BooleanField: (configParam: Cmp.Ui.Bases.IFindFieldConfig): Cmp.Ui.Services.IModalFindFluentService => { return null; },

			Show: <TReturnType>(listSource: any[] | cmp.IPromise<any[]> | { (): any[] } | { (): cmp.IPromise<any[]> }): cmp.IPromise<TReturnType> => { return null; }
		};
	}

	export function MockLoggerService() {
		return <Cmp.Ui.Services.ILoggerService>{
			Error: (message: string, data?: any): void => { return null },
			Info: (message: string, data?: any): void => { return null },
			Success: (message: string, data?: any): void => { return null },
			Warning: (message: string, data?: any): void => { return null }
		}

	}


    export function SetupCommonLangsRequestMock(httpBackend: angular.IHttpBackendService) {
        var langs = new Array<Cmp.Ui.Factories.ResourceCollection>();

        httpBackend.expectPOST('Resources/GetAppResourceStrings', {
            languageCode: 'en'
        }).respond(langs);
    }

    export function SetupCommonTokenRequestMock(httpBackend: angular.IHttpBackendService) {
        httpBackend.expectPOST('Authentication/GetToken', {}).respond("mocked token");
    }

    export function MockTranslator(cmpPromise: Cmp.Ui.Services.IPromiseService, useEs6Promise?: boolean): angular.translate.ITranslateService {

        var service: any = function (translationId: string|string[], interpolateParams?: any, interpolationId?: string): cmp.IPromise<string>|cmp.IPromise<{ [key: string]: string }> {
            if (Cmp.Js.TypeOf(translationId) === 'array') {
                var retVal: { [key: string]: string } = {};
                for (var cntr = 0; cntr < translationId.length; cntr++) {
                    retVal[translationId[cntr]] = translationId[cntr];
                }
                return useEs6Promise ? (Promise.resolve(retVal)) : cmpPromise.Resolve(retVal);
            } else {
                return useEs6Promise ? (Promise.resolve(translationId)) : cmpPromise.Resolve(translationId);
            }
        };

        service.cloakClassName = (): string => {
            return '';
        };
        service.fallbackLanguage = (langKey?: string | string[]): string => {
            return '';
        };
        service.instant = (translationId: string | string[], interpolateParams?: any, interpolationId?: string): string => {
            return '';
        };
        service.isPostCompilingEnabled = (): boolean => {
            return false;
        }
        service.preferredLanguage = (langKey?: string): string => {
            return '';
        };
        service.proposedLanguage = (): string => {
            return '';
        };
        service.refresh = (langKey?: string): angular.IPromise<void> => {
            return null;
        };
        service.storage = (): angular.translate.IStorage => {
            return null;
        };
        service.storageKey = (): string => {
            return '';
        };
        service.use = (key?: string): string | angular.IPromise<string> => {
            return '';
        };
        service.useFallbackLanguage = (langKey?: string): void => { };
        service.versionInfo = (): string => {
            return '';
        };
        service.loaderCache = (): any => {
            return {};
        };

        return service;
    }

    /** Returns a ICmpPromise that resolves to the specified value */
    export function MockResolvedPromise<U>(resolveValue?: U) {

        var promise: cmp.IPromise<U> = {

            then: (onFulfilled?: (value: U) => U | Thenable<U>, onRejected?: (error: any) => U | Thenable<U>): Promise<U> => {

                if (onFulfilled) {
                    return Promise.resolve(onFulfilled(resolveValue));
                }
                else {
                    return this;
                }
            },
            catch: (onRejected?: (error: any) => any | Thenable<any>): Promise<any> => {
                return null;
            }
        }
        return promise;
    }

    export var MockTimeout: any = function (callBack: () => void) {
        callBack();
    };

    /** A mock for working with elements depending on Toastr*/
    export class ToastrMock implements Toastr {

        public clear = (toast?: JQuery): void => { };

        public error = (message: string, title?: string, overrides?: ToastrOptions): JQuery => {
            return null;
        };

        public info = (message: string, title?: string, overrides?: ToastrOptions): JQuery => {
            return null;
        };

        public options: ToastrOptions = {};

        public success = (message: string, title?: string, overrides?: ToastrOptions): JQuery => {
            return null;
        };

        public warning = (message: string, title?: string, overrides?: ToastrOptions): JQuery => {
            return null;
        };

        public version: string = "ToasterMock";

    }

    /** An explicit log mock that can be used in service construction */
    export class NgLogMock implements angular.ILogService {

        private GetMockLogCall = (): angular.ILogCall=> {
            var x: any = function (...args: any[]): void { }
            x.log = [];
            return x;
        }

        public debug = this.GetMockLogCall();
        public error = this.GetMockLogCall();
        public info = this.GetMockLogCall();
        public log = this.GetMockLogCall();
        public warn = this.GetMockLogCall();

        public assertEmpty = (): void  => { };
        public reset = (): void => { };
    }

    /** Adds a toastr mock to the list of constants */
    export function MockToastr() {

        module(function ($provide) {
            $provide.constant('toastr', new ToastrMock());
        });
    }

    /** An empty mock of the busy indicator */
    export class MockBusyIndicator implements Cmp.Ui.Services.IBusyIndicator {
        MarkBusy: () => {};
        MarkBusyImediate: () => {};
        MarkIdle: () => {};
        IsBusy: boolean = false;
    }

    /** Returns a IPromiseService*/
    export function MockPromiseService(includeImplementation? : boolean) {

        var retPromise: Cmp.Ui.Services.IPromiseService = {
            Promise<TReturnType>(callback: (resolve: (value?: TReturnType) => void, reject: (error?: any) => void) => void): cmp.IPromise<TReturnType> {
                return null;
            },
            Resolve<TReturnType>(value?: TReturnType): cmp.IPromise<TReturnType> {
                if (includeImplementation) {
                    return Promise.resolve(value);
                }
                else {
                    return null;
                }
            },
            Reject<TReturnType>(error: any): cmp.IPromise<TReturnType> {
                if (includeImplementation) {
                    return Promise.reject(error);
                }
                else {
                    return null;
                }
            },
            All(promises: Array<cmp.IPromise<any>>): cmp.IPromise<any> {
                if (includeImplementation) {
                    return Promise.resolve();
                }
                else {
                    return null;
                }
            }
        }
        return retPromise;
    }


}