﻿/// <reference path="../../common-refs.d.ts" />﻿
/// <reference path="../../mocks/shared-stack-mocks.ts" />


describe("Cmp.Ui.Components.CmpLookup", function () {
    beforeEach(function (done) {
        module('cmp.ui.components', 'cmp.ui.services');
		done();
    });

    afterEach(function () { });

    it("_updateInnerString no lookup options", function (done) {

        var component = Cmp.Ui.Components.CmpLookup.Instance(null, null, null, null, null);
		var scope = <any>{
			InnerString: <string>undefined
		};
        component._updateInnerString({
			foo: 'bar'
		}, scope);

        expect(scope.InnerString).toBe(undefined);
        done();
    });
    it("_updateInnerString with lookup options but no display string", function (done) {

        var component = Cmp.Ui.Components.CmpLookup.Instance(null, null, null, null, null);
		var scope = <any>{
			InnerString: <string>undefined,
			LookupOptions: {}
		};
        component._updateInnerString({
			foo: 'bar'
		}, scope);

        expect(scope.InnerString).toBe('');
        done();
    });
    it("_updateInnerString with lookup options but no display string in model", function (done) {

        var component = Cmp.Ui.Components.CmpLookup.Instance(null, null, null, null, null);
		var scope = <any>{
			InnerString: <string>undefined,
			LookupOptions: {
				DisplayPropertyName: 'x'
			}
		};
        component._updateInnerString({
			foo: 'bar'
		}, scope);

        expect(scope.InnerString).toBe('');
        done();
    });
    it("_updateInnerString with lookup options with display string", function (done) {

        var component = Cmp.Ui.Components.CmpLookup.Instance(null, null, null, null, null);
		var scope = <any>{
			InnerString: <string>undefined,
			LookupOptions: {
				DisplayPropertyName: 'foo'
			}
		};
        component._updateInnerString({
			foo: 'bar'
		}, scope);

        expect(scope.InnerString).toBe('bar');
        done();
    });

    it("_createLookup no lookup options", function (done) {
		var fluentModalService = Tests.StackMocks.MockModalFindFluentService();
		var modalService = Tests.StackMocks.MockModalFindService();
		var passedErrorMessage = null;
		modalService.Modal = () => {
			return fluentModalService;
		};
		var loggerService = Tests.StackMocks.MockLoggerService();
		loggerService.Error = (errorMessage) => {
			passedErrorMessage = errorMessage;
		};

        var component = Cmp.Ui.Components.CmpLookup.Instance(null, null, null, modalService, loggerService);
		var scope = <any>{ };
        component._createLookup(scope);

        expect(passedErrorMessage).toBe('Lookup options have not been set.');
        done();
    });


    it("_createLookup with lookup options", function (done) {
		var fluentModalService = Tests.StackMocks.MockModalFindFluentService();
		var fieldPassCount = 0;
		fluentModalService.Size = function (fieldVal) {
			fieldPassCount++;
			expect(fieldVal).toBe('lg');
			return this;
		};
		fluentModalService.Title = function (fieldVal) {
			fieldPassCount++;
			expect(fieldVal).toBe('foo title');
			return this;
		};
		fluentModalService.DateField = function (fieldVal) {
			fieldPassCount++;
			expect(fieldVal).toBe('Date');
			return this;
		};
		fluentModalService.DateTimeField = function (fieldVal) {
			fieldPassCount++;
			expect(fieldVal).toBe('DateTime');
			return this;
		};
		fluentModalService.NumberField = function (fieldVal) {
			fieldPassCount++;
			expect(fieldVal).toBe('Number');
			return this;
		};
		fluentModalService.CurrencyField = function (fieldVal) {
			fieldPassCount++;
			expect(fieldVal).toBe('Currency');
			return this;
		};
		fluentModalService.BooleanField = function (fieldVal) {
			fieldPassCount++;
			expect(fieldVal).toBe('Boolean');
			return this;
		};
		fluentModalService.StringField = function (fieldVal) {
			fieldPassCount++;
			expect(fieldVal).toBe('String');
			return this;
		};
		fluentModalService.Show = function () {

			return Tests.StackMocks.MockResolvedPromise('test value');
		};
		var modalService = Tests.StackMocks.MockModalFindService();
		modalService.Modal = () => {
			return fluentModalService;
		};
		var model = {
			foo: undefined
		};

        var component = Cmp.Ui.Components.CmpLookup.Instance(null, null, null, modalService, null);
		var scope = <any>{
			LookupOptions: {
				GridTitle: 'foo title',
				ColumnOptions: [
					{
						ColumnType: Cmp.Ui.Components.CmpLookupColumnType.Boolean,
						FindFieldConfig: 'Boolean'
					},
					{
						ColumnType: Cmp.Ui.Components.CmpLookupColumnType.Currency,
						FindFieldConfig: 'Currency'
					},
					{
						ColumnType: Cmp.Ui.Components.CmpLookupColumnType.Number,
						FindFieldConfig: 'Number'
					},
					{
						ColumnType: Cmp.Ui.Components.CmpLookupColumnType.Date,
						FindFieldConfig: 'Date'
					},
					{
						ColumnType: Cmp.Ui.Components.CmpLookupColumnType.DateTime,
						FindFieldConfig: 'DateTime'
					},
					{
						ColumnType: Cmp.Ui.Components.CmpLookupColumnType.String,
						FindFieldConfig: 'String'
					}]
			},
			SourceListCollection: [],
			Property: 'foo',
			Model: model
		};
        component._createLookup(scope);

        expect(fieldPassCount).toBe(8);
        expect(model.foo).toBe('test value');
        done();
    });

});