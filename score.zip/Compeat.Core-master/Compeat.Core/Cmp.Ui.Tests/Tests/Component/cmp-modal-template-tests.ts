﻿/// <reference path="../../common-refs.d.ts" />﻿

describe('Cmp.Ui.Components.CmpModalTemplate', function () {
	var instance;

	beforeEach(function () {
        module('Cmp.Ui.Components');
		instance = Cmp.Ui.Components.CmpModalTemplate.Instance();
    });

	it('has an templateUrl assigned to expected template', function () {
		var expectedTempalte = 'cmp-ui/Component/CmpModal/cmp-modal-template.html';

		expect(instance.templateUrl).toBe(expectedTempalte);
	});
});