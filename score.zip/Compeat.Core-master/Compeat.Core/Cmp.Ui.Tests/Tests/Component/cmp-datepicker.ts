﻿/// <reference path="../../common-refs.d.ts" />﻿
/// <reference path="../../mocks/shared-stack-mocks.ts" />


describe("Cmp.Ui.Components.CmpDatepicker", function () {
    var cmpPromise: Cmp.Ui.Services.PromiseService;
    var rootScope: angular.IRootScopeService;
    beforeEach(function (done) {
        module('cmp.ui.components', 'cmp.ui.services');
        inject(function (_cmpPromise_: Cmp.Ui.Services.PromiseService, $rootScope: angular.IRootScopeService) {

            cmpPromise = _cmpPromise_;
            rootScope = $rootScope;
            done();
        });
    });

    afterEach(function (done) {
        done();
    });

    it("link stack check", function (done) {
        var receivedDatePickerArgs: any = null;
        var receivedOnName: any = null;
        var receivedWatchPropName: any = null;

        var component = Cmp.Ui.Components.CmpDatepicker.Instance(Tests.StackMocks.MockTimeout, Tests.StackMocks.MockTranslator(cmpPromise), cmpPromise);
        component._getDateGroup = ():any => {
            return {
                datetimepicker: (dpArgs: BootstrapV3DatetimePicker.DatetimepickerOptions) => {
                    receivedDatePickerArgs = dpArgs;
                },
                on: (evtName:string) => {
                    receivedOnName = evtName;
                }
            };
        };

        var scope: any = {
            Form: { Foo: { } },
            NameId: 'Foo',
            Property: 'Bar',
            $watch: (propName: string) => {
                receivedWatchPropName = propName;
            }
        };
        var element: any = { };
        var attrs: any = { };

        var promise = component
            ._linkAsPromise(scope, element, attrs)
            .then(function () {
                expect(receivedDatePickerArgs).toBeTruthy();
                expect(receivedOnName).toBe('dp.change');
                expect(receivedWatchPropName).toBe('Model.Bar');
                done();
            });
        rootScope.$apply();
    });
});