﻿/// <reference path="../../common-refs.d.ts" />﻿
/// <reference path="../../mocks/shared-stack-mocks.ts" />


describe("Cmp.Ui.Components.CmpTextbox", function () {
    var cmpPromise: Cmp.Ui.Services.PromiseService;
    var rootScope: angular.IRootScopeService;
    beforeEach(function (done) {
        module('cmp.ui.components', 'cmp.ui.services');
        inject(function (_cmpPromise_: Cmp.Ui.Services.PromiseService, $rootScope: angular.IRootScopeService) {

            cmpPromise = _cmpPromise_;
            rootScope = $rootScope;
            done();
        });
    });

    afterEach(function (done) {
        done();
    });

    it("link stack check", function (done) {

        var component = Cmp.Ui.Components.CmpTextbox.Instance(Tests.StackMocks.MockTranslator(cmpPromise), cmpPromise);

        var scope: any = {
            NgMinlength: 1,
            NgMaxlength: 2
        };
        var element: any = { };
        var attrs: any = { };

        var promise = component
            ._linkAsPromise(scope, element, attrs)
            .then(function () {
                expect(scope.Type).toBe('text');
                expect(scope.CustomNgMessages.length).toBe(2);
                expect(scope.CustomNgMessages[0].MessageType).toBe(Cmp.Ui.Rules.NgMessageTypes.MinLength);
                expect(scope.CustomNgMessages[1].MessageType).toBe(Cmp.Ui.Rules.NgMessageTypes.MaxLength);
                done();
            });
        rootScope.$apply();
    });
});