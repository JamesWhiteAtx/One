﻿/// <reference path="../../common-refs.d.ts" />﻿
/// <reference path="../../mocks/shared-stack-mocks.ts" />


describe("Cmp.Ui.Components.CmpGrid", function () {
    beforeEach(function (done) {
        module('cmp.ui.components', 'cmp.ui.services');
		done();
    });

    afterEach(function () { });

    it("_SetupKendoOptions first call", function (done) {
        var promises = Tests.StackMocks.MockPromiseService();
        promises.Promise = (callback: (resolve: (val) => void, reject: (error?: any) => void) => void): cmp.IPromise<any> => {
            var resolve = () => { };
            var reject = () => { };
            callback(resolve, reject);
            return null;
        };
        var component = Cmp.Ui.Components.CmpGrid.Instance(Tests.StackMocks.MockTimeout, Tests.StackMocks.MockTranslator(null, true), promises, null, null, Tests.StackMocks.MockLoggerService());
        var scope = <any>{
            Data: <Cmp.Ui.Components.ICmpGridDataSet<any>>{
                Data: <Array<Cmp.Ui.Bases.BaseBoModel>>[
                    <any>{
                        CmpDel: false,
                        CmpNew: false,
                        ToJson: () => {
                            return {
                                foo: "foo1 val",
                                bar: 1
                            };
                        }
                    },
                    <any>{
                        CmpDel: false,
                        CmpNew: false,
                        ToJson: () => {
                            return {
                                foo: "foo2 val",
                                bar: 2
                            };
                        }
                    }
                ],
                RowCount: 2
            },
            Options: <Cmp.Ui.Components.ICmpGridOptions>{
                Columns: [{
                    IsPropertyOfData: true,
                    PropertyName: "foo",
                    PropertyType: Cmp.Js.Enums.CmpGridPropertyType.String,
                    ColumnIsVisible: true,
                    ColumnHeaderText: "Foo Column",
                    Template: undefined
                }, {
                        IsPropertyOfData: true,
                        PropertyName: "bar",
                        PropertyType: Cmp.Js.Enums.CmpGridPropertyType.Number,
                        ColumnIsVisible: true,
                        ColumnHeaderText: "Bar Column",
                        Template: undefined
                    }],
                KeyPropertyName: "",
                DisableSorting: false,
                EnableClientSidePaging: true,
                PageSize: 25,
                Height: "200",
                EnableDeleting: true
            }
        };
        component._SetupKendoOptions(scope, scope.Options);


        expect(scope.KendoColumnOptions).toBeTruthy();
        expect(scope.KendoDataSource).toBeTruthy();
        expect(scope.KendoColumnOptions.columns.length).toBe(3);
        expect(scope.KendoColumnOptions.sortable).toBe(true);
        expect(scope.KendoColumnOptions.height).toBe("200");
        expect(scope.KendoColumnOptions.pageable).toEqual({ refresh: false, pageSizes: true, buttonCount: 5, pageSize: 25 });
        expect(scope.KendoDataSource.pageSize()).toBe(25);
        
        done();
    });

    it("_SetupKendoOptions second call", function (done) {
        var readDataSourceCalled = false;
        var promises = Tests.StackMocks.MockPromiseService();
        promises.Promise = (callback: (resolve: (val) => void, reject: (error?: any) => void) => void): cmp.IPromise<any> => {
            var resolve = () => { };
            var reject = () => { };
            callback(resolve, reject);
            return null;
        };
        var component = Cmp.Ui.Components.CmpGrid.Instance(Tests.StackMocks.MockTimeout, Tests.StackMocks.MockTranslator(null, true), promises, null, null, Tests.StackMocks.MockLoggerService());
        var scope = <any>{
            KendoDataSource: {
                read: () => {
                    readDataSourceCalled = true;
                    return Tests.StackMocks.MockResolvedPromise();
                }
            },
            Options: <Cmp.Ui.Components.ICmpGridOptions>{
                Columns: [{
                    IsPropertyOfData: true,
                    PropertyName: "foo",
                    PropertyType: Cmp.Js.Enums.CmpGridPropertyType.String,
                    ColumnIsVisible: true,
                    ColumnHeaderText: "Foo Column",
                    Template: undefined
                }, {
                        IsPropertyOfData: true,
                        PropertyName: "bar",
                        PropertyType: Cmp.Js.Enums.CmpGridPropertyType.Number,
                        ColumnIsVisible: true,
                        ColumnHeaderText: "Bar Column",
                        Template: undefined
                    }],
                KeyPropertyName: "",
                DisableSorting: false,
                EnableClientSidePaging: true,
                PageSize: 25,
                Height: "200",
                EnableDeleting: true
            },
            OptionsHaveBeenProcessed: true
        };
        component._SetupKendoOptions(scope, scope.Options);
        expect(readDataSourceCalled).toBeTruthy();
        done();
    });

    it("CmpGridClientSideCrudHandling read stack test", function (done) {
        var passedResults: Cmp.Ui.Components.ICmpGridDataSet<any> = null;
        var scope = <any>{
            LastRawData: [
                {
                    CmpDel: false,
                    Val: "Foo1"
                },{
                    CmpDel: false,
                    Val: "Foo2"
                }, {
                    CmpDel: false,
                    Val: "Foo3"
                }
            ]
        };
        var opts = <any> {
            success: (results: Cmp.Ui.Components.ICmpGridDataSet<any>) => {
                passedResults = results;
            }
        };

        var clientHandler = new Cmp.Ui.Components.CmpGridClientSideCrudHandling(scope);

        clientHandler.read(opts);

        expect(passedResults).toBeTruthy();
        expect(passedResults.RowCount).toBe(3);
        expect(passedResults.Data.length).toBe(3);
        expect(passedResults.Data[0]["Val"]).toBe("Foo1");
        expect(passedResults.Data[1]["Val"]).toBe("Foo2");
        expect(passedResults.Data[2]["Val"]).toBe("Foo3");

        done();

    });

    it("_ProcessEditClick no object to edit, so it creates a new one", function (done) {
		var baseTools = Tests.StackMocks.MockBaseTools();
		var modalService = Tests.StackMocks.MockModalService();
		var expectedNewItem: any = { val: 'foo' };
		baseTools.CreateInstance = (passedConstructor) => {
			return passedConstructor;
		};
		modalService.Open = (opts) => {
			return <any>{
				result: Tests.StackMocks.MockResolvedPromise<boolean>(true)
			};
		};
        var component = Cmp.Ui.Components.CmpGrid.Instance(Tests.StackMocks.MockTimeout, null, null, modalService, baseTools, Tests.StackMocks.MockLoggerService());

        var scope = <any>{
            Options: <Cmp.Ui.Components.ICmpGridOptions>{
				Columns: [],
                KeyPropertyName: "bar",
				EditModalEditType: expectedNewItem,
				EditModalControllerType: <Cmp.Ui.Bases.IValidatableModalController>{
					AssignToModalSettings: (modalSettings?: angular.ui.bootstrap.IModalSettings): angular.ui.bootstrap.IModalSettings => {

						return null;
					}
				}
            },
            OptionsHaveBeenProcessed: true,
			Data: {
				Data: [],
				RowCount: 0
			}
        };
		component._ProcessEditClick(undefined, scope);

        expect(scope.Data.Data.length).toBe(1);
        expect(scope.Data.RowCount).toBe(1);
        expect(scope.Data.Data[0].CmpNew).toBe(true);
        expect(scope.Data.Data[0].val).toBe(expectedNewItem.val);

        done();

    });

    it("_ProcessEditClick match is found for editing", function (done) {

		var baseTools = Tests.StackMocks.MockBaseTools();
		var modalService = Tests.StackMocks.MockModalService();
		var expectedNewItem: any = { val: 'foo' };
		var passedModalArgs: Cmp.Ui.Bases.IValidatableModalArgs<any, any> = null;
		baseTools.CreateInstance = (passedConstructor) => {
			return passedConstructor;
		};
		modalService.Open = (opts) => {
			return <any>{
				result: Tests.StackMocks.MockResolvedPromise<boolean>(true)
			};
		};
        var component = Cmp.Ui.Components.CmpGrid.Instance(Tests.StackMocks.MockTimeout, null, null, modalService, baseTools, Tests.StackMocks.MockLoggerService());

        var scope = <any>{
            Options: <Cmp.Ui.Components.ICmpGridOptions>{
				Columns: [],
                KeyPropertyName: "bar",
				EditModalEditType: expectedNewItem,
				EditModalControllerType: <Cmp.Ui.Bases.IValidatableModalController>{
					AssignToModalSettings: (modalSettings?: angular.ui.bootstrap.IModalSettings): angular.ui.bootstrap.IModalSettings => {
						passedModalArgs = modalSettings.resolve.modalArguments();
						return null;
					}
				}
            },
            OptionsHaveBeenProcessed: true,
			Data: {
				Data: [{
						bar: 10
					}, {
						bar: 20
					}, {
						bar: 30
					}],
				RowCount: 3
			}
        };

		component._ProcessEditClick({ bar: 20 }, scope);

        expect(passedModalArgs).toBeTruthy();
        expect(passedModalArgs.Model).toBeTruthy();
        expect(passedModalArgs.Model.bar).toBe(20);
		
        done();

    });

    it("_ProcessEditClick no match is found for editing", function (done) {

		var modalService = Tests.StackMocks.MockModalService();
		var loggerService = Tests.StackMocks.MockLoggerService();
		var errorOccured = false;
		loggerService.Error = () => {
			errorOccured = true;
		};
		modalService.Open = (opts) => {
			return <any>{
				result: Tests.StackMocks.MockResolvedPromise<boolean>(true)
			};
		};
        var component = Cmp.Ui.Components.CmpGrid.Instance(Tests.StackMocks.MockTimeout, null, null, modalService, Tests.StackMocks.MockBaseTools(), loggerService);

        var scope = <any>{
            Options: <Cmp.Ui.Components.ICmpGridOptions>{
				Columns: [],
                KeyPropertyName: "bar",
				EditModalControllerType: <Cmp.Ui.Bases.IValidatableModalController>{
					AssignToModalSettings: (modalSettings?: angular.ui.bootstrap.IModalSettings): angular.ui.bootstrap.IModalSettings => {

						return null;
					}
				}
            },
            OptionsHaveBeenProcessed: true,
			Data: {
				Data: [],
				RowCount: 0
			}
        };
		component._ProcessEditClick('test', scope);
		expect(errorOccured).toBe(true);
		done();
    });

    it("_ProcessDeleteClick no match is found for deleting", function (done) {

		var loggerService = Tests.StackMocks.MockLoggerService();
		var errorOccured = false;
		loggerService.Error = () => {
			errorOccured = true;
		};
        var component = Cmp.Ui.Components.CmpGrid.Instance(Tests.StackMocks.MockTimeout, null, null, Tests.StackMocks.MockModalService(), Tests.StackMocks.MockBaseTools(), loggerService);

        var scope = <any>{
            Options: <Cmp.Ui.Components.ICmpGridOptions>{
				Columns: [],
                KeyPropertyName: "bar"
            },
            OptionsHaveBeenProcessed: true,
			Data: {
				Data: [],
				RowCount: 0
			}
        };
		component._ProcessDeleteClick('test', scope);
		expect(errorOccured).toBe(true);
		done();

    });
    it("_ProcessDeleteClick match is found for deleting w/o AllowDelete promise", function (done) {
		var deleteCalled = false;
		var kendoRemoveCalled = false;
		var foundMatch:any = {
			bar: 20
		};
        var component = Cmp.Ui.Components.CmpGrid.Instance(Tests.StackMocks.MockTimeout, null, null, Tests.StackMocks.MockModalService(),
			Tests.StackMocks.MockBaseTools(), Tests.StackMocks.MockLoggerService());

        var scope = <any>{
			KendoDataSource: {
				remove: () => {
					kendoRemoveCalled = true;
				}
			},
            Options: <Cmp.Ui.Components.ICmpGridOptions>{
				Columns: [],
                KeyPropertyName: "bar",
				DeleteRow: () => {
					deleteCalled = true;
				},
            },
            OptionsHaveBeenProcessed: true,
			Data: {
				Data: [{
					bar: 10
				}, foundMatch, {
						bar: 30
					}],
				RowCount: 3
			}
        };

		component._ProcessDeleteClick({ bar: 20 }, scope);
		expect(deleteCalled).toBe(true);
		expect(kendoRemoveCalled).toBe(true);
		expect(foundMatch.CmpDel).toBe(true);
        done();

    });
    it("_ProcessDeleteClick match is found for deleting w AllowDelete successful promise", function (done) {
		var deleteCalled = false;
		var kendoRemoveCalled = false;
		var foundMatch: any = {
			bar: 20
		};
        var component = Cmp.Ui.Components.CmpGrid.Instance(Tests.StackMocks.MockTimeout, null, null, Tests.StackMocks.MockModalService(),
			Tests.StackMocks.MockBaseTools(), Tests.StackMocks.MockLoggerService());

        var scope = <any>{
			KendoDataSource: {
				remove: () => {
					kendoRemoveCalled = true;
				}
			},
            Options: <Cmp.Ui.Components.ICmpGridOptions>{
				Columns: [],
                KeyPropertyName: "bar",
				DeleteRow: () => {
					deleteCalled = true;
				},
				AllowDelete: () => {
					return Tests.StackMocks.MockResolvedPromise(true);
				}
            },
            OptionsHaveBeenProcessed: true,
			Data: {
				Data: [{
					bar: 10
				}, foundMatch, {
						bar: 30
					}],
				RowCount: 3
			}
        };

		component._ProcessDeleteClick({ bar: 20 }, scope);
		expect(deleteCalled).toBe(true);
		expect(kendoRemoveCalled).toBe(true);
		expect(foundMatch.CmpDel).toBe(true);
        done();

    });
    it("_ProcessDeleteClick match is found for deleting w AllowDelete failed promise", function (done) {
		var deleteCalled = false;
		var kendoRemoveCalled = false;
		var foundMatch: any = {
			bar: 20
		};
        var component = Cmp.Ui.Components.CmpGrid.Instance(Tests.StackMocks.MockTimeout, null, null, Tests.StackMocks.MockModalService(),
			Tests.StackMocks.MockBaseTools(), Tests.StackMocks.MockLoggerService());

        var scope = <any>{
			KendoDataSource: {
				remove: () => {
					kendoRemoveCalled = true;
				}
			},
            Options: <Cmp.Ui.Components.ICmpGridOptions>{
				Columns: [],
                KeyPropertyName: "bar",
				DeleteRow: () => {
					deleteCalled = true;
				},
				AllowDelete: () => {
					return Tests.StackMocks.MockResolvedPromise(false);
				}
            },
            OptionsHaveBeenProcessed: true,
			Data: {
				Data: [{
					bar: 10
				}, foundMatch, {
						bar: 30
					}],
				RowCount: 3
			}
        };

		component._ProcessDeleteClick({ bar: 20 }, scope);
		expect(deleteCalled).toBeFalsy();
		expect(kendoRemoveCalled).toBeFalsy();
		expect(foundMatch.CmpDel).toBeFalsy();
        done();

    });
});