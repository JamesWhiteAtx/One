﻿/// <reference path="../../common-refs.d.ts" />﻿
/// <reference path="../../mocks/shared-stack-mocks.ts" />


describe("Cmp.Ui.Components.CmpInteger", function () {
    var cmpPromise: Cmp.Ui.Services.PromiseService;
    var rootScope: angular.IRootScopeService;
    beforeEach(function (done) {
        module('cmp.ui.components', 'cmp.ui.services');
        inject(function (_cmpPromise_: Cmp.Ui.Services.PromiseService, $rootScope: angular.IRootScopeService) {

            cmpPromise = _cmpPromise_;
            rootScope = $rootScope;
            done();
        });
    });

    afterEach(function (done) {
        done();
    });

    it("link stack check", function (done) {
        var watchList = new Array<string>();
        var parserList = new Array<string>();

        var component = Cmp.Ui.Components.CmpInteger.Instance(Tests.StackMocks.MockTranslator(cmpPromise), cmpPromise);

        var scope: any = {
            NgMinlength: 1,
            NgMaxlength: 2,
            Min: 3,
            Max: 4,

            Form: {
                Foo: {
                    $parsers: parserList,
                    $validators: {}
                }
            },
            NameId: 'Foo',
            Property: 'Bar'
        };
        var element: any = { };
        var attrs: any = { };

        var promise = component
            ._linkAsPromise(scope, element, attrs)
            .then(function () {
                expect(scope.Type).toBe('text');
                expect(parserList.length).toBe(1);
                expect(scope.Form.Foo.$validators["number"]).toBeTruthy();
                expect(scope.Form.Foo.$validators["min"]).toBeTruthy();
                expect(scope.Form.Foo.$validators["max"]).toBeTruthy();
                expect(scope.CustomNgMessages.length).toBe(5);
                expect(scope.CustomNgMessages[0].MessageType).toBe(Cmp.Ui.Rules.NgMessageTypes.Number);
                expect(scope.CustomNgMessages[1].MessageType).toBe(Cmp.Ui.Rules.NgMessageTypes.Min);
                expect(scope.CustomNgMessages[2].MessageType).toBe(Cmp.Ui.Rules.NgMessageTypes.Max);
                expect(scope.CustomNgMessages[3].MessageType).toBe(Cmp.Ui.Rules.NgMessageTypes.MinLength);
                expect(scope.CustomNgMessages[4].MessageType).toBe(Cmp.Ui.Rules.NgMessageTypes.MaxLength);
                done();
            });
        rootScope.$apply();
    });
});