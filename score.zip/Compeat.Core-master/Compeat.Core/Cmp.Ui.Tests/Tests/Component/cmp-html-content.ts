﻿/// <reference path="../../common-refs.d.ts" />﻿

describe('Cmp.Ui.Components.CmpHtmlContent', function () {
	var instance;
	var MockParseService: angular.IParseService;

	beforeEach(() => {
        module('Cmp.Ui.Components');

		/** mock the angular parse service, not sure how to make a function with an attached function in TypeScrit (see angular.ICompiledExpression) */
		MockParseService = (expression: string): angular.ICompiledExpression => {
			var mockParseFcn = (context: any, locals?: any): any => {
				return context[expression];
			};
			var castParseFcn: angular.ICompiledExpression = <angular.ICompiledExpression><any>mockParseFcn;
			return castParseFcn;
		};

		instance = Cmp.Ui.Components.CmpHtmlContent.Instance(MockParseService);
    });

	it('has an instance with a link method', function () {
		expect(instance.link).toBeDefined();
	});

	describe('link method', function () {
		var scope: any;
		var element: any;
		var attrs: any;
		var controller: any;
		var transclude: angular.ITranscludeFunction;
		var transcludeFncRan: boolean;

		transclude = (fcn: any) => {
			fcn();
			transcludeFncRan = true;
			return null;
		};

		beforeEach(() => {
			scope = {};
			element = {
				append: () => {
				}
			};
			attrs = {};
			controller = null;
			transcludeFncRan = false;

			transclude = (fcn: any) => {
				fcn();
				transcludeFncRan = true;
				return null;
			};
		});

		it('executes transclude function if no attributes assigned', function () {
			instance.link(scope, element, attrs, controller, transclude);

			expect(transcludeFncRan).toBe(true);
		});

		it('assigns true to "Display" if "If" attribute is not defined', function () {
			instance.link(scope, element, attrs, controller, transclude);

			expect(scope.Display).toBe(true);
		});

		it('assigns false to "Display" if "If" attribute is false', function () {
			var expectedVal = false;
			attrs.cgIf = 'theIfValue';
			scope.theIfValue = expectedVal;

			instance.link(scope, element, attrs, controller, transclude);

			expect(scope.Display).toBe(expectedVal);
		});

		it('does not execute transclude function if "If" attribute is false', function () {
			var expectedVal = false;
			attrs.cgIf = 'theIfValue';
			scope.theIfValue = expectedVal;
			transcludeFncRan = false;

			instance.link(scope, element, attrs, controller, transclude);

			expect(scope.Display).toBe(false);
			expect(transcludeFncRan).toBe(false);
		});

		it('does not execute transclude function if "Url" attribute is assigned', function () {
			var expectedVal = 'SomeUrl';
			attrs.cgUrl = 'theUrl';
			scope.theUrl = expectedVal;
			transcludeFncRan = false;

			instance.link(scope, element, attrs, controller, transclude);

			expect(scope.Display).toBe(true);
			expect(transcludeFncRan).toBe(false);
		});

		it('does not execute transclude function if "Content" attribute is assigned', function () {
			var expectedVal = 'SomeContent';
			attrs.cgContent = 'theContent';
			scope.theContent = expectedVal;
			transcludeFncRan = false;

			instance.link(scope, element, attrs, controller, transclude);

			expect(scope.Display).toBe(true);
			expect(transcludeFncRan).toBe(false);
		});

	});
}); 