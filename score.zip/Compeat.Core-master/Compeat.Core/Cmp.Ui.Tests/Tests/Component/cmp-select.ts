﻿/// <reference path="../../common-refs.d.ts" />﻿
/// <reference path="../../mocks/shared-stack-mocks.ts" />


describe("Cmp.Ui.Components.CmpSelect", function () {
    var cmpPromise: Cmp.Ui.Services.PromiseService;
    var rootScope: angular.IRootScopeService;
    beforeEach(function (done) {
        module('cmp.ui.components', 'cmp.ui.services');
        inject(function (_cmpPromise_: Cmp.Ui.Services.PromiseService, $rootScope: angular.IRootScopeService) {

            cmpPromise = _cmpPromise_;
            rootScope = $rootScope;
            done();
        });
    });

    afterEach(function (done) {
        done();
    });

    it("link stack check", function (done) {
        var receivedBindName: any = null;
        var watchList = new Array<string>();
        var parserList = new Array<string>();
        var observeList = new Array<string>();

		// The select component has internal logic that queries Cmp.Js.OnMobile, this test is just for desktop, so mock it to allways be false.
		Cmp.Js.OnMobile = () => {
			return false;
		};

        var component = Cmp.Ui.Components.CmpSelect.Instance(Tests.StackMocks.MockTimeout, cmpPromise);
        component._getSelectElement = (): any => {
            return {
                bind: (evtName: string) => {
                    receivedBindName = evtName;
                },
                select2: ():any => { }
            };
        };
        component._setupSelect2 = (): any => { }
        component._timeoutAndRender = (): any => { }
        var scope: any = {
            Form: {
                Foo: {
                    $parsers: parserList
                }
            },
            NameId: 'Foo',
            Property: 'Bar',
            $watch: (propName: string) => {
                watchList.push(propName);
            }

        };
        var element: any = {};
        var attrs: any = {
            $observe: function (propName: string) {
                observeList.push(propName);
            }
        };

        var promise = component
            ._linkAsPromise(scope, element, attrs)
            .then(function () {
                expect(receivedBindName).toBe('$destroy');
                expect(parserList.length).toBe(1);
                expect(watchList.length).toBe(2);
                expect(watchList[0]).toBe('Collection');
                expect(watchList[1]).toBe('Model.Bar');
                expect(observeList.length).toBe(2);
                expect(observeList[0]).toBe('disabled');
                expect(observeList[1]).toBe('readonly');
                done();
            });
        rootScope.$apply();
    });

    var makeScope = function (Collection?: Array<any>, IsMultiple?: boolean, AllowClear?:boolean): any {
        return {
            Collection: Collection,
            IsMultiple: IsMultiple,
            AllowClear: AllowClear,
            ValueProperty: 'id',
            DisplayProperty: 'description',
        };
    }

    it("_getCollectionData is empty", function (done) {

        var scopeAsSelect = makeScope();
        var component = Cmp.Ui.Components.CmpSelect.Instance(Tests.StackMocks.MockTimeout, cmpPromise);
        var results = component._getCollectionData(scopeAsSelect);
        expect(results).toBeTruthy();
        expect(results.length).toBe(0);
        done();
    });

    it("_getCollectionData transforms as expected", function (done) {

        var scopeAsSelect = makeScope([{ id: 1, description: 'foo' }, { id: 2, description: 'Bar' }, { id: 3, description: 'test' }]);
        var component = Cmp.Ui.Components.CmpSelect.Instance(Tests.StackMocks.MockTimeout, cmpPromise);
        var results = component._getCollectionData(scopeAsSelect);
        expect(results).toBeTruthy();
        expect(results.length).toBe(3);
        expect(results[0].id).toBe(1);
        expect(results[0].text).toBe('foo');
        expect(results[1].id).toBe(2);
        expect(results[1].text).toBe('Bar');
        expect(results[2].id).toBe(3);
        expect(results[2].text).toBe('test');
        done();
    });
    it("_getCollectionData adds blank options first", function (done) {

        var scopeAsSelect = makeScope([{ id: 1, description: 'foo' }, { id: 2, description: 'Bar' }, { id: 3, description: 'test' }], false, true);
        var component = Cmp.Ui.Components.CmpSelect.Instance(Tests.StackMocks.MockTimeout, cmpPromise);
        var results = component._getCollectionData(scopeAsSelect);
        expect(results).toBeTruthy();
        expect(results.length).toBe(4);
        expect(results[0].id).toBe('');
        expect(results[0].text).toBe('');
        done();
    });


    it("_cmpTokenizer adds 2 options for 'foo,bar' ", function (done) {
        var returnedList = new Array<any>();
        var component = Cmp.Ui.Components.CmpSelect.Instance(Tests.StackMocks.MockTimeout, cmpPromise);
        component._getRawCollection = (): any => { return [{ id: 1, text: 'foo' }, { id: 2, text: 'Bar' }, { id: 3, text: 'test' }]; }
        var results = component._cmpTokenizer({ term: 'foo,bar' }, function (cb_returned) {
            returnedList.push(cb_returned);
        });

        expect(returnedList.length).toBe(2);
        expect(returnedList[0].id).toBe(1);
        expect(returnedList[0].text).toBe('foo');
        expect(returnedList[1].id).toBe(2);
        expect(returnedList[1].text).toBe('Bar');
        done();
    });

    it("_cmpTokenizer adds 2 options for 'foo,bar,' ", function (done) {
        var returnedList = new Array<any>();
        var component = Cmp.Ui.Components.CmpSelect.Instance(Tests.StackMocks.MockTimeout, cmpPromise);
        component._getRawCollection = (): any => { return [{ id: 1, text: 'foo' }, { id: 2, text: 'Bar' }, { id: 3, text: 'test' }]; }
        var results = component._cmpTokenizer({ term: 'foo,bar,' }, function (cb_returned) {
            returnedList.push(cb_returned);
        });

        expect(returnedList.length).toBe(2);
        expect(returnedList[0].id).toBe(1);
        expect(returnedList[0].text).toBe('foo');
        expect(returnedList[1].id).toBe(2);
        expect(returnedList[1].text).toBe('Bar');
        done();
    });

    it("_cmpTokenizer adds 0 options for 'bad input' ", function (done) {
        var returnedList = new Array<any>();
        var component = Cmp.Ui.Components.CmpSelect.Instance(Tests.StackMocks.MockTimeout, cmpPromise);
        component._getRawCollection = (): any => { return [{ id: 1, text: 'foo' }, { id: 2, text: 'Bar' }, { id: 3, text: 'test' }]; }
        var results = component._cmpTokenizer({ term: 'bad input' }, function (cb_returned) {
            returnedList.push(cb_returned);
        });

        expect(returnedList.length).toBe(0);
        done();
    });

});