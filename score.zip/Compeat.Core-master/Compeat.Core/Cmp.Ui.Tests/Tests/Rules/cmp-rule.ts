﻿/// <reference path="../../common-refs.d.ts" />﻿

describe("Cmp.Ui.Rules.CmpRule", function () {

	beforeEach(function (done) {
		Cmp.Ui.Rules.CmpRule.RuleCounter = 0;
		done();
	});

	var dummyTestableFunction = function () {
		return "foo";
	};

	it("constructor general rule", function () {
		var rule = new Cmp.Ui.Rules.CmpRule(dummyTestableFunction, "test1", 5, [], Cmp.Ui.Rules.NgMessageTypes.Required);
		expect(rule.Rule).toBeTruthy();
		expect(rule.Message).toBe("test1");
		expect(rule.Severity).toBe(5);
		expect(rule.PropertyName).toBe(Cmp.Ui.Rules.GENERAL_RULE_ID);
		expect(rule.RuleName).toBe("_rule0");
	});

	it("constructor custom property", function () {
		var rule = new Cmp.Ui.Rules.CmpRule(dummyTestableFunction, "test1", 5, ['prop1'], Cmp.Ui.Rules.NgMessageTypes.Required);

		expect(rule.Rule).toBeTruthy();
		expect(rule.Message).toBe("test1");
		expect(rule.Severity).toBe(5);
		expect(rule.PropertyName).toBe('prop1');
		expect(rule.RuleName).toBe("_rule0");
	});

	it("constructor rule name auto increment", function () {
		var rule1 = new Cmp.Ui.Rules.CmpRule(dummyTestableFunction, "test1", 5, ['prop1'], Cmp.Ui.Rules.NgMessageTypes.Required);
		var rule2 = new Cmp.Ui.Rules.CmpRule(dummyTestableFunction, "test2", 5, ['prop2'], Cmp.Ui.Rules.NgMessageTypes.Required);
		var rule3 = new Cmp.Ui.Rules.CmpRule(dummyTestableFunction, "test3", 5, ['prop3'], Cmp.Ui.Rules.NgMessageTypes.Required);

		expect(Cmp.Ui.Rules.CmpRule.RuleCounter).toBe(3);
	});
});