﻿/// <reference path="../../common-refs.d.ts" />﻿

describe("Cmp.Ui.Rules", function () {

	it("_isValid no children true empty collection, no errors", function (done) {

		var testModel: Cmp.Ui.Rules.IHaveRules = {
			BrokenRules: undefined,
			RuledChildProperties: undefined,
            GetRules: function (): cmp.IPromise<Array<Cmp.Ui.Rules.CmpRule>> {
				return undefined;
			}
		};
		expect(Cmp.Ui.Rules._isValid(testModel)).toBe(true);
		done();
	});

	it("_isValid no children true warnings only", function (done) {
		var broken = <Cmp.Js.Types.IStringMap<Cmp.Ui.Rules.BrokenRuleResultCollection>>{};

    var testBrokenRulesObj = new Cmp.Ui.Rules.BrokenRuleResultCollection();
    testBrokenRulesObj.AddRuleResult("foo1", "foo1 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Warning);
    testBrokenRulesObj.AddRuleResult("foo2", "foo2 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Warning);
    testBrokenRulesObj.AddRuleResult("foo3", "foo3 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Warning);
		broken["foo"] = testBrokenRulesObj;

		var testModel: Cmp.Ui.Rules.IHaveRules = {
			BrokenRules: broken,
			RuledChildProperties: undefined,
            GetRules: function (): cmp.IPromise<Array<Cmp.Ui.Rules.CmpRule>> {
				return undefined;
			}
		};
		expect(Cmp.Ui.Rules._isValid(testModel)).toBe(true);
		done();
	});

	it("_isValid no children false warnings and error", function (done) {
		var broken = <Cmp.Js.Types.IStringMap<Cmp.Ui.Rules.BrokenRuleResultCollection>>{};

    var testBrokenRulesObj = new Cmp.Ui.Rules.BrokenRuleResultCollection();
    testBrokenRulesObj.AddRuleResult("foo1", "foo1 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Warning);
    testBrokenRulesObj.AddRuleResult("foo2", "foo2 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Error);
    testBrokenRulesObj.AddRuleResult("foo3", "foo3 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Warning);
		broken["foo"] = testBrokenRulesObj;

		var testModel: Cmp.Ui.Rules.IHaveRules = {
			BrokenRules: broken,
			RuledChildProperties: undefined,
            GetRules: function (): cmp.IPromise<Array<Cmp.Ui.Rules.CmpRule>> {
				return undefined;
			}
		};
		expect(Cmp.Ui.Rules._isValid(testModel)).toBe(false);
		done();
	});

	it("_isValid no children false error only", function (done) {
		var broken = <Cmp.Js.Types.IStringMap<Cmp.Ui.Rules.BrokenRuleResultCollection>>{};

    var testBrokenRulesObj = new Cmp.Ui.Rules.BrokenRuleResultCollection();
    testBrokenRulesObj.AddRuleResult("foo1", "foo1 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Error);
		broken["foo"] = testBrokenRulesObj;

		var testModel: Cmp.Ui.Rules.IHaveRules = {
			BrokenRules: broken,
			RuledChildProperties: undefined,
            GetRules: function (): cmp.IPromise<Array<Cmp.Ui.Rules.CmpRule>> {
				return undefined;
			}
		};
		expect(Cmp.Ui.Rules._isValid(testModel)).toBe(false);
		done();
	});

	it("_isValid with children true warnings only", function (done) {
		var broken = <Cmp.Js.Types.IStringMap<Cmp.Ui.Rules.BrokenRuleResultCollection>>{};

    var testBrokenRulesObj = new Cmp.Ui.Rules.BrokenRuleResultCollection();
    testBrokenRulesObj.AddRuleResult("foo1", "foo1 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Warning);
    testBrokenRulesObj.AddRuleResult("foo2", "foo2 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Warning);
    testBrokenRulesObj.AddRuleResult("foo3", "foo3 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Warning);
		broken["foo"] = testBrokenRulesObj;
		var testChild: Cmp.Ui.Rules.IHaveRules = {
			BrokenRules: broken,
			RuledChildProperties: undefined,
            GetRules: function (): cmp.IPromise<Array<Cmp.Ui.Rules.CmpRule>> {
				return undefined;
			}
		};
		var testModel: Cmp.Ui.Rules.IHaveRules = {
			Foo: testChild,
			BrokenRules: undefined,
			RuledChildProperties: ["Foo"],
            GetRules: function (): cmp.IPromise<Array<Cmp.Ui.Rules.CmpRule>> {
				return undefined;
			}
		};
		expect(Cmp.Ui.Rules._isValid(testModel)).toBe(true);
		done();
	});

	it("_isValid with children false warnings and error", function (done) {
		var broken = <Cmp.Js.Types.IStringMap<Cmp.Ui.Rules.BrokenRuleResultCollection>>{};

    var testBrokenRulesObj = new Cmp.Ui.Rules.BrokenRuleResultCollection();
    testBrokenRulesObj.AddRuleResult("foo1", "foo1 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Warning);
    testBrokenRulesObj.AddRuleResult("foo2", "foo2 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Error);
    testBrokenRulesObj.AddRuleResult("foo3", "foo3 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Warning);
		broken["Foo"] = testBrokenRulesObj;
		var testChild: Cmp.Ui.Rules.IHaveRules = {
			BrokenRules: broken,
			RuledChildProperties: undefined,
            GetRules: function (): cmp.IPromise<Array<Cmp.Ui.Rules.CmpRule>> {
				return undefined;
			}
		};
		var testModel: Cmp.Ui.Rules.IHaveRules = {
			Foo: testChild,
			BrokenRules: undefined,
			RuledChildProperties: ["Foo"],
            GetRules: function (): cmp.IPromise<Array<Cmp.Ui.Rules.CmpRule>> {
				return undefined;
			}
		};
		expect(Cmp.Ui.Rules._isValid(testModel)).toBe(false);
		done();
	});

	it("_isValid with children false error only", function (done) {
		var broken = <Cmp.Js.Types.IStringMap<Cmp.Ui.Rules.BrokenRuleResultCollection>>{};

    var testBrokenRulesObj = new Cmp.Ui.Rules.BrokenRuleResultCollection();
    testBrokenRulesObj.AddRuleResult("foo1", "foo1 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Error);
		broken["Foo"] = testBrokenRulesObj;
		var testChild: Cmp.Ui.Rules.IHaveRules = {
			BrokenRules: broken,
			RuledChildProperties: undefined,
            GetRules: function (): cmp.IPromise<Array<Cmp.Ui.Rules.CmpRule>> {
				return undefined;
			}
		};
		var testModel: Cmp.Ui.Rules.IHaveRules = {
			Foo: testChild,
			BrokenRules: undefined,
			RuledChildProperties: ["Foo"],
            GetRules: function (): cmp.IPromise<Array<Cmp.Ui.Rules.CmpRule>> {
				return undefined;
			}
		};
		expect(Cmp.Ui.Rules._isValid(testModel)).toBe(false);
		done();
	});

});