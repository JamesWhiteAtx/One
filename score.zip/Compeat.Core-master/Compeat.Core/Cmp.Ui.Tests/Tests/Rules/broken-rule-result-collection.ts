﻿/// <reference path="../../common-refs.d.ts" />﻿

describe("Cmp.Ui.Rules.BrokenRuleResultCollection", function () {

	it("addRuleResult", function (done) {
    var testBrokenRulesObj = new Cmp.Ui.Rules.BrokenRuleResultCollection();

		testBrokenRulesObj.AddRuleResult("foo1", "foo1 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Warning);
    testBrokenRulesObj.AddRuleResult("foo2", "foo2 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Error);

    var results = testBrokenRulesObj.Content;

		expect(results.length).toBe(2);
		expect(results[0].RuleName).toBe("foo1");
		expect(results[0].Message).toBe("foo1 msg");
		expect(results[0].Severity).toBe(Cmp.Ui.Rules.BrokenRuleSeverities.Warning);
		expect(results[1].RuleName).toBe("foo2");
		expect(results[1].Message).toBe("foo2 msg");
		expect(results[1].Severity).toBe(Cmp.Ui.Rules.BrokenRuleSeverities.Error);

		done();
	});

	it("removeRuleResult", function (done) {
    var testBrokenRulesObj = new Cmp.Ui.Rules.BrokenRuleResultCollection();

    testBrokenRulesObj.AddRuleResult("foo1", "foo1 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Warning);
    testBrokenRulesObj.AddRuleResult("foo2", "foo2 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Error);
    testBrokenRulesObj.AddRuleResult("foo3", "foo3 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Error);

    testBrokenRulesObj.RemoveRuleResult("foo2");
    var results = testBrokenRulesObj.Content;

		expect(results.length).toBe(2);
		expect(results[0].RuleName).toBe("foo1");
		expect(results[1].RuleName).toBe("foo3");
		done();
	});

	it("hasError false add only", function (done) {
    var testBrokenRulesObj = new Cmp.Ui.Rules.BrokenRuleResultCollection();

    testBrokenRulesObj.AddRuleResult("foo1", "foo1 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Warning);
    testBrokenRulesObj.AddRuleResult("foo2", "foo2 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Warning);
    testBrokenRulesObj.AddRuleResult("foo3", "foo3 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Warning);

    var results = testBrokenRulesObj.Content;

		expect(testBrokenRulesObj.HasError).toBe(false);
		done();
	});

	it("hasError true add only", function (done) {
    var testBrokenRulesObj = new Cmp.Ui.Rules.BrokenRuleResultCollection();

    testBrokenRulesObj.AddRuleResult("foo1", "foo1 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Warning);
    testBrokenRulesObj.AddRuleResult("foo2", "foo2 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Error);
    testBrokenRulesObj.AddRuleResult("foo3", "foo3 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Warning);

    var results = testBrokenRulesObj.Content;

		expect(testBrokenRulesObj.HasError).toBe(true);
		done();
	});

	it("hasError true with remove", function (done) {
    var testBrokenRulesObj = new Cmp.Ui.Rules.BrokenRuleResultCollection();

    testBrokenRulesObj.AddRuleResult("foo1", "foo1 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Warning);
    testBrokenRulesObj.AddRuleResult("foo2", "foo2 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Error);
    testBrokenRulesObj.AddRuleResult("foo3", "foo3 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Error);
    testBrokenRulesObj.RemoveRuleResult("foo3");

    var results = testBrokenRulesObj.Content;

		expect(testBrokenRulesObj.HasError).toBe(true);
		done();
	});


	it("hasNotification false add only", function (done) {
    var testBrokenRulesObj = new Cmp.Ui.Rules.BrokenRuleResultCollection();

    testBrokenRulesObj.AddRuleResult("foo1", "foo1 msg", Cmp.Ui.Rules.BrokenRuleSeverities.None);
    testBrokenRulesObj.AddRuleResult("foo2", "foo2 msg", Cmp.Ui.Rules.BrokenRuleSeverities.None);
    testBrokenRulesObj.AddRuleResult("foo3", "foo3 msg", Cmp.Ui.Rules.BrokenRuleSeverities.None);

    var results = testBrokenRulesObj.Content;

		expect(testBrokenRulesObj.HasError).toBe(false);
		done();
	});

	it("hasNotification true add only", function (done) {
    var testBrokenRulesObj = new Cmp.Ui.Rules.BrokenRuleResultCollection();

    testBrokenRulesObj.AddRuleResult("foo1", "foo1 msg", Cmp.Ui.Rules.BrokenRuleSeverities.None);
    testBrokenRulesObj.AddRuleResult("foo2", "foo2 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Error);
    testBrokenRulesObj.AddRuleResult("foo3", "foo3 msg", Cmp.Ui.Rules.BrokenRuleSeverities.None);

    var results = testBrokenRulesObj.Content;

		expect(testBrokenRulesObj.HasError).toBe(true);
		done();
	});
	it("hasNotification true with remove", function (done) {
    var testBrokenRulesObj = new Cmp.Ui.Rules.BrokenRuleResultCollection();

    testBrokenRulesObj.AddRuleResult("foo1", "foo1 msg", Cmp.Ui.Rules.BrokenRuleSeverities.None);
    testBrokenRulesObj.AddRuleResult("foo2", "foo2 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Error);
    testBrokenRulesObj.AddRuleResult("foo3", "foo3 msg", Cmp.Ui.Rules.BrokenRuleSeverities.Error);
    testBrokenRulesObj.RemoveRuleResult("foo3");

    var results = testBrokenRulesObj.Content;

		expect(testBrokenRulesObj.HasError).toBe(true);
		done();
	});



});