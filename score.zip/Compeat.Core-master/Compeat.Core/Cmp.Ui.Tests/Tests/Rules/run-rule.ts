﻿/// <reference path="../../common-refs.d.ts" />﻿

describe("Cmp.Ui.Rules", function () {

    var cmpPromise: Cmp.Ui.Services.PromiseService;
    var _$rootScope: angular.IRootScopeService;

    beforeEach(function (done) {

        module('cmp.ui.services');

        inject(function (_cmpPromise_: Cmp.Ui.Services.PromiseService, $rootScope: angular.IRootScopeService) {
            cmpPromise = _cmpPromise_;
            _$rootScope = $rootScope;
        });

		Cmp.Ui.Rules.CmpRule.RuleCounter = 0;
		done();
  });

	it("_runRule collection added when missing, and is empty", function (done) {

		var testRule = new Cmp.Ui.Rules.CmpRule(function (resolve: (isValid: boolean) => void) {
			return resolve(true);
		}, "foo msg", Cmp.Ui.Rules.BrokenRuleSeverities.None, ["Foo"], Cmp.Ui.Rules.NgMessageTypes.Required);

		var testModel: Cmp.Ui.Rules.IHaveRules = {
			Foo: 'test',
			BrokenRules: undefined,
			RuledChildProperties: undefined,
            GetRules: function (): cmp.IPromise<Array<Cmp.Ui.Rules.CmpRule>> {
				return undefined;
			}
		};

        Cmp.Ui.Rules._runRule(testModel, testRule, cmpPromise).then(function () {
			var brokenRules = testModel.BrokenRules;
			var fooRules = brokenRules["Foo"];
			expect(fooRules && fooRules.Content).toBeTruthy();
			expect(fooRules.Content.length).toBe(0);
			done();
        });

        _$rootScope.$digest();
	});

	it("_runRule error added on fail", function (done) {

		var testRule = new Cmp.Ui.Rules.CmpRule(function (resolve: (isValid: boolean) => void) {
			return resolve(false);
		}, "foo msg", Cmp.Ui.Rules.BrokenRuleSeverities.Error, ["Foo"], Cmp.Ui.Rules.NgMessageTypes.Required);

		var testModel: Cmp.Ui.Rules.IHaveRules = {
			Foo: 'test',
			BrokenRules: undefined,
			RuledChildProperties: undefined,
            GetRules: function (): cmp.IPromise<Array<Cmp.Ui.Rules.CmpRule>> {
				return undefined;
			}
		};

        Cmp.Ui.Rules._runRule(testModel, testRule, cmpPromise).then(function () {
			var brokenRules = testModel.BrokenRules;
			var fooRules = brokenRules["Foo"];
			expect(fooRules && fooRules.Content).toBeTruthy();
			var resultCollection = fooRules.Content;
			expect(resultCollection.length).toBe(1);
			expect(resultCollection[0].RuleName).toBe("_rule0");
			expect(resultCollection[0].Message).toBe("foo msg");
			expect(resultCollection[0].Severity).toBe(Cmp.Ui.Rules.BrokenRuleSeverities.Error);
			done();
        });
        _$rootScope.$digest();
	});

	it("_runRule error removed on rerun with success", function (done) {

    var desiredErrorResult = false;
		var testRule = new Cmp.Ui.Rules.CmpRule(function (resolve: (isValid: boolean) => void) {
			return resolve(desiredErrorResult);
		}, "foo msg", Cmp.Ui.Rules.BrokenRuleSeverities.Error, ["Foo"], Cmp.Ui.Rules.NgMessageTypes.Required);

		var testModel: Cmp.Ui.Rules.IHaveRules = {
			Foo: 'test',
			BrokenRules: undefined,
			RuledChildProperties: undefined,
            GetRules: function (): cmp.IPromise<Array<Cmp.Ui.Rules.CmpRule>> {
				return undefined;
			}
		};
        Cmp.Ui.Rules._runRule(testModel, testRule, cmpPromise).then(function () {
			var brokenRules = testModel.BrokenRules;
			var fooRules = brokenRules["Foo"];
			var resultCollection = fooRules.Content;
			expect(resultCollection.length).toBe(1);

			desiredErrorResult = true;
            Cmp.Ui.Rules._runRule(testModel, testRule, cmpPromise).then(function () {
				var brokenRules = testModel.BrokenRules;
				var fooRules = brokenRules["Foo"];
				var resultCollection = fooRules.Content;
				expect(resultCollection.length).toBe(0);
				done();
			});
        });

        _$rootScope.$digest();
	});


});