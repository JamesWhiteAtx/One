﻿/// <reference path="../../common-refs.d.ts" />﻿

describe("Cmp.Ui.Services.LocalStorage", function () {

    var theLocalStorage: Cmp.Ui.Services.LocalStorageService;
    var path;

    beforeEach(function () {
        theLocalStorage = new Cmp.Ui.Services.LocalStorageService();
        path = "myLocalStorage";
    });

    it("WriteObject", function () {
        var val = "100";
        theLocalStorage.WriteObject(path, val);
        expect(theLocalStorage.ReadObject(path)).toBe(val);
    });

    it("ReadObject", function () {
        var val = "101";
        theLocalStorage.WriteObject(path, val);
        expect(theLocalStorage.ReadObject(path)).toBe(val);
    });

    it("Clear", function () {
        var val = "102";
        theLocalStorage.WriteObject(path, val);
        theLocalStorage.Clear();
        expect(theLocalStorage.ReadObject(path)).toBeNull();
    });

    it("Remove", function () {
        var val = "103";
        theLocalStorage.WriteObject(path, val);
        theLocalStorage.Remove(path);
        expect(theLocalStorage.ReadObject(path)).toBeNull();
    });
});