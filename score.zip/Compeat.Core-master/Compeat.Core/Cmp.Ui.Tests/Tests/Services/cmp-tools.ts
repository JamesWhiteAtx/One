﻿/// <reference path="../../common-refs.d.ts" />﻿

describe("Cmp.Ui.Services.CmpTools", function () {

    it("GetFirstDayOfWeek", function (done) {

        var service = new Cmp.Ui.Services.CmpTools();

        expect(service.GetFirstDayOfWeek(undefined, Cmp.Ui.Enums.DayOfWeek.Sunday)).toBeUndefined();
        expect(service.GetFirstDayOfWeek(null, Cmp.Ui.Enums.DayOfWeek.Tuesday)).toBeNull();

        // month is 0 based
        expect(service.GetFirstDayOfWeek(new Date(2015, 8, 3), Cmp.Ui.Enums.DayOfWeek.Sunday)).toEqual(new Date(2015, 7, 30));
        expect(service.GetFirstDayOfWeek(new Date(2015, 8, 3), Cmp.Ui.Enums.DayOfWeek.Monday)).toEqual(new Date(2015, 7, 31));
        expect(service.GetFirstDayOfWeek(new Date(2015, 8, 3), Cmp.Ui.Enums.DayOfWeek.Tuesday)).toEqual(new Date(2015, 8, 1));
        done();
    });
    it("GetLastDayOfWeek", function (done) {

        var service = new Cmp.Ui.Services.CmpTools();

        expect(service.GetLastDayOfWeek(undefined, Cmp.Ui.Enums.DayOfWeek.Sunday)).toBeUndefined();
        expect(service.GetLastDayOfWeek(null, Cmp.Ui.Enums.DayOfWeek.Tuesday)).toBeNull();

        // month is 0 based
        expect(service.GetLastDayOfWeek(new Date(2015, 8, 3), Cmp.Ui.Enums.DayOfWeek.Sunday)).toEqual(new Date(2015, 8, 5));
        expect(service.GetLastDayOfWeek(new Date(2015, 8, 3), Cmp.Ui.Enums.DayOfWeek.Monday)).toEqual(new Date(2015, 8, 6));
        expect(service.GetLastDayOfWeek(new Date(2015, 8, 3), Cmp.Ui.Enums.DayOfWeek.Tuesday)).toEqual(new Date(2015, 8, 7));
        done();
    });

    it("GetBrowserTimeFromUTC", function (done) {

        var service = new Cmp.Ui.Services.CmpTools();

        expect(service.GetBrowserTimeFromUTC(moment('02/01/2001 01:02:03', 'MM/DD/YYYY hh:mm:ss').utc().toDate())).toEqual(moment(new Date(2001, 1, 1, 7, 2, 3)).local().toDate());
        done();
    });

    it("GetUTCFromBrowserTime", function (done) {

        var service = new Cmp.Ui.Services.CmpTools();
        var result = moment(service.GetUTCFromBrowserTime(moment([2001, 1, 1, 7, 2, 3]).toDate())).format('MM/DD/YYYY hh:mm:ss');
        var shouldBe = moment([2001, 1, 1, 1, 2, 3]).utc().format('MM/DD/YYYY hh:mm:ss');
        expect(result).toEqual(shouldBe);
        done();
    });
});