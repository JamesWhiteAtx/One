﻿/// <reference path="../../common-refs.d.ts" />﻿

describe("Cmp.Ui.Services._BaseDeDataService", function () {

    it("GetRecord id -1 (aka new item)", function (done) {
		var callCount = 0;
		var finalModel = null;
		var stateParams: any = {
			id: "-1"
		};
		var returnModel = {
			foo: 'bar'
		};
		var promiseService = Tests.StackMocks.MockPromiseService();
        promiseService.Promise = (callback: (resolve: (val) => void, reject: (error?: any) => void) => void): cmp.IPromise<any> => {
            var resolve = () => { };
            var reject = () => { };
            callback(resolve, reject);
            return Tests.StackMocks.MockResolvedPromise(finalModel);//finalModel will be set by the GetRecordDone call defined in the controller below
        };
		var baseTools = Tests.StackMocks.MockBaseTools();
		baseTools.CreateInstance = (constructor) => {
			if (constructor === 'constructor') {
				return returnModel;
			} else {
				return null;
			}
		}
		var timeoutService = Tests.StackMocks.MockTimeout;
        var service = new Cmp.Ui.Services._BaseDeDataService<any, any>(stateParams, promiseService, baseTools, timeoutService);
		var controller: any = {
			GetConstructor: () => {
				return <any>'constructor';
			},
			GetRecordDone: (model) => {
				expect(model).toBe(returnModel);
				callCount++;
				finalModel = model;
				return Tests.StackMocks.MockResolvedPromise(finalModel);
			}, 
			SetNewRecordDefaults: (model) => {
				//working
				expect(model).toBe(returnModel);
				callCount++;
			}
		};

		service.GetRecord(controller).then((model) => {
			expect(model).toBe(returnModel);
			callCount++;
		});
		expect(callCount).toBe(3);//make sure all tests were run
        done();
    });


    it("GetRecord with an id (existing item)", function (done) {
		var callCount = 0;
		var finalModel = null;
		var expectedUrl = 'my url';
		var expectedArgs = 'my args';
		var stateParams: any = {
			id: "99"
		};
		var returnModel = {
			foo: 'bar'
		};
		var promiseService = Tests.StackMocks.MockPromiseService();
        promiseService.Promise = (callback: (resolve: (val) => void, reject: (error?: any) => void) => void): cmp.IPromise<any> => {
            var resolve = () => { };
            var reject = () => { };
            callback(resolve, reject);
            return Tests.StackMocks.MockResolvedPromise(finalModel);//finalModel will be set by the GetRecordDone call defined in the controller below
        };
		var baseTools = Tests.StackMocks.MockBaseTools();
		var timeoutService = Tests.StackMocks.MockTimeout;
        var service = new Cmp.Ui.Services._BaseDeDataService<any, any>(stateParams, promiseService, baseTools, timeoutService);
		var controller: any = {
			GetConstructor: () => {
				return <any>'constructor';
			},
			GetRecordDone: (model) => {
				expect(model).toBe(returnModel);
				callCount++;
				finalModel = model;
				return Tests.StackMocks.MockResolvedPromise(finalModel);
			},
			GetByIdUrl: (controller) => {
				callCount++;
				return expectedUrl;
			},
			GetByIdArgs: (controller, id) => {
				expect(id).toBe('99');
				callCount++;
				return expectedArgs;
			}, 
			GetRecordData: (url, args, constructor) => {
				expect(url).toBe(expectedUrl);
				expect(args).toBe(expectedArgs);
				expect(constructor).toBe('constructor');
				callCount++;
				return Tests.StackMocks.MockResolvedPromise(returnModel);
			}
		};

		service.GetRecord(controller).then((model) => {
			expect(model).toBe(returnModel);
			callCount++;
		});
		expect(callCount).toBe(5);//make sure all tests were run
        done();
    });
});