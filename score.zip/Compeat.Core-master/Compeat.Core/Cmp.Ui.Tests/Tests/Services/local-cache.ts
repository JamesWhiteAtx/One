﻿/// <reference path="../../common-refs.d.ts" />﻿
/// <reference path="../../mocks/shared-stack-mocks.ts" />


enum TestCacheTypes {
    Unknown,
    Test1,
    Test2
}

describe("Cmp.Ui.Services.LocalCache", function () {
    var httpBackend: angular.IHttpBackendService;
    var http: angular.IHttpService;
    var baseTools: Cmp.Ui.Services.IBaseTools;
    var _rootScope: angular.IRootScopeService;
    var _timeout: angular.ITimeoutService;

    var testUrl = "testPath/get";
    var testCachePathProvider: Cmp.Ui.Services.ILocalCachePaths<TestCacheTypes> = {
        GetPromisePath: (key) => {
            return testUrl;
        }
    };
    var testCacheKey1: Cmp.Ui.Services.CacheKey<TestCacheTypes> = new Cmp.Ui.Services.CacheKey<TestCacheTypes>(TestCacheTypes.Test1);
    var testCacheKey2: Cmp.Ui.Services.CacheKey<TestCacheTypes> = new Cmp.Ui.Services.CacheKey<TestCacheTypes>(TestCacheTypes.Test2);
    var localCacheService: Cmp.Ui.Services.ILocalCache<TestCacheTypes>;
    var expectedResponseTest1 = [
        98,
        99
    ];
    var expectedResponseTest2 = [
        100,
        101
    ];

    function expectRejection(promise, done) {
        promise.then(
            () => {
                expect(false).toBe(true);
                done();
            },
            (error) => {
                expect(true).toBe(true);
                done();
            });
    }

    beforeEach(function (done) {
        module('cmp.ui.services');
        Tests.StackMocks.MockToastr();
        inject(function ($httpBackend,
            $http: angular.IHttpService,
            _baseTools_: Cmp.Ui.Services.IBaseTools,
            $timeout: angular.ITimeoutService,
            $rootScope: angular.IRootScopeService,
            _cmpLocalCache_: Cmp.Ui.Services.ILocalCache<TestCacheTypes>) {

            httpBackend = $httpBackend;
            http = $http;
            baseTools = _baseTools_;
            _timeout = $timeout;
            _rootScope = $rootScope;
            localCacheService = _cmpLocalCache_;
            done();
        });
    });

    afterEach(function (done) {
        //httpBackend.verifyNoOutstandingExpectation();
        httpBackend.verifyNoOutstandingRequest();
        done();
    });

    it("GetCachePromise-GoodResponse", function () {
        var returnVal: Array<number>;
        httpBackend.expectPOST(testUrl)
            .respond(200, expectedResponseTest1);

        localCacheService.GetCachePromise<Array<number>>(testCachePathProvider, testCacheKey1, expectedResponseTest1)
            .then((result) => {
                returnVal = result;
            });

        httpBackend.flush();

        expect(returnVal).toBeTruthy();
        expect(returnVal.length).toBe(2);

        expect(returnVal[0]).toBe(expectedResponseTest1[0]);
        expect(returnVal[1]).toBe(expectedResponseTest1[1]);
    });

    it("GetCachePromise-Only1Request", function () {
        var returnVal1: Array<number>;
        var returnVal2: Array<number>;
        httpBackend.expectPOST(testUrl)
            .respond(200, expectedResponseTest1);

        localCacheService.GetCachePromise<Array<number>>(testCachePathProvider, testCacheKey1, expectedResponseTest1)
            .then((result1) => {
                returnVal1 = result1;

                //second request is not expected by so should error if is used
                localCacheService.GetCachePromise<Array<number>>(testCachePathProvider, testCacheKey1, expectedResponseTest1)
                    .then((result2) => {
                        returnVal2 = result2;
                    });
            });

        httpBackend.flush();
        expect(returnVal1).toBeTruthy();
        expect(returnVal1.length).toBe(2);
        expect(returnVal2).toBeTruthy();
        expect(returnVal2.length).toBe(2);

        expect(returnVal2).toBe(returnVal1);
    });

    it("GetCachePromise-BadResponse", function () {

        httpBackend.expectPOST(testUrl)
            .respond(500, {});

        expectRejection(localCacheService.GetCachePromise<Array<number>>(testCachePathProvider, testCacheKey1, expectedResponseTest1), function () { });

        httpBackend.flush();
    });

    it("GetCachePromise-BadResponse Request is repeated", function () {
        var returnVal1: Array<number>;

        httpBackend.expectPOST(testUrl)
            .respond(500, {});

        expectRejection(localCacheService.GetCachePromise<Array<number>>(testCachePathProvider, testCacheKey1, expectedResponseTest1), function () { });

        httpBackend.flush();

        httpBackend.expectPOST(testUrl)
            .respond(200, expectedResponseTest1);

        localCacheService.GetCachePromise<Array<number>>(testCachePathProvider, testCacheKey1, expectedResponseTest1)
            .then((result1) => {
                returnVal1 = result1;
            });
        httpBackend.flush();

        expect(returnVal1).toBeTruthy();
        expect(returnVal1.length).toBe(2);
        expect(returnVal1[0]).toBe(expectedResponseTest1[0]);
        expect(returnVal1[1]).toBe(expectedResponseTest1[1]);
    });

    it("GetCachePromise-2RequestsDifferentTypes", function () {
        var returnVal1: Array<number>;
        var returnVal2: Array<number>;
        httpBackend.expectPOST(testUrl)
            .respond(200, expectedResponseTest1);
        httpBackend.expectPOST(testUrl)
            .respond(200, expectedResponseTest2);

        localCacheService.GetCachePromise<Array<number>>(testCachePathProvider, testCacheKey1, expectedResponseTest1)
            .then((result1) => {
                returnVal1 = result1;
            });


        localCacheService.GetCachePromise<Array<number>>(testCachePathProvider, testCacheKey2, expectedResponseTest2)
            .then((result2) => {
                returnVal2 = result2;
            });

        httpBackend.flush();
        expect(returnVal1).toBeTruthy();
        expect(returnVal1.length).toBe(2);
        expect(returnVal2).toBeTruthy();
        expect(returnVal2.length).toBe(2);

        expect(returnVal1[0]).toBe(expectedResponseTest1[0]);
        expect(returnVal1[1]).toBe(expectedResponseTest1[1]);
        expect(returnVal2[0]).toBe(expectedResponseTest2[0]);
        expect(returnVal2[1]).toBe(expectedResponseTest2[1]);
    });

    it("ClearWholeCache", function () {
        var returnVal1: Array<number>;
        var returnVal2: Array<number>;
        httpBackend.expectPOST(testUrl)
            .respond(200, expectedResponseTest1);
        httpBackend.expectPOST(testUrl)
            .respond(200, expectedResponseTest2);

        localCacheService.GetCachePromise<Array<number>>(testCachePathProvider, testCacheKey1, expectedResponseTest1)
            .then((result1) => { });

        localCacheService.GetCachePromise<Array<number>>(testCachePathProvider, testCacheKey2, expectedResponseTest2)
            .then((result2) => {});

        httpBackend.flush();

        //now clear the cache to make sure the requests happen again
        localCacheService.ClearWholeCache();
        httpBackend.expectPOST(testUrl)
            .respond(200, expectedResponseTest1);
        httpBackend.expectPOST(testUrl)
            .respond(200, expectedResponseTest2);

        localCacheService.GetCachePromise<Array<number>>(testCachePathProvider, testCacheKey1, expectedResponseTest1)
            .then((result1) => { });

        localCacheService.GetCachePromise<Array<number>>(testCachePathProvider, testCacheKey2, expectedResponseTest2)
            .then((result2) => { });

        httpBackend.flush();
    });
});

describe("Cmp.Ui.Services.CacheKey", function () {
    var setupNewCacheKey = (ct: TestCacheTypes, storeNum?: number, strVal?: string): Cmp.Ui.Services.CacheKey<TestCacheTypes> => {
        var retVal = new Cmp.Ui.Services.CacheKey<TestCacheTypes>(ct);
        if (!Cmp.Js.IsNullOrUndefined(storeNum)) {
            retVal.StoreNum = storeNum;
        }
        if (!Cmp.Js.IsNullOrUndefined(strVal)) {
            retVal.StrVal1 = strVal;
        }
        return retVal;
    };

    it("Guid", function () {
        expect(setupNewCacheKey(TestCacheTypes.Unknown).Guid()).toBe(TestCacheTypes.Unknown.toString());
        expect(setupNewCacheKey(TestCacheTypes.Test1).Guid()).toBe(TestCacheTypes.Test1.toString());
        expect(setupNewCacheKey(TestCacheTypes.Test2).Guid()).toBe(TestCacheTypes.Test2.toString());

        expect(setupNewCacheKey(TestCacheTypes.Test1, 0).Guid()).toBe(TestCacheTypes.Test1.toString() + '-0');
        expect(setupNewCacheKey(TestCacheTypes.Test1, 99).Guid()).toBe(TestCacheTypes.Test1.toString() + '-99');

        expect(setupNewCacheKey(TestCacheTypes.Test1, 99, 'teststr').Guid()).toBe(TestCacheTypes.Test1.toString() + '-99-teststr');
    });
});