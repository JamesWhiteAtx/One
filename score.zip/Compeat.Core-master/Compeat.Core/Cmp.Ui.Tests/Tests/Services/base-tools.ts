﻿/// <reference path="../../common-refs.d.ts" />﻿
/// <reference path="../../mocks/shared-stack-mocks.ts" />



class BasToolsDummyClassNoLoadFromRaw {
    public foo: string;
    public fromUrl: string;
    constructor() { }
    public TestFunction() { }
}
class BasToolsDummyClass {
    public foo: string;
    public fromUrl: string;
    constructor() { }
    public LoadFromRaw = (fromUrl: string, rawObj: any) => {
        this.fromUrl = fromUrl;
        this.foo = rawObj.foo;
    }
    public TestFunction() { }
}


describe("Cmp.Ui.Services.DataService", function () {

    beforeEach(function (done) {
        module('cmp.ui.services');
		done();
    });

    afterEach(function (done) {
        done();
    });

    it("GetFilledInstance No LoadFromRaw defined", function () {
        var returnVal = null;
        var service = new Cmp.Ui.Services._BaseTools(null, null, null, null);
		service.CreateInstance = () => {
			return new BasToolsDummyClassNoLoadFromRaw();
		}
        returnVal = service.GetFilledInstance('foo.com', { foo: 'test' }, BasToolsDummyClassNoLoadFromRaw);

        expect(returnVal.foo).toBeFalsy();
        expect(returnVal.fromUrl).toBeFalsy();
    });

    it("GetFilledInstance with LoadFromRaw defined", function () {
        var returnVal = null;
        var service = new Cmp.Ui.Services._BaseTools(null, null, null, null);
		service.CreateInstance = () => {
			return new BasToolsDummyClass();
		}
        returnVal = service.GetFilledInstance('foo.com', { foo: 'test' }, BasToolsDummyClassNoLoadFromRaw);

        expect(returnVal.foo).toBe('test');
        expect(returnVal.fromUrl).toBe('foo.com');
    });


});