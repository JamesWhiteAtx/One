﻿/// <reference path="../../common-refs.d.ts" />﻿
/// <reference path="../../mocks/shared-stack-mocks.ts" />



class DataServiceDummyClass {
    public foo: string;
    public fromUrl: string;
    constructor(public baseTools: Cmp.Ui.Services.IBaseTools) { }	
    public LoadFromRaw = (fromUrl: string, rawObj: any) => {
        this.fromUrl = fromUrl;
        this.foo = rawObj.foo;
    }
    public TestFunction() { }
}


describe("Cmp.Ui.Services.DataService", function () {
    var httpBackend: angular.IHttpBackendService;
    var http: angular.IHttpService;
    var baseTools: Cmp.Ui.Services.IBaseTools;
    var _rootScope: angular.IRootScopeService;
    var _timeout: angular.ITimeoutService;
    var emptyLogger = <any>{
        Error: function (message: string, data: any) { }
    };
    beforeEach(function (done) {
        module('cmp.ui.services');
        inject(function ($httpBackend,
            $http: angular.IHttpService,
            _baseTools_: Cmp.Ui.Services.IBaseTools,
            $timeout: angular.ITimeoutService,
            $rootScope: angular.IRootScopeService) {

            httpBackend = $httpBackend;
            http = $http;
            baseTools = _baseTools_;
            _timeout = $timeout;
            _rootScope = $rootScope;
            done();
        });
    });

    afterEach(function (done) {
        //httpBackend.verifyNoOutstandingExpectation();
        httpBackend.verifyNoOutstandingRequest();
        done();
    });

    it("GetData No Class wrapper", function () {
        var expectedResponse = { foo: "bar" };
        var args = { test: "x" };
        var returnVal = null;
        httpBackend.expectPOST('foo.com', args)
            .respond(200, expectedResponse);

        var service = new Cmp.Ui.Services._DataService(http, baseTools, emptyLogger);
        service.GetData('foo.com', args).then(function (retVal: any) {
            returnVal = retVal;
        }, function () {
        });
        httpBackend.flush();
        //flush runs a digest cycle
        expect(returnVal.foo).toBe('bar');
    });

    it("GetData With Class wrapper", function () {
        var expectedResponse = { foo: "bar" };
        var args = { test: "x" };
        var returnVal = null;
        httpBackend.expectPOST('foo.com', args)
            .respond(200, expectedResponse);

        var service = new Cmp.Ui.Services._DataService(http, baseTools, emptyLogger);
        service.GetData('foo.com', args, DataServiceDummyClass).then(function (retVal: any) {
            returnVal = retVal;
        }, function () {
        });
        httpBackend.flush();
        //flush runs a digest cycle
        expect(returnVal.foo).toBe('bar');
        expect(returnVal.fromUrl).toBe('foo.com');
        //make sure the functions exist to prove it was wrapped
        expect(returnVal.TestFunction).toBeTruthy();
    });

    it("SendData No Class wrapper", function () {
        var expectedResponse = { foo: "bar" };
        var args = { test: "x" };
        var returnVal = null;
        httpBackend.expectPOST('foo.com', args)
            .respond(200, expectedResponse);

        var service = new Cmp.Ui.Services._DataService(http, baseTools, emptyLogger);
        service.SendData('foo.com', args).then(function (retVal: any) {
            returnVal = retVal;
        }, function () {
        });
        httpBackend.flush();
        //flush runs a digest cycle
        expect(returnVal.foo).toBe('bar');
    });

    it("SendData With Class wrapper", function () {
        var expectedResponse = { foo: "bar" };
        var args = { test: "x" };
        var returnVal = null;
        httpBackend.expectPOST('foo.com', args)
            .respond(200, expectedResponse);

        var service = new Cmp.Ui.Services._DataService(http, baseTools, emptyLogger);
        service.SendData('foo.com', args, DataServiceDummyClass).then(function (retVal: any) {
            returnVal = retVal;
        }, function () {
        });
        httpBackend.flush();
        //flush runs a digest cycle
        expect(returnVal.foo).toBe('bar');
        expect(returnVal.fromUrl).toBe('foo.com');
        //make sure the functions exist to prove it was wrapped
        expect(returnVal.TestFunction).toBeTruthy();
    });

    it("SendModel No Class wrapper", function () {
        var expectedResponse = { foo: "bar" };
        var args = {
            test: "x",
            ToJson(): Object { return { test: this.test }; }
        };
        var returnVal = null;
        httpBackend.expectPOST('foo.com', args)
            .respond(200, expectedResponse);

        var service = new Cmp.Ui.Services._DataService(http, baseTools, emptyLogger);
        service.SendModel('foo.com', args).then(function (retVal: any) {
            returnVal = retVal;
        }, function () {
        });
        httpBackend.flush();
        //flush runs a digest cycle
        expect(returnVal.foo).toBe('bar');
    });

    it("SendModel With Class wrapper", function () {
        var expectedResponse = { foo: "bar" };
        var args = {
            test: "x",
            ToJson(): Object { return { test: this.test }; }
        };
        var returnVal = null;
        httpBackend.expectPOST('foo.com', args)
            .respond(200, expectedResponse);

        var service = new Cmp.Ui.Services._DataService(http, baseTools, emptyLogger);
        service.SendModel('foo.com', args, DataServiceDummyClass).then(function (retVal: any) {
            returnVal = retVal;
        }, function () {
        });
        httpBackend.flush();
        //flush runs a digest cycle
        expect(returnVal.foo).toBe('bar');
        expect(returnVal.fromUrl).toBe('foo.com');
        //make sure the functions exist to prove it was wrapped
        expect(returnVal.TestFunction).toBeTruthy();
    });

    it("GetDataWithList", function () {
        var expectedResponse = [{ foo: "bar1" }, { foo: "bar2" }];
        var args = { test: "x" };
        var returnVal = null;
        httpBackend.expectPOST('foo.com', args)
            .respond(200, expectedResponse);

        var service = new Cmp.Ui.Services._DataService(http, baseTools, emptyLogger);
        service.GetDataList('foo.com', args, DataServiceDummyClass).then(function (retVal: any) {
            returnVal = retVal;
        }, function () {
        });
        httpBackend.flush();

        expect(returnVal).toBeTruthy();
        expect(returnVal.length).toBe(2);
        //flush runs a digest cycle
        expect(returnVal[0].foo).toBe('bar1');
        expect(returnVal[0].fromUrl).toBe('foo.com');
        //make sure the functions exist to prove it was wrapped
        expect(returnVal[0].TestFunction).toBeTruthy();

        expect(returnVal[1].foo).toBe('bar2');
        expect(returnVal[1].fromUrl).toBe('foo.com');
        //make sure the functions exist to prove it was wrapped
        expect(returnVal[1].TestFunction).toBeTruthy();
    });

});