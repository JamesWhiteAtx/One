﻿/// <reference path="../../common-refs.d.ts" />﻿

describe("Cmp.Ui.Services.AuthInterceptor", function () {

    var cmpPromise: Cmp.Ui.Services.PromiseService;
    var _$rootScope: angular.IRootScopeService;

    beforeEach(function (done) {
        module('cmp.ui.services');

        inject(function (
            _cmpPromise_: Cmp.Ui.Services.PromiseService,
            $rootScope: angular.IRootScopeService) {

            cmpPromise = _cmpPromise_;
            _$rootScope = $rootScope;

            done();
        });
    });

    it("respose - 401", function (done) {

        _$rootScope.$broadcast = jasmine.createSpy("broacast spy");

        var interceptor = new Cmp.Ui.Services.AuthInterceptor(_$rootScope, cmpPromise);

        var responseData: angular.IHttpPromiseCallbackArg<any> = {
            data: "testData",
            status: 401
        };

        var result = interceptor.response(responseData);

        expect(_$rootScope.$broadcast).toHaveBeenCalledWith(Cmp.Ui.Services.AuthInterceptor.AUTH401_BROADCAST);
        
        // run internal promise
        _$rootScope.$apply();

        var errorRan = false;

        (<angular.IPromise<any>>result).then(
            (success) => { },
            (error) => {
                errorRan = true;
            })
            .then(() => {
                expect(errorRan).toBe(true);
                done();
            });

        // resolve the above promise
        _$rootScope.$apply();
    });

    it("respose - other", function (done) {

        _$rootScope.$broadcast = jasmine.createSpy("broacast spy");

        var interceptor = new Cmp.Ui.Services.AuthInterceptor(_$rootScope, cmpPromise);

        var responseData: angular.IHttpPromiseCallbackArg<any> = {
            data: "testData",
            status: 200
        };

        var result = interceptor.response(responseData);
        expect(_$rootScope.$broadcast).not.toHaveBeenCalled();
        expect(result).toBe(responseData);
        done();
    });

    it("responseError - 401", function (done) {

        _$rootScope.$broadcast = jasmine.createSpy("broacast spy");

        var interceptor = new Cmp.Ui.Services.AuthInterceptor(_$rootScope, cmpPromise);

        var rejection: any = {
            status: 401
        };

        var result = interceptor.responseError(rejection);
        expect(_$rootScope.$broadcast).toHaveBeenCalledWith(Cmp.Ui.Services.AuthInterceptor.AUTH401_BROADCAST);
        done();
    });

    it("responseError - other", function (done) {

        _$rootScope.$broadcast = jasmine.createSpy("broacast spy");

        var interceptor = new Cmp.Ui.Services.AuthInterceptor(_$rootScope, cmpPromise);

        var rejection: any = {
            status: 403
        };

        var result = interceptor.responseError(rejection);
        expect(_$rootScope.$broadcast).not.toHaveBeenCalled();
        done();
    });
});