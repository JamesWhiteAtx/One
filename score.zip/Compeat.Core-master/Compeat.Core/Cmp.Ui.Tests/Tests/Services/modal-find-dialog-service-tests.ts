﻿/// <reference path="../../common-refs.d.ts" />﻿

describe('Service', function () {
	var fluentService: Cmp.Ui.Services.IModalFindFluentService;
	var injectedService: Cmp.Ui.Services.ICmpModalFindDialogService;

	var serviceModalOptions: any;

	var mokModalresult = {
		result: {
			then: (arg1, arg2) => { }
		}
	};

	var uibModalService: any = {
		open: (passedModalOptions: any): any => {
			serviceModalOptions = passedModalOptions;
			return mokModalresult;
		}
	}

	var mokPromise = {
		then: (successCallback, promiseValue) => null,
		'catch': (onRejected) => null,
		'finally': (finallyCallback) => null
	}

	var mokDefered = {
		resolve: (value?: any) => { },
		reject: (reason?: any) => { },
		notify: (state?: any) => { },
		promise: mokPromise
	}


	var mokQ: angular.IQService;
	var mokFilter: angular.IFilterService;
	var mokDefer = <T>(): angular.IDeferred<T> => { return null; };

	beforeEach(function () {
		inject(function ($q) {
			mokQ = $q;
			mokQ.defer = () => mokDefered;
		})
	});

	describe('Cmp.Ui.Services._ModalFindFluentService', function () {

		it('returns Q defer promise for Show method', function () {
			fluentService = new Cmp.Ui.Services._FluentModalFindService(uibModalService, mokQ, mokFilter, null);
			var result = fluentService.Show([1]);

			expect(result).toBe(mokPromise);
		});

		it('returns self from Size', function () {
			fluentService = new Cmp.Ui.Services._FluentModalFindService(uibModalService, mokQ, mokFilter, null);
			expect(fluentService.Size('x')).toBe(fluentService);
		});

		it('returns self from Title', function () {
			fluentService = new Cmp.Ui.Services._FluentModalFindService(uibModalService, mokQ, mokFilter, null);
			expect(fluentService.Title('x')).toBe(fluentService);
		});

		describe('field definition methods', function () {
			var configParam: Cmp.Ui.Bases.IFindFieldConfig;
			var defnType: string;
			var fieldDefn: Cmp.Ui.Bases.IFindFieldDefinition;

			beforeEach(function () {
				defnType = 'string';
				configParam = {
					name: 'name',
					title: 'title',
					width: 2
				};
				fieldDefn = new Cmp.Ui.Bases.BaseFindFieldDefinition(defnType, configParam);
			});

			it('returns self from AddFieldDefn', function () {
				fluentService = new Cmp.Ui.Services._FluentModalFindService(uibModalService, mokQ, mokFilter, null);
				expect(fluentService.AddFieldDefn(fieldDefn)).toBe(fluentService);
			});

			it('returns self from StringField', function () {
				fluentService = new Cmp.Ui.Services._FluentModalFindService(uibModalService, mokQ, mokFilter, null);
				expect(fluentService.StringField(configParam)).toBe(fluentService);
			});

			it('returns self from DateField', function () {
				fluentService = new Cmp.Ui.Services._FluentModalFindService(uibModalService, mokQ, mokFilter, null);
				expect(fluentService.DateField(configParam)).toBe(fluentService);
			});

			it('returns self from DateTimeField', function () {
				fluentService = new Cmp.Ui.Services._FluentModalFindService(uibModalService, mokQ, mokFilter, null);
				expect(fluentService.DateTimeField(configParam)).toBe(fluentService);
			});

			it('returns self from NumberField', function () {
				fluentService = new Cmp.Ui.Services._FluentModalFindService(uibModalService, mokQ, mokFilter, null);
				expect(fluentService.NumberField(configParam)).toBe(fluentService);
			});

			it('returns self from CurrencyField', function () {
				fluentService = new Cmp.Ui.Services._FluentModalFindService(uibModalService, mokQ, mokFilter, null);
				expect(fluentService.CurrencyField(configParam)).toBe(fluentService);
			});

			it('returns self from BooleanField', function () {
				fluentService = new Cmp.Ui.Services._FluentModalFindService(uibModalService, mokQ, mokFilter, null);
				expect(fluentService.BooleanField(configParam)).toBe(fluentService);
			});

		});

		it('returns self from TemplateOptions', function () {
			var templateOptions: Cmp.Ui.Services.ICmpModalServiceSettings;
			templateOptions = { OkText: 'TestOk' };
			fluentService = new Cmp.Ui.Services._FluentModalFindService(uibModalService, mokQ, mokFilter, null);
			expect(fluentService.TemplateOptions(templateOptions)).toBe(fluentService);
		});

		it('returns self from ModalOptions', function () {
			var settings: angular.ui.bootstrap.IModalSettings;
			settings = { templateUrl: 'some.url.com' };
			fluentService = new Cmp.Ui.Services._FluentModalFindService(uibModalService, mokQ, mokFilter, null);
			expect(fluentService.ModalOptions(settings)).toBe(fluentService);
		});

	});

	describe('Cmp.Ui.Services._CmpModalFindDialogService', function () {

		it('returns a fluent service from Modal method', function () {
			injectedService = new Cmp.Ui.Services._CmpModalFindDialogService(uibModalService, mokQ, mokFilter, null);

			fluentService = injectedService.Modal();

			expect(fluentService).toBeDefined();

			expect(fluentService.Size).toBeDefined();
			expect(fluentService.Title).toBeDefined();
			expect(fluentService.TemplateOptions).toBeDefined();
			expect(fluentService.ModalOptions).toBeDefined();
			expect(fluentService.AddFieldDefn).toBeDefined();
			expect(fluentService.StringField).toBeDefined();
			expect(fluentService.DateField).toBeDefined();
			expect(fluentService.DateTimeField).toBeDefined();
			expect(fluentService.NumberField).toBeDefined();
			expect(fluentService.CurrencyField).toBeDefined();
			expect(fluentService.BooleanField).toBeDefined();
			expect(fluentService.Show).toBeDefined();
		});

	});

});



