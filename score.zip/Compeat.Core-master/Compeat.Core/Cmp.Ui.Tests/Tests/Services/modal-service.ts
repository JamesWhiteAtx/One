﻿/// <reference path="../../common-refs.d.ts" />﻿

describe('Cmp.Ui.Services.CmpModalService', function () {
    var service: Cmp.Ui.Services._CmpModalService;

	var serviceModalOptions: any;

	var mockPromise = () => {
		return {
			then: () => mockPromise(),
			catch: () => mockPromise()
		}
	};

	var uibModalService: any = {
		open: (passedModalOptions: any): any => {
			serviceModalOptions = passedModalOptions;
			return {
                result: mockPromise(),
                opened: mockPromise(),
                rendered: mockPromise()
            };
		}
	};

    var mockCmpPromise = Tests.StackMocks.MockPromiseService(true);
    

	it('calls $uibModal service "open" method from then Open method', function () {
        service = new Cmp.Ui.Services._CmpModalService(uibModalService, mockCmpPromise);
		service.Open();
		expect(serviceModalOptions).toBeDefined();
	});

	describe('OpenModal method', function () {

		it('calls $uibModal service "open" method', function () {
            service = new Cmp.Ui.Services._CmpModalService(uibModalService, mockCmpPromise);
			service.OpenModal();
			expect(serviceModalOptions).toBeDefined();
		});

		it('assigns the default modal options', function () {
            service = new Cmp.Ui.Services._CmpModalService(uibModalService, mockCmpPromise);
			service.OpenModal();
			expect(serviceModalOptions.animation).toBe(true);
			expect(serviceModalOptions.templateUrl).toBe('cmp-ui/Component/CmpModal/cmp-modal-base.html');
			expect(serviceModalOptions.controller).toBe(Cmp.Ui.Services.CmpModalServiceController);
			expect(serviceModalOptions.controllerAs).toBe(Cmp.Ui.Services.CmpModalServiceController.ModalControllerName);

			expect(serviceModalOptions.resolve).toBeDefined();
			expect(serviceModalOptions.resolve.templateOptions).toBeNull();
		});

		it('assigns passed template options', function () {
			var expectedBodyContent = 'expected body content';

            service = new Cmp.Ui.Services._CmpModalService(uibModalService, mockCmpPromise);

			service.OpenModal({ BodyContent: expectedBodyContent });

			expect(serviceModalOptions.resolve).toBeDefined();
			expect(serviceModalOptions.resolve.templateOptions()).toBeDefined();

			var actualTemplateOptions = serviceModalOptions.resolve.templateOptions();

			expect(actualTemplateOptions).toBeDefined();
			expect(actualTemplateOptions.BodyContent).toBe(expectedBodyContent);
		});

		it('assigns passed modal options', function () {
			var expectedTemplateUrl = 'Expected Template Url';
            service = new Cmp.Ui.Services._CmpModalService(uibModalService, mockCmpPromise);

			service.OpenModal(null, { templateUrl: expectedTemplateUrl });

			expect(serviceModalOptions.templateUrl).toBe(expectedTemplateUrl);
		});

	});

	it('assigns template BodyContent template option with Confirm method', function () {
		var expectedBodyContent = 'expected body content';

        service = new Cmp.Ui.Services._CmpModalService(uibModalService, mockCmpPromise);

		service.Confirm(expectedBodyContent);

		var actualTemplateOptions = serviceModalOptions.resolve.templateOptions();

		expect(actualTemplateOptions).toBeDefined();
		expect(actualTemplateOptions.BodyContent).toBe(expectedBodyContent);
	});

	it('assigns template BodyContent template option with ConfirmUrl method', function () {
		var expectedBodyUrl = 'expected body content';

        service = new Cmp.Ui.Services._CmpModalService(uibModalService, mockCmpPromise);

		service.ConfirmUrl(expectedBodyUrl);

		var actualTemplateOptions = serviceModalOptions.resolve.templateOptions();

		expect(actualTemplateOptions).toBeDefined();
		expect(actualTemplateOptions.BodyUrl).toBe(expectedBodyUrl);
	});

	it('assigns the infrmational template options with Info method', function () {
        service = new Cmp.Ui.Services._CmpModalService(uibModalService, mockCmpPromise);

		service.Info('some info');

		var actualTemplateOptions = serviceModalOptions.resolve.templateOptions();

		expect(actualTemplateOptions).toBeDefined();
		expect(actualTemplateOptions.ConfirmIcon).toBe(false);
		expect(actualTemplateOptions.InfoIcon).toBe(true);
		expect(actualTemplateOptions.HideCancel).toBe(true);
		expect(actualTemplateOptions.TitleText).toBe('Core$Info');
	});

	it('assigns template BodyContent template option with Info method', function () {
		var expectedBodyContent = 'expected body content';

        service = new Cmp.Ui.Services._CmpModalService(uibModalService, mockCmpPromise);

		service.Info(expectedBodyContent);

		var actualTemplateOptions = serviceModalOptions.resolve.templateOptions();

		expect(actualTemplateOptions).toBeDefined();
		expect(actualTemplateOptions.BodyContent).toBe(expectedBodyContent);
	});

	it('assigns template BodyUrl template option with InfoUrl method', function () {
		var expectedBodyUrl = 'expected body content';

        service = new Cmp.Ui.Services._CmpModalService(uibModalService, mockCmpPromise);

		service.InfoUrl(expectedBodyUrl);

		var actualTemplateOptions = serviceModalOptions.resolve.templateOptions();

		expect(actualTemplateOptions).toBeDefined();
		expect(actualTemplateOptions.BodyUrl).toBe(expectedBodyUrl);
	});

	it('assigns template BodyContent template option with YesNoCancel method', function () {
		var expectedBodyContent = 'expected body content';
		var expectedTitle = 'expected title';

        service = new Cmp.Ui.Services._CmpModalService(uibModalService, mockCmpPromise);

		service.YesNoCancel(expectedBodyContent, expectedTitle);

		var actualTemplateOptions = serviceModalOptions.resolve.templateOptions();

		expect(actualTemplateOptions).toBeDefined();
		expect(actualTemplateOptions.BodyContent).toBe(expectedBodyContent);
		expect(actualTemplateOptions.TitleText).toBe(expectedTitle);
		expect(actualTemplateOptions.FooterUrl).toBe('cmp-ui/Component/CmpModal/yes-no-cancel.html');
	});

});