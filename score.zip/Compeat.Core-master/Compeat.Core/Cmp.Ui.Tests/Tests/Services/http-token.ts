﻿/// <reference path="../../common-refs.d.ts" />﻿
/// <reference path="../../mocks/shared-stack-mocks.ts" />

describe("Cmp.Ui.Services.IHttpToken", function () {
    var httpBackend: angular.IHttpBackendService;
    var http: angular.IHttpService;
    var baseTools: Cmp.Ui.Services.IBaseTools;
    var _rootScope: angular.IRootScopeService;
    var _timeout: angular.ITimeoutService;
    var cmpHttpToken: Cmp.Ui.Services.IHttpToken;
    var dataService: Cmp.Ui.Services.IDataService;
    var cmpPromise: Cmp.Ui.Services.PromiseService;

    beforeEach(function (done) {
        module('cmp.ui.services');
        Tests.StackMocks.MockToastr();
        inject(function ($httpBackend,
            $http: angular.IHttpService,
            _baseTools_: Cmp.Ui.Services.IBaseTools,
            $timeout: angular.ITimeoutService,
            $rootScope: angular.IRootScopeService,
            _cmpHttpToken_: Cmp.Ui.Services.IHttpToken,
            _dataService_: Cmp.Ui.Services.IDataService,
            _cmpPromise_: Cmp.Ui.Services.PromiseService) {

            httpBackend = $httpBackend;
            http = $http;
            baseTools = _baseTools_;
            _timeout = $timeout;
            _rootScope = $rootScope;
            cmpHttpToken = _cmpHttpToken_;
            dataService = _dataService_;
            cmpPromise = _cmpPromise_;
            done();
        });
    });

    afterEach(function (done) {
        //httpBackend.verifyNoOutstandingExpectation();
        httpBackend.verifyNoOutstandingRequest();
        done();
    });

    it("CheckToken - null response", function (done) {
        httpBackend.expectPOST('Authentication/GetToken')
            .respond(200, null);

        Cmp.Ui.Services.CheckToken(dataService, cmpPromise).then(function (result) {
            expect(result.Success).toBe(false);
            expect(result.Token).toBe('');
            done();
        });

        httpBackend.flush();
    });

    it("CheckToken - text response", function (done) {
        httpBackend
            .expectPOST('Authentication/GetToken')
            .respond(200, 'text');

        Cmp.Ui.Services.CheckToken(dataService, cmpPromise).then(function (result) {
            expect(result.Success).toBe(true);
            expect(result.Token).toBe('text');
            done();
        });

        httpBackend.flush();
    });

    it("CheckToken - 500 error", function (done) {
        httpBackend
            .expectPOST('Authentication/GetToken')
            .respond(500, {});

        Cmp.Ui.Services.CheckToken(dataService, cmpPromise).then(function (result) {
            expect(result.Success).toBe(false);
            expect(result.Token).toBe('');
            done();
        });

        httpBackend.flush();
    });

    it("cmpHttpToken - sets the token on the service", function (done) {
        httpBackend
            .expectPOST('Authentication/GetToken')
            .respond(200, 'text');

        cmpHttpToken.CheckToken().then(function () {
            expect(cmpHttpToken.Token).toBe('text');
            done();
        });
        
        httpBackend.flush();       
    });
});
