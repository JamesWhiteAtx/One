﻿/// <reference path="../../common-refs.d.ts" />﻿

describe("Cmp.Ui.Services.BusyIndicator", function () {
    
    var _timeout: angular.ITimeoutService;
    var _$rootScope: angular.IRootScopeService;

    beforeEach(function (done) {
        module('cmp.ui.services');

        inject(function (
            $timeout: angular.ITimeoutService,
            $rootScope: angular.IRootScopeService) {
            
            _timeout = $timeout;
            _$rootScope = $rootScope;
            done();
        });
    });

    it("Simple busy", function (done) {

        var indicator = new Cmp.Ui.Services._BusyIndicator(_timeout);
        indicator.MarkBusy();
        _$rootScope.$digest();
        expect(indicator.IsBusy).toBe(true);
        done();
    });

    it("Defaults to idle", function (done) {

        var indicator = new Cmp.Ui.Services._BusyIndicator(_timeout);
        expect(indicator.IsBusy).toBe(false);
        done();
    });

    it("Busy to idle", function (done) {

        var indicator = new Cmp.Ui.Services._BusyIndicator(_timeout);
        indicator.MarkBusy();
        expect(indicator.IsBusy).toBe(true);
        indicator.MarkBusy();
        _$rootScope.$digest();
        expect(indicator.IsBusy).toBe(true);

        indicator.MarkIdle();
        expect(indicator.IsBusy).toBe(true);
        indicator.MarkIdle();
        expect(indicator.IsBusy).toBe(false);
        done();
    });

    it("Extra idles do nothing", function (done) {

        var indicator = new Cmp.Ui.Services._BusyIndicator(_timeout);

        indicator.MarkBusy();
        _$rootScope.$digest();
        expect(indicator.IsBusy).toBe(true);

        indicator.MarkIdle();
        expect(indicator.IsBusy).toBe(false);
        indicator.MarkIdle();
        expect(indicator.IsBusy).toBe(false);
        
        indicator.MarkBusy();
        _$rootScope.$digest();
        expect(indicator.IsBusy).toBe(true);

        done();
    });

    it("Simple imediate busy", function (done) {

        var indicator = new Cmp.Ui.Services._BusyIndicator(_timeout);
        indicator.MarkBusyImediate();
        expect(indicator.IsBusy).toBe(true);

        done();
    });

    it("Imediate busy to idle", function (done) {

        var indicator = new Cmp.Ui.Services._BusyIndicator(_timeout);
        indicator.MarkBusyImediate();
        expect(indicator.IsBusy).toBe(true);
        indicator.MarkBusyImediate();
        expect(indicator.IsBusy).toBe(true);

        indicator.MarkIdle();
        expect(indicator.IsBusy).toBe(true);
        indicator.MarkIdle();
        expect(indicator.IsBusy).toBe(false);

        done();
    });

    it("Extra idles do nothing with imediate busy", function (done) {

        var indicator = new Cmp.Ui.Services._BusyIndicator(_timeout);

        indicator.MarkBusyImediate();
        expect(indicator.IsBusy).toBe(true);

        indicator.MarkIdle();
        expect(indicator.IsBusy).toBe(false);
        indicator.MarkIdle();
        expect(indicator.IsBusy).toBe(false);

        indicator.MarkBusyImediate();
        expect(indicator.IsBusy).toBe(true);

        done();
    });
});
