﻿/// <reference path="../../common-refs.d.ts" />﻿

describe('Cmp.Ui.Services.CmpHttpHeader', function () {

	it('GetHeaderObject undefined .defaults', function () {
        var service = new Cmp.Ui.Services._HttpHeader(<any>{});
		expect(service.GetHeaderObject()).toBeUndefined();
	});

	it('GetHeaderObject undefined .defaults.headers', function () {
        var service = new Cmp.Ui.Services._HttpHeader(<any>{ defaults: {} });
		expect(service.GetHeaderObject()).toBeUndefined();
	});

	it('GetHeaderObject undefined .defaults.headers.common', function () {
        var service = new Cmp.Ui.Services._HttpHeader(<any>{ defaults: { headers: {} } });
		expect(service.GetHeaderObject()).toBeUndefined();
	});
	it('GetHeaderObject null .defaults', function () {
        var service = new Cmp.Ui.Services._HttpHeader(<any>{ defaults: null });
		expect(service.GetHeaderObject()).toBeUndefined();
	});

	it('GetHeaderObject null .defaults.headers', function () {
        var service = new Cmp.Ui.Services._HttpHeader(<any>{ defaults: { headers: null } });
		expect(service.GetHeaderObject()).toBeUndefined();
	});

	it('GetHeaderObject null .defaults.headers.common', function () {
        var service = new Cmp.Ui.Services._HttpHeader(<any>{ defaults: { headers: { common: null } } });
		expect(service.GetHeaderObject()).toBeUndefined();
	});

	it('GetHeaderObject has value', function () {
        var service = new Cmp.Ui.Services._HttpHeader(<any>{ defaults: { headers: { common: { foo: 'bar'}}}});
		expect(service.GetHeaderObject()).toEqual({ foo: 'bar' });
	});

});