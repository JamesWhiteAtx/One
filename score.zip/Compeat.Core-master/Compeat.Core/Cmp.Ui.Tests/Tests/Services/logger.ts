﻿/// <reference path="../../common-refs.d.ts" />﻿
/// <reference path="../../mocks/shared-stack-mocks.ts" />﻿

describe("Cmp.Ui.Services.Logger", function () {

    it("ErrorIsLogged", function (done) {

        var mockToastr = new Tests.StackMocks.ToastrMock();
        var mockLogger = new Tests.StackMocks.NgLogMock();

        var logService = new Cmp.Ui.Services.LoggerService(mockLogger, mockToastr);
        
        mockToastr.error = jasmine.createSpy("error spy");

        logService.Error("Test Error");
        expect(mockToastr.error).toHaveBeenCalled();

        done();
    });

    it("401NotLogged", function (done) {

        var mockToastr = new Tests.StackMocks.ToastrMock();
        var mockLogger = new Tests.StackMocks.NgLogMock();

        var logService = new Cmp.Ui.Services.LoggerService(mockLogger, mockToastr);

        mockToastr.error = jasmine.createSpy("error spy");

        logService.Error("Test Error", { status: 401 });
        expect(mockToastr.error).not.toHaveBeenCalled();

        done();
    });
});