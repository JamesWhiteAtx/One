﻿/// <reference path='../common-refs.d.ts' />﻿

describe('Cmp.Ui.Bases.BaseSession', function () {

    it('HasRight_Uninitialized', function () {

        var session = new Cmp.Ui.Bases.BaseSession();
        expect(session.HasRight('TestRight1')).toBe(false);
    });
   
    it('HasRight_UserHasRight', function () {

        var session = new Cmp.Ui.Bases.BaseSession();
        session.AddRight('TestRight2');
        expect(session.HasRight('TestRight2')).toBe(true);
    });
     
    it('HasRight_UserHasSomeOtherRight', function () {

        var session = new Cmp.Ui.Bases.BaseSession();
        session.AddRight('TestRight3');
        expect(session.HasRight('TestRight4')).toBe(false);
    });

    it('InitializeRights_Simple', function () {

        var session = new Cmp.Ui.Bases.BaseSession();
        session.InitializeRights(['TestRight5', 'TestRight6']);
        expect(session.HasRight('TestRight5')).toBe(true);
        expect(session.HasRight('TestRight6')).toBe(true);
    });

    it('InitializeRights_ClearsPriorRights', function () {

        var session = new Cmp.Ui.Bases.BaseSession();
        session.AddRight('TestRight7');
        session.InitializeRights(['TestRight8']);
        expect(session.HasRight('TestRight7')).toBe(false);
        expect(session.HasRight('TestRight8')).toBe(true);
    });

    it('AddRight_Simple', function () {

        var session = new Cmp.Ui.Bases.BaseSession();
        expect(session.HasRight('TestRight9')).toBe(false);
        session.AddRight('TestRight9');
        expect(session.HasRight('TestRight9')).toBe(true);
    });

    it('HasAllRights_Yes', function () {

        var session = new Cmp.Ui.Bases.BaseSession();
        session.InitializeRights(['TestRight10', 'TestRight11']);
        expect(session.HasAllRights(['TestRight10', 'TestRight11'])).toBe(true);
    });

    it('HasAllRights_No_LastMissing', function () {

        var session = new Cmp.Ui.Bases.BaseSession();
        session.InitializeRights(['TestRight12', 'TestRight13']);
        expect(session.HasAllRights(['TestRight12', 'TestRight13', 'TestRight14'])).toBe(false);
    });

    it('HasAllRights_No_FirstMissing', function () {

        var session = new Cmp.Ui.Bases.BaseSession();
        session.InitializeRights(['TestRight16', 'TestRight17']);
        expect(session.HasAllRights(['TestRight15', 'TestRight16', 'TestRight17'])).toBe(false);
    });

    it('HasSomeRights_Yes_LastFound', function () {

        var session = new Cmp.Ui.Bases.BaseSession();
        session.InitializeRights(['TestRight19', 'TestRight20']);
        expect(session.HasSomeRights(['TestRight18', 'TestRight19'])).toBe(true);
    });

    it('HasSomeRights_Yes_FirstFound', function () {

        var session = new Cmp.Ui.Bases.BaseSession();
        session.InitializeRights(['TestRight21', 'TestRight22']);
        expect(session.HasSomeRights(['TestRight22', 'TestRight23'])).toBe(true);
    });

    it('HasSomeRights_No', function () {

        var session = new Cmp.Ui.Bases.BaseSession();
        session.InitializeRights(['TestRight24', 'TestRight25']);
        expect(session.HasSomeRights(['TestRight26'])).toBe(false);
    });

});