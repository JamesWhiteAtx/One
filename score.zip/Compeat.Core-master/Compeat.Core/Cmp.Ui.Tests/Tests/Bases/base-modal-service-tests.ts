﻿/// <reference path="../../common-refs.d.ts" />﻿

describe('Cmp.Ui.Bases.BaseModalService', function () {
	var service: Cmp.Ui.Bases.BaseModalService;

	var serviceModalOptions: any;

	var uibModalService: any = {
		open: (passedModalOptions: any) => {
			serviceModalOptions = passedModalOptions;
		}
	};

	describe('Open method', function () {
		service = new Cmp.Ui.Bases.BaseModalService(uibModalService);

		it('calls $uibModal service "open" method', function () {
			service.Open();
			expect(serviceModalOptions).toBeDefined();
		});

		it('accepts multiple options params and combines them', function () {

			service.Open({ templateUrl: 'test' }, { animation: false }, { size: 'size' });
			expect(serviceModalOptions.templateUrl).toBe('test');
			expect(serviceModalOptions.animation).toBe(false);
			expect(serviceModalOptions.size).toBe('size');
		});

	});

});