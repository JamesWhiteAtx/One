﻿/// <reference path="../../common-refs.d.ts" />﻿

describe('Cmp.Ui.Bases.BaseModalFindController', function () {
	var controller: Cmp.Ui.Bases.BaseModalFindController;
	var baseTools: any;

	var closeResult: any;
	var dismissResult: any;

	var modalInstance: any = {
		close: (result: any) => {
			closeResult = result;
		},
		dismiss: (result: any) => {
			dismissResult = result;
		}
	};
	var rowDefinition: Cmp.Ui.Bases.IFindRowDefinition;
	var sourceList: any[];
	var templateOptions: Cmp.Ui.Services.ICmpModalServiceSettings;

	var makeController = () => new Cmp.Ui.Bases.BaseModalFindController(baseTools, modalInstance, rowDefinition, sourceList, templateOptions);

	beforeEach(function () {
		rowDefinition = new Cmp.Ui.Bases.FindRowDefinition();
		sourceList = [{ id: 1 }, { id: 2 }, { id: 3 }];
		templateOptions = { OkText: 'TestOk' };
	});

	describe('constructor', function () {
		beforeEach(function () {
			controller = makeController();
		});

		it('configure row definition', function () {
			expect(rowDefinition.RowSortCallback).toBeDefined();
		});

		it('assigns rows from source list argument', function () {
			expect(controller.Rows).toBeDefined();
			expect(controller.Rows.length).toEqual(sourceList.length);
			expect(controller.Rows[0].Data).toBe(sourceList[0]);
			expect(controller.Rows[0].Selected).toBe(true);
		});

		it('assigns title text App$Find', function () {
			expect(controller.TitleText).toEqual('App$Find');
		});

		it('hides icons', function () {
			expect(controller.ConfirmIcon).toEqual(false);
			expect(controller.InfoIcon).toEqual(false);
		});

		it('sets HideOk to true', function () {
			expect(controller.HideOk).toEqual(true);
		});

		it('assigns template options', function () {
			expect(controller.OkText).toEqual('TestOk');
		});

	});


	it('filters all rows', function () {
		controller = makeController();

		var row1 = controller.Rows[0];
		var row2 = controller.Rows[1];
		var row3 = controller.Rows[2];
		var expectedFilterText = 'exexex';

		spyOn(row1, 'AssignFound');
		spyOn(row2, 'AssignFound');
		spyOn(row3, 'AssignFound');

		controller.FilterText = expectedFilterText;
		controller.Filter();

		expect(row1.AssignFound).toHaveBeenCalledWith(expectedFilterText);
		expect(row2.AssignFound).toHaveBeenCalledWith(expectedFilterText);
		expect(row3.AssignFound).toHaveBeenCalledWith(expectedFilterText);
	});

	it('calls ok when picking a row', function () {
		var pickedRow: Cmp.Ui.Bases.IFindRowInstance;
		controller = makeController();
		spyOn(controller, 'Ok');
		pickedRow = controller.Rows[0];

		controller.PickRow(pickedRow);

		expect(controller.Ok).toHaveBeenCalled();
	});

	it('assigns raw list source objec when picking a row', function () {
		var pickedRow: Cmp.Ui.Bases.IFindRowInstance;
		controller = makeController();
		pickedRow = controller.Rows[0];

		controller.PickRow(pickedRow);

		expect(controller.Picked).toBe(sourceList[0]);
	});

});