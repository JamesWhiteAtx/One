﻿/// <reference path="../../common-refs.d.ts" />﻿

describe('Cmp.Ui.Bases.FindRowDefinition', function () {
	var rowDefn: Cmp.Ui.Bases.FindRowDefinition;
	var filter: angular.IFilterService;

	var configParam: Cmp.Ui.Bases.IFindFieldConfig;
	var defnType: string;
	var fieldDefn: Cmp.Ui.Bases.IFindFieldDefinition;

	beforeEach(function () {
		defnType = 'string';
		configParam = {
			name: 'name',
			title: 'title',
			width: 2
		};
		fieldDefn = new Cmp.Ui.Bases.BaseFindFieldDefinition(defnType, configParam);
	});


	beforeEach(function () {
		filter = (name: string) => { return () => 'filtered!';}
		rowDefn = new Cmp.Ui.Bases.FindRowDefinition(filter);
	});

	it('persists RowSortCallback', function () {
		var callback = () => 'ok';
		rowDefn.RowSortCallback = callback;

		expect(rowDefn.RowSortCallback).toBe(callback);
	});

	it('adds a field definition', function () {
		var callback = () => 'ok';

		rowDefn.AddFieldDefn(fieldDefn);

		expect(rowDefn.FieldDefns.length).toEqual(1);
	});

	it('makes a field definition', function () {
		rowDefn.MakeFieldDefn(Cmp.Ui.Bases.FindStringField, configParam);

		expect(rowDefn.FieldDefns.length).toEqual(1);
	});

	it('makes a string field definition', function () {
		rowDefn.StringField(configParam);

		expect(rowDefn.FieldDefns.length).toEqual(1);
	});

	it('makes a date field definition', function () {
		rowDefn.DateField(configParam);

		expect(rowDefn.FieldDefns.length).toEqual(1);
	});

	it('makes a date time field definition', function () {
		rowDefn.DateTimeField(configParam);

		expect(rowDefn.FieldDefns.length).toEqual(1);
	});

	it('makes a number field definition', function () {
		rowDefn.NumberField(configParam);

		expect(rowDefn.FieldDefns.length).toEqual(1);
	});

	it('makes a currency field definition', function () {
		rowDefn.CurrencyField(configParam);

		expect(rowDefn.FieldDefns.length).toEqual(1);
	});

	it('makes a boolean field definition', function () {
		rowDefn.BooleanField(configParam);

		expect(rowDefn.FieldDefns.length).toEqual(1);
	});

	it('un-sorts all other field definitions', function () {
		rowDefn.StringField(configParam);
		rowDefn.NumberField(configParam);
		rowDefn.BooleanField(configParam);

		var defn1 = rowDefn.FieldDefns[0];
		var defn2 = rowDefn.FieldDefns[1];
		var defn3 = rowDefn.FieldDefns[2];

		defn1.Sort = 1;
		defn2.Sort = 1;
		defn3.Sort = 1;
		rowDefn.SortBy(defn1);

		expect(defn1.Sort).toEqual(1);
		expect(defn2.Sort).toEqual(0);
		expect(defn3.Sort).toEqual(0);
	});

	it('calls RowSortCallback when asked to sort', function () {
		var spyObj = {
			callback: () => 'ok'
		}
		spyOn(spyObj, 'callback');

		rowDefn.RowSortCallback = spyObj.callback;

		rowDefn.StringField(configParam);
		var defn1 = rowDefn.FieldDefns[0];

		rowDefn.SortBy(defn1);


		expect(spyObj.callback).toHaveBeenCalled();
	});

	it('makes a row instance', function () {
		var instance = rowDefn.MakeRowInstance({a: 1, b: 2});

		expect(instance).toBeDefined();
	});


});