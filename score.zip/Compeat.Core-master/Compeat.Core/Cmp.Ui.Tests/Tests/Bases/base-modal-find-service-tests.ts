﻿/// <reference path="../../common-refs.d.ts" />﻿

describe('Cmp.Ui.Bases.BaseModalFindService', function () {
	var service: Cmp.Ui.Bases.BaseModalFindService;

	var serviceModalOptions: any;

	var uibModalService: any = {
		open: (passedModalOptions: any) => {
			serviceModalOptions = passedModalOptions;
		}
	};

	it('can be created without errors', function () {
		service = new Cmp.Ui.Bases.BaseModalFindService(uibModalService);
		expect(service).toBeDefined();
	});
});