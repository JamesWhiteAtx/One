﻿/// <reference path="../../common-refs.d.ts" />﻿

describe('Cmp.Ui.Bases.FindFieldInstance', function () {
	var instance: Cmp.Ui.Bases.FindFieldInstance;

	var mockDefn: Cmp.Ui.Bases.IFindFieldDefinition = {
		RowDefn: null,
		Name: null,
		Type: null,
		Title: null,
		Width: null,
		Right: null,
		Center: null,
		Sort: null,
		Filterable: null,
		IsText: null,
		IsBool: null,
		Value: null,
		TextValue: null,
		UnSort: null,
		SortToggle: null,
		MakeInstance: null
	}

	var rawObj: any;

	beforeEach(function () {
		rawObj = { id: 1, name: 'Telly Savalas' };
	});

	describe('constructor', function () {

		it('calls definition TextValue for text display', function () {
			var expectedValue = 'expected';
			mockDefn.IsText = true;
			mockDefn.TextValue = (rawObj: any): string => expectedValue;

			spyOn(mockDefn, 'TextValue');

			instance = new Cmp.Ui.Bases.FindFieldInstance(rawObj, mockDefn);

			expect(mockDefn.TextValue).toHaveBeenCalledWith(rawObj);
		});

		it('assigns text display from defn text value', function () {
			var expectedValue = 'expected';
			mockDefn.IsText = true;
			mockDefn.TextValue = (rawObj: any): string => expectedValue;

			instance = new Cmp.Ui.Bases.FindFieldInstance(rawObj, mockDefn);

			expect(instance.Display).toEqual(expectedValue);
		});

		it('assigns non-test display from defn value', function () {
			var expectedValue = 'expected';
			mockDefn.IsText = false;
			mockDefn.Value = (rawObj: any): any => expectedValue;

			spyOn(mockDefn, 'Value');

			instance = new Cmp.Ui.Bases.FindFieldInstance(rawObj, mockDefn);

			expect(mockDefn.Value).toHaveBeenCalledWith(rawObj);
		});

	});

	describe('Match', function () {
		var matchStr: string;

		it('returns false if no Display', function () {
			matchStr = 'match str';
			instance = new Cmp.Ui.Bases.FindFieldInstance(rawObj, mockDefn);

			var result = instance.Match(matchStr);

			expect(result).toBe(false);
		});

		it('returns true if Display equals match string', function () {
			var expectedValue = 'expected';
			mockDefn.IsText = true;
			mockDefn.TextValue = (rawObj: any): string => expectedValue;

			matchStr = expectedValue;

			instance = new Cmp.Ui.Bases.FindFieldInstance(rawObj, mockDefn);

			var result = instance.Match(matchStr);

			expect(result).toBe(true);
		});

		it('returns true regardless of case', function () {
			var expectedValue = 'ExpectedVal';
			mockDefn.IsText = true;
			mockDefn.TextValue = (rawObj: any): string => expectedValue;

			matchStr = expectedValue.toLowerCase();

			instance = new Cmp.Ui.Bases.FindFieldInstance(rawObj, mockDefn);

			var result = instance.Match(matchStr);

			expect(result).toBe(true);
		});

		it('returns true if Display contains match string', function () {
			matchStr = 'match';

			var expectedValue = matchStr + 'extra';
			mockDefn.IsText = true;
			mockDefn.TextValue = (rawObj: any): string => expectedValue;

			instance = new Cmp.Ui.Bases.FindFieldInstance(rawObj, mockDefn);

			var result = instance.Match(matchStr);

			expect(result).toBe(true);
		});

	});

});