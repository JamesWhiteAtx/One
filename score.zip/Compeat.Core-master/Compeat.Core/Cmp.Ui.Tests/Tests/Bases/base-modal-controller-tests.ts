﻿/// <reference path="../../common-refs.d.ts" />﻿

describe('Cmp.Ui.Bases.CmpModalTemplateController', function () {
	var controller: Cmp.Ui.Bases.CmpModalTemplateController;
	var baseTools: any;

	var closeResult: any;
	var dismissResult: any;

	var modalInstance: any = {
		close: (result: any) => {
			closeResult = result;
		},
		dismiss: (result: any) => {
			dismissResult = result;
		}
	};

	it('calls the modalInstance close method with Ok method', function () {
		controller = new Cmp.Ui.Bases.CmpModalTemplateController(baseTools, modalInstance);
		var overridenOkResult = 99;

		/** cast controller as any in order to override protectres OkResult method */
		var controllerAsAny: any = <any>controller;

		controllerAsAny.OkResult = (): any => {
			return overridenOkResult;
		}

		controller.Ok();
		expect(closeResult).toBe(overridenOkResult);
	});

	it('calls the modalInstance dismiss method with Cancel method', function () {
		controller = new Cmp.Ui.Bases.CmpModalTemplateController(baseTools, modalInstance);
		var overridenCancelResult = 22;

		/** cast controller as any in order to override protectres CancelResult method */
		var controllerAsAny: any = <any>controller;

		controllerAsAny.CancelResult = (): any => {
			return overridenCancelResult;
		}

		controller.Cancel();
		expect(dismissResult).toBe(overridenCancelResult);
	});

	it('hides icon variables with HideIcons method', function () {
		controller = new Cmp.Ui.Bases.CmpModalTemplateController(baseTools, modalInstance);

		controller.HideIcons();

		expect(controller.ConfirmIcon).toBe(false);
		expect(controller.InfoIcon).toBe(false);
	});

	it('has the expected ModalControllerName', function () {
		var modalControllerName = Cmp.Ui.Bases.CmpModalTemplateController.ModalControllerName;
		expect(modalControllerName).toBe('modalVm');
	});

	it('assigns itself and the ModalControllerName to modal settings object', function () {
		var modalControllerName = Cmp.Ui.Bases.CmpModalTemplateController.ModalControllerName;
		var modalSettings = Cmp.Ui.Bases.CmpModalTemplateController.AssignToModalSettings();

		expect(modalSettings).toBeDefined();
		expect(modalSettings.controller).toBe(Cmp.Ui.Bases.CmpModalTemplateController);
		expect(modalSettings.controllerAs).toBe(modalControllerName);
	});

});