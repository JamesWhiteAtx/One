﻿/// <reference path="../../common-refs.d.ts" />﻿

describe('Cmp.Ui.Bases.BaseFindFieldDefinition', function () {

	var configParam: Cmp.Ui.Bases.IFindFieldConfig;
	var defnType: string;
	var defn: Cmp.Ui.Bases.BaseFindFieldDefinition;

	beforeEach(function () {
		defnType = 'string';
		configParam = {
			name: 'name',
			title: 'title',
			width: 2
		};
		defn = new Cmp.Ui.Bases.BaseFindFieldDefinition(defnType, configParam);
	});

	describe('Default', function () {

		it('Filterable is false', function () {
			expect(defn.Filterable).toBe(false); 
		});

		it('IsText is true', function () {
			expect(defn.IsText).toBe(true);
		});

		it('IsBool is false', function () {
			expect(defn.IsBool).toBe(false);
		});

		it('Right is false', function () {
			expect(defn.Right).toBe(false);
		});

		it('Center is false', function () {
			expect(defn.Center).toBe(false);
		});

	});

	it('persists RowDefn', function () {
		var expectedRowDefn: Cmp.Ui.Bases.IFindRowDefinition = new Cmp.Ui.Bases.FindRowDefinition();
		defn.RowDefn = expectedRowDefn;
		expect(defn.RowDefn).toBe(expectedRowDefn);
	});

	it('makes text value using toString', function () {
		var raw = 99;
		var expectedValue = raw.toString();
		var actualValue = defn.TextValue(raw);
		expect(actualValue).toEqual(expectedValue);
	});

	it('returns the raw argument as display value', function () {
		var raw = {id: 1};
		var expectedValue = raw;
		var actualValue = defn.Value(raw);
		expect(actualValue).toEqual(expectedValue);
	});

	it('makes an instance with Defn as itself', function () {
		var raw = { id: 1 };
		var instance = defn.MakeInstance(raw);
		expect(instance.Defn).toEqual(defn);
	});

	it('makes an instance with data as raw argument', function () {
		var raw = { id: 1 };
		var expectedValue = raw;
		var instance = defn.MakeInstance(raw);
		expect(instance.Data).toEqual(expectedValue);
	});

	it('sets sort to 0 with UnSort', function () {
		defn.Sort = 22;
		defn.UnSort();
		expect(defn.Sort).toEqual(0);
	});

	describe('SortToggle method', function () {
		var expectedRowDefn: Cmp.Ui.Bases.IFindRowDefinition;
		beforeEach(function () {
			expectedRowDefn = new Cmp.Ui.Bases.FindRowDefinition();
			defn.RowDefn = expectedRowDefn;
		});

		it('changes sort from 0 to 1', function () {
			defn.Sort = 0;
			defn.SortToggle();
			expect(defn.Sort).toEqual(1);
		});
		it('changes sort from 1 to -1', function () {
			defn.Sort = 1;
			defn.SortToggle();
			expect(defn.Sort).toEqual(-1);
		});
		it('changes sort from -1 to 0', function () {
			defn.Sort = -1;
			defn.SortToggle();
			expect(defn.Sort).toEqual(0);
		});
		it('changes sort from othres to 0', function () {
			defn.Sort = 99;
			defn.SortToggle();
			expect(defn.Sort).toEqual(0);
		});

		it('calls RowDefn SortBy', function () {
			spyOn(expectedRowDefn, 'SortBy');
			defn.SortToggle();
			expect(expectedRowDefn.SortBy).toHaveBeenCalled();
		});

		it('calls RowDefn SortBy with itself as the argument', function () {
			spyOn(expectedRowDefn, 'SortBy');
			defn.SortToggle();
			expect(expectedRowDefn.SortBy).toHaveBeenCalledWith(defn);
		});

	});
});

describe('Cmp.Ui.Bases.FindStringField', function () {
	var configParam: Cmp.Ui.Bases.IFindFieldConfig;
	var defnType: string;
	var defn: Cmp.Ui.Bases.FindStringField;

	beforeEach(function () {
		configParam = {
			name: 'name',
			title: 'title',
			width: 2
		};
		defn = new Cmp.Ui.Bases.FindStringField(configParam);
	});

	it('has a type of string', function () {
		expect(defn.Type).toEqual('string');
	});

	it('trims the text value', function () {
		var raw = 'raw value ';
		var expectedValue = raw.trim();
		var actualValue = defn.TextValue(raw);
		expect(actualValue).toEqual(expectedValue);
	});

	it('has the expected configuration', function () {
		expect(defn.IsText).toBe(true);
		expect(defn.IsBool).toBe(false);
		expect(defn.Right).toBe(false);
		expect(defn.Center).toBe(false);
	});
});

describe('Cmp.Ui.Bases.FindDateField', function () {

	var configParam: Cmp.Ui.Bases.IFindFieldConfig;
	var defnType: string;
	var defn: Cmp.Ui.Bases.FindDateField;

	beforeEach(function () {
		configParam = {
			name: 'name',
			title: 'title',
			width: 2
		};
		defn = new Cmp.Ui.Bases.FindDateField(configParam);
	});

	it('has a type of date', function () {
		expect(defn.Type).toEqual('date');
	});

	it('formats text value using moment and Tests.StackMocks.DateFormat', function () {
		var raw = new Date(1999, 0, 3);
		var expectedValue = moment(raw).format(Tests.StackMocks.DateFormat);
		var actualValue = defn.TextValue(raw);
		expect(actualValue).toEqual(expectedValue);
	});

	it('has the expected configuration', function () {
		expect(defn.IsText).toBe(true);
		expect(defn.IsBool).toBe(false);
		expect(defn.Right).toBe(false);
		expect(defn.Center).toBe(false);
	});
});

describe('Cmp.Ui.Bases.FindDateTimeField', function () {

	var configParam: Cmp.Ui.Bases.IFindFieldConfig;
	var defnType: string;
	var defn: Cmp.Ui.Bases.FindDateTimeField;

	beforeEach(function () {
		configParam = {
			name: 'name',
			title: 'title',
			width: 2
		};
		defn = new Cmp.Ui.Bases.FindDateTimeField(configParam);
	});

	it('has a type of date', function () {
		expect(defn.Type).toEqual('date');
	});

	it('formats text value using moment and "M/D/YYYY hh:mm A" ', function () {
		var raw = new Date(1999, 0, 3);
		var expectedValue = moment(raw).format('M/D/YYYY hh:mm A');
		var actualValue = defn.TextValue(raw);
		expect(actualValue).toEqual(expectedValue);
	});

	it('has the expected configuration', function () {
		expect(defn.IsText).toBe(true);
		expect(defn.IsBool).toBe(false);
		expect(defn.Right).toBe(false);
		expect(defn.Center).toBe(false);
	});
});

describe('Cmp.Ui.Bases.FindNumberField', function () {

	var configParam: Cmp.Ui.Bases.IFindNumberFieldConfig;
	var defnType: string;
	var defn: Cmp.Ui.Bases.FindNumberField;

	beforeEach(function () {
		configParam = {
			name: 'name',
			title: 'title',
			width: 2
		};
	});

	it('has a type of number', function () {
		defn = new Cmp.Ui.Bases.FindNumberField(configParam);
		expect(defn.Type).toEqual('number');
	});

	it('formats text value when decimals not specified using toString', function () {
		var raw = 123;
		var expectedValue = raw.toString();

		defn = new Cmp.Ui.Bases.FindNumberField(configParam);

		var actualValue = defn.TextValue(raw);
		expect(actualValue).toEqual(expectedValue);
	});

	it('formats text value with decimals using toFixed', function () {
		var raw = 123;
		var expectedValue = raw.toFixed(2);

		configParam.decimals = 2;
		defn = new Cmp.Ui.Bases.FindNumberField(configParam);

		var actualValue = defn.TextValue(raw);
		expect(actualValue).toEqual(expectedValue);
	});

	it('has the expected configuration', function () {
		expect(defn.IsText).toBe(true);
		expect(defn.IsBool).toBe(false);
		expect(defn.Right).toBe(true);
		expect(defn.Center).toBe(false);
	});
});

describe('Cmp.Ui.Bases.FindCurrencyField', function () {

	var configParam: Cmp.Ui.Bases.IFindNumberFieldConfig;
	var defnType: string;
	var defn: Cmp.Ui.Bases.FindCurrencyField;

	beforeEach(function () {
		configParam = {
			name: 'name',
			title: 'title',
			width: 2
		};
	});

	it('has a type of number', function () {
		defn = new Cmp.Ui.Bases.FindCurrencyField(configParam);
		expect(defn.Type).toEqual('number');
	});

	it('formats text value with 2 decimals when decimals not specified', function () {
		var raw = 123;
		var expectedValue = raw.toFixed(2);

		defn = new Cmp.Ui.Bases.FindCurrencyField(configParam);

		var actualValue = defn.TextValue(raw);
		expect(actualValue).toEqual(expectedValue);
	});

	it('formats text value with decimals using toFixed', function () {
		var raw = 123;
		var expectedValue = raw.toFixed(3);

		configParam.decimals = 3;
		defn = new Cmp.Ui.Bases.FindCurrencyField(configParam);

		var actualValue = defn.TextValue(raw);
		expect(actualValue).toEqual(expectedValue);
	});

	describe('formatter service argument', function () {

		var testFormatterObj = {
			currencyFcn: (amount: any, curSymbol: any, fractionSize: any) => {
					return (amount || '').toString()
						+ '-' + (curSymbol || '').toString()
						+ '-' + (fractionSize || '').toString();
				}
		}

		var testServiceObj = {
			formatter: (formatName: string): Function => {
				return testFormatterObj.currencyFcn;
			}
		}

		beforeEach(function () {
			configParam = {
				name: 'name',
				title: 'title',
				width: 2
			};
		});

		it('is called as a function by the constructor', function () {
			spyOn(testServiceObj, 'formatter');
			configParam.formatter = testServiceObj.formatter;

			defn = new Cmp.Ui.Bases.FindCurrencyField(configParam);

			expect(testServiceObj.formatter).toHaveBeenCalled();
		});

		it('is called as a function with the "currency" argument by the constructor', function () {
			spyOn(testServiceObj, 'formatter');
			configParam.formatter = testServiceObj.formatter;

			defn = new Cmp.Ui.Bases.FindCurrencyField(configParam);

			expect(testServiceObj.formatter).toHaveBeenCalledWith('currency')
		});

		it('assigns the formatter function used to format text', function () {
			spyOn(testFormatterObj, 'currencyFcn');

			configParam.formatter = testServiceObj.formatter;
			configParam.decimals = 3;

			defn = new Cmp.Ui.Bases.FindCurrencyField(configParam);
			var actualValue = defn.TextValue(123);

			expect(testFormatterObj.currencyFcn).toHaveBeenCalled();
		});

		it('assigns the formatter function used with expected arguments', function () {
			spyOn(testFormatterObj, 'currencyFcn');
			var raw = 123;
			var expectedDecimals = 3;

			configParam.formatter = testServiceObj.formatter;
			configParam.decimals = expectedDecimals;

			defn = new Cmp.Ui.Bases.FindCurrencyField(configParam);
			var actualValue = defn.TextValue(raw);

			expect(testFormatterObj.currencyFcn).toHaveBeenCalledWith(raw, void 0, expectedDecimals);
		});

		it('assigns the formatter function with expected text value', function () {
			var raw = 123;
			var expectedDecimals = 3;
			var expectedValue = testFormatterObj.currencyFcn(raw, void 0, expectedDecimals);

			configParam.formatter = testServiceObj.formatter;
			configParam.decimals = expectedDecimals;

			defn = new Cmp.Ui.Bases.FindCurrencyField(configParam);
			var actualValue = defn.TextValue(raw);

			expect(actualValue).toEqual(expectedValue);
		});

	});

	it('has the expected configuration', function () {
		expect(defn.IsText).toBe(true);
		expect(defn.IsBool).toBe(false);
		expect(defn.Right).toBe(true);
		expect(defn.Center).toBe(false);
	});
});