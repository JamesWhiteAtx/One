﻿/// <reference path="../../common-refs.d.ts" />﻿

describe("Cmp.Ui.Factories", function () {
    beforeEach(function () {
        module('cmp.ui.factories');
    });

    it("RunFocus simple call check", function (done) {
        var passedAttrName = undefined;
        var passedVal = undefined;
        var factoryToTest = Cmp.Ui.Factories.RunFocus(<any>{
            $broadcast: function (attrName, val) {
                passedAttrName = attrName;
                passedVal = val;
            }
        }, <any>(function (cb) {
            cb();
        })); 
        factoryToTest("test")
        expect(passedAttrName).toBe('setFocus');
        expect(passedVal).toBe('test');
        done();
    });
});