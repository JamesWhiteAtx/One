﻿/// <reference path="../../common-refs.d.ts" />﻿

describe("Cmp.Ui.Providers.VersionProvider", function () {
	
	var theProvider: Cmp.Ui.Providers.VersionProvider;
	var testVersion = 'test.test.0.0';

	beforeEach(function () {
		theProvider = new Cmp.Ui.Providers.VersionProvider();
	});

	it('should be defined', function () {
		expect(Cmp.Ui.Providers.VersionProvider).toBeDefined();
	});

	it('should be a new-able function', function () {
		expect(theProvider).toBeDefined();
	});

	it('should have a $get defined', function () {
		expect(theProvider.$get).toBeDefined();
	});

	it('should have a Version defined', function () {
		expect(theProvider.Version).toBeDefined();
	});

	it('should have a Version that equals Cmp.AppInfo.Version', function () {
		Cmp.AppInfo.Version = testVersion;
		expect(theProvider.Version).toEqual(testVersion);
	});

	it('should have a IsDebug defined', function () {
		expect(theProvider.IsDebug).toBeDefined();
	});

	it('should have a IsDebug that equals Cmp.AppInfo.Debug', function () {
		Cmp.AppInfo.Debug = false;
		expect(theProvider.IsDebug).toEqual(false);
		Cmp.AppInfo.Debug = true;
		expect(theProvider.IsDebug).toEqual(true);
	});

	describe("VersionedUrl", function () {
		var theBaseUrl: string;

		beforeEach(function () {
			theBaseUrl = 'test/url/for/test.html';
		});

		it('should be defined', function () {
			expect(theProvider.VersionedUrl).toBeDefined();
		});

        it('should append version to url when in debug mode', function () {
            Cmp.AppInfo.Debug = true
			var dateNow = Date.now();
			theProvider._GetCurrentDate = () => {
				return dateNow;
			};
            var now = '?v=' + moment(dateNow).format("YYYY-MM-DDTHH:mm:ssZZ");
            var versionUrl = theProvider.VersionedUrl(theBaseUrl);
			expect(versionUrl).toEqual(theBaseUrl +  now);
		});

		it('should change url when not in debug mode', function () {
			Cmp.AppInfo.Debug = false;
			var versionUrl = theProvider.VersionedUrl(theBaseUrl);
			expect(versionUrl).not.toEqual(theBaseUrl);
		});

		it('should append version to url when not in debug mode', function () {
			Cmp.AppInfo.Debug = false;
			Cmp.AppInfo.Version = testVersion;
			var versionUrl = theProvider.VersionedUrl(theBaseUrl);
			expect(versionUrl).toEqual(theBaseUrl + '?v=' + Cmp.AppInfo.Version);
		});

		it('should append correct conjunction to a url with a query string when not in debug mode', function () {
			Cmp.AppInfo.Debug = false;
			Cmp.AppInfo.Version = testVersion;

			theBaseUrl = theBaseUrl + '?param=99'

			var versionUrl = theProvider.VersionedUrl(theBaseUrl);
			expect(versionUrl).toEqual(theBaseUrl + '&v=' + Cmp.AppInfo.Version);
		});

	});

});