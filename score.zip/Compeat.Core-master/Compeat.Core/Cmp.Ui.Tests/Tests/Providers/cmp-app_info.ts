﻿/// <reference path="../../common-refs.d.ts" />﻿

describe("Cmp.AppInfo", function () {

	it('should be defined', function () {
		expect(Cmp.AppInfo).toBeDefined();
	});

	it('should be an object', function () {
		expect(typeof Cmp.AppInfo).toBe('object')
	});

	it('should have a Version property', function () {
		expect(Cmp.AppInfo.Version).toBeDefined();
	});

	it('should have a Debug property', function () {
		expect(Cmp.AppInfo.Debug).toBeDefined();
	});

});