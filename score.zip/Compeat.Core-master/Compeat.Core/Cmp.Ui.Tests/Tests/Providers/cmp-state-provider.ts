﻿/// <reference path="../../common-refs.d.ts" />﻿

describe("Cmp.Ui.Providers.CmpStateProvider", function () {

	var $stateProvider: angular.ui.IStateProvider;
	var mockStateProvider: any;
	mockStateProvider = {
		state: (): any => {
			return null;
		}
	}

	var cmpVersionProvider: Cmp.Ui.Providers.VersionProvider;
	var theProvider: Cmp.Ui.Providers.CmpStateProvider;

	it('should be defined', function () {
		expect(Cmp.Ui.Providers.CmpStateProvider).toBeDefined();
	});

	beforeEach(function () {
		module('ui.router', 'cmp.ui.providers');
		inject(function (
			$state: angular.ui.IStateProvider,
			cmpVersion: Cmp.Ui.Providers.VersionProvider) {
			$stateProvider = $state;
			cmpVersionProvider = cmpVersion;
		});

		theProvider = new Cmp.Ui.Providers.CmpStateProvider(mockStateProvider, cmpVersionProvider);
	});

	it('should have a $get defined', function () {
		expect(theProvider.$get).toBeDefined();
	});

	it('should be a new-able function', function () {
		expect(theProvider).toBeDefined();
	});

	it('should have a $get defined', function () {
		expect(theProvider.$get).toBeDefined();
	});

	describe("DefineState", function () {
		it('should be defined', function () {
			expect(theProvider.DefineState).toBeDefined();
		});

		it('should call StateProvider with name and config object', function () {
			var stateName = 'state.name';
			var configObj = { templateUrl: 'aa/bb/cc/xx.js'};
			spyOn(mockStateProvider, 'state');

			theProvider.DefineState(stateName, configObj);

			expect(mockStateProvider.state).toHaveBeenCalledWith(stateName, configObj);
		});

		it('should call StateProvider with just config object', function () {
			var configObj = { templateUrl: 'aa/bb/cc/xx.js' };
			spyOn(mockStateProvider, 'state');

			theProvider.DefineState(configObj);

			expect(mockStateProvider.state).toHaveBeenCalledWith(configObj);
		});
	});

	describe("DefineFeatureState", function () {
		it('should be  defined', function () {
			expect(theProvider.DefineFeatureState).toBeDefined();
		});

		it('should append version info to config templateUrl string in debug mode', function () {
			Cmp.AppInfo.Debug = false;
			Cmp.AppInfo.Version = '1.2.3.4';

			var baseUrl = 'aa/bb/cc/xx.js';
			var stateName = 'state.name';
			var configObj = { templateUrl: baseUrl };

			theProvider.DefineFeatureState(stateName, configObj);

			expect(configObj.templateUrl).toEqual(baseUrl + '?v=' + Cmp.AppInfo.Version);
		});

		it('should define a version info function to enclose config templateUrl function in debug mode', function () {
			Cmp.AppInfo.Debug = false;
			Cmp.AppInfo.Version = '1.2.3.4';

			var baseUrl = 'aa/bb/cc/xx.js';
			var stateName = 'state.name';
			var configObj = {
				templateUrl: function () {
					return baseUrl;
				}
			};

			theProvider.DefineFeatureState(stateName, configObj);

			var result = configObj.templateUrl();

			expect(result).toEqual(baseUrl + '?v=' + Cmp.AppInfo.Version);
		});
	});
});