﻿/// <reference path="../../common-refs.d.ts" />﻿

describe("Cmp.Ui.Directives", function () {
    beforeEach(function () {
        module('cmp.ui.directives');
    });

    it("RunFocus simple link call check", function (done) {
        var instance = Cmp.Ui.Directives.CmpFocus.Instance();
        var expectedFocusName = "foo";
        var focusWasCalled = false;
        var passedCallBack: (e, name) => void;
        var inputElement = [{
            focus: function () {
                focusWasCalled = true;
            }
        }]
        var testScope = {
            $on: function (key, cb: (e, name) => void) {
                passedCallBack = cb;
            }
        };

        instance.link(<any>testScope, <any>{
            find: function (){
                return inputElement;
            }
        }, <any>{
            cmpFocus: expectedFocusName
        });

        expect(passedCallBack).toBeTruthy();
        passedCallBack(null, expectedFocusName);
        expect(focusWasCalled).toBeTruthy();
        done();
    });
    it("RunFocus nothing to focus check", function (done) {
        var instance = Cmp.Ui.Directives.CmpFocus.Instance();
        var expectedFocusName = "foo";
        var focusWasCalled = false;
        var passedCallBack: (e, name) => void;
        var inputElement = [{
            focus: function () {
                focusWasCalled = true;
            }
        }]
        var testScope = {
            $on: function (key, cb: (e, name) => void) {
                passedCallBack = cb;
            }
        };

        instance.link(<any>testScope, <any>{
            find: function () {
                return undefined;
            }
        }, <any>{
            cmpFocus: expectedFocusName
        });

        expect(passedCallBack).toBeTruthy();
        passedCallBack(null, expectedFocusName);
        expect(focusWasCalled).toBeFalsy();
        done();
    });
});