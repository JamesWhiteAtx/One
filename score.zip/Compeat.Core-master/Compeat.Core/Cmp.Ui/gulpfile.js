/// <binding ProjectOpened='watch:startup' />
// gulp modules
var gulp = require('gulp');
var concat = require('gulp-concat');
var sourcemaps = require('gulp-sourcemaps');
var uglify = require('gulp-uglify');
var rename = require('gulp-rename');
var sass = require('gulp-sass')
var minifyCss = require('gulp-minify-css');
var htmlmin = require('gulp-htmlmin');
var gutil = require('gulp-util');
var templateCache = require('gulp-angular-templatecache');
var batch = require('gulp-batch');
var urlAdjuster = require('gulp-css-url-adjuster');

// node modules
var runSequence = require('run-sequence');
var path = require('path');
var merge = require('merge2');
var del = require('del');
var fs = require('fs');
var streamqueue = require('streamqueue');

// custom modules
var tsCompile = require('gulp-internal-ts-compile');

var defs = {
	outputDir: '_output',
	outputFiles: ['_output/*.*', '!_output/.gitignore'],
	buildOutputsDir: '../../../BuildOutputs/Compeat.Core/',

	thirdPartyDevBundleName: 'cmp-3p.js',
	thirdPartyReleaseBundleName: 'cmp-3p.min.js',



	thirdPartyFiles: [
		'3rdPartyJs/jquery-2.1.4.js',
		'3rdPartyJs/bootstrap-3.3.5.js',
		'3rdPartyJs/angular-1.4.0.js',
		'3rdPartyJs/angular-ui-router-0.2.15.js',
		'3rdPartyJs/angular-messages-1.4.0.js',
		'3rdPartyJs/angular-translate-2.7.2.js',
		'3rdPartyJs/angular-css-1.0.7.js',
		'3rdPartyJs/angular-sanitize-1.4.0.js',
		'3rdPartyJs/angular-animate-1.4.0.js',
		'3rdPartyJs/moment-2.10.6.js',
		'3rdPartyJs/toastr.js',
		'3rdPartyJs/select2.full-4.0.0.js',
		'3rdPartyJs/es6-promise-polyfill-3.0.2.js',
		'3rdPartyJs/observe-polyfill-0.5.6.js',
		'3rdPartyJs/bootstrap-datetimepicker-4.15.35.js',
		'3rdPartyJs/dirPagination.js',
		'3rdPartyJs/underscore-1.8.3.js',
		'3rdPartyJs/jszip-1.0.0.js',
		'3rdPartyJs/kendo.custom-2015.3.1111.js',
		'3rdPartyJs/ui-bootstrap-tpls-0.14.2.js'
	],

	reportModuleName: 'cmp-rpt',
	reportFiles: [
		'Src/Features/report-nav-helpers.ts',
		'Src/Models/report-models.ts',
		'Src/common-refs.d.ts',
		'../../../BuildOutputs/Compeat.Core/Scripts/cmp-js.d.ts',
		'../../../Resources/TypeScriptDefs/*.d.ts'
	],

	typeScripts: [
		'Src/**/*.ts',
		'Src/**/**/*.ts',
		'../../../BuildOutputs/Compeat.Core/Scripts/cmp-js.d.ts',
		'../../../Resources/TypeScriptDefs/*.d.ts'
	],
	moduleName: 'cmp-ui',
	jsResourceBase: 'Scripts',

	sassFile: 'Styles/Sass/cmp-ui.scss',
	allSassFiles: 'Styles/Sass/**/*.scss',
	cssFileName: 'cmp-ui',
	styleWatchFiles: 'Styles/**/*',

	cssResources: ['Styles/Images/**/*', 'Styles/Fonts/**/*'],
	cssResourceBase: 'Styles',
	css3rdPartyResourceBase: 'Styles/Css/',

	imageResourceBase: 'Images',

	ngTemplateRootUrl: 'cmp-ui',
	ngTemplatesModuleName: 'cmp.ui.templates',
	ngTemplates: ['Src/**/*.html'],

	// vendor resource definitions

	// Kendo
	kendoResourceBase: 'Styles/Css/kendo/',
	kendoFileBase: '**/*',
	kendoCssFiles: [
		'kendo.bootstrap.min.css',
		'kendo.common.min.css'
	],
	kendoOutputBase: '/kendo'
};

gulp.task('clean:output', function (cb) {
	// no stream output to return
	del(defs.outputFiles, cb);
});

gulp.task('3rdPartyJs:dev', function () {

	var outStream = gulp.src(defs.thirdPartyFiles)
		.pipe(sourcemaps.init())
		.pipe(concat(defs.thirdPartyDevBundleName))
		.pipe(sourcemaps.write('./', { includeContent: true }));

	return merge([
		outStream.pipe(gulp.dest(defs.outputDir)),

		outStream.pipe(gulp.dest(defs.buildOutputsDir + defs.jsResourceBase))
	]);
});

gulp.task('3rdPartyJs:release', function () {

	var minFiles = defs.thirdPartyFiles.map(function (file) {
		return file.replace(/\.js$/, '.min.js');
	});

	var outStream = gulp.src(minFiles)
		.pipe(concat(defs.thirdPartyReleaseBundleName));

	return merge([
		outStream.pipe(gulp.dest(defs.outputDir)),
		outStream.pipe(gulp.dest(defs.buildOutputsDir + defs.jsResourceBase))
	]);

});

var compileTs = function (isRelease) {
	var result = tsCompile(defs.typeScripts, defs.moduleName, isRelease, true, false);
	return merge([
		result.js.pipe(gulp.dest(defs.outputDir)),
		result.js.pipe(gulp.dest(defs.buildOutputsDir + defs.jsResourceBase)),
		result.dts.pipe(gulp.dest(defs.buildOutputsDir + defs.jsResourceBase))
	]);
};

gulp.task('compileTs:dev', function () {
	return compileTs(false);
});

gulp.task('compileTs:release', function () {
	return compileTs(true);
});

var compileRpt = function (isRelease) {
	var result = tsCompile(defs.reportFiles, defs.reportModuleName, isRelease, true, false);
	return merge([
		result.js.pipe(gulp.dest(defs.outputDir)),
		result.js.pipe(gulp.dest(defs.buildOutputsDir + defs.jsResourceBase)),
		result.dts.pipe(gulp.dest(defs.buildOutputsDir + defs.jsResourceBase))
	]);
}

gulp.task('compileRpt:dev', function () {
	return compileRpt(false);
});

gulp.task('compileRpt:release', function () {
	return compileRpt(true);
});

var kendoCssStream = function () {

	var _kendoCssFiles = defs.kendoCssFiles.map(function (file) {
		return defs.css3rdPartyResourceBase + file;
	})

	var imageUrl = '../' + defs.imageResourceBase + defs.kendoOutputBase;
	var retStream = gulp.src(_kendoCssFiles)
						.pipe(urlAdjuster({
							replace: ['Bootstrap', imageUrl + '/Bootstrap'],
						})).pipe(urlAdjuster({
							replace: ['textures', imageUrl + '/textures'],
						})).pipe(urlAdjuster({
							replace: ['fonts/glyphs', imageUrl + '/fonts/glyphs'],
						})).pipe(urlAdjuster({
							replace: ['fonts/DejaVu', imageUrl + '/fonts/DejaVu'],
						}));

	return retStream;
}

var kendoCopyImages = function () {
	return gulp.src([defs.kendoResourceBase + defs.kendoFileBase])
		.pipe(gulp.dest(defs.buildOutputsDir + defs.imageResourceBase + defs.kendoOutputBase))
}

var compileStyles = function (isRelease) {

	var sassStream = gulp.src(defs.sassFile)
		.pipe(sourcemaps.init())
		.pipe(sass({ precision: 9 }).on('error', sass.logError));

	var outStream = new streamqueue({ objectMode: true })
		.queue(sassStream)
		.queue(kendoCssStream())
		.done();

	if (isRelease) {
		outStream = outStream.pipe(minifyCss());
	}

	outStream = outStream.pipe(sourcemaps.write())
		.pipe(sourcemaps.init({ loadMaps: true }))
		.pipe(concat(defs.cssFileName + '.css'));

	if (isRelease) {
		outStream = outStream.pipe(concat(defs.cssFileName + '.min.css'));
	}
	else {
		outStream = outStream.pipe(concat(defs.cssFileName + '.css'));
	}

	outStream = outStream.pipe(sourcemaps.write('./'));

	return merge([
		outStream.pipe(gulp.dest(defs.outputDir)),
		outStream.pipe(gulp.dest(defs.buildOutputsDir + defs.cssResourceBase)),
		gulp.src(defs.cssResources, { base: defs.cssResourceBase }).pipe(gulp.dest(defs.buildOutputsDir)),
		kendoCopyImages()
	]);
}




gulp.task('compileStyles:dev', function () {
	return compileStyles(false);
});

gulp.task('compileStyles:release', function () {
	return compileStyles(true);
});

gulp.task('bundleNgTemplates', function () {

	var outStream = gulp.src(defs.ngTemplates)
		.pipe(htmlmin({ collapseWhitespace: true }))
		.pipe(templateCache({
			module: defs.ngTemplatesModuleName,
			root: defs.ngTemplateRootUrl,
			standalone: true
		}))
		.pipe(rename({ basename: defs.moduleName, extname: '.html.js' }));

	return merge([
		outStream.pipe(gulp.dest(defs.outputDir)),
		outStream.pipe(gulp.dest(defs.buildOutputsDir + defs.jsResourceBase))
	]);
});

gulp.task('all:dev', function (cb) {
	runSequence(
		'clean:output',
		['3rdPartyJs:dev',
			'compileTs:dev',
			'compileRpt:dev',
			'compileStyles:dev',
			'bundleNgTemplates'],
		cb);
});

gulp.task('all:release', function (cb) {
	runSequence(
		'clean:output',
		['3rdPartyJs:release',
			'compileTs:release',
			'compileRpt:release',
			'compileStyles:release',
			'bundleNgTemplates'],
		cb);
});

gulp.task('watch:startup', ['all:dev'], function () {

	gulp.watch(defs.thirdPartyFiles, batch({ timeout: 2000 }, function (events, done) {
		gulp.start('3rdPartyJs:dev', done);
	}));

	gulp.watch(defs.ngTemplates, batch({ timeout: 2000 }, function (events, done) {
		gulp.start('bundleNgTemplates', done);
	}));

	gulp.watch(defs.typeScripts, batch({ timeout: 2000 }, function (events, done) {
		gulp.start('compileTs:dev', done);
	}));

	gulp.watch(defs.reportFiles, batch({ timeout: 2000 }, function (events, done) {
		gulp.start('compileRpt:dev', done);
	}));

	gulp.watch(defs.styleWatchFiles, batch({ timeout: 2000 }, function (events, done) {
		gulp.start('compileStyles:dev', done);
	}));

});

// create a minified file and a source map for some junk you just found on the internet
// !!remember to preserve any copyright comments manually in the minified file after it is created!!
gulp.task('minifyJsOnDemand', function () {
	return gulp.src('3rdPartyJs/underscore-1.8.3.js')
	.pipe(rename({ extname: '.min.js' }))
	.pipe(uglify())
	.pipe(gulp.dest('3rdPartyJs'));
});

