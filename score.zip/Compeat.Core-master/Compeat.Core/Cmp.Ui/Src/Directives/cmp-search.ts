﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="directives-module.ts" />

namespace Cmp.Ui.Directives {

	export class CmpSearch implements ng.IDirective {
		constructor() { }
		
		/*@ngInject*/
		static Instance() {
            return new CmpSearch();
		}

		link = (scope: angular.IScope | angular.IScope, element: angular.IAugmentedJQuery, attrs: angular.IAttributes) => {
           element.bind("keydown keypress", function (event) {
                if (event.which === 13) {
                    event.preventDefault();
                }
            });
 		};
		restrict: string = 'A';
	}

	angular
		.module('cmp.ui.directives')
        .directive('cmpSearch', CmpSearch.Instance);

}
