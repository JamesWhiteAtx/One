﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="directives-module.ts" />

namespace Cmp.Ui.Directives {

	export class CmpFocus implements ng.IDirective {
		constructor() { }
		
		/*@ngInject*/
		static Instance() {
            return new CmpFocus();
		}

		link = (scope: angular.IScope, element: angular.IAugmentedJQuery, attrs: angular.IAttributes) => {
            scope.$on('setFocus', function (e, name) {
                if (name === attrs["cmpFocus"]) {
                    var input = element.find('input');
                    if (input && input.length) {
                        input[0].focus();
                    }
                }
            });	
		};

		restrict: string = 'A';
	}

	angular
		.module('cmp.ui.directives')
        .directive('cmpFocus', CmpFocus.Instance);

}
