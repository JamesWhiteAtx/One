﻿/// <reference path="../common-refs.d.ts" />

namespace Cmp.Ui.Directives {
	angular.module('cmp.ui.directives', ['pascalprecht.translate']);
}
