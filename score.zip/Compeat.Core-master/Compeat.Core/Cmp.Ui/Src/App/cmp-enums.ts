﻿/**
 * provides a structure for storing enums
 * @namespace
 */
namespace Cmp.Ui.Enums {
    /** an enum that matches the c# DayOfWeek enum */
    export enum DayOfWeek {
        Sunday = 0,/* if this changes, it will mess up alot of stuff  */
        Monday = 1,
        Tuesday = 2,
        Wednesday = 3,
        Thursday = 4,
        Friday = 5,
        Saturday = 6
    }

    /** an enum for the response from a query, for example a modal confirm dialog */
    export enum Response {
        Cancel = 0,
        Ok = 1,
        Yes = 2,
        No = 3
    }

}