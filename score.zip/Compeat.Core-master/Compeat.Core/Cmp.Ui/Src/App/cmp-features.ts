﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="../services/script-loader.ts" />
/// <reference path="cmp-constants.ts" />
/// <reference path="../providers/cmp-state-provider.ts" />

namespace Cmp.Ui.Features {

    var stockFeatureRequires = ['ui.router', 'cmp.ui.providers'];
    var featureControllerProviderKey = 'cmpNgControllerProvider';
    var featureProvideKey = 'cmpNgProvide';
    var compileProviderKey = 'cmpNgCompileProvider';

    export interface IFeatureModule {

        /** registers the feature controller with the angular provider*/
        RegisterController(controllerConstructor: Function): void;
        /** registers a find feature controller with the angular provider*/
        RegisterFindController(controllerConstructor: Function): void;
        /** registers a data entry feature controller with the angular provider*/
        RegisterDataEntryController(controllerConstructor: Function): void;
        /** registers the feature service with the angular provider*/
        RegisterService(serviceName: string, serviceConstructor: Function): void;

        /** registers the feature directive with the angular provider*/
        RegisterDirective(directiveName: string, directiveFactory: Function): void;

         //** property access FeatureControllerKey value, used in testing, for now */
        FeatureControllerKey: string;
        FeatureFindControllerKey: string;
        FeatureDataEntryControllerKey: string;
    }

    class FeatureModule implements IFeatureModule {

		private _featureName: string;
		private _ngModule: angular.IModule
        constructor(moduleName: string) {
			var self = this;
			var featureName = moduleName.replace('app.', '');
            self._ngModule = angular.module(moduleName);
            self._featureName = featureName;
        }

        public RegisterController = (controllerConstructor: Function) => {
			var self = this;
			self.RegisterControllerToKey(self.FeatureControllerKey, controllerConstructor);
        }
        public RegisterFindController = (controllerConstructor: Function) => {
			var self = this;
			self.RegisterControllerToKey(self.FeatureFindControllerKey, controllerConstructor);
        }
        public RegisterDataEntryController = (controllerConstructor: Function) => {
			var self = this;
			self.RegisterControllerToKey(self.FeatureDataEntryControllerKey, controllerConstructor);
        }

        private RegisterControllerToKey(controllerKey: string, controllerConstructor: Function){
			var self = this;
            var provider = <angular.IControllerProvider>(<any>self._ngModule)[featureControllerProviderKey];
            provider.register(controllerKey, controllerConstructor);
        }

        public RegisterService = (serviceName: string, serviceConstructor: Function) => {
            var provider = <angular.auto.IProvideService>(<any>this._ngModule)[featureProvideKey];
            provider.service(serviceName, serviceConstructor);
        }

        public RegisterDirective = (directiveName: string, directiveFactory: Function) => {
            var compileProvider = <angular.ICompileProvider>(<any>this._ngModule)[compileProviderKey];
            compileProvider.directive(directiveName, directiveFactory);
        }

        get FeatureControllerKey(): string {
            return FeatureModule.BuildFeatureControllerKey(this._featureName);
        }

        get FeatureFindControllerKey(): string {
            return FeatureModule.BuildFindFeatureControllerKey(this._featureName);
        }

        get FeatureDataEntryControllerKey(): string {
            return FeatureModule.BuildDataEntryFeatureControllerKey(this._featureName);
        }

		/** applies a controller naming convention. only used internally for uniqueness, isnt important to consumers */
		public static BuildFeatureControllerKey(featureName: string): string {
			return featureName + 'Controller';
		}
		/** applies a controller naming convention. only used internally for uniqueness, isnt important to consumers */
		public static BuildFindFeatureControllerKey(featureName: string): string {
			return featureName + 'FindController';
		}
		/** applies a controller naming convention. only used internally for uniqueness, isnt important to consumers */
		public static BuildDataEntryFeatureControllerKey(featureName: string): string {
			return featureName + 'EditController';
		}
    }
    
    /** registers the feature with the router and with the angular provider*/
    export function CreateFeatureModule(moduleName: string, hasCss?: boolean, extraRequires?: string[]) {

        var moduleDependencies: string[];
        if (extraRequires && extraRequires.length > 0) {
            moduleDependencies = stockFeatureRequires.concat(extraRequires);
        }
        else {
            moduleDependencies = stockFeatureRequires;
        }

        var newNgModule = angular.module(moduleName, moduleDependencies)
            .config(config);

        /*@ngInject*/
        function config(cmpStateProvider: Cmp.Ui.Providers.CmpStateProvider,
            $controllerProvider: angular.IControllerProvider,
            $provide: angular.auto.IProvideService,
            $compileProvider: angular.ICompileProvider) {

            var featureName = moduleName.replace('app.', '');

            (<any>newNgModule)[featureControllerProviderKey] = $controllerProvider;
            (<any>newNgModule)[featureProvideKey] = $provide;
            (<any>newNgModule)[compileProviderKey] = $compileProvider;

            cmpStateProvider.DefineFeatureState(moduleName, /*@ngInject*/{
                url: '/' + featureName,
                templateUrl: 'Assets/Features/' + featureName + '/' + Cmp.Js.Strings.KebabCase(featureName) + '.html',
                css: hasCss ? 'Assets/Features/' + featureName + '/' + Cmp.Js.Strings.KebabCase(featureName) + '.css' : undefined,
                controllerAs: Cmp.Ui.Constants.StandardControllerName,
                controller: FeatureModule.BuildFeatureControllerKey(featureName),
                resolve: {
                    lazySource: (scriptLoader: Cmp.Ui.Services.IScriptLoaderService) => {
                        return scriptLoader.LoadScript('Assets/Features/' + featureName + '/source.js');
                    }
                }
            });
        }
    }

	/** 
		registers a feature(that uses the find controller and data entry controller) with the router and with the angular provider
		@extraRequires - this is a string array of angular module names if they are needed in the module being created
		@extraInitPromises - this is an object whose properties are resolved before the route loads(be sure to nginject it before passing) ex: { foo: function () { return new Promise(...) }  }
				
	*/
	export function CreateFindAndEditFeatureModule(moduleName: string, extraRequires?: string[], extraInitPromises?: any, editCustomCssPath?: string,
		overrideSourceModule?: string) {

		var moduleDependencies: string[];
		if (extraRequires && extraRequires.length > 0) {
			moduleDependencies = stockFeatureRequires.concat(extraRequires);
		}
		else {
			moduleDependencies = stockFeatureRequires;
		}

		var newNgModule = angular.module(moduleName, moduleDependencies)
			.config(config);

		/*@ngInject*/
		function config(cmpStateProvider: Cmp.Ui.Providers.CmpStateProvider,
			$controllerProvider: angular.IControllerProvider,
			$provide: angular.auto.IProvideService) {

			var featureName = moduleName.replace('app.', '');
			var overrideSourceModuleFeatureName = overrideSourceModule ? overrideSourceModule.replace('app.', '') : featureName;
			
			(<any>newNgModule)[featureControllerProviderKey] = $controllerProvider;
			(<any>newNgModule)[featureProvideKey] = $provide;

			var promisesFind: any = {
				lazySource: /*@ngInject*/(scriptLoader: Cmp.Ui.Services.IScriptLoaderService) => {
					return scriptLoader.LoadScript('Assets/Features/' + overrideSourceModuleFeatureName + '/source.js'); //will also grab the edit source since its in the same directory
				}
			};
			var promisesEdit: any = {};
			
			//if other promises were passed, add them to the promises object
			if (extraInitPromises) {
				angular.extend(promisesFind, extraInitPromises);
				angular.extend(promisesEdit, extraInitPromises);
			}

			cmpStateProvider.DefineFeatureState(moduleName, {
				url: '/' + featureName,
				templateUrl: ('Assets/Features/' + overrideSourceModuleFeatureName + '/' + Cmp.Js.Strings.KebabCase(overrideSourceModuleFeatureName) + '-find.html'),
				controllerAs: Cmp.Ui.Constants.StandardControllerName,
				controller: FeatureModule.BuildFindFeatureControllerKey(overrideSourceModuleFeatureName),
				resolve: promisesFind
			});

			var editObj: any = /*@ngInject*/{
				url: '/:id',
				templateUrl: ('Assets/Features/' + overrideSourceModuleFeatureName + '/' + Cmp.Js.Strings.KebabCase(overrideSourceModuleFeatureName) + '-edit.html'),
				controllerAs: Cmp.Ui.Constants.StandardControllerName,
				controller: FeatureModule.BuildDataEntryFeatureControllerKey(overrideSourceModuleFeatureName),
				resolve: promisesEdit
			};

			if (editCustomCssPath && editCustomCssPath.length) {
				editObj.css = editCustomCssPath;
			};

			cmpStateProvider.DefineFeatureState(moduleName + '.edit', editObj);
		}
	}
    
    /** returns the wrapped angular module setup needs for a feature */
    export function GetFeatureModule(moduleName: string): IFeatureModule {
        return new FeatureModule(moduleName);
    }
}