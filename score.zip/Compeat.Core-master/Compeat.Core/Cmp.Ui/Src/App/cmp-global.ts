﻿$(document).ready(function () {
	$(document).on("click", ".navbar-nav .hover-pointer", function (event) {
				$(".navbar-collapse").collapse('hide');
	});
});

