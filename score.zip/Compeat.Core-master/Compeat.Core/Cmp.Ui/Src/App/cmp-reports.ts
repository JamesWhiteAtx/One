﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="../services/script-loader.ts" />
/// <reference path="cmp-constants.ts" />
/// <reference path="../providers/cmp-state-provider.ts" />

namespace Cmp.Ui.Reports {

	var stockReportRequires = ['ui.router', 'cmp.ui.providers'];
	var reportControllerProviderKey = 'cmpNgControllerProvider';
	var reportProvideKey = 'cmpNgProvide';

	export interface IReportModule {
		RegisterController(controllerConstructor: Function): void;
		RegisterService(serviceName: string, serviceConstructor: Function): void;
		ControllerName: string;
	}

	function GetControllerName(ngModule: angular.IModule) {
		return ngModule.name.replace('app.', '') + 'Ctrl';
	}

	class ReportModule implements IReportModule {

		private _controllerName: string;

		constructor(private _ngModule: angular.IModule) {
			this._controllerName = GetControllerName(_ngModule);
		}

		/** registers the report controller with the angular provider*/
		public RegisterController = (controllerConstructor: Function) => {
			var provider = <angular.IControllerProvider>(<any>this._ngModule)[reportControllerProviderKey];
			provider.register(this._controllerName, controllerConstructor);
		}

		/** registers the report service with the angular provider*/
		public RegisterService = (serviceName: string, serviceConstructor: Function) => {
			var provider = <angular.auto.IProvideService>(<any>this._ngModule)[reportProvideKey];
			provider.service(serviceName, serviceConstructor);
		}

		/** property access reportControllerKey value, used in testing, for now */
		public get ControllerName(): string {
			return this._controllerName;
		}

	}
		
	/** registers the report with the router and with the angular provider*/
	export function CreateReportModule(moduleName: string, extraRequires?: string[], useReportsFolder?: boolean) {

		var moduleDependencies: string[];
		if (extraRequires && extraRequires.length > 0) {
			moduleDependencies = stockReportRequires.concat(extraRequires);
		}
		else {
			moduleDependencies = stockReportRequires;
		}

		var newNgModule = angular.module(moduleName, moduleDependencies)
			.config(config);

		/*@ngInject*/
		function config(cmpStateProvider: Cmp.Ui.Providers.CmpStateProvider,
			$controllerProvider: angular.IControllerProvider,
			$provide: angular.auto.IProvideService,
			$stateProvider: angular.ui.IStateProvider) {

			var basePath: string;
			var featureName = moduleName.replace('app.', '');

			if (useReportsFolder) {
				basePath = 'Assets/Features/Reports/';
			} else {
				basePath = 'Assets/Features/';
			}

			(<any>newNgModule)[reportControllerProviderKey] = $controllerProvider;
			(<any>newNgModule)[reportProvideKey] = $provide;

			cmpStateProvider.DefineFeatureState(moduleName, /*@ngInject*/ {
				url: '/' + featureName,
				templateUrl: basePath + featureName + '/' + Cmp.Js.Strings.KebabCase(featureName) + '.html',
				controllerAs: Cmp.Ui.Constants.StandardControllerName,
				controller: GetControllerName(newNgModule),
				resolve: {
					lazySource: (scriptLoader: Cmp.Ui.Services.IScriptLoaderService) => {
						return scriptLoader.LoadScript(basePath + featureName + '/source.js');
					}
				}
			});
		}
	}
		
	/** returns the wrapped angular module setup needs for a report */
	export function GetReportModule(moduleName: string): IReportModule {
		return new ReportModule(angular.module(moduleName));
	}
}