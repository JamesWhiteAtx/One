﻿/**
 * provides a structure for storing application information
 * @namespace
 */
namespace Cmp.AppInfo {

	/**
	 * The application version number, assigned directly in index type html main pages.
	 * @variable
	 */
	export var Version: string = '';

	/**
	 * Indicates whether the application is running debug mode or not, assigned directly in index type html main pages.
	 * @variable
	 */
    export var Debug: boolean = false;

}