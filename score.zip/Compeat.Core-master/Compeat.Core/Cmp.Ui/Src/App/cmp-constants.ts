﻿/**
 * provides a structure for storing constants
 * @namespace
 */
namespace Cmp.Ui.Constants {

	/**
	* The standard controller name, typically 'vm'.
	*/
	export var StandardControllerName: string = 'vm';

}