﻿namespace Cmp.Ui {

    /** Describes an object that knows how to serialize itself to Json */
    export interface Jsonifiable {
        ToJson: () => Object;
    }

}