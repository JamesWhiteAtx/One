﻿/// <reference path="../../../../Resources/TypeScriptDefs/jquery-2.0.d.ts" />﻿
/// <reference path="../../../../Resources/TypeScriptDefs/angular-1.4.0.d.ts" />﻿
/// <reference path="../../../../Resources/TypeScriptDefs/angular-ui-router.d.ts" />﻿
/// <reference path="../../../../Resources/TypeScriptDefs/angular-translate-2.4.0.d.ts" />
/// <reference path="../../../../Resources/TypeScriptDefs/toastr.d.ts" />
/// <reference path="../../../../Resources/TypeScriptDefs/moment-2.8.0.d.ts" />
/// <reference path="../../../../Resources/TypeScriptDefs/bootstrap-2.2.d.ts" />
/// <reference path="../../../../Resources/TypeScriptDefs/bootstrap.v3.datetimepicker-3.0.0.d.ts" />
/// <reference path="../../../../Resources/TypeScriptDefs/select2-4.0.0.d.ts" />
/// <reference path="../../../../Resources/TypeScriptDefs/es6-promise.d.ts" />
/// <reference path="../../../../Resources/TypeScriptDefs/CompeatTypes-1.0.d.ts" />
/// <reference path="../../../../Resources/TypeScriptDefs/observe-polyfill-0.5.6.d.ts" />
/// <reference path="../../../../Resources/TypeScriptDefs/underscore.d.ts" />
/// <reference path="../../../../Resources/TypeScriptDefs/angular-ui-bootstrap-0.13.3.d.ts" />﻿
/// <reference path="../../../../Resources/TypeScriptDefs/kendo.all.d.ts" />﻿
/// <reference path="../../../../BuildOutputs/Compeat.Core/Scripts/cmp-js.d.ts" />﻿


