﻿namespace Cmp.Ui.Models {
    export class UserStorePair {
        constructor(public StoreName: string, public StoreNum: number, public Current: boolean) { }
    }
}