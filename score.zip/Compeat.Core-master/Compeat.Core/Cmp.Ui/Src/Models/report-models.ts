﻿namespace Cmp.Ui.ReportModels {

	export class ReportParameter {
		constructor(
			public Name: string,
			public Value: any) {
		}
	}

	export class ReportRequestModel {
		constructor(
			public ReportName: string,
			public ReportParameters: Array<ReportParameter>,
			public CsrfToken: string) {
		}
	}

	export class DrillThroughModel extends ReportRequestModel {
		constructor(
			reportName: string,
			reportParameters: Array<ReportParameter>,
			csrfToken: string,
			public DrillThroughTag: string) {

			super(reportName, reportParameters, csrfToken);
		}
	}
}