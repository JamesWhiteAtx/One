﻿namespace Cmp.Ui.Models {
    /** Something to wrap a collection of data and contain the total amount of data available. */
    export class CmpDataSet<TDataType> {
        constructor(
            public RowCount: number,
            public Data: Array<TDataType>) {}

        /** adds a new item to the collection and adjusts the counter as needed */
        public AddItem(newItem: TDataType) {
            var self = this;
            if (!self.Data || !self.Data.length) {
                self.Data = new Array<TDataType>();
            }
            self.Data.push(newItem);
            self.RowCount = self.RowCount ? self.RowCount + 1 : 1;
        }
    }

}