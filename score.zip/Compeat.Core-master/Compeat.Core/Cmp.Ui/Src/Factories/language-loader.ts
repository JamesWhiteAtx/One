﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="factories-module.ts" />
/// <reference path="../services/promise.ts" />
/// <reference path="../services/data-service.ts" />

namespace Cmp.Ui.Factories {
    /** this factory is needed by angular translate to grab the translations from the server and set them up as angular translate needs them */
	/* ngInject */
    function LanguageLoadAndActivate(dataService: Cmp.Ui.Services.IDataService, cmpPromise: Cmp.Ui.Services.PromiseService): (options: any) => cmp.IPromise<angular.translate.ITranslationTable> {
		// $translateProvider.useLoader('cmpLanguageLoader');
		// options is an optional parameter to useLoader( merged with a string key and $http in angular-translate
        return (options: any): cmp.IPromise<angular.translate.ITranslationTable> => {
            return cmpPromise.Promise((resolve, reject): void => {
				// If we introduce multiple language choices, we may need to add the application type (mobile counts) to the object parameter passed to useLoader
                dataService.GetData<Array<ResourceCollection>>('Resources/GetAppResourceStrings', {
                    languageCode: options.key
                }).then((results): void => {
                    if (results && results.length) {
                        var newLangObj: angular.translate.ITranslationTable = {};

                        for (var collectionCnt = 0; collectionCnt < results.length; collectionCnt++) {
                            var resultResources = results[collectionCnt].Resources;
                            if (resultResources && resultResources.length > 0) {
                                for (var resourceCnt = 0; resourceCnt < resultResources.length; resourceCnt++) {
                                    newLangObj[results[collectionCnt].Name + "$" + resultResources[resourceCnt].Name] =
                                    resultResources[resourceCnt].Value;
                                }
                            }
                        }

                        resolve(newLangObj);
                    } else {
                        reject(options.key);
                    }
                }, function () {
                    reject(options.key);
                });
			});
		};
	}

	angular.module('cmp.ui.factories').factory('cmpLanguageLoader', LanguageLoadAndActivate)

	export class ResourceValue {
		public Name: string;
        public Value: string;
	}

	export class ResourceCollection {
		public Name: string;
        public Resources: ResourceValue[];
	}
} 