﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="factories-module.ts" />

namespace Cmp.Ui.Factories {

    export interface IFocus{
        (name: string): void;
    }

    /** this factory focuses elements with the cmp-focus directive set to the name passed in , exported for testing*/
	/* ngInject */
    export function RunFocus($rootScope: angular.IRootScopeService, $timeout: angular.ITimeoutService): IFocus {
        return function (name) {
            $timeout(function () {
                $rootScope.$broadcast('setFocus', name);
            });
        }
	}

    angular
        .module('cmp.ui.factories')
        .factory('focusElement', RunFocus);

} 