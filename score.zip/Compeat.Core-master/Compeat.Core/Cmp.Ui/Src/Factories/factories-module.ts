﻿/// <reference path="../common-refs.d.ts" />

namespace Cmp.Ui.Factories {
	angular.module('cmp.ui.factories', [
	]);
}