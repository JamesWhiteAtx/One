﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="../services/base-tools.ts" />
namespace Cmp.Ui.Rules {
	/**
		existing keys from https://docs.angularjs.org/api/ngMessages
	*/
	export class NgMessageTypes {

		public static Required: string = 'required';
		public static Email: string = 'email';
		public static MinLength: string = 'minlength';
		public static MaxLength: string = 'maxlength';
		public static Min: string = 'min';
		public static Max: string = 'max';
		public static Number: string = 'number';
		public static Pattern: string = 'pattern';
	}

	/**
		 a class to use for custom ng message keys
	*/
	export class CustomValidationMessage {
		public MessageType: string;
        public Message: string;
	}

	export var GENERAL_RULE_ID: string = 'GENERAL';

	/** controls if observers are added or removed on the model by the validation mixin*/
	export enum RuleObserverModes { Add, Remove };

	/** determines if the rule violation is critical*/
	export enum BrokenRuleSeverities {
		None = 0,
		Warning = 1,
		Error = 2
	};

	export class CmpRule {

		public static RuleCounter: number = 0;
		public PropertyName: string;
		public RuleName: string;

		constructor(
			public Rule: (resolve: (isValid: boolean) => void, model: any) => void,
			public Message: string,
			public Severity: Cmp.Ui.Rules.BrokenRuleSeverities,
			public ObservedProperties: Array<string>,
			public NgMessageType: string
			) {


			if (ObservedProperties && ObservedProperties.length && ObservedProperties[0]) {
				this.PropertyName = ObservedProperties[0];
			}
			else {
				this.PropertyName = GENERAL_RULE_ID;
			}


			this.RuleName = '_rule' + (CmpRule.RuleCounter++);
		}
	}

	/** a single property rule that is always in an error state when violated */
	export class SimpleRule extends CmpRule {
		constructor(rule: (resolve: (isValid: boolean) => void, model: any) => void, propertyName: string, message: string, ngMessageType?: string) {
			super(rule, message, BrokenRuleSeverities.Error, [propertyName], ngMessageType);
		}
	}

	/** a single property rule that requires that the property value have a length > 0 */
	export class StringRequiredRule extends SimpleRule {
		constructor(propertyName: string, message: string, ngMessageType?: string) {
			super((resolve: (isValid: boolean) => void, model: any): void => {
				resolve(!Cmp.Js.Strings.IsEmpty(model[propertyName]));
			}, propertyName, message, ngMessageType);
		}
	}

	/** a single property rule that requires that a date is not falsey */
	export class DateRequiredRule extends SimpleRule {
		constructor(propertyName: string, message: string, ngMessageType?: string) {
			super((resolve: (isValid: boolean) => void, model: any): void => {
				resolve(Cmp.Js.Boolify(model[propertyName]));
			}, propertyName, message, ngMessageType);
		}
	}

	/** a single property rule that requires that the property value be a valid integer */
	export class IntegerRequiredRule extends SimpleRule {
		constructor(propertyName: string, message: string, ngMessageType?: string) {
			super((resolve: (isValid: boolean) => void, model: any): void => {
				resolve(Cmp.Js.Strings.IsInteger(model[propertyName]));
			}, propertyName, message, ngMessageType);
		}
	}

	/** a single property rule that requires that the property be a valid integer or not specified */
	export class IntegerRequiredOrEmpty extends SimpleRule {
		constructor(propertyName: string, message: string, ngMessageType?: string) {
			super((resolve: (isValid: boolean) => void, model: any): void => {
				resolve(Cmp.Js.Strings.IsIntegerOrEmpty(model[propertyName]));
			}, propertyName, message, ngMessageType);
		}
	}

	/** a single property rule that requires that the property value be a valid decimal number */
	export class DecimalRequiredRule extends SimpleRule {
		constructor(propertyName: string, message: string, ngMessageType?: string) {
			super((resolve: (isValid: boolean) => void, model: any): void => {
                resolve(Cmp.Js.Strings.IsDecimal(model[propertyName]));
			}, propertyName, message, ngMessageType);
		}
    }

	/** an ember helper class that represents the results of a rule being tested */
	export class BrokenRule {
		public Message: string = '';
		public Severity: Cmp.Ui.Rules.BrokenRuleSeverities = Cmp.Ui.Rules.BrokenRuleSeverities.None;
		public RuleName: string = '';
		public IsError: boolean;
		public IsWarning: boolean;
		public NgMessageType: string;
	};

	/** the content of this collection should be an array of broken rules for a given property */
	export class BrokenRuleResultCollection {
		public Content: Array<BrokenRule>;
		public HasNotification: boolean;
		public HasError: boolean;

		constructor() {
			var self = this;
			self.Content = new Array<BrokenRule>()
			self.HasNotification = false;
			self.HasError = false;
		}

		/** adds the result of validation to the rule result collection */
		public AddRuleResult = (ruleName: string, message: string, severity: Cmp.Ui.Rules.BrokenRuleSeverities, ngMessageType?: string) => {
			var newRule = new BrokenRule();
			newRule.RuleName = ruleName;
			newRule.Message = message;
			newRule.Severity = severity;
			newRule.NgMessageType = ngMessageType;
			newRule.IsError = severity === Cmp.Ui.Rules.BrokenRuleSeverities.Error;
			newRule.IsWarning = severity === Cmp.Ui.Rules.BrokenRuleSeverities.Warning;

			if (newRule.IsError || newRule.IsWarning) {
				this.HasNotification = true;
			}
			if (newRule.IsError) {
				this.HasError = true;
			}
			this.Content.push(newRule);
		}
		
		/** removes all results related to a a specific rule */
		public RemoveRuleResult = (ruleName: string) => {
			for (var resultCnt: number = this.Content.length - 1; resultCnt >= 0; resultCnt--) {
				if (this.Content[resultCnt].RuleName == ruleName) {
					this.Content.splice(resultCnt, 1);
				}
			}
			this.HasNotification = false;
			this.HasError = false;
			for (var resultCnt: number = 0; resultCnt < this.Content.length; resultCnt++) {
				var rule = this.Content[resultCnt];
				if (rule.IsError) {
					this.HasNotification = true;
					this.HasError = true;
					break;//break early since flag is already done
				} else if (rule.IsWarning) {
					this.HasNotification = true;
					//keep going to an error if it exists
				}
			}
		}
	
		/** clears results from prior validation runs */
		public ClearRuleResults = () => {
			this.Content = new Array<BrokenRule>();
			this.HasNotification = false;
			this.HasError = false;
		}
		
		/** get the entire contents of rule validation */
		public GetRuleResults = () => {
			return this.Content;
		}

	};
    
	/** 
        adds a general bucket error to the obj param 
        @obj {IHaveRules} the object to add the error to
    */
	export function AddGeneralError(obj: IHaveRules, message: string, severity?: Cmp.Ui.Rules.BrokenRuleSeverities, propertyName?: string) {
		if (!propertyName) {
			propertyName = Rules.GENERAL_RULE_ID;
		}
		if (!severity) {
			severity = Rules.BrokenRuleSeverities.Error;
		}

		var ruleBucket = obj.BrokenRules;
		var ruleResults: Cmp.Ui.Rules.BrokenRuleResultCollection = ruleBucket[propertyName];

		if (!ruleResults) {
			ruleBucket[propertyName] = new Cmp.Ui.Rules.BrokenRuleResultCollection(); // initialize a new empty bucket
			ruleResults = ruleBucket[propertyName];
		}

		ruleResults.AddRuleResult(Rules.GENERAL_RULE_ID, message, severity);
	}
    
	/** 
        clears the general bucket errors of the obj param 
        @obj {IHaveRules} the object to clear the errors from
    */
	export function ClearGeneralErrors(obj: IHaveRules, propertyName?: string) {
		if (!propertyName) {
			propertyName = Rules.GENERAL_RULE_ID;
		}

		var ruleResults: Cmp.Ui.Rules.BrokenRuleResultCollection = obj.BrokenRules[propertyName];
		if (ruleResults) {
			ruleResults.RemoveRuleResult(Rules.GENERAL_RULE_ID);
		}
	}
    
	/** 
        clears all error buckets of the obj param 
        @obj {IHaveRules} the object to clear the errors from
    */
	export function ClearAllRuleResults(obj: IHaveRules) {
		var ruleBuckets: any = obj.BrokenRules;
		if (ruleBuckets) {
			for (var prop in ruleBuckets) {
				if (ruleBuckets.hasOwnProperty(prop)) {
					var ruleResults: Cmp.Ui.Rules.BrokenRuleResultCollection = ruleBuckets[prop];
					if (ruleResults) {
						ruleResults.ClearRuleResults();
					}
				}
			}
		}
		//check if their are any known child IHaveRules properties so they can be run too
		var childProps = obj.RuledChildProperties;
		if (childProps && childProps.length) {
			for (var propCounter: number = 0; propCounter < childProps.length; propCounter++) {
				var childPropName = childProps[propCounter];
				var child = obj[childPropName];
				if (child) {
					if (Cmp.Js.TypeOf(child) === 'array') {
						//child is collection so runrules on each item
						if (child.length) {
							for (var elementCounter: number = 0; elementCounter < child.length; elementCounter++) {
								var element = <IHaveRules>child[elementCounter];
								if (element) {
									ClearAllRuleResults(element);
								}
							}
						}
					}
					else {
						ClearAllRuleResults(<IHaveRules>child);
					}
				}
			}
		}
	}
	
	/**
	exported for testability only, checks the error buckets for errors
	*/
	export function _isValid(self: IHaveRules) {
		var ruleBuckets: any = self.BrokenRules;
		if (ruleBuckets) {
			for (var prop in ruleBuckets) {
				if (ruleBuckets.hasOwnProperty(prop)) {
					var ruleResults: Cmp.Ui.Rules.BrokenRuleResultCollection = ruleBuckets[prop];
					if (ruleResults && ruleResults.HasError) {
						return false;
					}
				}
			}
		}
		//check if their are any known child IHaveRules properties so they can be run too
		var childProps = self.RuledChildProperties;
		if (childProps && childProps.length) {
			for (var propCounter: number = 0; propCounter < childProps.length; propCounter++) {
				var childPropName = childProps[propCounter];
				var child = self[childPropName];
				if (child) {
					if (Cmp.Js.TypeOf(child) === 'array') {
						//child is collection so runrules on each item
						if (child.length) {
							for (var elementCounter: number = 0; elementCounter < child.length; elementCounter++) {
								var element = <IHaveRules>child[elementCounter];
								if (element) {
									var subReturnVal = _isValid(element);
									if (!subReturnVal) {
										return false;
									}
								}
							}
						}
					}
					else {
						//child is an object so run rules on it
						var subReturnVal = _isValid(<IHaveRules>child);
						if (!subReturnVal) {
							return false;
						}
					}
				}
			}
		}

		return true;
	}

	function _updateNgMessages(self: IHaveRules, currPropertyPath: string, form: angular.IFormController, depth: number) {
		var ruleBuckets: any = self.BrokenRules;
		if (ruleBuckets) {
			for (var prop in ruleBuckets) {
				if (ruleBuckets.hasOwnProperty(prop)) {
					var ruleResults: Cmp.Ui.Rules.BrokenRuleResultCollection = ruleBuckets[prop];
					if (ruleResults && ruleResults.HasError && ruleResults.Content && ruleResults.Content.length) {
						var first = Cmp.Js.Arrays.First(ruleResults.Content, (itm): boolean => {
							return itm.IsError;
						});
						if (first) {
							var modelObj = (<angular.INgModelController>form[(currPropertyPath && currPropertyPath.length && depth ? currPropertyPath + '.' : '') + prop]);
							//might not be a model object even if there is a rules
							if (modelObj) {
								modelObj.$setValidity(first.NgMessageType && first.NgMessageType.length ? first.NgMessageType : first.RuleName, false);
							}
						}
						return false;
					}
				}
			}
		}
		//check if their are any known child IHaveRules properties so they can be run too
		var childProps = self.RuledChildProperties;
		if (childProps && childProps.length) {
			for (var propCounter: number = 0; propCounter < childProps.length; propCounter++) {
				var childPropName = childProps[propCounter];
				var child = self[childPropName];
				if (child) {
					if (Cmp.Js.TypeOf(child) === 'array') {
						//child is collection so update messages on each item
						if (child.length) {
							for (var elementCounter: number = 0; elementCounter < child.length; elementCounter++) {
								var element = <IHaveRules>child[elementCounter];
								if (element) {
									_updateNgMessages(element, (currPropertyPath && currPropertyPath.length && depth ? currPropertyPath + '.' : '') + childPropName + '[' + elementCounter + ']', form, depth + 1);
								}
							}
						}
					}
					else {
						//child is an object so update messages on it
						_updateNgMessages(<IHaveRules>child, (currPropertyPath && currPropertyPath.length && depth ? currPropertyPath + '.' : '') + childPropName, form, depth + 1);
					}
				}
			}
		}
	}

	/**
	exported for testability only
	*/
    export function _runRule(context: IHaveRules, thisRule: CmpRule, cmpPromise: Cmp.Ui.Services.IPromiseService): cmp.IPromise<any> {
        return cmpPromise.Promise<any>((resolve): void => {

			if (!context.BrokenRules) {
				context.BrokenRules = {};
			}
			var ruleBucket = context.BrokenRules;

			//get this rule's result bucket
			var ruleResults = ruleBucket[thisRule.PropertyName];

			if (!ruleResults) {
				ruleBucket[thisRule.PropertyName] = new BrokenRuleResultCollection(); // initialize a new empty bucket
				ruleResults = ruleBucket[thisRule.PropertyName];
			}

			//remove old error message if its in there
			ruleResults.RemoveRuleResult(thisRule.RuleName);
			//run rule and react if failed
			thisRule.Rule(function (runResult) {
				if (!runResult) {
					//push the new error into the bucket for that property
					ruleResults.AddRuleResult(thisRule.RuleName, thisRule.Message, thisRule.Severity, thisRule.NgMessageType);
				}

				resolve();//leave runRule()
			}, context);
		});
	}

	/** calls all rules, waits for them to run, and returns(via promise value) the success of validation */
    export function RunRules(self: IHaveRules, form: angular.IFormController, cmpPromise: Cmp.Ui.Services.IPromiseService): cmp.IPromise<boolean> {
        return cmpPromise.Promise<boolean>((resolve, reject): void => {
            if (self && self.GetRules) {
                Cmp.Ui.Rules.ClearAllRuleResults(self);//clear current error list
                self.GetRules().then((myRules: Array<Rules.CmpRule>): void => {
                    var promises = new Array<cmp.IPromise<any>>();

                    if (myRules && myRules.length) {
                        for (var ruleCnt: number = 0; ruleCnt < myRules.length; ruleCnt++) {
                            promises.push(_runRule(self, myRules[ruleCnt], cmpPromise));
                        }
                    }
                    //check if their are any known child IHaveRules properties so they can be run too
                    var childProps = self.RuledChildProperties;
                    if (childProps && childProps.length) {
                        for (var propCounter: number = 0; propCounter < childProps.length; propCounter++) {
                            var childPropName = childProps[propCounter];
                            var child = self[childPropName];
                            if (child) {
                                if (Cmp.Js.TypeOf(child) === 'array') {
                                    //child is collection so runrules on each item
                                    if (child.length) {
                                        for (var elementCounter: number = 0; elementCounter < child.length; elementCounter++) {
                                            var element = <IHaveRules>child[elementCounter];
                                            if (element) {
                                                promises.push(RunRules(element, null, cmpPromise));
                                            }
                                        }
                                    }
                                }
                                else {
                                    //child is an object so run rules on it
                                    promises.push(RunRules(<IHaveRules>child, null, cmpPromise));
                                }
                            }
                        }
                    }

                    cmpPromise.All(promises).then((): void => {
                        if (form) {
                            _updateNgMessages(self, '', form, -1);
                        }
                        resolve(_isValid(self));
                    });// wait for all promises then resolve the run rules call
                });
            } else {
                if (self && !self.GetRules) {
                    console.error("RunRules called on invalid object. GetRules() was expected to exist, but didnt.");
                }
                return resolve(false);
            }
		});
	}
    
    /** objects with compeat error buckets should implement this in order to use the buckets */
	export interface IHaveRules {
		BrokenRules: Cmp.Js.Types.IStringMap<Cmp.Ui.Rules.BrokenRuleResultCollection>;
		RuledChildProperties: Array<string>;
        GetRules(): cmp.IPromise<Array<Cmp.Ui.Rules.CmpRule>>;
		[index: string]: any; // items accessed this way are typically validatable children.
	}
}




