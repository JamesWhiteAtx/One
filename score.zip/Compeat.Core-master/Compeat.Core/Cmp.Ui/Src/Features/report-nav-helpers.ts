﻿/// <reference path="../../../../../Resources/TypeScriptDefs/jquery-2.0.d.ts" />﻿
/// <reference path="../models/report-models.ts" />

namespace Cmp.Ui.ReportNavHelpers {

	export var SourceReportName = '';
	export var CsrfToken = '';

	function _getDevExpressHelper(): any {
		return (<any>window)['dxo'].viewer;
	}

    /** called from reports to sort a report by a column */
	export function ReportSort(tag: string) {

		var helper = _getDevExpressHelper();
		var parameters = eval('(' + helper.getParametersHiddenField().value + ')');
		if (parameters && parameters.UserSortField != undefined) {
			if (parameters.UserSortField === tag) {
				parameters.ReverseUserSort = !parameters.ReverseUserSort;
			} else {
				parameters.UserSortField = tag;
			}

			helper.getParametersHiddenField().value = (<any>window)['_aspxToJson'](parameters);
			helper.getKeyHiddenField().value = '';
			helper.gotoPageInternal(helper.getCurrentPageIndex());
			helper.refreshRising.FireEvent(this);
		}
	}

    /** called from reports to cause the report to drill down into a sub report*/
	export function ReportDrillThrough(tag: string) {
		var helper = _getDevExpressHelper();
		var requestModel = new Cmp.Ui.ReportModels.DrillThroughModel(SourceReportName, [], CsrfToken, tag);
		var parameters = eval('(' + helper.getParametersHiddenField().value + ')');
		if (parameters) {
			for (var key in parameters) {
				// top level properties that are not parameters of subreports (MySubReport.MyParameter)
				if (parameters.hasOwnProperty(key) && (key.indexOf('.') < 0)) {
					requestModel.ReportParameters.push(new Cmp.Ui.ReportModels.ReportParameter(key, parameters[key]));
				}
			}
		}

		var postData = JSON.stringify(requestModel);

		var form = '<form id="requestForm" action="reports/drillthrough" method="POST"/>';
		var input = $('<input type="hidden" name="request">');
		input.val(postData);

		if ($('#requestForm').length) {
			$('#requestForm').remove();
		}

		$(form).append(input).appendTo('body').submit();

	}

	/** Creates a new empty browser window and injects a report request into contents.  */
	export function OpenReportLoaderWindow(requestModel: Cmp.Ui.ReportModels.ReportRequestModel) {

		var postData = JSON.stringify(requestModel);

		var form = '<form id="requestForm" target="_blank" action="reports/report" method="POST"/>';
		var input = $('<input type="hidden" name="request">');
		input.val(postData);

		if ($('#requestForm').length) {
			$('#requestForm').remove();
		}

		$(form).append(input).appendTo('body').submit();
	}

}