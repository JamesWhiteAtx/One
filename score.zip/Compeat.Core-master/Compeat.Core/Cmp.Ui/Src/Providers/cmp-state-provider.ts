﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="version-provider.ts" />

namespace Cmp.Ui.Providers {

	/**
	 * Provider class to provide a wrapper for angular UI-Router
	 * @class
	 */
	export class CmpStateProvider implements angular.IServiceProvider {

		/** constructor to assign $stateProvider as private property */
		/*@ngInject*/
		constructor(
			private $stateProvider: angular.ui.IStateProvider,
			private cmpVersionProvider: Cmp.Ui.Providers.VersionProvider) {
		}

		/** inject $stateProvider and supply to the constructor */
		/*@ngInject*/
		public $get(
			$state: angular.ui.IStateProvider,
			cmpVersionProvider: Cmp.Ui.Providers.VersionProvider): CmpStateProvider {
			return new CmpStateProvider($state, cmpVersionProvider);
		}

		/**
		 * Registers a state configuration under a given state name.
		 * @method
		 * @param {string} name - A unique state name, e.g. "home", "about", "contacts".
		 * @param {IState} config - stateConfig State configuration object..
		 * @returns {IStateProvider}, so you can chain state declarations.
		 */
		public DefineState(nameOrConfig: string | angular.ui.IState, config?: angular.ui.IState): CmpStateProvider {
			var self = this;

			if (angular.isObject(config)) {
				self.$stateProvider.state(<string>nameOrConfig, config);
			} else {
				self.$stateProvider.state(<angular.ui.IState>nameOrConfig);
			}

			return self;
		}

		/**
		 * Registers a state configuration for features, with appropriate cache busting debug and version info.
		 * This method will update the templateUrl of passed config object with cache busting features.
		 * @method
		 * @param {string} name - A unique state name, e.g. "home", "about", "contacts".
		 * @param {IState} config - stateConfig State configuration object..
		 * @returns {IStateProvider}, so you can chain state declarations.
		 */
		public DefineFeatureState(name: string | angular.ui.IState, config?: angular.ui.IState): CmpStateProvider {
			var self = this;

			// only apply cache busting if in debug mode
			if (!self.cmpVersionProvider.IsDebug) {

				// The templateUrl of the config object can be either a string or a function { (): string }; 
				
				// If it is a string, append cache busting to the url string
				if (angular.isString(config.templateUrl)) {
					config.templateUrl = self.cmpVersionProvider.VersionedUrl(<string>config.templateUrl);
				}

				// if it is a function, envclose the defined function, and apply cache busting to the result
				if (angular.isFunction(config.templateUrl)) {

					var templateFcn = <{ (): string }>config.templateUrl;

					config.templateUrl = function () {
						var url = <string>templateFcn.apply(arguments);

						url = self.cmpVersionProvider.VersionedUrl(url);

						return url;
					}
				}
			}

			self.DefineState(name, config);

			return self;
		}

		//** $stateProvider method not currently implemented for the CmpStateProvider wrapper */
		//public decorator(name?: string, decorator?: (state: IState, parent: Function) => any): any { }

	}

	angular.module('cmp.ui.providers').provider('cmpState', CmpStateProvider);
}

