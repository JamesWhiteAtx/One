﻿namespace Cmp.Ui.Providers {
    angular.module('cmp.ui.providers', [
    ]);
}