﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="../app/cmp-app-info.ts" />
/// <reference path="providers-module.ts" />

namespace Cmp.Ui.Providers {

	/**
	 * Provider class to provide application version utilities, for cache busting
	 * @class
	 */
	export class VersionProvider implements angular.IServiceProvider {

		public $get(): VersionProvider {
			return new VersionProvider();
		}

		/**
		 * Property access of app info version number as string
		 * @property
		 * @returns {string}
		 */
		get Version(): string {
			return Cmp.AppInfo.Version;
		}


		/**
		 * Property access of app info version number as string
		 * @property
		 * @returns {string}
		 */
		get IsDebug(): boolean {
            return Cmp.AppInfo.Debug;
		}

		/** this function returns the result of Date.now() in js. its exposed/needed only for testing*/
		public _GetCurrentDate = (): number => {
			return Date.now();
		}

		/**
		 * Gets returns a url with a version query string appended, for cache busting
		 * @method
		 * @param {string} url - a url string.
		 * @returns {string}
		 */
		public VersionedUrl(url: string): string {
			var qst: string;
			var delim: string;

            var self = this;
            var ver = self.Version;
			var versUrl: string = url;

            if (url) {
                if (self.IsDebug) {
                    ver = moment(self._GetCurrentDate()).format("YYYY-MM-DDTHH:mm:ssZZ");                                     
                }
				qst = '?';
				delim = (url.indexOf(qst) === -1) ? qst : '&';
				versUrl = versUrl + delim + 'v=' + ver;
			}

			return versUrl;
		}

	}

	angular.module('cmp.ui.providers').provider('cmpVersion', VersionProvider);
}

