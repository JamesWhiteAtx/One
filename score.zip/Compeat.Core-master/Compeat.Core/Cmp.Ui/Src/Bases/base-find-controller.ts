﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="base-controller.ts" />
/// <reference path="base-bo-controller.ts" />
/// <reference path="../features/rules.ts" />
/// <reference path="base-bo-model.ts" />
/// <reference path="../services/base-tools.ts" />
/// <reference path="../component/cmpgrid/cmp-grid-settings.ts" />
/// <reference path="../interfaces/constructor.ts" />
/// <reference path="../component/cmpfindpage/cmp-find-page.ts" />

namespace Cmp.Ui.Bases {

	export class BaseFindController<TEditModelType extends Cmp.Js.Types.ICmpIdable, TListModelType extends Cmp.Js.Types.ICmpIdable> extends Cmp.Ui.Bases.BaseBoController<any> {


		/** Holds the list of records to display in the find grid */
		public FindList: Cmp.Ui.Models.CmpDataSet<TListModelType>;
		/** 
				Holds some basic options for the find control 
		*/
		public FindOptions: Cmp.Ui.Components.ICmpFindPageOptions<TEditModelType, TListModelType>;

		public DataService: Cmp.Ui.Services.IDataService;
		public $translate: angular.translate.ITranslateService;
		public Logger: Cmp.Ui.Services.LoggerService;
		public $state: angular.ui.IStateService;

		constructor(
			baseTools: Cmp.Ui.Services.IBaseTools) {
			super(baseTools);
			var self = this;
			self.DataService = baseTools.GetInstance<Cmp.Ui.Services.IDataService>('dataService');
			self.$translate = baseTools.GetInstance<angular.translate.ITranslateService>('$translate');
			self.Logger = baseTools.GetInstance<Cmp.Ui.Services.LoggerService>('logger');
			self.$state = baseTools.GetInstance<angular.ui.IStateService>('$state');
		}
		/** Gets the list of records to display in the find grid */
		public GetFindData = (classObj: Cmp.Ui.Interfaces.IConstructor, postData?: any, urlRoute?: string) => {
			var self = this;

			if (!urlRoute) {
				urlRoute = "{0}/GetList";
			}

			// get the list of records to display in the find grid
			return self.DataService.GetDataList<TListModelType>(Cmp.Js.Strings.Format(urlRoute, self.TableName), postData, classObj).then(
				(result) => {
					self.FindList = new Cmp.Ui.Models.CmpDataSet<TListModelType>(result && result.length ? result.length : 0, result);
				});
		}
		/** removes a record from the server based on its id, resolves a promise when its done */
		public DeleteRecord = (id: string): cmp.IPromise<TEditModelType> => {
			var self = this;
			var url = self.DeleteUrl(self);
			return self.BaseTools.CmpPromise.Promise<TEditModelType>((resolve, reject) => {
				if (Cmp.Js.IsNullOrUndefined(id)) {
					self.$state.go("app." + self.RouteName).then(() => {
						resolve(null);
					}, reject);
				} else {
					var postData = self.DeleteArgs(self, id);
					self.DataService.SendData<{ id: string }, TEditModelType>(url, postData).then(
						(result) => {
							//remove from findlist if possible, 
							if (self.FindList && self.FindList.Data && self.FindList.Data.length) {
								var rowsRemoved = Cmp.Js.Arrays.Remove<TListModelType>(self.FindList.Data, (itm) => {
									return itm.id == id;
								});
								if (rowsRemoved) {
									self.FindList.RowCount -= rowsRemoved;
								}
							}
							//setup for redirect back to root
							self.Logger.Success(self.$translate.instant('Core$YourRecordWasDeleted'));
							self.$state.go("app." + self.RouteName).then(() => {
								resolve(result);
							}, reject);
						}, reject);
				}
			});
		}

		/** Override if a special url is needed that doesnt fit the table based crud pattern */
		public DeleteUrl(thisController: BaseFindController<TEditModelType, TListModelType>): string {
			return Cmp.Js.Strings.Format('{0}/Delete', thisController.TableName);
		}

		/** Override if a special args are needed for the getbyid call that dont fit the table based crud pattern */
		public DeleteArgs(thisController: BaseFindController<TEditModelType, TListModelType>, id: any): any {
			return {
				id: id
			};
		}
	}
}
