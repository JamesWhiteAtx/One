﻿/// <reference path="../common-refs.d.ts" />

namespace Cmp.Ui.Bases {

    /** A base container for the user's current session.  It contains general information that is aquired on login or initial
        application bootstrap that is needed for client-side applicaiton level controls.
    */
    export class BaseSession {

        /** The unique identifier of the current logged in user */
        public UserId: number = null;
        
        /** The current logged in user's name */
        public UserDisplayName: string = null;

        /** The user's desired language */
        public Language: string = 'en';

        /** The user's current menu */
        public UserMenu: MenuNode[] = [];

        /** The user's list of external applicatiosn */
        public ExternalApps: ExternalApp[] = [];

        /** The user account links  */
        public UserLinks: UserLink[] = [];

        /** The user account links  */
        public MessagesLink: MessageLink =  new MessageLink();

        // User rights

        /** User rights container.  Use HasRight for testing */
        private _userRights: UserRights = new UserRights();

        /** Resets the user rights container and loads it with the provided rights */
        public InitializeRights(rights: string[]): void {
            var self = this;
            self._userRights = new UserRights();
            rights.forEach((right) => {
                self._userRights[right] = true;
            });
        }

        /** Adds a new user right to the session */
        public AddRight(right: string): void {
            this._userRights[right] = true;
        }

        /** Returns true if the user has been assigned the specified right */
        public HasRight(right: string): boolean {
            return Cmp.Js.Boolify(this._userRights[right]);
        }

        /** Returns true if the user has all of the specified rights */
        public HasAllRights(rights: string[]): boolean {

            var allRightsFound = true;
            for (var i = 0; i < rights.length; i++) {
                if (!Cmp.Js.Boolify(this._userRights[rights[i]])) {
                    allRightsFound = false;
                    break;
                }
            }
            return allRightsFound;
        }

        /** Returns true if the user has one of the specified rights */
        public HasSomeRights(rights: string[]): boolean {

            var rightFound = false;
            for (var i = 0; i < rights.length; i++) {
                if (Cmp.Js.Boolify(this._userRights[rights[i]])) {
                    rightFound = true;
                    break;
                }
            }
            return rightFound;
        }

    }

    /** A container bucket for if a right has been assigned to a user */
    class UserRights {
        [index: string]: boolean;
    }

    export enum NodeTypes {
        MenuNode = 1,
        Feature = 2,
        WorkflowUnit = 3,
        Workflow = 4,
        CustomReport = 5
    }

    /** A container for the current user's menu options */
    export class MenuNode {

        public NodeType: number;
        public Description: string;
        public ActionId: number;
        public Children: MenuNode[] = [];

        /** Returns true if the tested noe is a menu item */
        public static IsMenuType(menuNode: MenuNode) {
            return menuNode.NodeType === NodeTypes.MenuNode;
        }
    }

    /** A container for the current user's available external links */
    export class ExternalApp {
        public DisplayName: string;
        public Url: string;
    }

    /** A container for the current user's user account links */
    export class UserLink {
        public DisplayName: string;
        public ActionType: number;
        public ActionId: number;
    }

    /** A container for the messages */
    export class MessageLink {
        public Display: boolean;
        public ActionType: number;
        public ActionId: number;
        public Count: string;
    }
}