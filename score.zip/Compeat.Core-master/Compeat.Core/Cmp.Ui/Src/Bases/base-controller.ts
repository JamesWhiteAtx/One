﻿/// <reference path="../services/base-tools.ts" />

namespace Cmp.Ui.Bases {

	export class BaseController {
		constructor(public BaseTools: Cmp.Ui.Services.IBaseTools) { }

	}
} 
