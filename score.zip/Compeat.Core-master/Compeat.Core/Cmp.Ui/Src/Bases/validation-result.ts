﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="base-model.ts" />
/// <reference path="../features/rules.ts" />
/// <reference path="../services/base-tools.ts" />

namespace Cmp.Ui.Bases {

	export class ValidationResult {
		public IsValid: boolean;
		public Errors: any[];
	}
}
