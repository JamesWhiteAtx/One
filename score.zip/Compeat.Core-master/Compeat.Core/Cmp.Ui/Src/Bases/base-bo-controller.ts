﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="base-validatable-controller.ts" />
/// <reference path="base-bo-model.ts" />
/// <reference path="../services/logger.ts" />
/// <reference path="../interfaces/ajax-post-response.ts" />

namespace Cmp.Ui.Bases {

	export class BaseBoController<TModelType extends IBaseBoModel> extends Cmp.Ui.Bases.BaseValidatableController {

		public Model: TModelType;
		/** Used to build links.  For a page like Master Inventory this would be 'masterinventory' to match the routes. */
		public RouteName: string;
		/** Used to make api calls.  For a page like Master Inventory this would be 'inventoryheader' to match the generated table classes. */
		public TableName: string;

		constructor(
			baseTools: Cmp.Ui.Services.IBaseTools
		) {
			super(baseTools);
			this.RuledChildProperties.push('Model');
		}

		/** If the route name and table name are the same, you only need to pass in the route name. */
		public SetRouteAndTableName(
			/** the name of the angular url */
			routeName: string, 
			/** the name of the generated table */
			tableName?: string): void {
			var self = this;
			self.RouteName = routeName;
			if (Cmp.Js.IsNullOrUndefined(tableName)) {
				self.TableName = routeName;
			} else {
				self.TableName = tableName;
			}
		}

	}
}

