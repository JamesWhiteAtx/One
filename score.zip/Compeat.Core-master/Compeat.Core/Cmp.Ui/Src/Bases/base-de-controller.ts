﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="base-controller.ts" />
/// <reference path="base-bo-controller.ts" />
/// <reference path="../features/rules.ts" />
/// <reference path="base-bo-model.ts" />
/// <reference path="../interfaces/base-de-model.ts" />
/// <reference path="../Component/CmpFindPage/cmp-find-page.ts" />
/// <reference path="../interfaces/constructor.ts" />
/// <reference path="../services/base-de-data-service.ts" />

namespace Cmp.Ui.Bases {

	export class BaseDeController<TEditModelType extends Cmp.Ui.Interfaces.IBaseDeModel,
		TListModelType extends Cmp.Js.Types.ICmpIdable> extends Cmp.Ui.Bases.BaseBoController<TEditModelType> {

		/** Defined in templates */
		public MainForm: angular.IFormController;
		/** The scope of the parent find page */
		public FindPageScope: Cmp.Ui.Components.ICmpFindPage<TEditModelType, TListModelType>;
		/** Any detail table collections that need to be loaded */
		public CollectionsToLoad: Array<any>;
		public LoadAllCollections: boolean;
		/** Whether or not the show the header visibility button in cmp-de-buttons */
		public ShowHeaderBtn: boolean;
		/** Whether or not to show a header section on this page.  This is controlled by the ShowHeaderBtn button. */
		public ShowHeader: boolean;

		private _boType: Cmp.Ui.Interfaces.IConstructor;
		public DataService: Cmp.Ui.Services.IDataService;
		public $translate: angular.translate.ITranslateService;
		public Logger: Cmp.Ui.Services.LoggerService;
		public $timeout: angular.ITimeoutService;
		public $state: angular.ui.IStateService;
		public $stateParams: ng.ui.IStateParamsService;
		public baseDeDataService: Cmp.Ui.Services.IBaseDeDataService<TEditModelType, TListModelType>;
		public $scope: angular.IScope;

		constructor(
			baseTools: Cmp.Ui.Services.IBaseTools,
			boType: Cmp.Ui.Interfaces.IConstructor,
			$scope: angular.IScope) {
			super(baseTools);
			var self = this;

			self.CollectionsToLoad = [];
			self.LoadAllCollections = false;
			self.ShowHeaderBtn = false;
			self.ShowHeader = true;
			self._boType = boType

			self.DataService = baseTools.GetInstance<Cmp.Ui.Services.IDataService>('dataService');
			self.$translate = baseTools.GetInstance<angular.translate.ITranslateService>('$translate');
			self.Logger = baseTools.GetInstance<Cmp.Ui.Services.LoggerService>('logger');
			self.$state = baseTools.GetInstance<angular.ui.IStateService>('$state');
			self.$stateParams = baseTools.GetInstance<angular.ui.IStateParamsService>('$stateParams');
			self.$timeout = baseTools.GetInstance<angular.ITimeoutService>('$timeout');
			self.baseDeDataService = baseTools.GetInstance<Cmp.Ui.Services.IBaseDeDataService<TEditModelType, TListModelType>>('baseDeDataService');
			self.$scope = $scope;
			self.FindPageScope = <Cmp.Ui.Components.ICmpFindPage<TEditModelType, TListModelType>>(<any>self.$scope.$parent);
		}

		public GetConstructor(): Cmp.Ui.Interfaces.IConstructor {
			return this._boType;
		}

		/** retreives the record from the server that will be used to edit */
		public GetRecord = (): cmp.IPromise<TEditModelType> => {
			var self = this;
			return self.baseDeDataService.GetRecord(self);
		}

		/** 
			override this function if the data from the server isnt going to match the data type needed to edit with.  
			an overridden version can be used to transform the data from the server as needed before returning it to the controller. 
		*/
		public GetRecordData(url: string, args: any, controllerBoType: Cmp.Ui.Interfaces.IConstructor): cmp.IPromise<TEditModelType> {
			return this.DataService.GetData<TEditModelType>(url, args, controllerBoType);
		}
		/** 
			override this function if the data from the server isnt going to match the data type needed to edit with.  
			an overridden version can be used to transform the data to and from the server as needed before returning it to the controller. 
		*/
		public SaveRecordData(url: string, model: TEditModelType, controllerBoType: Cmp.Ui.Interfaces.IConstructor): cmp.IPromise<TEditModelType> {
			return this.DataService.SendModel<TEditModelType>(url, model, controllerBoType);
		}

		private GetStateService(): angular.ui.IStateService {
			return this.BaseTools.GetInstance<angular.ui.IStateService>('$state');
		}

		/** save the modified record to the server after client side validation */
		public SaveRecord = (): cmp.IPromise<TEditModelType> => {
			var self = this;

			return self.BeforeSave().then(() => {
				//create return promise
				return self.BaseTools.CmpPromise.Promise<TEditModelType>((resolveSave, rejectSave) => {
					//validate info to save
					self.IsValid(self.MainForm).then(function (isValid) {
						//check validation result
						if (isValid) {
							//grab the id now since the save might change it
							var originalId = self.Model.id;

							//send off model data to save
							self.SaveRecordData(Cmp.Js.Strings.Format('{0}/Save', self.TableName), self.Model, self.GetConstructor()).then(
								(saveResult) => {
									//update model with server return val(assumes the server is returning a copy of the model
									self.Model = saveResult;
									//check serverside validation results
									if (self.Model.ValidationResults.IsValid) {

										//resolve the promise with the final saved result
										//prepare a redirect for successful save if it was a new record, then go to the new route
										var sendOff = (endVal: TEditModelType) => {
											self.Logger.Success(self.$translate.instant('Core$YourDataWasSaved'));
											self.GetStateService().go("app." + self.RouteName +".edit", { id: saveResult.id }).then(() => {
												resolveSave(endVal);
											}, rejectSave);
										};

										// run any refresh code on the model before it is sent to UpdateFindList
										self.AfterRefresh(self.Model).then((model) => {

											var indexFound = -1;
											for (var i = 0; i < self.FindPageScope.FindList.Data.length; i++) {
												var findItem: TListModelType = self.FindPageScope.FindList.Data[i];
												if (findItem.id == originalId) {
													indexFound = i;
													break;
												}
											}
											
											//use custom find list update handling
											var findListResult = self.FindPageScope.FindOptions.UpdateFindList(self.Model, indexFound);
											//verify is promise
											if (findListResult && findListResult.then) {
												findListResult.then(sendOff, sendOff);
											} else {
												sendOff(self.Model);
											}

										})
										.catch((reason) => {
											rejectSave(reason);
										});

									} else {
										self.AfterRefresh(self.Model);
										rejectSave();
									}
								}, rejectSave);
						} else {
							rejectSave();
						}
					}, rejectSave);
				});
			}, function (err) {
				self.Logger.Error(err);
			});
		}

		/** Override if the model needs default values after creation */
		public SetNewRecordDefaults = (model: TEditModelType) => { }

		/** Override this to run some code before saving the record */
		public BeforeSave = (): cmp.IPromise<any> => {
			return this.BaseTools.CmpPromise.Resolve(null);
		}

		/** Override if a special url is needed that doesnt fit the table based crud pattern */
		public GetByIdUrl(thisController: BaseDeController<TEditModelType, TListModelType>): string{
			return Cmp.Js.Strings.Format('{0}/GetById', thisController.TableName);
		}

		/** Override if a special args are needed for the getbyid call that dont fit the table based crud pattern */
		public GetByIdArgs(thisController: BaseDeController<TEditModelType, TListModelType>, id: any): any {
			return {
				id: id,
				collectionsToLoad: thisController.CollectionsToLoad,
				loadAllCollections: thisController.LoadAllCollections
			};
		}
		/** called by the de data service when getrecord is done */
		public GetRecordDone(model: TEditModelType): cmp.IPromise<TEditModelType> {
			return this.AfterRefresh(model);
		}

		/** 
		Called after resolution of GetRecord and SaveRecord 
		Override this in descendant classes in order run any code on the model after is created new, 
		retrieved from the server for edit, or saved to the server.
		*/
		protected AfterRefresh(model: TEditModelType): cmp.IPromise<TEditModelType> {
			var self = this;
			return self.BaseTools.CmpPromise.Resolve(model);
		}
	}
}
