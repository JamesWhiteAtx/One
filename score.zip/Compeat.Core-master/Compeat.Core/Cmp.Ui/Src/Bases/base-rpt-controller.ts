﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="base-validatable-controller.ts" />

namespace Cmp.Ui.Bases {

    export class BaseRptController extends Cmp.Ui.Bases.BaseValidatableController {

       
    }
} 