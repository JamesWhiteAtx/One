﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="base-model.ts" />
/// <reference path="validation-result.ts" />
/// <reference path="../features/rules.ts" />
/// <reference path="../services/base-tools.ts" />
/// <reference path="../interfaces/jsonable.ts" />
/// <reference path="base-bo-model.ts" />
/// <reference path="../interfaces/constructor.ts" />

namespace Cmp.Ui.Bases {

	export interface IBaseGenBoModel extends Cmp.Ui.Bases.IBaseBoModel {
		/** should return all field members that will get serizalized, used by the generator only */
		FieldMembers: string[];
		
		/** should return all date field members that will get serizalized, used by the generator only */
		DateFieldMembers: string[];

		/** should return all collection field members that will get serizalized, used by the generator only */
		CollectionMembers: string[];

		/** takes a raw object and copies like named values from it into this instance */
		LoadFromRaw(fromUrl: string, rawObj: any): void;

		/** runs before filled from the raw object, override to do custom filling */
		BeforeLoadFromRaw: (fromUrl: string, rawObj: any) => void;
		
		/** runs after filled from the raw object, override to do custom filling */
		AfterLoadFromRaw: (fromUrl: string, rawObj: any) => void;

		/** Creates a new instance clone of this object */
		Clone<TResultType extends IBaseGenBoModel>(destinationBoType: Cmp.Ui.Interfaces.IConstructor): TResultType;
	}

	export class BaseGenBoModel extends BaseBoModel implements IBaseGenBoModel {

		/** should return all field members that will get serizalized, used by the generator only */
		public get FieldMembers(): Array<string> {
			return new Array<string>();
		}

		/** should return all date field members that will get serizalized, used by the generator only */
		public get DateFieldMembers(): Array<string> {
			return new Array<string>();
		}

		/** should return all collection field members that will get serizalized, used by the generator only */
		public get CollectionMembers(): Array<string> {
			return new Array<string>();
		}

		/** if defined, it runs before filled from the raw object, override to do custom filling */
		public BeforeLoadFromRaw: (fromUrl: string, rawObj: any) => void;
		
		/** if defined, it runs after filled from the raw object, override to do custom filling */
		public AfterLoadFromRaw: (fromUrl: string, rawObj: any) => void;
		
		/** takes a raw object and copies like named values from it into this instance */
		public LoadFromRaw(fromUrl: string, rawObj: any): void{
			var self = this;
            var fields = self.FieldMembers;
            var dates = self.DateFieldMembers;
			if (self.BeforeLoadFromRaw) {
				self.BeforeLoadFromRaw(fromUrl, rawObj);
			}
            if (rawObj.ValidationResults) {
                self.ValidationResults = rawObj.ValidationResults;
            }
			for (var i = 0; i < fields.length; i++) {
                Cmp.Js.MapPropertyIfUndef(rawObj, self, fields[i]);
            }
			// convert all fields that are supposed to be dates 
			for (var i = 0; i < dates.length; i++) {
				var dateFieldName = dates[i];
				if (!Cmp.Js.IsNullOrUndefined(self[dateFieldName])) {
					self[dateFieldName] = moment(self[dateFieldName]).toDate();
				}
            }
			if (self.LoadChildrenFromRaw) {
				self.LoadChildrenFromRaw(fromUrl, rawObj);
			}
			if (self.AfterLoadFromRaw) {
				self.AfterLoadFromRaw(fromUrl, rawObj);
			}
		}		

		/** used to process child collections during load. the generator will fill it in */
		public LoadChildrenFromRaw: (fromUrl: string, rawObj: any) => void;
        
		/** serializes the model to a json object */
		public ToJson(): Object{
			var self = this;
			return Cmp.Js.Jsonify(self, self.FieldMembers.concat(self.ExtraSerializedMemebers).concat(self.CollectionMembers));

		}
		/**
		 * This function returns a new instance of the type passed in after filling it with date from the current object instance. 
		 * @param destinationBoType The constructor of the bo that should be returned
		 */
		public Clone<TResultType extends IBaseGenBoModel>(destinationBoType: Cmp.Ui.Interfaces.IConstructor): TResultType {
			var self = this;
			var retVal = self.GetBaseTools().CreateInstance<TResultType>(destinationBoType);//create new instance of BO
			retVal.LoadFromRaw('Clone', self); //copy data from the raw instance into the new instance
			return retVal;//return the new instance
		}


		public LoadProperty(propertyName: string, propertyValue: any): void {
			this[((propertyName == "CmpNew") ? "" : "_") + propertyName] = propertyValue;
		}
	}

}
