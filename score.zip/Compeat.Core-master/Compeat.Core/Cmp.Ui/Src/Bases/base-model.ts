﻿/// <reference path="../services/base-tools.ts" />

namespace Cmp.Ui.Bases {

	export class BaseModel {
		public ExtraSerializedMemebers: string[] = [];

		public GetBaseTools: () => Cmp.Ui.Services.IBaseTools;

		constructor(BaseTools: Cmp.Ui.Services.IBaseTools) {
			this.GetBaseTools = () => {
				return BaseTools;
			}
		}

		/** Adds adds fields that should be serialized in addition to code generated values */
		public AddToSerializer = (propertyName: string): void => {
			if (this.ExtraSerializedMemebers.indexOf(propertyName) < 0) {
				this.ExtraSerializedMemebers.push(propertyName);
			}
		}
	}
}