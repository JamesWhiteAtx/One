﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="base-controller.ts" />
/// <reference path="../features/rules.ts" />
/// <reference path="../services/base-tools.ts" />
/// <reference path="base-gen-bo-model.ts" />
/// <reference path="../interfaces/constructor.ts" />
/// <reference path="base-modal-controller.ts" />

namespace Cmp.Ui.Bases {

	/** args needed for a modal */
	export interface IValidatableModalArgs<TModelType extends Cmp.Ui.Bases.IBaseGenBoModel, TAdditionalArguments> {
		Model: TModelType;
		BoType: Function;
		AdditionalArguments: TAdditionalArguments;

	}

	export interface IValidatableModalController extends Cmp.Ui.Interfaces.IConstructor {
		AssignToModalSettings(modalSettings?: angular.ui.bootstrap.IModalSettings): angular.ui.bootstrap.IModalSettings;
	}

	export interface IValidatableModalModelType extends Cmp.Ui.Interfaces.IConstructor { }

    export class BaseValidatableModalController<TModelType extends IBaseGenBoModel, TAdditionalArguments> extends Cmp.Ui.Bases.CmpModalTemplateController implements Cmp.Ui.Rules.IHaveRules {

		/** Defined in templates */
		public MainForm: angular.IFormController;
		public Model: TModelType;

        [index: string]: any;

        public BrokenRules: Cmp.Js.Types.IStringMap<Cmp.Ui.Rules.BrokenRuleResultCollection>;
        public RuledChildProperties: Array<string>;

        constructor(baseTools: Cmp.Ui.Services.IBaseTools,
			$modalInstance: angular.ui.bootstrap.IModalServiceInstance,
			private modalArguments: IValidatableModalArgs<TModelType, TAdditionalArguments>) {
            super(baseTools, $modalInstance);
			var self = this;
			self.ConfirmIcon = false;
			self.InfoIcon = false;
            self.RuledChildProperties = new Array<string>();
            self.BrokenRules = {};
			self.RuledChildProperties.push('Model');

			//clone the model into this controller so the original isnt edited until ok is pressed
			self.Model = modalArguments.Model.Clone<TModelType>(modalArguments.BoType);

        }
        
        /** can be overridden to provide rules */
        public GetRules = (): cmp.IPromise<Array<Cmp.Ui.Rules.CmpRule>> => {
            return this.BaseTools.CmpPromise.Resolve(null);
        }
        
        /** adds an error to the general broken rule bucket */
        public AddGeneralError(message: string, severity?: Cmp.Ui.Rules.BrokenRuleSeverities, propertyName?: string): void {
            Cmp.Ui.Rules.AddGeneralError(this, message, severity, propertyName);
        }

        /** clears the general broken rule bucket */
        public ClearGeneralErrors(propertyName?: string): void {
            Cmp.Ui.Rules.ClearGeneralErrors(this, propertyName);
        }

        /** clears all broken rule buckets */
        public ClearAllRuleResults(): void {
            Cmp.Ui.Rules.ClearAllRuleResults(this);
        }
		/**
		returns a promise that says if this controller and its children are valid
		@form {angular.IFormController} should represent the form that can be used to hook to the angular validation subsystem
		*/
        public IsValid(form?: angular.IFormController): cmp.IPromise<boolean> {
            return Cmp.Ui.Rules.RunRules(this, form, this.BaseTools.CmpPromise);
        }

		/** runs the controller's validation which will run the model's validation as well */
		protected AllowOkToClose = (): cmp.IPromise<boolean> => {
			var self = this;
			return self.BaseTools.CmpPromise.Promise<boolean>((resolve, reject) => {
				self.IsValid(self.MainForm).then((isValid) => {
					if (isValid) {
						resolve(true);
					} else {
						resolve(false);
					}
				}, () => {
					resolve(false);
				});
			});
		}

		/** 
		* overriding the base function so it can be changed to trigger validation and return the model 
		*/
		protected OkResult = (): any => {
			var self = this;
			//copy the clone back into the original
			self.modalArguments.Model.LoadFromRaw('Clone', self.Model);
			return true;
		}

		/** 
		* return the original model 
		*/
		protected CancelResult = (): any => {
			return false;
		}

    }
} 