﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="base-model.ts" />
/// <reference path="validation-result.ts" />
/// <reference path="../features/rules.ts" />
/// <reference path="../services/base-tools.ts" />
/// <reference path="../interfaces/jsonable.ts" />

namespace Cmp.Ui.Bases {

	export interface IBaseBoModel extends Cmp.Ui.Rules.IHaveRules, Cmp.Ui.Interfaces.IJsonable {
			CmpDel: boolean;
			CmpNew: boolean;
			[index: string]: any;

			BrokenRules: Cmp.Js.Types.IStringMap<Cmp.Ui.Rules.BrokenRuleResultCollection>;
			RuledChildProperties: Array<string>;
			ValidationResults: ValidationResult;
				
			/** can be overridden to provide rules */
			GetRules: () => cmp.IPromise<Array<Cmp.Ui.Rules.CmpRule>>;
				
			/** adds an error to the general broken rule bucket */
			AddGeneralError(message: string, severity?: Cmp.Ui.Rules.BrokenRuleSeverities, propertyName?: string): void;
				
			/** clears the general broken rule bucket */
			ClearGeneralErrors(propertyName?: string): void;
				
			/** clears all broken rule buckets */
			ClearAllRuleResults(): void;
			/**
			returns a promise that says if this model is valid
			*/
			IsValid(): cmp.IPromise<boolean>;

			/** serializes the model to a json object */
			ToJson(): Object;

			OnPropertyChanged(propertyName: string): void;
	}


	export class BaseBoModel extends BaseModel implements IBaseBoModel {

		private _CmpDel: boolean;
		public get CmpDel(): boolean {
			return this._CmpDel;
		}
		public set CmpDel(value: boolean) {
			this.CheckSetNotify("CmpDel", value);
		}

		public CmpNew: boolean;


		[index: string]: any;

		public BrokenRules: Cmp.Js.Types.IStringMap<Cmp.Ui.Rules.BrokenRuleResultCollection>;
		public RuledChildProperties: Array<string>;
		public ValidationResults: ValidationResult;

		constructor(baseTools: Cmp.Ui.Services.IBaseTools) {
			super(baseTools);
			var self = this;

			self.RuledChildProperties = new Array<string>();
		}
				
		/** can be overridden to provide rules */
		public GetRules = (): cmp.IPromise<Array<Cmp.Ui.Rules.CmpRule>> => {
			return this.GetBaseTools().CmpPromise.Resolve(null);
		}
				
		/** adds an error to the general broken rule bucket */
		public AddGeneralError(message: string, severity?: Cmp.Ui.Rules.BrokenRuleSeverities, propertyName?: string): void {
			Cmp.Ui.Rules.AddGeneralError(this, message, severity, propertyName);
		}
				
		/** clears the general broken rule bucket */
		public ClearGeneralErrors(propertyName?: string): void {
			Cmp.Ui.Rules.ClearGeneralErrors(this, propertyName);
		}
				
		/** clears all broken rule buckets */
		public ClearAllRuleResults(): void {
			Cmp.Ui.Rules.ClearAllRuleResults(this);
		}
		/**
		returns a promise that says if this model is valid
		*/
		public IsValid(): cmp.IPromise<boolean> {
			return Cmp.Ui.Rules.RunRules(this, null, this.GetBaseTools().CmpPromise);
		}

		/** serializes the model to a json object */
		public ToJson(): Object {
			return null;
		}

		protected CheckSetNotify<T>(propertyName: string, newValue: T) {
			var self = this;
			var localPropName = "_" + propertyName;
			var oldValue = self[localPropName];
			var actuallyChanged = newValue != self[localPropName];
			if (newValue !== self[localPropName]) {
				self[localPropName] = newValue;
			}
			if (actuallyChanged) {
				self.OnPropertyChanged(propertyName, oldValue);
			}
		}

		public OnPropertyChanged(propertyName: string, oldValue?: any): void { }

		/**
			Override this method to specify when a detail record in a master/detail
			relationship should not be saved.  This is for when a new line is entered
			in a data grid but no data is entered for it.
			Return true if the record should not be saved to the database. */
		public ChildRecordShouldNotBeSaved(): boolean {
			return false;
		}

	}
}
