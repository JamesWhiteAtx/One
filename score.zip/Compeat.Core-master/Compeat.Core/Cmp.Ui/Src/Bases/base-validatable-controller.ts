﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="base-controller.ts" />
/// <reference path="../features/rules.ts" />
/// <reference path="../services/base-tools.ts" />

namespace Cmp.Ui.Bases {

	export class BaseValidatableController extends Cmp.Ui.Bases.BaseController implements Cmp.Ui.Rules.IHaveRules {

		[index: string]: any;

		public BrokenRules: Cmp.Js.Types.IStringMap<Cmp.Ui.Rules.BrokenRuleResultCollection>;
		public RuledChildProperties: Array<string>;

		constructor(baseTools: Cmp.Ui.Services.IBaseTools) {
			super(baseTools);
			this.RuledChildProperties = new Array<string>();
			this.BrokenRules = {};
		}
				
		/** can be overridden to provide rules */
		public GetRules = (): cmp.IPromise<Array<Cmp.Ui.Rules.CmpRule>> => {
			return this.BaseTools.CmpPromise.Resolve(null);
		}
				
		/** adds an error to the general broken rule bucket */
		public AddGeneralError(message: string, severity?: Cmp.Ui.Rules.BrokenRuleSeverities, propertyName?: string): void {
			Cmp.Ui.Rules.AddGeneralError(this, message, severity, propertyName);
		}

		/** clears the general broken rule bucket */
		public ClearGeneralErrors(propertyName?: string): void {
			Cmp.Ui.Rules.ClearGeneralErrors(this, propertyName);
		}

		/** clears all broken rule buckets */
		public ClearAllRuleResults(): void {
			Cmp.Ui.Rules.ClearAllRuleResults(this);
		}
		/**
		returns a promise that says if this controller and its children are valid
		@form {angular.IFormController} should represent the form that can be used to hook to the angular validation subsystem
		*/
		public IsValid(form?: angular.IFormController): cmp.IPromise<boolean> {
			return Cmp.Ui.Rules.RunRules(this, form, this.BaseTools.CmpPromise);
		}
	}
} 