﻿/// <reference path="../../common-refs.d.ts" />
/// <reference path="../components-module.ts" />
/// <reference path="../../Bases/base-session.ts" />

namespace Cmp.Ui.Components {

	export interface ICmpDynamicMenuContentScope extends angular.IScope {
		InternalMenuClickAction: (actionType: number, actionId: number) => void;
		InternalEntityClickAction: (storeNum: number) => void;
		InternalProcessSearch: (event: any) => void;
		ProcessSearch: () => void;
        ShowSearchBox: boolean | string;
        UserCheckedIn: boolean | string;

		UserMenu: Cmp.Ui.Bases.MenuNode[];
		ExternalApps: Cmp.Ui.Bases.ExternalApp[];
		UserLinks?: Cmp.Ui.Bases.UserLink[];
        MessageLinks?: Cmp.Ui.Bases.MessageLink;
		MenuClickAction: () => void;
		EntityClickAction: () => void;
	}

	export class CmpDynamicMenuContent implements ng.IDirective {

		private static USER_ENTITY_TEMPLATE: string = '<li class="dropdown">' +
		'<a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">{{\'Core$DynamicMenu_CurrentSelectionTc\' | translate:SelectedEntity}}</a>' +
		'<ul class="dropdown-menu scrollable-menu">' +
		'<li ng-repeat="entity in UserEntities">' +
		'<a class="hover-pointer" ng-click="InternalEntityClickAction(entity.StoreNum)">{{entity.StoreName}}</a>' +
		'</li></ul></li>';

		private static APPS_TEMPLATE: string = '<li class="dropdown">' +
		'<a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">{{\'Core$DynamicMenu_AppsTc\' | translate}}</a>' +
		'<ul class="dropdown-menu">' +
		'<li ng-repeat="app in ExternalApps">' +
		'<a href="{{app.Url}}">{{app.DisplayName}}</a>' +
		'</li></ul></li>';

		private static USER_LINKS_TEMPLATE: string = '<li ng-repeat="userLink in UserLinks">' +
		'<a class="hover-pointer" ng-click="InternalMenuClickAction(userLink.ActionType, userLink.ActionId)">{{userLink.DisplayName}}</a></li>';

		private static COLUMN_HEADER = '<ul class="~COLUMN_SIZE_PLACEHOLDER~ list-unstyled">'
		private static COLUMN_FOOTER = '</ul>';
		private static FULL_LI_BREAK = '<li class="cmp-hide-for-mobile">&nbsp;</li>';
		private static MOBILE_LI_BREAK = '<li class="cmp-show-for-mobile">&nbsp;</li>';

		/*@ngInject*/
		constructor(private $compile: angular.ICompileService, private $translate: angular.translate.ITranslateService) {
		}

		/*@ngInject*/
		static Instance($compile: angular.ICompileService, $translate: angular.translate.ITranslateService) {
			return new CmpDynamicMenuContent($compile, $translate);
		}

		scope = {
			'UserMenu': '=userMenu',
			'MenuClickAction': '&menuClickAction',
			'ProcessSearch': '&processSearch',
            'ShowSearchBox': '@showSearchBox',
            'UserCheckedIn': '=?userCheckedIn',
			'Refresh': '=refresh',
			'UserEntities': '=userEntities',
			'SelectedEntity': '=selectedEntity',
			'EntityClickAction': '&entityClickAction',
			'ExternalApps': '=externalApps',
		    'UserLinks': '=?userLinks',
		    'MessageLinks': '=?messageLinks'
		};

		link = (scope: ICmpDynamicMenuContentScope, element: angular.IAugmentedJQuery, attrs: angular.IAttributes) => {

			var self = this;
			self.$translate([
				'Core$DynamicMenu_CurrentSelectionTc',
				'Core$DynamicMenu_AppsTc'])
				.then(() => {
                    scope.UserCheckedIn = false;
					scope.InternalMenuClickAction = self.InternalMenuClickAction;
					scope.InternalEntityClickAction = self.InternalEntityClickAction;
					scope.InternalProcessSearch = self.InternalProcessSearch;
					scope.$watch('Refresh', (current, old): void => {
						element.html(self.GetTemplate(scope)).show();
						self.$compile(element.contents())(scope);
					});

				});
		};

		restrict: string = 'E';

		private GetTemplate = (scope: ICmpDynamicMenuContentScope): string => {

			var userMenu = scope.UserMenu;
			var externalApps = scope.ExternalApps;

			var template = '<div id="navbar-collapse" class="navbar-collapse collapse"><ul class="nav navbar-nav">';

			if (externalApps && externalApps.length > 0) {
				template += CmpDynamicMenuContent.APPS_TEMPLATE;
			}

			if (userMenu && userMenu.length > 0) {
				for (var l1Cnt = 0; l1Cnt < userMenu.length; l1Cnt++) {
					if (Cmp.Ui.Bases.MenuNode.IsMenuType(userMenu[l1Cnt])) {
						template += this.GetLevel1Menu(userMenu[l1Cnt]);
					}
					else {
						template += this.GetAction(userMenu[l1Cnt]);
					}
				}
			}

			template += CmpDynamicMenuContent.USER_ENTITY_TEMPLATE;

			template += '</ul>';

			template += this.GetSearchAndRightSideNavigation(scope) + '</div>';

			return template;
		};

		private GetAction = (node: Cmp.Ui.Bases.MenuNode): string => {
			return '<li><a class="hover-pointer" ng-click="' + 'InternalMenuClickAction' + '(' + node.NodeType + ',' + node.ActionId + ')"' + '>' + node.Description + '</a></li > ';
		};

		private GetSearchAndRightSideNavigation = (scope: ICmpDynamicMenuContentScope): string => {
			var strNavSearch = `<form class=\"form-search form-inline\">
																		<input id=\"searchInput\" type=\"text\" ng-keypress=\"InternalProcessSearch($event)\"  class=\"search-query input-sm searchbox\" placeholder=\"Search\" \/>
																<\/form>`;
            var strMessages = ``;
            if (scope.MessageLinks) {
                if (scope.MessageLinks.Display) {
                    strMessages = `<li  class=\"dropdown\">
                                    <a class=\"dropdown\" ng-click=\"InternalMenuClickAction(` + scope.MessageLinks.ActionType.toString() + `,` + scope.MessageLinks.ActionId.toString() + `)\">
                                        <i class=\"fa fa-envelope\"><\/i>`;

                    if (scope.MessageLinks.Count != "0") {
                        strMessages += `<span class=\"badge messages-badge\">` + scope.MessageLinks.Count + `</span>`;
                    }
                    strMessages += `<\/a></li>`;
                }
            }

			/*			var strNavRight = `<ul class=\"nav navbar-nav navbar-right\">
																			<li class=\"hidden-xs\">${strNavSearch}</li>
			
																			<li class=\"dropdown\">
																				<a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\"><i class=\"nav-badge fa fa-envelope fa-2x icon-grey\"></i><\/a>
																				<ul class=\"dropdown-menu\">
																					<li role=\"separator\" class=\"divider\"><\/li>
																					<li><a class=\"hover-pointer\" ng-click=\"InternalMenuClickAction(2, -101)\"><span class=\"badge\">0</span> Requests</a></li>
																				<\/ul>
																			<\/li>
			
																			<li class=\"dropdown\">
																				<a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\"><i class=\"glyphicon glyphicon-user\"></i> <span class=\"caret\"><\/span><\/a>
																				<ul class=\"dropdown-menu\">
																					<li role=\"separator\" class=\"divider\"><\/li>
																					<li><a class=\"hover-pointer\" ng-click=\"InternalMenuClickAction(2, -101)\">Logoff</a></li>
																				<\/ul>
																			<\/li>
			
																			<li class=\"dropdown\">
																				<a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\"><i class=\"glyphicon glyphicon-option-vertical\"></i><\/a>
																				<ul class=\"dropdown-menu\">
																					<li role=\"separator\" class=\"divider\"><\/li>
																					<li><a class=\"hover-pointer\" ng-click=\"InternalMenuClickAction(2, -101)\"><span class=\"glyphicon glyphicon-phone-alt\"/> Contact Us</a></li>
																				<\/ul>
																			<\/li>
			
																		 <\/ul>`; */

			var strNavRight = `<ul class=\"nav navbar-nav navbar-right\">
														<li class=\"hidden-xs\" ng-if=\"` + scope.ShowSearchBox + `\">${strNavSearch}</li>			
                                                        ${strMessages}													    
														<li class=\"dropdown\">
															<a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\"><i ng-class=\"{false:'fa fa-user', true:'fa fa-user-plus'}[` + scope.UserCheckedIn.toString() +  `]\"	></i> <span class=\"caret\"><\/span><\/a>
															<ul class=\"dropdown-menu\">
																<li role=\"separator\" class=\"divider\"><\/li>  
																	 ${CmpDynamicMenuContent.USER_LINKS_TEMPLATE} 																    
																	 <li><a class=\"hover-pointer\" ng-click=\"InternalMenuClickAction(2, -101)\">Logoff</a></li>                                                                
															<\/ul>
														<\/li>
													<\/ul>`;

			return strNavRight;
		};

		private GetLevel1Menu = (node: Cmp.Ui.Bases.MenuNode): string => {

			var isFirstSectionPrint = true;
			var currentColumnItemCount: number = 0;
			var columnInProgress: boolean = false;
			var columnCount: number = 0;
			var template = '';
			if (node.Children && node.Children.length > 0) {

				template += '<li class="dropdown">' +
					'<a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">' + node.Description + '</a>' +
					'<ul class="dropdown-menu">' +
					'<li><div class="yamm-content"><div class="row">';

				var menuLayoutInfo = this.GetMenu1LayoutInfo(node);

				var directChildren = node.Children.filter((currentItem, index, source) => {
					return !Cmp.Ui.Bases.MenuNode.IsMenuType(currentItem);
				});

				// build the immediate feature links - if any.  These always go in the first column
				if (directChildren && directChildren.length > 0) {

					for (var i = 0; i < directChildren.length; i++) {
						// we may need to begin a new column
						if (columnInProgress
							&& columnCount < menuLayoutInfo.MaxColumnCount
							&& currentColumnItemCount >= menuLayoutInfo.DesiredItemsPerColumn) {

							template += CmpDynamicMenuContent.COLUMN_FOOTER;
							columnInProgress = false;
						}

						if (!columnInProgress) {
							// big primary categories may wrap
							template += CmpDynamicMenuContent.COLUMN_HEADER + this.GetMenuSectionHeader(node, columnCount > 0, isFirstSectionPrint);
							currentColumnItemCount = 1; // 1 for the header print
							columnCount++;
							columnInProgress = true;
							isFirstSectionPrint = false;
						}

						template += this.GetAction(directChildren[i]);
						currentColumnItemCount++;
					}

				}

				// build content for one level of submenus
				for (var i = 0; i < node.Children.length; i++) {

					var currentSubMenu = node.Children[i];

					if (Cmp.Ui.Bases.MenuNode.IsMenuType(currentSubMenu)
						&& currentSubMenu.Children) {

						// we only want non-menu children here
						var childActionItems = currentSubMenu.Children.filter((currentItem, index, source) => {
							return !Cmp.Ui.Bases.MenuNode.IsMenuType(currentItem);
						});

						if (childActionItems && childActionItems.length > 0) {

							var firstSubMenuSectionHeaderWasPrinted = false;

							for (var j = 0; j < childActionItems.length; j++) {
								// we may need to begin a new column
								if (columnInProgress
									&& columnCount < menuLayoutInfo.MaxColumnCount
									&& currentColumnItemCount >= menuLayoutInfo.DesiredItemsPerColumn) {

									template += CmpDynamicMenuContent.COLUMN_FOOTER;
									columnInProgress = false;
								}

								if (!columnInProgress) {
									template += CmpDynamicMenuContent.COLUMN_HEADER + this.GetMenuSectionHeader(currentSubMenu, firstSubMenuSectionHeaderWasPrinted, isFirstSectionPrint);
									firstSubMenuSectionHeaderWasPrinted = true;
									currentColumnItemCount = 1; // 1 for the header print
									columnCount++;
									columnInProgress = true;
									isFirstSectionPrint = false;
								}

								// add a section header if it did not already appear as part of a brand new column
								if (!firstSubMenuSectionHeaderWasPrinted) {
									// we need an LI page break here, it is following another menu category in the same column
									template += CmpDynamicMenuContent.FULL_LI_BREAK + this.GetMenuSectionHeader(currentSubMenu, false, isFirstSectionPrint);
									currentColumnItemCount++;
									firstSubMenuSectionHeaderWasPrinted = true;
									isFirstSectionPrint = false;
								}

								template += this.GetAction(childActionItems[j]);
								currentColumnItemCount++;
							}
						} // eind if childActionItems
					} // end if subMenuChildren[i].Children
				} // end for subMenuChildren.length

				// terminate the remaining open column
				if (columnInProgress) {
					template += CmpDynamicMenuContent.COLUMN_FOOTER;
				}

				// terminate the drop down menu tags
				template += '</div></div></li></ul></li>';
			}

			// replace the column placeholder with a css class based on # of columns rendered
			var cssClass = 'col-sm-12';
			if (columnCount <= 1) {
				cssClass = 'col-sm-12';
			}
			else if (columnCount === 2) {
				cssClass = 'col-sm-6';
			}
			else if (columnCount === 3) {
				cssClass = 'col-sm-4';
			}
			else {
				cssClass = 'col-sm-3';
			}

			return template.replace(/~COLUMN_SIZE_PLACEHOLDER~/g, cssClass);
		};
				
		// get the total number of rendered items we'll we'll encounter
		private GetMenu1LayoutInfo = (node: Cmp.Ui.Bases.MenuNode): Menu1LayoutInfo => {

			var headerCounted = false;
			var childItems = 0;

			if (node.Children) {

				for (var i = 0; i < node.Children.length; i++) {
					var isMenuNode = Cmp.Ui.Bases.MenuNode.IsMenuType(node.Children[i]);

					// count the first loose item header
					if (!headerCounted && !isMenuNode) {
						childItems++;
						headerCounted = true;
					}

					childItems++; // the item will either be a header or a feature, count 1

					if (isMenuNode && node.Children[i].Children) {
						// count only non-menus at level 2
						for (var j = 0; j < node.Children[i].Children.length; j++) {
							if (!Cmp.Ui.Bases.MenuNode.IsMenuType(node.Children[i].Children[j])) {
								childItems++;
							}
						}
					}
				} // end for each node child
			}

			var result = new Menu1LayoutInfo();

			if (childItems <= 10) {
				result.MaxColumnCount = 1;
				result.DesiredItemsPerColumn = 99;
			}
			else if (childItems <= 30) {
				result.MaxColumnCount = 2;
				result.DesiredItemsPerColumn = (childItems / result.MaxColumnCount) + 1;
			}
			else if (childItems <= 50) {
				result.MaxColumnCount = 3;
				result.DesiredItemsPerColumn = (childItems / result.MaxColumnCount) + 1;
			}
			else {
				result.MaxColumnCount = 4;
				result.DesiredItemsPerColumn = (childItems / result.MaxColumnCount) + 1;
			}

			return result;

		};

		private GetMenuSectionHeader = (node: Cmp.Ui.Bases.MenuNode, isFragment: boolean, isFirstSectionPrint: boolean): string => {
			return (!isFirstSectionPrint && !isFragment ? CmpDynamicMenuContent.MOBILE_LI_BREAK : '') +
				'<li' +
				(isFragment ? ' class="cmp-hide-for-mobile"' : '') +
				'><p><strong>' + node.Description + '</strong></p></li>';
		};

		public InternalMenuClickAction(actionType: number, actionId: number) {
			// 'this' is scope here
			var ctrlScope = <ICmpDynamicMenuContentScope>(<any>this);
			var clickAction = <Function>(<any>ctrlScope.MenuClickAction);
			if (clickAction) {
				clickAction({
					'actionType': actionType,
					'actionId': actionId
				});
			}
		};

		public InternalProcessSearch(keyEvent: any) {
			if (keyEvent.which === 13) {
				var ctrlScope = <ICmpDynamicMenuContentScope>(<any>this);
				if (ctrlScope.ProcessSearch) {
					ctrlScope.ProcessSearch();
				}

			}
		};

		public InternalEntityClickAction(storeNum: number) {
			// 'this' is scope here
			var ctrlScope = <ICmpDynamicMenuContentScope>(<any>this);
			var clickAction = <Function>(<any>ctrlScope.EntityClickAction);
			if (clickAction) {
				clickAction({
					'storeNum': storeNum
				});
			}
		};

	}

	class Menu1LayoutInfo {
		DesiredItemsPerColumn: number = 10;
		MaxColumnCount: number = 4;
	}

	angular
		.module('cmp.ui.components')
		.directive('cmpDynamicMenuContent', CmpDynamicMenuContent.Instance);

} 