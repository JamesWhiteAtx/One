﻿/// <reference path="../../common-refs.d.ts" />
/// <reference path="../components-module.ts" />
/// <reference path="../../services/promise.ts" />
/// <reference path="../../app/cmp-app-info.ts" />

namespace Cmp.Ui.Components {

	export interface ICmpDatepicker extends angular.IScope {
		/**the model object, from the controller*/
		Model: any;
		/**the property on the model that is bound*/
		Property: string;
		/**the angular form name in the template*/
		Form: angular.IFormController;
		NameId: string;
		Placeholder: string;
		/**For time use the format "hh:mm A", http://momentjs.com/docs/#/displaying/format/*/
		Format: string;
		/**binding to disable the field*/
		IsDisabled: boolean;
		NgRequired: string;
		/**model to bind to the datepicker's input*/
		InnerModel?: any;
		/** set to true if you need the date time picker to show the date and the time side by side.  */
		SideBySide?: boolean;

	}

	export class CmpDatepicker implements ng.IDirective {
		constructor(private _$timeout: angular.ITimeoutService, private _$translate: angular.translate.ITranslateService, private _cmpPromise: Cmp.Ui.Services.PromiseService) { }

		/*@ngInject*/
		static Instance($timeout: angular.ITimeoutService, $translate: angular.translate.ITranslateService, cmpPromise: Cmp.Ui.Services.PromiseService) {
			return new CmpDatepicker($timeout, $translate, cmpPromise);
		}

		scope = <any>{
			'Model': '=cgModel',
			'Property': '@cgProperty',
			'Form': '=cgForm',
			'NameId': '@?cgNameId',
			'Placeholder': '@?cgPlaceholder',
			'Format': '@?cgFormat',
			'IsDisabled': '=cgIsDisabled',
			'NgRequired': '=cgRequired',
			'SideBySide': '=cgSideBySide'
		};

		/** returns the div around the input and its icon, exposed public for mockability */
		_getDateGroup = (element: angular.IAugmentedJQuery): JQuery => {
			return $(element.find('div.input-group.date'));
		};

		/** returns the datepicker object, exposed public for mockability */
		_getDatePicker = (dateGroup: JQuery): BootstrapV3DatetimePicker.Datetimepicker => {
			return dateGroup.data("DateTimePicker");
		};

		/** returns the datepicker object's date, as a javascript date, exposed public for mockability */
		_getDatePickerDate = (dateGroup: JQuery, modelDate?: Date, preserveDate?: boolean, preserveTime?: boolean): Date => {
			var self = this;
			var datePicker: BootstrapV3DatetimePicker.Datetimepicker;
			var datePickerMoment: moment.Moment;
			var datePickerDate: Date;

			/** get the date picker instance */
			datePicker = self._getDatePicker(dateGroup);
			if (datePicker) {
				/** get the moment of the date picker */
				datePickerMoment = datePicker.date();
				if (datePickerMoment) {
					/** get the js date from the moment */
					datePickerDate = datePickerMoment.toDate();
				}
			}

			/** preserve either the date or time on the model */
			if (preserveDate || preserveTime) {
				/** on if both picker and model are dates */
				if (angular.isDate(datePickerDate) && angular.isDate(modelDate)) {
					if (preserveDate) {
						/** assign date part from model date */
						datePickerDate.setFullYear(
							modelDate.getFullYear(),
							modelDate.getMonth(),
							modelDate.getDate());
					}
					if (preserveTime) {
						/** assign time part from model date */
						datePickerDate.setHours(
							modelDate.getHours(),
							modelDate.getMinutes(),
							modelDate.getSeconds(),
							modelDate.getMilliseconds());
					}
				}
			}

			return datePickerDate;
		};

		/** update the inner model with the current vlue of the outer model */
		_updateInnerModel = (outerModel: any, scopeAsPickerParams: ICmpDatepicker, usedFormat: string ) => {
			var formatted: string;
			
			if (outerModel) { 
				/** get the formatted string of the date model */
				formatted = moment(outerModel).format(usedFormat);
			}
			
			/** assign the formatted string to the inner model, which is bound to the datepicker, this updates the datepicker display */
			if ((scopeAsPickerParams.InnerModel !== formatted) &&
				!(Cmp.Js.IsNullOrUndefined(scopeAsPickerParams.InnerModel) && Cmp.Js.IsNullOrUndefined(formatted))) {
				scopeAsPickerParams.InnerModel = formatted;
			}
		}

		/** the link function content, exposed public for testability */
		_linkAsPromise = (scope: ICmpDatepicker, element: angular.IAugmentedJQuery, attrs: angular.IAttributes) => {
			var self = this;
			/**Setting to preserve model date, use if only using time format*/
			var preserveDate: boolean;
			/**Setting to preserve model time, use if only using date format*/
			var preserveTime: boolean;

			preserveTime = !Cmp.Js.IsUndefined(attrs['cgPreserveTime']); // is the cg-preserve-time attribute present, with any or no value assigned?
			preserveDate = !Cmp.Js.IsUndefined(attrs['cgPreserveDate']); // is the cg-preserve-date attribute present, with any or no value assigned?

			scope.Placeholder = scope.Placeholder && scope.Placeholder.length ? scope.Placeholder : '';

			var passedFormat = scope.Format;

			return self._cmpPromise.Promise(function (resolve, reject) {
				self._$translate(["Core$Datepicker_today",
					"Core$Datepicker_clear",
					"Core$Datepicker_close",
					"Core$Datepicker_selectMonth",
					"Core$Datepicker_prevMonth",
					"Core$Datepicker_nextMonth",
					"Core$Datepicker_selectYear",
					"Core$Datepicker_prevYear",
					"Core$Datepicker_nextYear",
					"Core$Datepicker_selectDecade",
					"Core$Datepicker_prevDecade",
					"Core$Datepicker_nextDecade",
					"Core$Datepicker_prevCentury",
					"Core$Datepicker_nextCentury",
					"Core$MomentFullDateString"]).then((translation: any): void => {

						/** format string that will be used by the date picker, and to convert date model to a string*/
						var usedFormat = passedFormat && passedFormat.length ? passedFormat : translation.Core$MomentFullDateString; //this format determines if the timepicker is shown

						//http://eonasdan.github.io/bootstrap-datetimepicker/Options
						var datePickerBaseOptions: BootstrapV3DatetimePicker.DatetimepickerOptions = {
							format: usedFormat,
							showTodayButton: true,
							useStrict: true,
							keepOpen: false,
							keepInvalid: false,
							icons: {
								time: "fa fa-clock-o",
								date: "fa fa-calendar",
								up: "fa fa-arrow-up",
								down: "fa fa-arrow-down",
								previous: 'fa fa-chevron-left',
								next: 'fa fa-chevron-right',
								today: 'fa fa-crosshairs',
								clear: 'fa fa-trash'
							},
							sideBySide: Cmp.Js.Boolify(scope.SideBySide),
							tooltips: {
								today: translation.Core$Datepicker_today,
								clear: translation.Core$Datepicker_clear,
								close: translation.Core$Datepicker_close,
								selectMonth: translation.Core$Datepicker_selectMonth,
								prevMonth: translation.Core$Datepicker_prevMonth,
								nextMonth: translation.Core$Datepicker_nextMonth,
								selectYear: translation.Core$Datepicker_selectYear,
								prevYear: translation.Core$Datepicker_prevYear,
								nextYear: translation.Core$Datepicker_nextYear,
								selectDecade: translation.Core$Datepicker_selectDecade,
								prevDecade: translation.Core$Datepicker_prevDecade,
								nextDecade: translation.Core$Datepicker_nextDecade,
								prevCentury: translation.Core$Datepicker_prevCentury,
								nextCentury: translation.Core$Datepicker_nextCentury
							}
						};

						var ngModelCtrl: angular.INgModelController = scope.Form ? (<angular.IFormController>scope.Form)[scope.NameId] : null;
						if (ngModelCtrl) {
							var inputGroup: JQuery = self._getDateGroup(element);
							resolve(true);
							self._$timeout((): void => {
								
								/** create the date time picker widget */
								inputGroup.datetimepicker(datePickerBaseOptions);
								
								/** listen for changes from the date time picker widget */
								inputGroup.on('dp.change', function () {
									self._$timeout((): void => {
										/** when the datepicker emits a change event, get the date value and assign it to the Model Property */
										if (scope.Model && scope.Property) {
											/** get the date from the date time picker widget, adjusted with any preserved model data */
											var pickerDate = self._getDatePickerDate(inputGroup,
												scope.Model[scope.Property],
												preserveDate, preserveTime);
											/** update the bound model */
											scope.Model[scope.Property] = pickerDate;
										}
									});
								});

								scope.$watch('Model.' + scope.Property, (current, old): void => {
									if (current === old) {
										return;
									}
								
									/** the outer model has changed, update the inner model */
									self._updateInnerModel(current, scope, usedFormat);

								}, true);

								/** update the inner model with the initial value, if the outer model is resolved */
								if (scope.Model && scope.Property) {
									self._updateInnerModel(scope.Model[scope.Property], scope, usedFormat);
								}

								resolve(true);
							});
						} else {
							resolve(true);
						}
					}, function () {
						reject();
					});
			});
		};

		link = (scope: ICmpDatepicker, element: angular.IAugmentedJQuery, attrs: angular.IAttributes) => {
			this._linkAsPromise(scope, element, attrs);
		};

		templateUrl: string = 'cmp-ui/Component/CmpDatepicker/cmp-datepicker.html';
		restrict: string = 'E';
	}

	angular
		.module('cmp.ui.components')
		.directive('cmpDatepicker', CmpDatepicker.Instance);
} 
