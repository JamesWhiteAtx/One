﻿/// <reference path="../../common-refs.d.ts" />
/// <reference path="../components-module.ts" />
/// <reference path="../../services/promise.ts" />
/// <reference path="../../app/cmp-app-info.ts" />
/// <reference path="../../services/modal-find-dialog-service.ts" />
/// <reference path="../../services/logger.ts" />

namespace Cmp.Ui.Components {

    export enum CmpLookupColumnType {
        String,
        Date,
        DateTime,
        Number,
        Currency,
        Boolean
    }

    export interface ICmpLookupColumn {
        /** the variable type of the value in this column */
        ColumnType: CmpLookupColumnType;

        /** the config options for the column */
        FindFieldConfig: Cmp.Ui.Bases.IFindFieldConfig;
    }

    export interface ICmpLookupOptions<T> {
        /** 
            When the user selects and item it will show the items they selected in textbox next to the lookup
            this is the name of the property to display in the text box.
        */
        DisplayPropertyName: string;

        /** the items to display in the lookup */
        SourceListCollection: T[]| cmp.IPromise<T[]> | { (): T[] } | { (): cmp.IPromise<T[]> };

        /** the title above the lookup */
        GridTitle: string;

        /** The Column specs for the lookup grid */
        ColumnOptions: Array<ICmpLookupColumn>;
    
    }


    export interface ICmpLookupScope extends angular.IScope {
		/**the model object, from the controller*/
		Model: any;
		/**
            the property on the model that is bound, the consumer's version of this should be of the type of the options in the lookup list
        */
		Property: string;
		/**the angular form name in the template*/
		Form: angular.IFormController;
		NameId: string;
		/**binding to disable the field*/
		IsDisabled: boolean;
        NgRequired: string;
        /** options to setup the lookup */
        LookupOptions: ICmpLookupOptions<any>;

		/**model to bind to the datepicker's input*/
        InnerString?: string;

        /** displays the lookup window for this instance of the directive */
        ShowLookup: () => void;
        /** clears the lookup field */
        ClearLookup: () => void;
	}

    export class CmpLookup implements ng.IDirective {
        constructor(private _$timeout: angular.ITimeoutService,
            private _$translate: angular.translate.ITranslateService,
            private _cmpPromise: Cmp.Ui.Services.PromiseService,
            private _modalFindDlg: Cmp.Ui.Services.ICmpModalFindDialogService,
            private _logger: Cmp.Ui.Services.ILoggerService) { }

		/*@ngInject*/
        static Instance($timeout: angular.ITimeoutService,
            $translate: angular.translate.ITranslateService,
            cmpPromise: Cmp.Ui.Services.PromiseService,
            modalFindDlg: Cmp.Ui.Services.ICmpModalFindDialogService,
            logger: Cmp.Ui.Services.ILoggerService) {
            return new CmpLookup($timeout, $translate, cmpPromise, modalFindDlg, logger);
		}

        scope:any = <any>{
			'Model': '=cgModel',
			'Property': '@cgProperty',
			'Form': '=cgForm',
			'NameId': '@?cgNameId',
			'IsDisabled': '=cgIsDisabled',
            'NgRequired': '=cgRequired',
            'LookupOptions': '=cgLookupOptions'
		};

        _updateInnerString(outerModel: any, scope: ICmpLookupScope) {
            if (scope.LookupOptions) {
				var displayName = scope.LookupOptions.DisplayPropertyName;
                if (displayName && displayName.length && outerModel && outerModel[displayName]) {
                    scope.InnerString = outerModel[displayName];
                } else {
                    scope.InnerString = '';
                }
            }
		}

        _createLookup = (scope: ICmpLookupScope) => {
            var self = this;
            if (scope.LookupOptions) {
                var fluid = self._modalFindDlg.Modal()
                    .Size('lg')
                    .Title(scope.LookupOptions.GridTitle);
                scope.LookupOptions.ColumnOptions.forEach((col) => {
                    switch (col.ColumnType) {
                        case CmpLookupColumnType.Date:
                            fluid.DateField(col.FindFieldConfig);
                            break;
                        case CmpLookupColumnType.DateTime:
                            fluid.DateTimeField(col.FindFieldConfig);
                            break;
                        case CmpLookupColumnType.Number:
                            fluid.NumberField(col.FindFieldConfig);
                            break;
                        case CmpLookupColumnType.Currency:
                            fluid.CurrencyField(col.FindFieldConfig);
                            break;
                        case CmpLookupColumnType.Boolean:
                            fluid.BooleanField(col.FindFieldConfig);
                            break;
                        default:
                            fluid.StringField(col.FindFieldConfig);
                            break;
                    }
                });
                fluid.Show(scope.LookupOptions.SourceListCollection).then((chosenValue) => {
                    scope.Model[scope.Property] = chosenValue;
                    self._updateInnerString(chosenValue, scope);
                }, (reason: any) => {
                    scope.ClearLookup();
                });
            } else {
                self._logger.Error('Lookup options have not been set.');
            }
        }

        link = (scope: ICmpLookupScope, element: angular.IAugmentedJQuery, attrs: angular.IAttributes) => {
            var self = this;
            scope.ClearLookup = () => {
                scope.Model[scope.Property] = null;
            };
            scope.ShowLookup = () => {
                self._createLookup(scope);
            };
            self._$timeout(function () {
                scope.$watch('Model.' + scope.Property, (current, old): void => {
					//exit only if the innerstring is not set
                    if (current === old && scope.InnerString && scope.InnerString.length) {
                        return;
                    }
                    /** the outer model has changed, update the inner model */
                    self._updateInnerString(current, scope);

                }, true);
            });
		};

        templateUrl: string = 'cmp-ui/Component/CmpLookup/cmp-lookup.html';
		restrict: string = 'E';
	}

	angular
		.module('cmp.ui.components')
        .directive('cmpLookup', CmpLookup.Instance);
} 
