﻿/// <reference path="../../common-refs.d.ts" />
/// <reference path="../components-module.ts" />

namespace Cmp.Ui.Components {

	interface ICmpGroupParams extends angular.IScope {
		Header: string;
		NumColumns: string;
	}

	interface ICmpGroup extends ICmpGroupParams {
		/**the bootstrap CSS to use*/
		BsCss: string;
	}

	class CmpGroup implements ng.IDirective {

		constructor() { }
		
		/*@ngInject*/
		static Instance(): ng.IDirective {
			return new CmpGroup();
		}

		scope: any = {
			'Header': '@cgHeader',
			'NumColumns': '@cgNumColumns'
		};

		link = (scope: ICmpGroup, element: angular.IAugmentedJQuery, attrs: angular.IAttributes, ctrl: any) => {
			var self = this;

			if (!scope.NumColumns) {
				scope.NumColumns = "2";
			}

			switch (scope.NumColumns) {
				case "0":
					scope.BsCss = "";
					return;
				case "1":
					scope.BsCss = "col-xs-12 col-lg-6";
					return;
				case "2":
					scope.BsCss = "col-xs-12 col-sm-6";
					return;
				case "3":
					scope.BsCss = "col-xs-4";
					return;
			}
		}

		templateUrl: string = 'cmp-ui/Component/CmpGroup/cmp-group.html';
		restrict: string = 'E';
		transclude: boolean = true;
	}

	angular
		.module('cmp.ui.components')
		.directive('cmpGroup', CmpGroup.Instance);
}
