﻿/// <reference path="../../common-refs.d.ts" />
/// <reference path="../components-module.ts" />
/// <reference path="../../Bases/base-bo-model.ts" />
/// <reference path="../cmpdebuttons/cmp-de-buttons.ts" />
/// <reference path="../../bases/base-bo-controller.ts" />

namespace Cmp.Ui.Components {

	export interface ICmpErrors extends angular.IScope {

		/** true if the server messages should be displayed */
		ShowServerMessages: () => boolean;

		/** true if the model messages should be displayed */
		ShowModelMessages: () => boolean;

		/** true if the controller messages should be displayed */
		ShowControllerMessages: () => boolean;

		/** The model with possible errors */
		Model: Cmp.Ui.Bases.BaseBoModel;

		/** the controller with possible errors */
		Controller: Cmp.Ui.Bases.BaseBoController<Cmp.Ui.Bases.BaseBoModel>;
	}

	class CmpErrors implements ng.IDirective {
		constructor() { }

		/*@ngInject*/
		static Instance(): ng.IDirective {
			return new CmpErrors();
		}

		scope = <any>{
			'Model': '=?cgModel',
			'Controller': '=?cgController'
		};

		link = (scope: ICmpErrors, element: angular.IAugmentedJQuery, attrs: angular.IAttributes, ctrl: any) => {
			var self = this;
			var boolify = Cmp.Js.Boolify;
			scope.ShowServerMessages = (): boolean => {
				var model = scope.Model;
				return boolify(model && model.ValidationResults && model.ValidationResults.Errors && (model.ValidationResults.Errors.length > 0));
			};
			scope.ShowModelMessages = (): boolean => {
				var model = scope.Model;
				return boolify(model &&
					model.BrokenRules &&
					model.BrokenRules["GENERAL"] &&
					model.BrokenRules["GENERAL"].Content &&
					model.BrokenRules["GENERAL"].Content.length && 
					boolify(Cmp.Js.Arrays.First(model.BrokenRules["GENERAL"].Content, (item) => {
						return item.IsError;
					})));
			};
			scope.ShowControllerMessages = (): boolean => {
				var controller = scope.Controller;
				return boolify(controller && controller.BrokenRules &&
					controller.BrokenRules["GENERAL"] &&
					controller.BrokenRules["GENERAL"].Content &&
					controller.BrokenRules["GENERAL"].Content.length &&
					boolify(Cmp.Js.Arrays.First(controller.BrokenRules["GENERAL"].Content,
						(item) => {
							return item.IsError;
						})));
			};
		};

		templateUrl: string = 'cmp-ui/Component/CmpErrors/cmp-errors.html';
		restrict: string = 'E';
	}

	angular
		.module('cmp.ui.components')
		.directive('cmpErrors', CmpErrors.Instance);
}
