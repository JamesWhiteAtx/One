﻿/// <reference path="../../common-refs.d.ts" />
/// <reference path="../../Services/data-service.ts" />
/// <reference path="../components-module.ts" />
/// <reference path="../../services/modal-service.ts" />
/// <reference path="../cmpgrid/cmp-grid-settings.ts" />

namespace Cmp.Ui.Components {
    var propTypeEnum = Cmp.Js.Enums.CmpGridPropertyType;//for minify

	export interface ICmpFindPageOptions<TEditModelType extends Cmp.Js.Types.ICmpIdable, TListModelType extends Cmp.Js.Types.ICmpIdable> {
		/** Delete the record with the given primary key. */
		DeleteRecord: (idToDelete: string | number) => cmp.IPromise<any>;
		/** 
				Pass this in if the find list uses a custom query and you need to manually update it after saves.
				This function is required, the system will not try to smash the edit type into the find list

				@findListIndex - is the index that the item with the same id has as found in FindList.Data
		*/
		UpdateFindList: (objectAfterBeingUpdated: TEditModelType, findListIndex?: number) => cmp.IPromise<TEditModelType>;

		/** The columns to show in the find grid */
		FindCols: Cmp.Ui.Components.ICmpGridOptions;

		/** This is here so that it can be passed up from the DE page, if needed, for find list updates after saves */
		HideAddBtn?: boolean;

		/** 1 = Find Only, 2 = Edit Only, 3 = Find & Edit */
		PageMode?: Cmp.Js.Enums.PageModes;

		/** Used for the Json API calls and url changes */
		RouteName: string;

		/** desktop view only: If this is true and empty grid will not be displayed if there is no find data */
		HideEmptyResults?: boolean;

		/** desktop view only: This is a message that will be shown if HideEmptyResults is true and there is currently no data bound to the grid  */
		EmptyresultsMessage?: string;

		/** the place holder in the search text box */
		SearchBoxLabel?: string;
	}

	export interface ICmpFindPage<TEditModelType extends Cmp.Js.Types.ICmpIdable, TListModelType extends Cmp.Js.Types.ICmpIdable> extends ng.IScope {
		/** This is used to keep the edit page in split-screen mode when switching records */
		AllowCssReset: boolean;
		/** Used to show/hide the find section */
		FindClass: string;
		/** Used to show/hide the edit section */
		EditClass: string;
		/** This is used to only setup the find grid once */
		FindGridLoaded: boolean;
		SearchFilter: string;

		DeleteConfirm: (item: Cmp.Js.Types.ICmpIdable) => cmp.IPromise<Cmp.Js.Types.ICmpIdable>;
		/** The columns to show in the find list for mobile */
		MobileCols: Array<Cmp.Ui.Components.ICmpGridColumn>;

		/** The title of the page, used in an <h1> */
		Title: string;
		/** The list of records displayed in the find grid */
		FindList: Cmp.Ui.Models.CmpDataSet<TListModelType>;

		/** options for this find instance, done so that required options are seen at compile time rather than run time */
		FindOptions: ICmpFindPageOptions<TEditModelType, TListModelType>;

		/** The template uses this function to format output for the mobile data listing since mobile doesnt use the kendo grid */
		FormatMobileColumn: (column: Cmp.Ui.Components.ICmpGridColumn, value: any) => string;
	}

	class CmpFindPage<TEditModelType extends Cmp.Js.Types.ICmpIdable, TListModelType extends Cmp.Js.Types.ICmpIdable> implements ng.IDirective {
		constructor(
			private _$translate: angular.translate.ITranslateService,
			private _$state: angular.ui.IStateService,
			private _baseTools: Cmp.Ui.Services.IBaseTools,
			private _cmpModalService: Cmp.Ui.Services.ICmpModalService,
			private _cmpPromise: Cmp.Ui.Services.PromiseService,
			private _$location: angular.ILocationService,
			private _$sce: angular.ISCEService
		) { }
		
		/*@ngInject*/
		static Instance(
			$translate: angular.translate.ITranslateService,
			$state: angular.ui.IStateService,
			baseTools: Cmp.Ui.Services.IBaseTools,
			cmpModalService: Cmp.Ui.Services.ICmpModalService,
			paginationService: any,
			cmpPromise: Cmp.Ui.Services.PromiseService,
			$location: angular.ILocationService,
			$sce: angular.ISCEService
		): ng.IDirective {
			return new CmpFindPage($translate, $state, baseTools, cmpModalService, cmpPromise, $location, $sce);
		}

		scope = <any>{
			'Title': '@cgTitle',
			'FindList': '=cgFindList',
			'FindOptions': '=cgFindOptions',
		};

		link = (scope: ICmpFindPage<TEditModelType, TListModelType>, element: angular.IAugmentedJQuery, attrs: angular.IAttributes, ctrl: any) => {
			var directive = this;
			var nullOrUndef = Cmp.Js.IsNullOrUndefined;//for minify
			var stringFuncs = Cmp.Js.Strings;//for minify
			var colOptions = scope.FindOptions.FindCols;
			scope.FindOptions.SearchBoxLabel = scope.FindOptions.SearchBoxLabel && scope.FindOptions.SearchBoxLabel.length ? scope.FindOptions.SearchBoxLabel : 'Core$Search';

			scope.AllowCssReset = true;
			scope.FindOptions.PageMode = Cmp.Js.Enums.PageModes.FindOnly;
			scope.FindGridLoaded = false;
			scope.MobileCols = new Array<Cmp.Ui.Components.ICmpGridColumn>();
			colOptions.Columns.forEach((col) => {
				if ((col.ColumnIsVisible || nullOrUndef(col.ColumnIsVisible)) && !col.HiddenOnLoad && !col.HideInMobileFindControl) {
					scope.MobileCols.push(col);
				}
			});

			scope.FormatMobileColumn = (column: Cmp.Ui.Components.ICmpGridColumn, value: any): string => {
				var propTypeEnum = Cmp.Js.Enums.CmpGridPropertyType;//for minify
				var propType = column.PropertyType;
				var retVal: string = '';
				if (!nullOrUndef(value)) {
					switch (propType) {
						case propTypeEnum.DateTime:
							retVal = moment(value).format(directive._$translate.instant("Core$MomentFullDateTimeString"));
							break;
						case propTypeEnum.DurationSeconds:
							retVal = stringFuncs.FormatSecondsAsHourMinute(value);
							break;
						case propTypeEnum.Number2Decimal:
							retVal = kendo.toString(parseFloat(value.toString()), 'n');
							break;
						case propTypeEnum.Currency:
							retVal = kendo.toString(parseFloat(value.toString()), 'c');
							break;
						case propTypeEnum.Boolean:
							retVal = Cmp.Js.Boolify(value) ? '<input type=checkbox checked disabled />' : '<input type=checkbox disabled />';
							break;
						default:
							retVal = value.toString();
							break;
					}
				}
				return directive._$sce.trustAsHtml(retVal);
			};
			
			scope.$watch("SearchFilter", function (newValue: string, oldValue: string) {
				if (newValue == oldValue) {
					return;
				}
				var search = newValue && newValue.length ? newValue.toLowerCase().trim() : "";
				if (search.length) {
					scope.FindList.Data.forEach((item: any): void => {
						item._NotFound = true;
						item._NotFoundMobile = true;
						for (var colIndex = 0; colIndex < colOptions.Columns.length; colIndex++) {
							var col = colOptions.Columns[colIndex];
							var colValue = item[col.PropertyName];
							if (!col.DisableSearching && !nullOrUndef(colValue) && colValue.toString().toLowerCase().indexOf(search) >= 0) {
								item._NotFound = undefined;
								if (!col.HideInMobileFindControl) {
									item._NotFoundMobile = undefined;
								}
								break;
							}
						}
					});
				} else {
					scope.FindList.Data.forEach((item: any): void => {
						item._NotFoundMobile = undefined;
						item._NotFound = undefined;
					});
				}
			});

			scope.DeleteConfirm = (item: Cmp.Js.Types.ICmpIdable): cmp.IPromise<Cmp.Js.Types.ICmpIdable> => {
				var deleteInformation: string = "<ul>";
				var dateFormatString: string = directive._$translate.instant("Core$MomentFullDateTimeString");
				var noString: string = directive._$translate.instant("Core$No");
				var yesString: string = directive._$translate.instant("Core$Yes");
				for (var colIndex = 0; colIndex < colOptions.Columns.length; colIndex++) {
					var col = colOptions.Columns[colIndex];
					var colValue = item[col.PropertyName];
					var strVal:string = '';

					switch (col.PropertyType) {
						case propTypeEnum.DateTime:
							strVal = (!Cmp.Js.IsNullOrUndefined(colValue) ? moment(colValue).format(directive._$translate.instant("Core$MomentFullDateTimeString")) : '');
							break;
						case propTypeEnum.DurationSeconds:
							strVal = (!Cmp.Js.IsNullOrUndefined(colValue) ? Cmp.Js.Strings.FormatSecondsAsHourMinute(colValue) : '');
							break;
						case propTypeEnum.Number2Decimal:
							strVal = (!Cmp.Js.IsNullOrUndefined(colValue) ? kendo.toString(parseFloat(colValue), 'n') : '');
							break;
						case propTypeEnum.Currency:
							strVal = (!Cmp.Js.IsNullOrUndefined(colValue) ? kendo.toString(parseFloat(colValue), 'c') : '');
							break;
						case propTypeEnum.Boolean:
							strVal = (Cmp.Js.Boolify(colValue) ? yesString : noString);
							break;
						default:
							strVal = colValue;
							break;
					}

					deleteInformation += '<li><strong>' + col.ColumnHeaderText + ':</strong> ' + (!nullOrUndef(strVal) ? strVal.toString() : "") + '</li>';
				}
				deleteInformation += "</ul>";
				var prompt = directive._$translate.instant("Core$ConfirmDeleteBelowInformation") + deleteInformation;

				return directive._cmpPromise.Promise<Cmp.Js.Types.ICmpIdable>((resolve, reject) => {
					directive._cmpModalService.Confirm(prompt).Result.then((confirmResult: any) => {
						if (confirmResult) {
							scope.FindOptions.DeleteRecord(item.id).then(() => {
								resolve(item);
							}, reject);
						} else {
							reject();
						}
					}, reject);
				});
			};

			scope.$watch("FindOptions.PageMode", function (newValue, oldValue) {
				directive.SetupPageMode(scope);
			});

			colOptions.EnableSingleSelection = true;
			colOptions.RowWasSelected = (selectedRow: any) => {//slight hack on type for the find directive integration with the grid
				var actualType: Cmp.Js.Types.ICmpIdable = selectedRow;
				scope.AllowCssReset = false; // allow the page to stay in split-screen mode, if applicable

				directive._$location.path(stringFuncs.Format("/{0}/", scope.FindOptions.RouteName) + actualType.id);
				directive._baseTools.RefreshObservers();
				//self._$state.go("app." + scope.FindOptions.RouteName, { id: actualType.id });
				//self._baseTools.RefreshObservers();
			};
			colOptions.EnableDeleting = true;
			colOptions.AllowDelete = <any>scope.DeleteConfirm;
			colOptions.DeleteRow = (deletedRow: any) => { };//do nothing since it was already done in the delete confirm
			colOptions.UseDeepWatch = true;

		}

		templateUrl: string = 'cmp-ui/Component/CmpFindPage/cmp-find-page.html';
		restrict: string = 'E';
		transclude: boolean = true;

		/** Use this to configure the CSS for the 3 page modes */
		SetupPageMode(scope: ICmpFindPage<TEditModelType, TListModelType>): void {
			var self = this;

			switch (scope.FindOptions.PageMode) {
				case Cmp.Js.Enums.PageModes.FindOnly:
					scope.FindClass = "col-xs-12 col-md-12";
					break;
				case Cmp.Js.Enums.PageModes.EditOnly:
					scope.EditClass = "col-xs-12 col-md-12 mobile-no-padding";
					break;
				case Cmp.Js.Enums.PageModes.FindAndEdit:
					scope.FindClass = "col-xs-12 col-md-6";
					scope.EditClass = "col-xs-12 col-md-6";
					break;
			}
		}

	} // class CmpFindPage implements ng.IDirective {

	angular
		.module('cmp.ui.components')
		.directive('cmpFindPage', CmpFindPage.Instance);
}
