﻿/// <reference path="../../common-refs.d.ts" />
/// <reference path="../components-module.ts" />

namespace Cmp.Ui.Components {

    export interface ICmpCheckbox {
		//checkbox basics https://docs.angularjs.org/api/ng/input/input%5Bcheckbox%5D

		Model: string;//the model object, from the controller
		Property: string;//the property on the model that is bound
		NameId: string;
		Label: string;
		IsDisabled: boolean|string;//binding to disable the field
		NgChange: string;// see checkbox basics
		CssClass: string;
	}

    export class CmpCheckbox implements ng.IDirective {
		constructor() { }

		/*@ngInject*/
        static Instance() {
			return new CmpCheckbox();
		}

		scope: ICmpCheckbox = {
			'Model': '=cgModel',
			'Property': '@cgProperty',
			'NameId': '@?cgNameId',
			'Label': '@?cgLabel',
			'IsDisabled': '=cgIsDisabled',
			'NgChange': '&cgChange',
			'CssClass': '@?cgCssClass'
		};
		templateUrl: string = 'cmp-ui/Component/CmpCheckbox/cmp-checkbox.html';
		restrict: string = 'E';
	}

	angular
		.module('cmp.ui.components')
		.directive('cmpCheckbox', CmpCheckbox.Instance);

} 