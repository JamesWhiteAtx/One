﻿/// <reference path="../../common-refs.d.ts" />
/// <reference path="../components-module.ts" />
/// <reference path="../../features/rules.ts" />

namespace Cmp.Ui.Components {

	
	/**
		param layout for text box and friends
	*/
	export class CmpTextboxParams {
		//attributes
		//text box basics https://docs.angularjs.org/api/ng/input/input%5Btext%5D
		//number text box basics https://docs.angularjs.org/api/ng/input/input%5Bnumber%5D

		Model: string|angular.INgModelController;//the model object, from the controller
		Property: string;//the property on the model that is bound
		Form: string|angular.IFormController;//the angular form name in the template
		NameId: string;//the html control name, needed for angular validation ties with the form
		Placeholder: string;
		IsDisabled: boolean|string; //binding to disable the field
		Type: string; //the html input type
		NgChange: string; //see text box basics
		Min: string; //see number text box basics
		Max: string; //see number text box basics
		NgRequired: string;  //see text box basics
		NgMinlength: string;  //see text box basics
		NgMaxlength: string;  //see text box basics
		NgPattern: string;  //see text box basics
		PatternErrorMessage: string;//an error message if the pattern is wrong
		CssClass: string; // any custom CSS that the caller wants to pass in
	}

	/**
		param defaults needed for descendants of the text box
	*/
	export var TextboxScopeDefaults: CmpTextboxParams = {
		'Model': '=cgModel',
		'Property': '@cgProperty',
		'Form': '=cgForm',
		'NameId': '@cgNameId',
		'Placeholder': '@?cgPlaceholder',
		'IsDisabled': '=cgIsDisabled',
		'Type': '@?cgType',
		'NgChange': '&?cgChange',
		'Min': '@?cgMin',
		'Max': '@?cgMax',
		'NgRequired': '=cgRequired',
		'NgMinlength': '@?cgMinlength',
		'NgMaxlength': '@?cgMaxlength',
		'NgPattern': '=cgPattern',
		'PatternErrorMessage': '@?cgPatternErrorMessage',
		'CssClass': '@cgCssClass'
	};
	
	/**
		textbox template, can be used by other directives that derive from the text box
	*/
	export var TextboxTemplateUrl = 'cmp-ui/Component/CmpTextbox/cmp-textbox.html';

	export class TextBoxValidationTranslationArgs {
		NgMinlength: string;
		NgMaxlength: string;

	}
	export class TextBoxScope extends CmpTextboxParams {
		CustomNgMessages: Array<Cmp.Ui.Rules.CustomValidationMessage>;
	}

	export class CmpTextbox implements ng.IDirective {
		constructor(private _$translate: angular.translate.ITranslateService, private _cmpPromise: Cmp.Ui.Services.PromiseService) { }
		
		/*@ngInject*/
		static Instance($translate: angular.translate.ITranslateService, cmpPromise: Cmp.Ui.Services.PromiseService) {
			return new CmpTextbox($translate, cmpPromise);
		}

		scope: CmpTextboxParams = Cmp.Ui.Components.TextboxScopeDefaults;

		/** the link function content, exposed public for testability */
		_linkAsPromise = (scope: TextBoxScope | angular.IScope, element: angular.IAugmentedJQuery, attrs: angular.IAttributes) => {
			var self = this;
			var scopeAsTextbox: TextBoxScope = <TextBoxScope>scope;

			if (!scopeAsTextbox.Type || !scopeAsTextbox.Type.length) {
				scopeAsTextbox.Type = 'text';
			}

			return self._cmpPromise.Promise(function (resolve, reject) {
				//copy validation args into an object to pass to translation
				var trans = new TextBoxValidationTranslationArgs();
				trans.NgMinlength = scopeAsTextbox.NgMinlength;
				trans.NgMaxlength = scopeAsTextbox.NgMaxlength;

				self._$translate(["Core$MinLengthShort",
					"Core$MaxLengthExceeded"], trans).then((translation: any): void => {
						scopeAsTextbox.CustomNgMessages = new Array<Cmp.Ui.Rules.CustomValidationMessage>();

						if (!Cmp.Js.IsNullOrUndefined(scopeAsTextbox.NgMinlength)) {
							scopeAsTextbox.CustomNgMessages.push({ MessageType: Cmp.Ui.Rules.NgMessageTypes.MinLength, Message: translation.Core$MinLengthShort });
						}
						if (!Cmp.Js.IsNullOrUndefined(scopeAsTextbox.NgMaxlength)) {
							scopeAsTextbox.CustomNgMessages.push({ MessageType: Cmp.Ui.Rules.NgMessageTypes.MaxLength, Message: translation.Core$MaxLengthExceeded });
						}
						resolve();
					});
			});
		};

		link = (scope: TextBoxScope | angular.IScope, element: angular.IAugmentedJQuery, attrs: angular.IAttributes) => {
			this._linkAsPromise(scope, element, attrs);
		};
		templateUrl: string = Cmp.Ui.Components.TextboxTemplateUrl;
		restrict: string = 'E';
	}

	angular
		.module('cmp.ui.components')
		.directive('cmpTextbox', CmpTextbox.Instance);

} 