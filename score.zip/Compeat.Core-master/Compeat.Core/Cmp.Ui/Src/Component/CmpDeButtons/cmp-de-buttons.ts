﻿/// <reference path="../../common-refs.d.ts" />
/// <reference path="../../Bases/base-bo-model.ts" />
/// <reference path="../../Services/data-service.ts" />
/// <reference path="../components-module.ts" />
/// <reference path="../CmpFindPage/cmp-find-page.ts" />

namespace Cmp.Ui.Components {


    export interface ICmpDeButtons<TEditModelType extends Cmp.Js.Types.ICmpIdable, TListModelType extends Cmp.Js.Types.ICmpIdable> extends ng.IScope {
		/** The parent Find page */
        ParentController: ICmpFindPage<TEditModelType, TListModelType>;
		/** Hides the edit section */
		CloseEditPage: Function;
		/** Shows only the edit section */
		FullEditPage: Function;
		/** Shows both the find and the edit section */
		HalfEditPage: Function;
		/** Delete the current record */
        DeleteRecord: () => cmp.IPromise<any>;
		/** Flip the boolean variable that shows or hides a section of HTML in the parent page */
		ToggleHeaderVisibility: Function;
		/** Show or hide a section of HTML in the parent page */
		ShowHideHeader: Function;
		/** The CSS to use to control the font-awesome image on the Show/Hide Header button */
		ShowHideHeaderBtnFaCss: string;
		/** The tool tip text to show on the Show/Hide Header button */
        ShowHeaderBtnToolTip: string;

        /** Used for the Json API calls and url changes */
        RouteName: string;
        /** The record being edited */
        Model: any;
        /** Optional, custom save method to run in place of the normal save */
        SaveRecord: () => cmp.IPromise<TEditModelType>;
        /** Pass this in to show the button that shows/hides a section of HTML */
        ShowHeaderBtn: boolean | string;
        /** This gets passed up to the parent page to show/hide a section of HTML */
        ShowHeader: boolean | string;
        HideAddBtn: boolean | string;
        HideSaveBtn: boolean | string;
        HideDeleteBtn: boolean | string;
	}

    class CmpDeButtons<TEditModelType extends Cmp.Js.Types.ICmpIdable, TListModelType extends Cmp.Js.Types.ICmpIdable> implements ng.IDirective {

		constructor(
			private _$timeout: angular.ITimeoutService,
			private _$stateParams: ng.ui.IStateParamsService,
			private _$translate: angular.translate.ITranslateService,
            private _$state: angular.ui.IStateService
			) { }
		
		/*@ngInject*/
		static Instance(
			$timeout: angular.ITimeoutService,
			$stateParams: ng.ui.IStateParamsService,
			$translate: angular.translate.ITranslateService,
            $state: angular.ui.IStateService
		): ng.IDirective {
            return new CmpDeButtons($timeout, $stateParams, $translate, $state);
		}

		scope = <any>{
			'RouteName': '@cgRouteName',
			'Model': '=cgModel',
			'SaveRecord': '=cgSaveRecord',
			'ShowHeaderBtn': '@?cgShowHeaderBtn',
			'ShowHeader': '=cgShowHeader',
			'HideAddBtn': '@cgHideAddBtn',
			'HideSaveBtn': '@cgHideSaveBtn',
			'HideDeleteBtn': '@cgHideDeleteBtn'
		};

        link = (scope: ICmpDeButtons<TEditModelType, TListModelType>, element: angular.IAugmentedJQuery, attrs: angular.IAttributes, ctrl: any) => {
			var self = this;

            scope.ParentController = <ICmpFindPage<TEditModelType, TListModelType>>(scope.$parent.$parent);
			scope.ParentController.AllowCssReset = true;
			scope.ShowHeader = true;
			scope.ShowHideHeaderBtnFaCss = "fa fa-angle-double-up";

			if (!scope.ShowHeaderBtn) {
				scope.ShowHeaderBtn = false;
			}

			var id = self._$stateParams["id"];

			if (id === "-1") {
				scope.ParentController.FindOptions.PageMode = Cmp.Js.Enums.PageModes.EditOnly;
			} else {
				if (scope.ParentController.FindOptions.PageMode !== Cmp.Js.Enums.PageModes.FindAndEdit) {
                    scope.ParentController.FindOptions.PageMode = Cmp.Js.Enums.PageModes.EditOnly;
				}
			}

            scope.CloseEditPage = (): void => {
                self._$state.go("app." + scope.RouteName);
			}

			scope.FullEditPage = (): void => {
                scope.ParentController.FindOptions.PageMode = Cmp.Js.Enums.PageModes.EditOnly;
			}

			scope.HalfEditPage = (): void => {
                scope.ParentController.FindOptions.PageMode = Cmp.Js.Enums.PageModes.FindAndEdit;
			}

            scope.DeleteRecord = (): cmp.IPromise<Cmp.Js.Types.ICmpIdable> => {
                return scope.ParentController.DeleteConfirm(scope.Model);
			}

			scope.ToggleHeaderVisibility = (): void => {
				var self = this;

				scope.ShowHeader = !(<boolean>scope.ShowHeader);
				scope.ShowHideHeader();
			}

			scope.ShowHideHeader = (): void => {
				var self = this;

				if (<boolean>scope.ShowHeader) {
					scope.ShowHideHeaderBtnFaCss = "fa fa-angle-double-up";
					scope.ShowHeaderBtnToolTip = self._$translate.instant('Core$HideHeaderControls');
				} else {
					scope.ShowHideHeaderBtnFaCss = "fa fa-angle-double-down";
					scope.ShowHeaderBtnToolTip = self._$translate.instant('Core$ShowHeaderControls');
				}
			}

            scope.$on("$destroy", function handleDestroyEvent() {
				// if AllowCssReset is false, then they are in split-screen mode and they want to stay in that mode
				if (scope.ParentController.AllowCssReset) {
                    scope.ParentController.FindOptions.PageMode = Cmp.Js.Enums.PageModes.FindOnly;
				}
			});

			scope.ShowHideHeader();
		}

		templateUrl: string = 'cmp-ui/Component/CmpDeButtons/cmp-de-buttons.html';
		restrict: string = 'E';

	} // class CmpDeButtons implements ng.IDirective {

	angular
		.module('cmp.ui.components')
		.directive('cmpDeButtons', CmpDeButtons.Instance);
}
