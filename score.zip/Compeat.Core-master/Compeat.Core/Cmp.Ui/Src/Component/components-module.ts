﻿/// <reference path="../common-refs.d.ts" />

namespace Cmp.Ui.Components {
	angular.module('cmp.ui.components', ['pascalprecht.translate']);
}