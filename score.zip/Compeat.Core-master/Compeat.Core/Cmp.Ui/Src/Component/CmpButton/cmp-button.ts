﻿/// <reference path="../../common-refs.d.ts" />
/// <reference path="../components-module.ts" />

namespace Cmp.Ui.Components {

	export interface ICmpButtonParams {
		CgClass: string;
		CgFontAwesome: string;
		CgToolTip: string;
		CgClick: string;
		/**binding to disable the field*/
		IsDisabled: boolean | string;
	}

	export interface ICmpButton extends ICmpButtonParams {
		CgPlacement: string;
	}

	class CmpButton implements ng.IDirective {
		constructor(private _$compile: angular.ICompileService) { }

		/*@ngInject*/
		static Instance($compile: angular.ICompileService): ng.IDirective {
			return new CmpButton($compile);
		}

		scope: ICmpButtonParams = {
			'CgClass': '@cgClass',
			'CgFontAwesome': '@cgFontAwesome',
			'CgToolTip': '@cgToolTip',
			'CgClick': '&cgClick',
			'IsDisabled': '=cgIsDisabled'
		};

		link = (scope: ICmpButton | angular.IScope, element: angular.IAugmentedJQuery, attrs: angular.IAttributes, ctrl: any, transclude: any) => {
			var self = this;
			var scopeAsButton: ICmpButton = <ICmpButton>scope;
			var scopeAsNgScope: angular.IScope = <angular.IScope>scope;

			if (!scopeAsButton.CgClass) {
				scopeAsButton.CgClass = "btn btn-default";
			}

			scopeAsButton.CgPlacement = "bottom";
		};

		templateUrl: string = 'cmp-ui/Component/CmpButton/cmp-button.html';
		restrict: string = 'E';
		transclude: boolean = true;
	}

	angular
		.module('cmp.ui.components')
		.directive('cmpButton', CmpButton.Instance);
}
