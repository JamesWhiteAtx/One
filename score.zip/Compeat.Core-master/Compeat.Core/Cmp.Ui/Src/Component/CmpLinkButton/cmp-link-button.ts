﻿/// <reference path="../../common-refs.d.ts" />
/// <reference path="../components-module.ts" />

namespace Cmp.Ui.Components {

	export interface ICmpLinkButton {
		CgSref: string;
		CgHref: string;
		CgClass: string;
		CgFontAwesome: string;
		CgToolTip: string;
	}

	class CmpLinkButton implements ng.IDirective {
		constructor(private _$compile: angular.ICompileService) { }

		/*@ngInject*/
		static Instance($compile: angular.ICompileService): ng.IDirective {
			return new CmpLinkButton($compile);
		}

		scope: ICmpLinkButton = {
			'CgSref': '@cgSref',
			'CgHref': '@cgHref',
			'CgClass': '@cgClass',
			'CgFontAwesome': '@cgFontAwesome',
			'CgToolTip': '@cgToolTip'
		};

		link = (scope: ICmpLinkButton | angular.IScope, element: angular.IAugmentedJQuery, attrs: angular.IAttributes, ctrl: any, transclude: any) => {
			var self = this;
			var scopeAsButton: ICmpLinkButton = <ICmpLinkButton>scope;
			var scopeAsNgScope: angular.IScope = <angular.IScope>scope;

			if (!scopeAsButton.CgClass) {
				scopeAsButton.CgClass = "btn btn-default";
			}

			if (scopeAsButton.CgToolTip) {
				scopeAsNgScope["dataPlacement"] = "bottom";
				scopeAsNgScope["dataToggle"] = "tooltip";
			}
		};

		templateUrl: string = 'cmp-ui/Component/CmpLinkButton/cmp-link-button.html';
		restrict: string = 'E';
		transclude: boolean = true;
	}

	angular
		.module('cmp.ui.components')
		.directive('cmpLinkButton', CmpLinkButton.Instance);
}
