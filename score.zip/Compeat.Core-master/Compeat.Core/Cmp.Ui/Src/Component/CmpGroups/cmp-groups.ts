﻿/// <reference path="../../common-refs.d.ts" />
/// <reference path="../components-module.ts" />

namespace Cmp.Ui.Components {

	class CmpGroups implements ng.IDirective {
		constructor() { }
		
		/*@ngInject*/
		static Instance(): ng.IDirective {
			return new CmpGroups();
		}

		templateUrl: string = 'cmp-ui/Component/CmpGroups/cmp-groups.html';
		restrict: string = 'E';
		transclude: boolean = true;
	}

	angular
		.module('cmp.ui.components')
		.directive('cmpGroups', CmpGroups.Instance);
}
