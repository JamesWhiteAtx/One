﻿/// <reference path="../../common-refs.d.ts" />
/// <reference path="../components-module.ts" />

namespace Cmp.Ui.Components {

	export interface ICmpModalButtonParams {
		CgClass: string;
		CgFontAwesome: string;
		CgTarget: string;
		/**binding to disable the field*/
		IsDisabled: boolean | string;
	}

	export interface ICmpModalButton extends ICmpModalButtonParams {
		CgModalBtn: boolean;
	}

	class CmpModalButton implements ng.IDirective {
		constructor(private _$compile: angular.ICompileService) { }

		/*@ngInject*/
		static Instance($compile: angular.ICompileService): ng.IDirective {
			return new CmpModalButton($compile);
		}

		scope: ICmpModalButtonParams = {
			'CgClass': '@cgClass',
			'CgFontAwesome': '@cgFontAwesome',
			'CgTarget': '@cgTarget',
			'IsDisabled': '=cgIsDisabled'
		};

		link = (scope: ICmpModalButton | angular.IScope, element: angular.IAugmentedJQuery, attrs: angular.IAttributes, ctrl: any, transclude: any) => {
			var self = this;
			var scopeAsButton: ICmpModalButton = <ICmpModalButton>scope;
			var scopeAsNgScope: angular.IScope = <angular.IScope>scope;

			if (!scopeAsButton.CgClass) {
				scopeAsButton.CgClass = "btn btn-default";
			}
		};

		templateUrl: string = 'cmp-ui/Component/CmpModalButton/cmp-modal-button.html';
		restrict: string = 'E';
		transclude: boolean = true;
	}

	angular
		.module('cmp.ui.components')
		.directive('cmpModalButton', CmpModalButton.Instance);
}
