﻿/// <reference path="../../common-refs.d.ts" />
/// <reference path="../../bases/base-bo-model.ts" />
/// <reference path="../../bases/base-validatable-modal-controller.ts" />

namespace Cmp.Ui.Components {

    /** a custom event to run with a button */
    export interface ICmpCustomGridEvent {
        /** fa icon ok */
        ButtonText: string;
        /** the function to actually run when clicked */
        EventFunction: (objToDelete: Cmp.Ui.Bases.BaseBoModel) => void;
    }

    /** defines a column of the grid or the data passed in */
    export interface ICmpGridColumn {
        /** true if this property is contained in the data set */
        IsPropertyOfData?: boolean;
        PropertyName: string;
        /** css class(es) to apply after the classes based on the type (grid-cell-*) */
        CssClasses?: string;
        /** width of the kendo grid column */
        ColumnWidth?: number;

        /** Cmp.Ui.Components.CmpGridPropertyType... */
        PropertyType: Cmp.Js.Enums.CmpGridPropertyType;
        /** If a column should be shown in the grid */
        ColumnIsVisible?: boolean;
        /** The text header of a column, will be run through translate inside of the directive */
        ColumnHeaderText?: string;
        /** format of column output http://docs.telerik.com/kendo-ui/api/javascript/kendo#format */
        Template?: string;
        /** if EnableGrouping is true on the header and this is truthy, then grouping will not work for this column.  */
        DisableGrouping?: boolean;
        /** if EnableFiltering is true on the header and this is truthy, then filtering menu will not work for this column.  */
        DisableFiltering?: boolean;
        /** if EnableColumnPicker is true on the header and this is truthy, then this column will not be availble in the column picker  */
        DisableColumnPicker?: boolean;
        /** if DisableSorting is falsey on the header and this is truthy, then sorting will work for this column.  */
        DisableSorting?: boolean;
        /** If this is defined then this is the type of aggregation that will be performed on the column and displayed in the group footer */
        AggregateType?: Cmp.Js.Enums.CmpGridAggregateType;
        /** 
            If this is true, the column is hidden when the grid is loaded, it can be shown again using the column picker   
            this only works if the column picker is enabled. If the column picker is not enabled this option will be ignored. 
        */
        HiddenOnLoad?: boolean;
        /** client side text search is disabled on this column if this is true */
        DisableSearching?: boolean;
        /** If true this field will not be visible in the find control when on mobile(kendo grid isnt used on mobile */
        HideInMobileFindControl?: boolean;

    }

	export interface ICmpGridRowEditStarted {
		<TModelType extends Cmp.Ui.Bases.BaseBoModel>(model: TModelType, isNewItem: boolean, rawGridEditEvent?: kendo.ui.GridEditEvent): void;
	}

	/** This is used as a base to for the header button definitions */
	export interface ICmpGridHeaderButtonBase {
		/** the font awesome css class string that will be passed to the cmp-button, ex: "fa fa-plus" */
		cgFontAwesome?: string;
		/** the css class string that will be passed to the cmp-button, ex: "btn btn-primary" */
		cgClass?: string;
		/** the tool tip that will be passed to the cmp button */
		cgToolTip?: string;
		/** the button text (transcluded into the button) */
		Text: string;
	}
	
	export interface ICmpGridHeaderButtonClickAction {
		(selectedRows: Array<Cmp.Ui.Bases.BaseBoModel>): void;
	}

	/** Describes a custom button that will be rendered above the grid using the cmp-button directive */
	export interface ICmpGridHeaderButton extends ICmpGridHeaderButtonBase {
		/** the function that will be called when the used clicks the button. Any selected rows will be passed in as well.  */
		ClickAction: ICmpGridHeaderButtonClickAction;
	}

	/** used internally, creates a list using the header actions and the add button options, this is used in the template for the final rendering. */
	export interface ICmpGridHeaderPreppedButton extends ICmpGridHeaderButtonBase {
		/** the function that will be called when the used clicks the button. Any selected rows will be passed in as well.  */
		ClickAction: () => void;
	}

    /** defines the columns of the grid or the data passed in */
    export interface ICmpGridOptions {
        Columns: Array<Cmp.Ui.Components.ICmpGridColumn>;
        KeyPropertyName: string;

        EnableGrouping?: boolean;
        EnableFiltering?: boolean;
        EnableColumnPicker?: boolean;
        DisableSorting?: boolean;
        EnableClientSidePaging?: boolean
        //EnableServerSideActions?: boolean;
        PageSize?: number;
        Height?: string;
        /** A list of custom button columns to include and their callbacks */
        CustomEvents?: Array<ICmpCustomGridEvent>;

        /** if true the grid allows rows to be selected and will attempt to file the RowWasSelected event when a selection is made. the SelectedRow value on the directive is set to the current selection  */
        EnableSingleSelection?: boolean;
        /** fired when EnableSingleSelection is true and the user selects a row */
        RowWasSelected?: (objDeleted: Cmp.Ui.Bases.BaseBoModel) => void;

		/** if this is true the grid will allow multiple selection of rows and the header action buttons will be passed what is selected 
			This cannot be used at the same time that single selection is used. 
		*/
		EnableMultipleSelection?: boolean;

        /** if true, a more specific watch will be used to determin if the grid needs to have its rendering refresh */
        UseDeepWatch?: boolean;

		/** if true, this will enable the add button */
        EnableAdding?: boolean;
		/** if true, this will enable the edit button */
        EnableEditing?: boolean;
		/** if true, this will enable the delete button */
        EnableDeleting?: boolean;
		/** the width of the column with the stock edit/delete buttons in it */
		ActionsColumnWidth?: number;
		EditButtonCssClass?: string;
		DeleteButtonCssClass?: string;
        /** if a user clicks the delete button, the delete will only happen if this promise returns true */
        AllowDelete?: (objToDelete: Cmp.Ui.Bases.BaseBoModel) => cmp.IPromise<boolean>;
        /** if a user clicks the delete button, this will be called after the row has had its CmpDel field updated, 
        if the delete needs to be instant, the consumer should delete it here.  */
        DeleteRow?: (objDeleted: Cmp.Ui.Bases.BaseBoModel) => void;

		/** Custom header buttons to perform actions on grid items */
		HeaderActions?: Array<ICmpGridHeaderButton>;

		/** 
			If the user clicks the edit button, a modal is loaded, this property is the uninstanced type of the controller.  
			It must descend from BaseValidatableModalController
		*/
		EditModalControllerType?: Cmp.Ui.Bases.IValidatableModalController;
		/**
			the location of the template's url. 
			this template will be loaded into the modal and be backed by the controller specified in EditModalControllerType
		*/
		EditModalTemplateUrl?: string;
		/** 
			If the user clicks the edit button, a modal is loaded, this property is the uninstanced type of the of the model in this grid.  
			It must descend from IBaseGenBoModel
		*/
		EditModalEditType?: Cmp.Ui.Bases.IValidatableModalModelType;
		/** 
			these are additional arguments that will be passed to the modal 
		*/
		EditModalAdditionalArguments?: (modelSelected: Cmp.Ui.Bases.BaseBoModel) => any;
    }

    /** defines the actual data for the data binding */
    export interface ICmpGridDataSet<TBoType extends Cmp.Ui.Bases.BaseBoModel> {
        Data: Array<TBoType>;

        /** The total number of rows the control should expect (required for server side paging) */
        RowCount: number;
    }

    export interface ICmpGridParams<TBoType extends Cmp.Ui.Bases.BaseBoModel> {
        Data: ICmpGridDataSet<TBoType>;
        Options: ICmpGridOptions;
        /** the currently selected row.  */
        SelectedRow: Cmp.Ui.Bases.BaseBoModel;
    }

    export interface ICmpGridScope<TBoType extends Cmp.Ui.Bases.BaseBoModel> extends ICmpGridParams<TBoType>, angular.IScope {
        KendoColumnOptions: kendo.ui.GridOptions;
        KendoDataSource: kendo.data.DataSource;

        LastRawData: Array<any>;
        CrudHandler: CmpGridClientSideCrudHandling<TBoType>;

        OptionsHaveBeenProcessed: boolean;
        
		/** This will update the visible data, only going to the server if  */
        ForceClientDataRefresh: () => cmp.IPromise<any>;

		HeaderButtons: Array<ICmpGridHeaderPreppedButton>;
    }

    /** this is for client side crud handling, the read function just uses the array length for the row count since all the data is client side */
    export class CmpGridClientSideCrudHandling<TBoType extends Cmp.Ui.Bases.BaseBoModel> implements kendo.data.DataSourceTransportWithFunctionOperations {
        constructor(private _scope: ICmpGridScope<TBoType>) { }

        public create(opts: kendo.data.DataSourceTransportOptions) {
			opts.success(opts.data);
        }
        public read(opts: kendo.data.DataSourceTransportReadOptions) {
            var self = this;
            //repackage to expected schema: 
            var packedResults = <ICmpGridDataSet<TBoType>>{
                Data: self._scope.LastRawData,
                RowCount: (self._scope.LastRawData ? self._scope.LastRawData.length : 0)
            };
            opts.success(packedResults);
        }
        public update(opts: kendo.data.DataSourceTransportOptions) {
			opts.success(opts.data);
        }
        public destroy(opts: kendo.data.DataSourceTransportOptions) {
			opts.success(opts.data);
        }
    }
} 