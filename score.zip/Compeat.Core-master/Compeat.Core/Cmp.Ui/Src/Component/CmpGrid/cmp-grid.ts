﻿/// <reference path="../../common-refs.d.ts" />
/// <reference path="../components-module.ts" />
/// <reference path="../../bases/base-bo-model.ts" />
/// <reference path="cmp-grid-settings.ts" />
/// <reference path="../../services/modal-service.ts" />

namespace Cmp.Ui.Components {

	var cmpGridTemplateUrl = 'cmp-ui/Component/CmpGrid/cmp-grid.html';
    var boolify = Cmp.Js.Boolify; //for minify
    var propTypeEnum = Cmp.Js.Enums.CmpGridPropertyType;//for minify
    export class CmpGrid<TBoType extends Cmp.Ui.Bases.BaseBoModel> implements ng.IDirective {

        constructor(private _$timeout: angular.ITimeoutService,
            private _$translate: angular.translate.ITranslateService,
            private _cmpPromise: Cmp.Ui.Services.IPromiseService,
			private _cmpModalService: Cmp.Ui.Services.ICmpModalService,
			private _baseTools: Cmp.Ui.Services.IBaseTools,
			private _logger: Cmp.Ui.Services.ILoggerService) { }
		
        /*@ngInject*/
        static Instance($timeout: angular.ITimeoutService,
            $translate: angular.translate.ITranslateService,
            cmpPromise: Cmp.Ui.Services.IPromiseService,
			cmpModalService: Cmp.Ui.Services.ICmpModalService,
			baseTools: Cmp.Ui.Services.IBaseTools,
			logger: Cmp.Ui.Services.ILoggerService) {
            return new CmpGrid($timeout, $translate, cmpPromise, cmpModalService, baseTools, logger);
        }

        scope = {
            'Data': '=cgData',
            'Options': '=cgOptions',
            'SelectedRow': '=cgSelectedRow'
		}

        /** process the delete click (exposed for testing)  */
        _ProcessDeleteClick = (objToDelete: any, scope: ICmpGridScope<TBoType>) => {
            var directive = this;
            var keyProp = scope.Options.KeyPropertyName;
            var keyVal = objToDelete[scope.Options.KeyPropertyName];
            var firstMatch = Cmp.Js.Arrays.First(scope.Data.Data, (item) => {
                return item[keyProp] == keyVal;
            });
            var deleteObject = () => {
                if (firstMatch) {
                    firstMatch.CmpDel = true;
                }
                scope.KendoDataSource.remove(objToDelete); //kendo call too remove the object from the collection
                //notify consumer if interested
                if (scope.Options.DeleteRow) {
                    scope.Options.DeleteRow(firstMatch);
                }
            }
            //not in master collection, just remove
            if (!firstMatch) {
                directive._logger.Error('Grid row delete failed because no matching row was found');
            }else if (scope.Options.AllowDelete) {
                scope.Options.AllowDelete(firstMatch).then((result) => {
                    if (boolify(result)) {
                        deleteObject();
                    }//else dont delete
                });
            } else {
                deleteObject();
            }
        }

        /** process the edit click (exposed for testing)  */
        _ProcessEditClick = (objToEdit: any, scope: ICmpGridScope<TBoType>) => {
            var directive = this;
            var keyProp = scope.Options.KeyPropertyName;
			var match: TBoType;
			var isNew: boolean = false;
			if (objToEdit) {
				var keyVal = objToEdit[keyProp];
				match = Cmp.Js.Arrays.First(scope.Data.Data, (item) => {
					return item[keyProp] == keyVal;
				});
			} else {
				match = directive._baseTools.CreateInstance<TBoType>(scope.Options.EditModalEditType);
				isNew = true;
			}
			
            //if not in master collection, then its an issue
			if (!match) {
				directive._logger.Error('Grid row edit failed because no matching row was found!');
            } else {
				var newModalOptions = scope.Options.EditModalControllerType.AssignToModalSettings({
					size: 'md',
					templateUrl: scope.Options.EditModalTemplateUrl,
					resolve: {
						modalArguments: (): Cmp.Ui.Bases.IValidatableModalArgs<any, any> => {
							return {
								Model: match,
								BoType: scope.Options.EditModalEditType,
								AdditionalArguments: scope.Options.EditModalAdditionalArguments ? scope.Options.EditModalAdditionalArguments(match) : undefined
							};
						}
					}
				});
				var modalResult = <cmp.IPromise<boolean>>directive._cmpModalService.Open(newModalOptions).result;
				modalResult.then((results) => {
					//if this is a new item then add it to the parent collection
					if (isNew) {
						match.CmpNew = true;
						scope.Data.Data.push(match);
						scope.Data.RowCount++;
					}
				});
				//for now do nothing with the promise modalresult, possible event triggers can be made later if needed 
            }
        }

        private DurationHourMinuteFromSecondsTemplate(propertyName: string) {
            return "#= (!Cmp.Js.IsNullOrUndefined(" + propertyName + ") ? Cmp.Js.Strings.FormatSecondsAsHourMinute(" + propertyName + ") : '') #";
        }

        private DurationDayHourMinuteFromSecondsTemplate(propertyName: string) {
            return "#= (!Cmp.Js.IsNullOrUndefined(" + propertyName + ") ? Cmp.Js.Strings.FormatSecondsAsDayHourMinute(" + propertyName + ") : '') #";
        }

        private DateTimeFieldTemplate(translate: angular.translate.ITranslateService, propertyName: string){
            return "#= (!Cmp.Js.IsNullOrUndefined(" + propertyName + ") ? moment(" + propertyName + ").format('" + translate.instant("Core$MomentFullDateTimeString") + "') : '') #";
        }

        private CheckboxFromBooleanFieldTemplate(propertyName: string) {
            return "# if (Cmp.Js.Boolify(" + propertyName + ")) { # <input type=checkbox checked disabled /> # } else { # <input type=checkbox disabled /> # } #";
        }

        private Numeric2FieldTemplate(propertyName: string) {
            return "#= (!Cmp.Js.IsNullOrUndefined(" + propertyName + ") ? kendo.toString(parseFloat(" + propertyName + "), 'n') : '') #";
        }

        private CurrencyFieldTemplate(propertyName: string) {
            return "#= (!Cmp.Js.IsNullOrUndefined(" + propertyName + ") ? kendo.toString(parseFloat(" + propertyName + "), 'c') : '') #";
        }

        private NormalFieldTemplate(propertyName: string) {
            return "#= (!Cmp.Js.IsNullOrUndefined(" + propertyName + ") ? " + propertyName + " : '') #";
        }
        
        /** converts the direct options to kendo grid options, exposed for testability */
        _SetupKendoOptions = (scope: ICmpGridScope<TBoType>, gridOptions: ICmpGridOptions): cmp.IPromise<any> => {
			var directive = this;
			var translate = directive._$translate;
            return directive._cmpPromise.Promise<any>((resolveOptionsDone, rejectionOptionsDone) => {
                scope.LastRawData = scope.Data && scope.Data.Data && scope.Data.Data.length ? scope.Data.Data : null;
                if (!scope.OptionsHaveBeenProcessed && !scope.KendoColumnOptions) {
                    var newKendoOptions = <kendo.ui.GridOptions>{};
                    var newKendoDataSource = <kendo.data.DataSourceOptions>{};
                    var newKendoDataSourceSchema = <kendo.data.DataSourceSchemaWithOptionsModel>{};
                    newKendoDataSourceSchema.data = "Data";//to match Data on ICmpGridDataSet
                    newKendoDataSourceSchema.total = "RowCount";//to match RowCount on ICmpGridDataSet
                    var schemaModel = <kendo.data.DataSourceSchemaModelWithFieldsArray>{};
                    schemaModel.fields = <any>{};
                    var aggregateInfo = new Array<kendo.data.DataSourceAggregateItem>();
                    newKendoOptions.columns = new Array<kendo.ui.GridColumn>();
                    //var serverActions = boolify(gridOptions.EnableServerSideActions);
                    var disableSorting = boolify(gridOptions.DisableSorting);
                    var enableClientPaging = boolify(gridOptions.EnableClientSidePaging) /*&& !serverActions*/;
                    var enableGrouping = boolify(gridOptions.EnableGrouping);
                    var enableFiltering = boolify(gridOptions.EnableFiltering);
                    var enableColumnPicker = boolify(gridOptions.EnableColumnPicker);
                    var enableSingleSelection = boolify(gridOptions.EnableSingleSelection);
					var enableMultipleSelection = !enableSingleSelection && boolify(gridOptions.EnableMultipleSelection);

					//setup the header buttons if any are defined
					if (scope.Options &&
						((scope.Options.HeaderActions && scope.Options.HeaderActions.length) || boolify(scope.Options.EnableAdding))) {
						var buildSelectedList = (): Array<TBoType> => {
							var retList = new Array<TBoType>();
							var rawData: Array<TBoType> = scope.LastRawData;
							if (rawData && rawData.length) {
								rawData.forEach((dataItem) => {
									if (dataItem["__gridSelected"]) {
										retList.push(dataItem);
									}
								});
							}
							return retList;
						};

						var headerActions = scope.Options.HeaderActions;
						var headerButtons = new Array<ICmpGridHeaderPreppedButton>();
						var enableAdding = boolify(scope.Options.EnableAdding);
						if (enableAdding) {
							headerButtons.push({
								ClickAction: () => {
									directive._ProcessEditClick(null, scope);
								},
								cgFontAwesome: "fa fa-plus",
								cgClass: "btn btn-primary",
								cgToolTip: directive._$translate.instant('Core$CreateANewRecord'),
								Text: directive._$translate.instant('Core$AddU'),
							});
						}
						if (headerActions && headerActions.length) {
							headerActions.forEach((actionButton) => {
								headerButtons.push({
									ClickAction: () => {
										actionButton.ClickAction(buildSelectedList());
									},
									cgFontAwesome: actionButton.cgFontAwesome,
									cgClass: actionButton.cgClass,
									cgToolTip: actionButton.cgToolTip,
									Text: actionButton.Text,
								});
							});
						}
						scope.HeaderButtons = headerButtons;
					}

                    newKendoDataSource.filter = [
                        {
                            field: "CmpDel", operator: "neq", value: true
                        },
                        {
                            field: "_NotFound", operator: "neq", value: true  //used by inline search
                        },
                        
                    ];
                    if (!Cmp.Js.IsNullOrUndefined(gridOptions.Height)) {
                        newKendoOptions.height = gridOptions.Height;
                    }
                    if (enableClientPaging) {
                        var pageSize = gridOptions.PageSize ? gridOptions.PageSize : 25;
                        newKendoOptions.pageable = <kendo.ui.GridPageable>{
                            refresh: false,
                            pageSizes: true,
                            buttonCount: 5,
                            pageSize: pageSize
                        };
                    }
                    newKendoDataSource.pageSize = pageSize ? pageSize : undefined;
                    newKendoOptions.sortable = !disableSorting;
                    newKendoOptions.groupable = enableGrouping;
                    newKendoOptions.filterable = enableFiltering;
                    newKendoOptions.columnMenu = enableColumnPicker;

                    if (enableSingleSelection) {
                        newKendoOptions.selectable = 'row';
                        /** no fat arrow, 'this' matters in the change event */
                        newKendoOptions.change = function () {
                            var kendoInstance = this;
                            //single select handling
                            var selectedRows = kendoInstance.select();
                            if (selectedRows && selectedRows.length) {
                                var rowIndex = <number>selectedRows[0].rowIndex;
                                scope.SelectedRow = scope.LastRawData[rowIndex];
                            } else {
                                scope.SelectedRow = null;
                            }
                            if (scope.Options.RowWasSelected) {
                                scope.Options.RowWasSelected(scope.SelectedRow);
                            }
                        };
                    } else if (enableMultipleSelection) {
						/** enabled multi select */
                        newKendoOptions.selectable = 'multiple';
                        /** no fat arrow, 'this' matters in the change event */
                        newKendoOptions.change = function () {
                            var kendoInstance = this;
                            //single select handling
                            var selectedRows = kendoInstance.select();
							var rawData = scope.LastRawData;
							if (rawData && rawData.length) {
								//clear all selected rows
								rawData.forEach((_item) => {
									_item["__gridSelected"] = undefined;
								});
								//mark selected rows
								if (selectedRows && selectedRows.length) {
									for (var selectionIndex = 0; selectionIndex < selectedRows.length; selectionIndex++) {
										var selectedRow = selectedRows[selectionIndex];
										var rowIndex = selectedRow.rowIndex;
										var realItem = rawData[rowIndex];
										if (realItem) {
											realItem["__gridSelected"] = true;
										}
									}
								}
							}
                        };
					}

                    if (gridOptions.KeyPropertyName && gridOptions.KeyPropertyName.length) {
                        schemaModel.id = gridOptions.KeyPropertyName;
                    }
                    //process column list
                    gridOptions.Columns.forEach((item) => {
                        var isProperty = (item.IsPropertyOfData || Cmp.Js.IsNullOrUndefined(item.IsPropertyOfData)) && item.PropertyName && item.PropertyName.length;
                        if (item.ColumnIsVisible || Cmp.Js.IsNullOrUndefined(item.ColumnIsVisible)) {
                            //visible column setup
                            var newHeaderText = (item.ColumnHeaderText && item.ColumnHeaderText.length ? translate.instant(item.ColumnHeaderText) : <string>undefined);
                            var newField = isProperty ? item.PropertyName : undefined;
                            var newTemplate = item.Template && item.Template.length ? item.Template : undefined;
                            var additionalCssClasses = item.CssClasses;
							var columnWidth = item.ColumnWidth;
                            var allowGrouping = boolify(enableGrouping && !item.DisableGrouping);
                            var allowFiltering = boolify(enableFiltering && !item.DisableFiltering);
                            var allowColumnPicker = boolify(enableColumnPicker && !item.DisableColumnPicker);
                            var allowSorting = boolify(!disableSorting && !item.DisableSorting);
                            var columnHidden = boolify(item.HiddenOnLoad);
                            var propertyType = item.PropertyType;
                            //if a template was not specified, build one 
                            if (!newTemplate && newField) {
                                newTemplate = directive.GetPreferredTemplate(directive, newField, propertyType);
                            }
                            var aggregateTypeEnum = Cmp.Js.Enums.CmpGridAggregateType;
                            var aggregateType = item.AggregateType ? item.AggregateType : aggregateTypeEnum.None;
                            var aggregateEnabled = item.AggregateType !== aggregateTypeEnum.None;

                            var aggregateAsString: string = undefined;
                            var aggregateGroupHeaderTemplate: string = undefined;
                            var aggregateGroupFooterTemplate: string = undefined;
                            var aggregatePageFooterTemplate: string = undefined;

                            if (aggregateEnabled) {
                                switch (aggregateType) {
                                    case aggregateTypeEnum.Average:
                                        aggregateAsString = 'average';
                                        aggregateGroupHeaderTemplate = directive.GetPreferredTemplate(directive, 'average', propertyType, newHeaderText);
                                        aggregateGroupFooterTemplate = directive.GetPreferredTemplate(directive, 'average', propertyType);
                                        aggregatePageFooterTemplate = directive.GetPreferredTemplate(directive, 'average', propertyType, null, true);
                                        break;
                                    case aggregateTypeEnum.Count:
                                        aggregateAsString = 'count';
                                        aggregateGroupHeaderTemplate = directive.GetPreferredTemplate(directive, 'count', propertyType, newHeaderText);
                                        aggregateGroupFooterTemplate = directive.GetPreferredTemplate(directive, 'count', propertyType);
                                        aggregatePageFooterTemplate = directive.GetPreferredTemplate(directive, 'count', propertyType, null, true);
                                        break;
                                    case aggregateTypeEnum.Max:
                                        aggregateAsString = 'max';
                                        aggregateGroupHeaderTemplate = directive.GetPreferredTemplate(directive, 'max', propertyType, newHeaderText);
                                        aggregateGroupFooterTemplate = directive.GetPreferredTemplate(directive, 'max', propertyType);
                                        aggregatePageFooterTemplate = directive.GetPreferredTemplate(directive, 'max', propertyType, null, true);
                                        break;
                                    case aggregateTypeEnum.Min:
                                        aggregateAsString = 'min';
                                        aggregateGroupHeaderTemplate = directive.GetPreferredTemplate(directive, 'min', propertyType, newHeaderText);
                                        aggregateGroupFooterTemplate = directive.GetPreferredTemplate(directive, 'min', propertyType);
                                        aggregatePageFooterTemplate = directive.GetPreferredTemplate(directive, 'min', propertyType, null, true);
                                        break;
                                    case aggregateTypeEnum.Sum:
                                        aggregateAsString = 'sum';
                                        aggregateGroupHeaderTemplate = directive.GetPreferredTemplate(directive, 'sum', propertyType, newHeaderText);
                                        aggregateGroupFooterTemplate = directive.GetPreferredTemplate(directive, 'sum', propertyType);
                                        aggregatePageFooterTemplate = directive.GetPreferredTemplate(directive, 'sum', propertyType, null, true);
                                        break;
                                }
                                if (aggregateAsString) {
                                    aggregateInfo.push(<kendo.data.DataSourceParameterMapDataAggregate>{
                                        field: newField,
                                        aggregate: aggregateAsString
                                    });
                                }
                            }

                            var groupHeaderTemplate = aggregateEnabled && aggregateGroupHeaderTemplate ? aggregateGroupHeaderTemplate : undefined;
                            var groupFooterTemplate = aggregateEnabled && aggregateGroupFooterTemplate ? aggregateGroupFooterTemplate : undefined;
                            var pageFooterTemplate: string = aggregateEnabled && aggregatePageFooterTemplate ? aggregatePageFooterTemplate : undefined;

                            var cellCssClasses: string = undefined;

                            switch (propertyType) {
                                case propTypeEnum.Number:
                                    cellCssClasses = "grid-cell-number";
                                    if (pageFooterTemplate) {
                                        pageFooterTemplate = '<div class="grid-footer-number">' + pageFooterTemplate + '</div>';
                                    }
                                    break;
                                case propTypeEnum.DateTime:
                                    cellCssClasses = "grid-cell-datetime";
                                    if (pageFooterTemplate) {
                                        pageFooterTemplate = '<div class="grid-footer-datetime">' + pageFooterTemplate + '</div>';
                                    }
                                    break;
                                case propTypeEnum.DurationSeconds:
                                    cellCssClasses = "grid-cell-duration-seconds";
                                    if (pageFooterTemplate) {
                                        pageFooterTemplate = '<div class="grid-footer-duration-seconds">' + pageFooterTemplate + '</div>';
                                    }
                                    break;
                                case propTypeEnum.Number2Decimal:
                                    cellCssClasses = "grid-cell-number-2-decimal";
                                    if (pageFooterTemplate) {
                                        pageFooterTemplate = '<div class="grid-footer-number-2-decimal">' + pageFooterTemplate + '</div>';
                                    }
                                    break;
                                case propTypeEnum.Currency:
                                    cellCssClasses = "grid-cell-currency";
                                    if (pageFooterTemplate) {
                                        pageFooterTemplate = '<div class="grid-footer-currency">' + pageFooterTemplate + '</div>';
                                    }
                                    break;
                                case propTypeEnum.Boolean:
                                    cellCssClasses = "grid-cell-boolean";
                                    if (pageFooterTemplate) {
                                        pageFooterTemplate = '<div class="grid-footer-boolean">' + pageFooterTemplate + '</div>';
                                    }
                                    break;
                                default:
                                    cellCssClasses = "grid-cell-string";
                                    if (pageFooterTemplate) {
                                        pageFooterTemplate = '<div class="grid-footer-string">' + pageFooterTemplate + '</div>';
                                    }
                                    break;
                            }

                            if (additionalCssClasses && additionalCssClasses.length) {
								if (cellCssClasses && cellCssClasses.length) {
									cellCssClasses = cellCssClasses + ' ' + additionalCssClasses;
								} else {
									cellCssClasses = additionalCssClasses;
								}
                            } 

                            newKendoOptions.columns.push(<kendo.ui.GridColumn>{
                                field: newField,
                                title: newHeaderText,
                                template: newTemplate,
                                filterable: allowFiltering,
                                groupable: allowGrouping,
                                sortable: allowSorting,
                                menu: allowColumnPicker,
                                aggregates: aggregateEnabled && aggregateAsString ? [aggregateAsString] : undefined,
                                groupFooterTemplate: groupFooterTemplate,
                                groupHeaderTemplate: groupHeaderTemplate,
                                footerTemplate: pageFooterTemplate,
                                hidden: columnHidden,
                                attributes: {
                                    "class": cellCssClasses
                                },
								width: columnWidth ? columnWidth : undefined,
                            });
                        }
                        if (isProperty) {
                            (<any>schemaModel.fields)[item.PropertyName] = directive.CreateNewSchemaField(propertyType);
                        }
                    });
                    if (aggregateInfo && aggregateInfo.length) {
                        newKendoDataSource.aggregate = aggregateInfo;//force into place to match real schema
                    }
                    //hook up custom event columns
                    if (gridOptions.CustomEvents && gridOptions.CustomEvents.length) {
                        directive.HookUpCustomEventColumns(gridOptions, newKendoOptions, scope);
                    }


					directive.SetupEditorColumns(boolify(gridOptions.EnableEditing), boolify(gridOptions.EnableDeleting), newKendoOptions, scope, gridOptions.ActionsColumnWidth,
						gridOptions.DeleteButtonCssClass, gridOptions.EditButtonCssClass, directive._$translate);

                    newKendoDataSourceSchema.model = schemaModel;
                    newKendoDataSourceSchema.parse = (model: any) => {  
                        //if (model.Data && model.Data.length) {
                        //    var rawData: any[] = [];         
                        //    model.Data.forEach((item: any) => {
                        //        var newRaw = item.ToJson();
                        //        newRaw._NotFound = item._NotFound;
                        //        rawData.push(newRaw);
                        //    });
                        //    model.Data = rawData;
                        //}
                        return model;
                    };
                    newKendoDataSource.schema = newKendoDataSourceSchema;
                    scope.CrudHandler = new CmpGridClientSideCrudHandling(scope);
                    newKendoDataSource.transport = scope.CrudHandler;
					
                    newKendoOptions.dataSource = new kendo.data.DataSource(newKendoDataSource);

                    newKendoOptions.dataSource.autoSync = true;
                    scope.KendoDataSource = newKendoOptions.dataSource;
                    scope.KendoColumnOptions = newKendoOptions;
                    scope.OptionsHaveBeenProcessed = true;
                    resolveOptionsDone();//always resolve for now
                } else {
                    scope.KendoDataSource.read().then(resolveOptionsDone, rejectionOptionsDone);
                }
            });
        }

        private GetPreferredTemplate(directive: CmpGrid<TBoType>, propertyName: string, propType: Cmp.Js.Enums.CmpGridPropertyType, textPrefix?: string, isPageFooter?: boolean) {
            var retVal: string = undefined;
            switch (propType) {
                case propTypeEnum.DateTime:
                    retVal = directive.DateTimeFieldTemplate(directive._$translate, propertyName);
                    break;
                case propTypeEnum.DurationSeconds:
                    if (isPageFooter) {
                        retVal = directive.DurationDayHourMinuteFromSecondsTemplate(propertyName);
                    } else {
                        retVal = directive.DurationHourMinuteFromSecondsTemplate(propertyName);
                    }
                    break;
                case propTypeEnum.Number2Decimal:
                    retVal = directive.Numeric2FieldTemplate(propertyName);
                    break;
                case propTypeEnum.Currency:
                    retVal = directive.CurrencyFieldTemplate(propertyName);
                    break;
                case propTypeEnum.Boolean:
                    retVal = directive.CheckboxFromBooleanFieldTemplate(propertyName);
                    break;
                default:
                    retVal = directive.NormalFieldTemplate(propertyName);
                    break;
            }

            return (textPrefix && textPrefix.length ? textPrefix + ': ' : '') + retVal;
        }

        private CreateNewSchemaField(propType: Cmp.Js.Enums.CmpGridPropertyType) {
            var schemaField = <kendo.data.DataSourceSchemaModelField>{};

            switch (propType) {
                case propTypeEnum.Number:
                    schemaField.type = 'number';
                    break;
                case propTypeEnum.DateTime:
                    schemaField.type = 'date';
                    break;
                case propTypeEnum.DurationSeconds:
                    schemaField.type = 'number';
                    break;
                case propTypeEnum.Number2Decimal:
                    schemaField.type = 'number';
                    break;
                case propTypeEnum.Currency:
                    schemaField.type = 'number';
                    break;
                case propTypeEnum.Boolean:
                    schemaField.type = 'boolean';
                    break;
                default:
                    schemaField.type = 'string';
                    break;
            }
            return schemaField;
        }

        private HookUpCustomEventColumns(gridOptions: ICmpGridOptions, newKendoOptions: kendo.ui.GridOptions, scope: ICmpGridScope<TBoType>) {
            var eventCounter = 0;
            gridOptions.CustomEvents.forEach((ev) => {
                newKendoOptions.columns.push(<kendo.ui.GridColumn>{
                    command: <kendo.ui.GridColumnCommandItem[]>[
                        <kendo.ui.GridColumnCommandItem>{
                            name: "_custom_" + eventCounter++,
                            text: ev.ButtonText,
                            click: function (event: any) { //no fat arrow intentional
                                var tr = $(event.target).closest("tr"); //get the row for deletion
                                var data = this.dataItem(tr); //get the row data so it can be referred later
                                var keyProp = scope.Options.KeyPropertyName;
                                var keyVal = data[scope.Options.KeyPropertyName];
                                var firstMatch = Cmp.Js.Arrays.First(scope.Data.Data, (item) => {
                                    return item[keyProp] === keyVal;
                                });
                                ev.EventFunction(firstMatch);
                            }
                        }
                    ]
                });
            }); 
        }

        private SetupEditorColumns(enableEdit: boolean, enableDelete: boolean, newKendoOptions: kendo.ui.GridOptions, scope: ICmpGridScope<TBoType>,
			columnWidth: number, DeleteButtonCssClass: string, EditButtonCssClass: string, $translate: angular.translate.ITranslateService) {
            var directive = this;
			var commandItems: Array<kendo.ui.GridColumnCommandItem> = new Array<kendo.ui.GridColumnCommandItem>();
			if (enableEdit) {
				commandItems.push(<kendo.ui.GridColumnCommandItem>{
					name: "_coreEdit",
					text: "<i class='fa fa-edit'></i>",
					click: function (event: any) { //no fat arrow intentional
						var tr = $(event.target).closest("tr"); //get the row for deletion
						var data = this.dataItem(tr); //get the row data so it can be referred later
						directive._ProcessEditClick(data, scope);
					},
					className: EditButtonCssClass && EditButtonCssClass.length ? EditButtonCssClass : undefined
				});
			}
			if (enableDelete) {
				commandItems.push(<kendo.ui.GridColumnCommandItem>{
					name: "_coreDelete",
					text: "<i class='fa fa-trash'></i>",
					click: function (event: any) { //no fat arrow intentional
						var tr = $(event.target).closest("tr"); //get the row for deletion
						var data = this.dataItem(tr); //get the row data so it can be referred later
						directive._ProcessDeleteClick(data, scope);
					},
					className: DeleteButtonCssClass && DeleteButtonCssClass.length ? DeleteButtonCssClass : undefined
				});
			}
			if (commandItems && commandItems.length) {
				newKendoOptions.columns.push(<kendo.ui.GridColumn>{
					width: columnWidth ? columnWidth : undefined,
					command: commandItems
				});
			}
        }

        link = (scope: ICmpGridScope<TBoType>, element: angular.IAugmentedJQuery, attrs: angular.IAttributes) => {
            var directive = this;

            scope.ForceClientDataRefresh = () => {
                return directive._SetupKendoOptions(scope, scope.Options);
            };

			
            var handleDataChange = (current: ICmpGridDataSet<TBoType>, old: ICmpGridDataSet<TBoType>): void => {
                if (!current || current === old) {
                    return;
                }
                directive._$timeout((): void => {
                    //pass in the new data, ignore the scope options since they cant change
                    scope.ForceClientDataRefresh();
                });
            };

            var setupWatch = (): void => {
                if (scope.Options.UseDeepWatch) {
                    var lastHasVal = false;
                    var lastRowCount = 0;
                    var lastLength = 0;
                    scope.$watch((): any => {
                        //Build a unique object to represent the array that will actually be shown
                        var retVal: {
                            HasValue: boolean,
                            RowCount: number,
                            ArrayLength: number,
                            RawData: Array<any>
                        } = null;
                        var val = scope.Data;
                        var hasVal = !Cmp.Js.IsNullOrUndefined(val);
                        var rowCount = hasVal ? val.RowCount : 0;
                        var length = hasVal && val.Data ? val.Data.length : 0;

                        if (hasVal != lastHasVal || lastRowCount != rowCount || lastLength != length) {
                            retVal = {
                                HasValue: hasVal,
                                RowCount: rowCount,
                                ArrayLength: length,
                                RawData: null
                            };
                        } else {
                            var rawData = new Array<any>();
                            if (rowCount) {
                                scope.Data.Data.forEach((item) => {
                                    var newRaw: any = {};
                                    newRaw._NotFound = item["_NotFound"];
                                    scope.Options.Columns.forEach((col) => {
                                        newRaw[col.PropertyName] = item[col.PropertyName];
                                    });
                                    rawData.push(newRaw);
                                });
                            }
                            retVal = {
                                HasValue: hasVal,
                                RowCount: rowCount,
                                ArrayLength: length,
                                RawData: rawData
                            };
                        }
                        lastHasVal = hasVal;
                        lastRowCount = rowCount;
                        lastLength = length;
                        return retVal;
                    }, handleDataChange, true);
                } else {
                    //shallow array watch
                    scope.$watch('Data', handleDataChange);
                }
            };

            scope.ForceClientDataRefresh().then(setupWatch, setupWatch);

        };

		templateUrl: string = cmpGridTemplateUrl;
		restrict: string = 'E';
	}

	angular
		.module('cmp.ui.components')
        .directive('cmpGrid', CmpGrid.Instance);

} 