﻿/// <reference path="../../common-refs.d.ts" />
/// <reference path="../components-module.ts" />

namespace Cmp.Ui.Components {

	interface ICmpGroupRow {
		CgLabel: string;
		CssClass: string;
	}

	class CmpGroupRow implements ng.IDirective {
		constructor() { }
		
		/*@ngInject*/
		static Instance(): ng.IDirective {
			return new CmpGroupRow();
		}

		scope: ICmpGroupRow = {
			'CgLabel': '@cgLabel',
			'CssClass': '@cgCssClass'
		};

		templateUrl: string = 'cmp-ui/Component/CmpGroupRow/cmp-group-row.html';
		restrict: string = 'E';
		transclude: boolean = true;
	}

	angular
		.module('cmp.ui.components')
		.directive('cmpGroupRow', CmpGroupRow.Instance);
}
