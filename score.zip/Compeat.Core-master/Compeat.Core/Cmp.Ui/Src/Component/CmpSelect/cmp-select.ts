﻿/// <reference path="../../common-refs.d.ts" />
/// <reference path="../components-module.ts" />
/// <reference path="../../services/promise.ts" />

namespace Cmp.Ui.Components {

	export class CmpSelectParams {
		Model: string;//the model object, from the controller
		Property: string;//the property on the model that is bound
		Form: string | angular.IFormController;//the angular form name in the template
		NameId: string;
		Placeholder: string;
		IsDisabled: boolean | string;//binding to disable the field
		IsMultiple: boolean | string;//if true the control will allow multiple items
		NgRequired: string; // see https://docs.angularjs.org/api/ng/directive/ngOptions

		Collection: string | Array<any>;//the data source 
		DisplayProperty: string;//the property on each 'collection' item that will be visible to the user
		ValueProperty: string;//the property on each 'collection' item that will be the backing value for the selection 

		AllowClear: boolean | string;
		CssClass: string;
	}

	export class Select2CollectionRow {
		//properties must be lower camel
		constructor(public id: string, public text: string) { }
	}

	export class SelectScope extends CmpSelectParams { }

	export class CmpSelect implements ng.IDirective {
		private _sourceCollection: Array<Select2CollectionRow>;

		constructor(private _$timeout: angular.ITimeoutService, private _cmpPromise: Cmp.Ui.Services.PromiseService) { }

		/*@ngInject*/
		static Instance($timeout: angular.ITimeoutService, cmpPromise: Cmp.Ui.Services.PromiseService) {
			return new CmpSelect($timeout, cmpPromise);
		}
		//<cmp-select cg-allow-clear="true" cg-placeholder="foo1 placeholder 1" cg-model="loginCtrl.Model" cg-property="foo1" cg-form="loginCtrl.loginForm" cg-name-id="foo1" label="foo 1 cg-label" cg-collection="loginCtrl.fooCollection" cg-display-property="description" cg-value-property="id"></cmp-select>
		//<cmp-select cg-is-multiple="true" cg-allow-clear="true" cg-placeholder="empty placeholder 2" cg-model="loginCtrl.Model" cg-property="foo2" cg-form="loginCtrl.loginForm" cg-name-id="foo2" cg-label="foo 2 label" cg-collection="loginCtrl.fooCollection" cg-display-property="description" cg-value-property="id"></cmp-select>
		scope: CmpSelectParams = {
			'Model': '=cgModel',
			'Property': '@cgProperty',
			'Form': '=cgForm',
			'NameId': '@?cgNameId',
			'Placeholder': '@cgPlaceholder',
			'IsDisabled': '=cgIsDisabled',
			'IsMultiple': '=cgIsMultiple',
			'NgRequired': '=cgRequired',
			'Collection': '=cgCollection',
			'DisplayProperty': '@cgDisplayProperty',
			'ValueProperty': '@cgValueProperty',
			'AllowClear': '@cgAllowClear',
			'CssClass': '@cgCssClass'
		};
				
		/** converts the collection data into a select2 friendly form, exposed public for mockability */
		_getCollectionData = (scopeAsSelect: SelectScope): Array<Select2CollectionRow> => {
			var retVal = new Array<Select2CollectionRow>();
			var list = <Array<any>>scopeAsSelect.Collection;
			if (!(<boolean>scopeAsSelect.IsMultiple) && <boolean>scopeAsSelect.AllowClear) {
				//look for an empty value alreay in list
				var existingEmpty = Cmp.Js.Arrays.First(list, (val: any): boolean => {
					var _val = val[scopeAsSelect.ValueProperty];
					return !_val || !_val.toString().length;
				});
				//if there isnt already an empty value, add one
				if (!existingEmpty) {
					retVal.push({ id: '', text: '' });
				}
			}
			if (list && list.length) {
				list.forEach((val: any) => {
					retVal.push({ id: val[scopeAsSelect.ValueProperty], text: val[scopeAsSelect.DisplayProperty] });
				});
			}
			return retVal;
		};
				
		/** added and exposed for testability, returns the raw collection */
		_getRawCollection = () => {
			return this._sourceCollection;
		}

		/** toggles classes as the data changes, exposed public for mockability */
		_toggleClassesParser = (ngModelCtrl: angular.INgModelController, element: angular.IAugmentedJQuery): void => {
			var div = element.find('.select2-container');
			div
				.toggleClass('ng-invalid', !ngModelCtrl.$valid)
				.toggleClass('ng-valid', ngModelCtrl.$valid)
				.toggleClass('ng-invalid-required', !ngModelCtrl.$valid)
				.toggleClass('ng-valid-required', ngModelCtrl.$valid)
				.toggleClass('ng-dirty', ngModelCtrl.$dirty)
				.toggleClass('ng-pristine', ngModelCtrl.$pristine);
		};
				
		/** returns the select element as a jquery object, exposed public for mockability */
		_getSelectElement = (element: angular.IAugmentedJQuery): JQuery => {
			return $(element.find('select'));
		};
				
		/** returns a new item for the select, only if its not already in the list, exposed public for mockability */
		_createSelectionItem = (params: any, sourceCollection: Array<Select2CollectionRow>): any => {
			var term = $.trim(params.term).toLowerCase();

			//find in original collection, if there return, otherwise return null
			var itemFound = Cmp.Js.Arrays.First(sourceCollection, (val: Select2CollectionRow): boolean => {
				return val.text.toLowerCase() === term.toLowerCase();
			});

			if (!itemFound) {
				return null;
			} else {
				return itemFound;
			}
		};
				
		/** parses the comma delimited input in a way that will select the final item which didnt happen originally, exposed public for mockability */
		_cmpTokenizer = (input: any, selectCallback: (data: any) => void): any => {
			var self = this;
			//originally pulled from select2 code, but adjusted to fix bug where a tag was created either way
			//also added a fix for situations where a comma delimited string was pasted in
			var separators = [','];
			var term = input.term;
			var i = 0;
			var tokensFound: number = 0;
			while (i < term.length) {
				var termChar = term[i];

				if (termChar !== ',') {
					i++;
					continue;
				}
				tokensFound++;
				var part = term.substr(0, i);
				var partParams = $.extend({}, input, {
					term: part
				});

				var newSelection = self._createSelectionItem(partParams, self._getRawCollection());
				if (newSelection) {
					selectCallback(newSelection);
				}
				// Reset the term to not include the tokenized portion
				term = term.substr(i + 1) || '';
				i = 0;
			}

			//if more than 1 tokens were parsed and there is still a term, try to use it
			if (tokensFound && tokensFound >= 1 && term && term.length) {
				var partParams = $.extend({}, input, {
					term: term
				});
				var lastNewSelection = self._createSelectionItem(partParams, self._getRawCollection());
				if (lastNewSelection) {
					selectCallback(lastNewSelection);
					term = '';//clear search val
				}
			}

			return {
				term: term
			};
		}
				
		/** wait for the angular digest, then rerender the control, exposed public for mockability */
		_timeoutAndRender = (fullJqObj: JQuery, ngModelCtrl: angular.INgModelController): void => {
			this._$timeout((): void => {

				/** select 2's val function does not like setting an undefined value, ie. this.$element.val(...).trigger is not a function */
				if (Cmp.Js.IsUndefined(ngModelCtrl.$modelValue)) {
					return;
				}
				/** don't set select 2 widget's value if already set to same value */
				if (!fullJqObj.data('select2') || ngModelCtrl.$modelValue === fullJqObj.select2('val')) {
					return;
				}

				fullJqObj.select2('val', ngModelCtrl.$modelValue, true);
				ngModelCtrl.$render();
			});
		}
				
		/** calls the needed setup on for select2, exposed public for mockability */
		_setupSelect2 = (scopeAsSelect: SelectScope, fullJqObj: JQuery): void => {
			var self = this;
			//check if select2 is already setup, if so, destroy it and clear it
			if (fullJqObj.data('select2')) {
				fullJqObj.select2('destroy');
				fullJqObj.empty();
			}

			if (<boolean>scopeAsSelect.IsMultiple) {
				fullJqObj.select2({
					placeholder: scopeAsSelect.Placeholder,
					allowClear: <boolean>scopeAsSelect.AllowClear,
					data: self._getRawCollection(),
					multiple: true,
					tags: false,//dont allow unknown items to be added. 
										width: '100%',
					tokenizer: (input: any, options: Select2Options, selectCallback: (data: any) => void): any => {
						return self._cmpTokenizer(input, selectCallback);
					}
				});
			} else {
				fullJqObj.select2({
					placeholder: scopeAsSelect.Placeholder,
					allowClear: <boolean>scopeAsSelect.AllowClear,
					data: self._getRawCollection(),
					multiple: false,
										tags: false,//dont allow unknown items to be added. 
										width: '100%'
				});
			}
		}

		/** the link function content, exposed public for testability */
		_linkAsPromise = (scope: SelectScope | angular.IScope, element: angular.IAugmentedJQuery, attrs: angular.IAttributes) => {
			var self = this;
			var scopeAsSelect: SelectScope = <SelectScope>scope;
			var scopeAsNgScope: angular.IScope = <angular.IScope>scope;

			return self._cmpPromise.Promise(function (resolve, reject) {
				scopeAsSelect.Placeholder = scopeAsSelect.Placeholder && scopeAsSelect.Placeholder.length ? scopeAsSelect.Placeholder : '';

				var ngModelCtrl: angular.INgModelController = scopeAsSelect.Form ? (<angular.IFormController>scopeAsSelect.Form)[scopeAsSelect.NameId] : null;
				if (ngModelCtrl) {

					if (!Js.OnMobile()) {

						var fullJqObj: JQuery = self._getSelectElement(element);

						ngModelCtrl.$parsers.push((value: any): any => {
							self._toggleClassesParser(ngModelCtrl, element);
							return value;
						});

						fullJqObj.bind("$destroy", (): void => {
							fullJqObj.select2("destroy");
						});

						attrs.$observe('disabled', (value: any): void => {
							fullJqObj.select2('enable', !value);
						});

						attrs.$observe('readonly', (value: any): void => {
							fullJqObj.select2('readonly', !!value);
						});

						scopeAsSelect.IsMultiple = Cmp.Js.Boolify(scopeAsSelect.IsMultiple);

						if (scopeAsSelect.AllowClear == undefined) {
							scopeAsSelect.AllowClear = true;
						} else {
							scopeAsSelect.AllowClear = Cmp.Js.Boolify(scopeAsSelect.AllowClear);
						}

						self._sourceCollection = self._getCollectionData(scopeAsSelect);
						self._setupSelect2(scopeAsSelect, fullJqObj);
						self._$timeout((): void => {
							ngModelCtrl.$render = () => { };
						});
						scopeAsNgScope.$watch('Collection', (current, old): void => {
							if (!current) {
								return;
							}
							if (current === old) {
								return;
							}
							self._$timeout((): void => {
								scopeAsSelect.IsMultiple = Cmp.Js.Boolify(scopeAsSelect.IsMultiple);
								scopeAsSelect.AllowClear = Cmp.Js.Boolify(scopeAsSelect.AllowClear);
								self._sourceCollection = self._getCollectionData(scopeAsSelect);//update collection for tokenizer
								self._setupSelect2(scopeAsSelect, fullJqObj);//rebuild select
								ngModelCtrl.$render();
							});
						}, true);
						scopeAsNgScope.$watch('Model.' + scopeAsSelect.Property, (current, old): void => {
							if (Cmp.Js.IsNullOrUndefined(current)) {
								return;
							}
							if (current === old) {
								return;
							}
							self._timeoutAndRender(fullJqObj, ngModelCtrl);
						}, true);

						self._timeoutAndRender(fullJqObj, ngModelCtrl);

					} else {  // if (!Js.OnMobile()) {
						scopeAsSelect.IsMultiple = Cmp.Js.Boolify(scopeAsSelect.IsMultiple);
						if (scopeAsSelect.IsMultiple) {
							var sel = element.find('select.cmp-mobile');
							sel.attr('multiple', 'multiple');
						}
					}

					resolve();
				} else {
					resolve();
				}
			});
		};

		link = (scope: SelectScope | angular.IScope, element: angular.IAugmentedJQuery, attrs: angular.IAttributes) => {
			this._linkAsPromise(scope, element, attrs);
		};

		/** returns the url to the template file based on desktop or mobile */
		templateUrl = () => {
			if (Cmp.Js.OnMobile()) {
				return 'cmp-ui/Component/CmpSelect/cmp-select-mbl.html';
			} else {
				return 'cmp-ui/Component/CmpSelect/cmp-select-dsk.html';
			}
		}

		restrict: string = 'E';
	}

	angular
		.module('cmp.ui.components')
		.directive('cmpSelect', CmpSelect.Instance);

} 