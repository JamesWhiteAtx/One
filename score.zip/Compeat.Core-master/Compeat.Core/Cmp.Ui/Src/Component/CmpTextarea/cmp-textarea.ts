﻿/// <reference path="../../common-refs.d.ts" />
/// <reference path="../components-module.ts" />
/// <reference path="../../features/rules.ts" />

namespace Cmp.Ui.Components {

	export class CmpTextareaParams {
		//attributes
		//angular text area basics https://docs.angularjs.org/api/ng/directive/textarea
		//text area basics: http://www.w3schools.com/tags/tag_textarea.asp

		Model: string;//the model object, from the controller
		Property: string;//the property on the model that is bound
		Form: string;//the angular form name in the template
		NameId: string;//the html control name, needed for angular validation ties with the form
		Placeholder: string;
		IsDisabled: boolean | string; //binding to disable the field
		NgChange: string; //see angular text area basics
		NgRequired: string;  //see angular text area basics
		NgMinlength: string;  //see angular text area basics
		NgMaxlength: string;  //see angular text area basics
		NgPattern: string;  //see angular text area basics
		PatternErrorMessage: string;//an error message if the pattern is wrong
		Cols: number | string;// see text area basics
		Rows: number | string;// see text area basics
		Wrap: string; // see text area basics
	}

	var textareaTemplateUrl = 'cmp-ui/Component/CmpTextarea/cmp-textarea.html';

	export class TextAreaValidationTranslationArgs {
		NgMinlength: string;
		NgMaxlength: string;
	}

	export class TextareaScope extends CmpTextareaParams {
		CustomNgMessages: Array<Cmp.Ui.Rules.CustomValidationMessage>;
	}

	export class CmpTextarea implements ng.IDirective {
		constructor(private _$translate: angular.translate.ITranslateService, private _cmpPromise: Cmp.Ui.Services.PromiseService) { }
		
		/*@ngInject*/
		static Instance($translate: angular.translate.ITranslateService, cmpPromise: Cmp.Ui.Services.PromiseService) {
			return new CmpTextarea($translate, cmpPromise);
		}


		scope: CmpTextareaParams = {
			'Model': '=cgModel',
			'Property': '@cgProperty',
			'Form': '=cgForm',
			'NameId': '@cgNameId',
			'Placeholder': '@?cgPlaceholder',
			'IsDisabled': '=cgIsDisabled',
			'NgChange': '&?cgChange',
			'NgRequired': '=cgRequired',
			'NgMinlength': '@?cgMinlength',
			'NgMaxlength': '@?cgMaxlength',
			'NgPattern': '=cgPattern',
			'PatternErrorMessage': '@?cgPatternErrorMessage',
			'Cols': '@?cgCols',
			'Rows': '@?cgRows',
			'Wrap': '@?cgWrap'
		};

		/** the link function content, exposed public for testability */
		_linkAsPromise = (scope: TextareaScope | angular.IScope, element: angular.IAugmentedJQuery, attrs: angular.IAttributes) => {
			var self = this;
			var scopeAsTextarea: TextareaScope = <TextareaScope>scope;
			var scopeAsNgScope: angular.IScope = <angular.IScope>scope;

			return self._cmpPromise.Promise(function (resolve, reject) {
				//copy validation args into an object to pass to translation
				var trans = new TextAreaValidationTranslationArgs();
				trans.NgMinlength = scopeAsTextarea.NgMinlength;
				trans.NgMaxlength = scopeAsTextarea.NgMaxlength;

				self._$translate(["Core$MinLengthShort",
					"Core$MaxLengthExceeded"], trans).then((translation: any): void => {

						scopeAsTextarea.CustomNgMessages = new Array<Cmp.Ui.Rules.CustomValidationMessage>();

						if (!Cmp.Js.IsNullOrUndefined(scopeAsTextarea.NgMinlength)) {
							scopeAsTextarea.CustomNgMessages.push({ MessageType: Cmp.Ui.Rules.NgMessageTypes.MinLength, Message: translation.Core$MinLengthShort });
						}
						if (!Cmp.Js.IsNullOrUndefined(scopeAsTextarea.NgMaxlength)) {
							scopeAsTextarea.CustomNgMessages.push({ MessageType: Cmp.Ui.Rules.NgMessageTypes.MaxLength, Message: translation.Core$MaxLengthExceeded });
						}
						resolve();
					});
			});
		};

		link = (scope: TextareaScope | angular.IScope, element: angular.IAugmentedJQuery, attrs: angular.IAttributes) => {
			this._linkAsPromise(scope, element, attrs);
		};

		templateUrl: string = textareaTemplateUrl;
		restrict: string = 'E';
	}

	angular
		.module('cmp.ui.components')
		.directive('cmpTextarea', CmpTextarea.Instance);

} 