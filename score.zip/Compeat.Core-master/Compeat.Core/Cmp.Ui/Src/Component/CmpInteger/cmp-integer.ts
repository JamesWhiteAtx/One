﻿/// <reference path="../../common-refs.d.ts" />
/// <reference path="../components-module.ts" />
/// <reference path="../cmptextbox/cmp-textbox.ts" />
/// <reference path="../../features/rules.ts" />

namespace Cmp.Ui.Components {

	export class IntegerValidationTranslationArgs {
		Min: string;
		Max: string;
		NgMinlength: string;
		NgMaxlength: string;
	}

	export class IntegerScope extends Cmp.Ui.Components.CmpTextboxParams {
		CustomNgMessages: Array<Cmp.Ui.Rules.CustomValidationMessage>;
	}

	export class CmpInteger implements ng.IDirective {
		constructor(private _$translate: angular.translate.ITranslateService, private _cmpPromise: Cmp.Ui.Services.PromiseService) { }
		
		/*@ngInject*/
		static Instance($translate: angular.translate.ITranslateService, cmpPromise: Cmp.Ui.Services.PromiseService) {
			return new CmpInteger($translate, cmpPromise);
		}

		scope: Cmp.Ui.Components.CmpTextboxParams = Cmp.Ui.Components.TextboxScopeDefaults;

		/** the link function content, exposed public for testability */
		_linkAsPromise = (scope: IntegerScope | angular.IScope, element: angular.IAugmentedJQuery, attrs: angular.IAttributes) => {
			var self = this;
			var scopeAsTextbox: IntegerScope = <IntegerScope>scope;
			var scopeAsNgScope: angular.IScope = <angular.IScope>scope;
			var stringLib = Cmp.Js.Strings; //for min

			return self._cmpPromise.Promise(function (resolve, reject) {
				var ngModelCtrl: angular.INgModelController = scopeAsTextbox.Form ? (<angular.IFormController>scopeAsTextbox.Form)[scopeAsTextbox.NameId] : null;
				if (ngModelCtrl) {
					ngModelCtrl.$parsers.push((val: string): string => {
						var clean = stringLib.MakeIntegerString(val);
						if (val && val != clean) {
							ngModelCtrl.$setViewValue(clean);
							ngModelCtrl.$render();
						}
						return clean;
					});
					//verify its actually a number
					ngModelCtrl.$validators["number"] = (modelValue: string, viewValue: string): boolean => {
						var value = modelValue || viewValue;
						return stringLib.IsIntegerOrEmpty(value) || value === '-';
					};
					//verify the min value if one is set
					if (!Cmp.Js.IsNullOrUndefined(scopeAsTextbox.Min)) {
						ngModelCtrl.$validators["min"] = (modelValue: string, viewValue: string): boolean => {
							var value = modelValue || viewValue;
							if (stringLib.IsInteger(value) && value !== '-') {
								return parseInt(scopeAsTextbox.Min) <= parseInt(value);
							}
							return true;
						};
					}
					//verify the max value if one is set
					if (!Cmp.Js.IsNullOrUndefined(scopeAsTextbox.Max)) {
						ngModelCtrl.$validators["max"] = (modelValue: string, viewValue: string): boolean => {
							var value = modelValue || viewValue;
							if (stringLib.IsInteger(value) && value !== '-') {
								return parseInt(scopeAsTextbox.Max) >= parseInt(value);
							}
							return true;
						};
					}
				}

				//angular thinks the field is empty in chrome if its not a number, so use the normal text field for now
				scopeAsTextbox.Type = 'text'; 
			
				//copy validation args into an object to pass to translation
				var trans = new IntegerValidationTranslationArgs();
				trans.Min = scopeAsTextbox.Min;
				trans.Max = scopeAsTextbox.Max;
				trans.NgMinlength = scopeAsTextbox.NgMinlength;
				trans.NgMaxlength = scopeAsTextbox.NgMaxlength;

				self._$translate(["Core$MinLengthShort",
					"Core$MaxLengthExceeded",
					"Core$MinNumberShort",
					"Core$MaxNumberExceeded",
					"Core$InvalidInteger"], trans).then((translation: any): void => {

						scopeAsTextbox.CustomNgMessages = new Array<Cmp.Ui.Rules.CustomValidationMessage>();
						scopeAsTextbox.CustomNgMessages.push({ MessageType: Cmp.Ui.Rules.NgMessageTypes.Number, Message: translation.Core$InvalidInteger });
						if (!Cmp.Js.IsNullOrUndefined(scopeAsTextbox.Min)) {
							scopeAsTextbox.CustomNgMessages.push({ MessageType: Cmp.Ui.Rules.NgMessageTypes.Min, Message: translation.Core$MinNumberShort });
						}
						if (!Cmp.Js.IsNullOrUndefined(scopeAsTextbox.Max)) {
							scopeAsTextbox.CustomNgMessages.push({ MessageType: Cmp.Ui.Rules.NgMessageTypes.Max, Message: translation.Core$MaxNumberExceeded });
						}

						if (!Cmp.Js.IsNullOrUndefined(scopeAsTextbox.NgMinlength)) {
							scopeAsTextbox.CustomNgMessages.push({ MessageType: Cmp.Ui.Rules.NgMessageTypes.MinLength, Message: translation.Core$MinLengthShort });
						}
						if (!Cmp.Js.IsNullOrUndefined(scopeAsTextbox.NgMaxlength)) {
							scopeAsTextbox.CustomNgMessages.push({ MessageType: Cmp.Ui.Rules.NgMessageTypes.MaxLength, Message: translation.Core$MaxLengthExceeded });
						}
						resolve();
					});
			});
		};

		link = (scope: IntegerScope | angular.IScope, element: angular.IAugmentedJQuery, attrs: angular.IAttributes) => {
			this._linkAsPromise(scope, element, attrs);
		};

		templateUrl: string = Cmp.Ui.Components.TextboxTemplateUrl;
		restrict: string = 'E';
	}

	angular
		.module('cmp.ui.components')
		.directive('cmpInteger', CmpInteger.Instance);

}
