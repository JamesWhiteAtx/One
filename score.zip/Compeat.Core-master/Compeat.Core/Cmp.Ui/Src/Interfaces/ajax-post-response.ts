﻿
namespace Cmp.Ui.Interfaces {

    export interface IAjaxPostResponse {
        ColumnValues: string[][];
        Data: any;
        Message: string;
        ResponseData: string;
        ReturnUrl: string;
        SessionExpired: boolean;
        Succeeded: boolean;
        SuccessPath: string;
        FailurePath: string;
    }
}