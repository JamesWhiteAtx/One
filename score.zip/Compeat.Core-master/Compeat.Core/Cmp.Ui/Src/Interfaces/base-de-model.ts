﻿/// <reference path="../bases/base-bo-model.ts" />

namespace Cmp.Ui.Interfaces {

    export interface IBaseDeModel extends Cmp.Ui.Bases.IBaseBoModel, Cmp.Js.Types.ICmpIdable {
        id: number | string;
        [index: string]: any;
    }
}