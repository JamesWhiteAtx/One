﻿namespace Cmp.Ui.Interfaces {

    /** Describes an object that knows how to serialize itself to json */
    export interface IJsonable {
		/** serializes the model to a json object */
        ToJson(): Object;
    }

}