﻿namespace Cmp.Ui.Interfaces {
	/** we often have to pass types around so they can be instantiated with the 'new' keyword, this makes it a bit more clear */
	export interface IConstructor extends Function { }
}