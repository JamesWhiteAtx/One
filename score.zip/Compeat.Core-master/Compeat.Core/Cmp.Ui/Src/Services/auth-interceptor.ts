﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="services-module.ts" />
/// <reference path="base-tools.ts" />

namespace Cmp.Ui.Services {

    /** This class inspects for authorization failures and redirects the user to the login page
	*/
    export class AuthInterceptor {

        public static AUTH401_BROADCAST = 'Auth401';

        /*@ngInject*/
        constructor(
            private $rootScope: angular.IRootScopeService,
            private cmpPromise: Cmp.Ui.Services.PromiseService) {
        }

        private BroadcastAuthFailure() {
            var rootScope: angular.IRootScopeService = this.$rootScope;
            rootScope.$broadcast(AuthInterceptor.AUTH401_BROADCAST);
        }

        private RejectResponse(response: any): cmp.IPromise<any> {
            var cmpPromise: Cmp.Ui.Services.PromiseService = this.cmpPromise;
            return cmpPromise.Reject(response);
        }

        /** 
            do not rename this function, it must be 'response'
            the interceptors don't seem to be strongly typed by angular yet, the IHttpPromiseCallbackArg matches response exactly however 
            these signatures must use the fat arrow to have class 'this' context
        */
        public response = (response: angular.IHttpPromiseCallbackArg<any>): any => {
            if (response.status === 401) {
                this.BroadcastAuthFailure();
                return this.RejectResponse(response);
            }
            else {
                return response;
            }
        }

        /** 
            do not rename this function, it must be 'responseError'
            I can not find any official documentation on what to expect from rejection 
            these signatures must use the fat arrow to have class 'this' context
        */
        public responseError = (rejection: any) : any => {
            if (rejection.status === 401) {
                this.BroadcastAuthFailure();
            }
            return this.RejectResponse(rejection);
        }
    }

    angular.module('cmp.ui.services').service('authInterceptor', AuthInterceptor);
}