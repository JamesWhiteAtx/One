﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="services-module.ts" />

namespace Cmp.Ui.Services {


    export interface IPromiseService {

        /** 
        Creates and returns a new promise
        */
        Promise<TReturnType>(callback: (resolve: (value?: TReturnType) => void, reject: (error?: any) => void) => void): cmp.IPromise<TReturnType>;
        
        /** 
        Creates and resolved promise
        */
        Resolve<TReturnType>(value?: TReturnType): cmp.IPromise<TReturnType>;
    
        /** 
        Creates and rejected promise
        */
        Reject<TReturnType>(error: any): cmp.IPromise<TReturnType>;
        
        /**
            a promise that returns after all the promises passed in are returned
        */
        All(promises: Array<cmp.IPromise<any>>): cmp.IPromise<any>;
    }


    /** 
        Wraps the a promise type up in an es6 friendly way to avoid usage that will conflict later
    */
    export class PromiseService implements IPromiseService {

        private _$q: angular.IQService;
        /*@ngInject*/
        constructor($q: angular.IQService) {
            this._$q = $q;
        }

        /** 
        Creates and returns a new promise
        */
        public Promise<TReturnType>(callback: (resolve: (value?: TReturnType) => void, reject: (error?: any) => void) => void): cmp.IPromise<TReturnType> {
            return new this._$q<TReturnType>(callback);
        }
        
        /** 
        Creates and resolved promise
        */
	    public Resolve<TReturnType>(value?: TReturnType): cmp.IPromise<TReturnType> {
            return this._$q.when(value);
        }
    
        /** 
        Creates and rejected promise
        */
        public Reject<TReturnType>(error: any): cmp.IPromise<TReturnType> {
            return this._$q.reject(error);
        }
        
        /**
            a promise that returns after all the promises passed in are returned
        */
        public All(promises: Array<cmp.IPromise<any>>): cmp.IPromise<any> {
            return this._$q.all(<Array<angular.IPromise<any>>>promises);
        }
    }

    angular.module('cmp.ui.services').service('cmpPromise', PromiseService);

}