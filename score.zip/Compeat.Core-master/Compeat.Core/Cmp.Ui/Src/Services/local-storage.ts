﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="services-module.ts" />

namespace Cmp.Ui.Services {

    /** this service can store in localStorage */
    export class LocalStorageService {

		/*@ngInject*/
        constructor() { }
        
        private Read(path: string): any {
            var text: string = localStorage.getItem(path);
            return Cmp.Js.IsNullOrUndefined(text) ? null : text            
        }

        private Write(path: string, text: string): void {
            localStorage.setItem(path, text);
        }

        public ReadObject<T>(path: any): T {
            var text: any = this.Read(path);
            var data: T;
            try {
                data = <T>JSON.parse(text);
           } catch (error) {
                data = null;
            }
            return data;
        }

        public WriteObject(path: string, data: any): void {
            var text: string = JSON.stringify(data);
            this.Write(path, text);
        }

        public Remove(path: string): void {
            localStorage.removeItem(path);
        }

        public Clear(): void {
            localStorage.clear();
        }
	}

	angular.module('cmp.ui.services').service('localStorage', LocalStorageService);
}