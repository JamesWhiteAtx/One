﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="services-module.ts" />
/// <reference path="promise.ts" />

namespace Cmp.Ui.Services {

    
    /** A global busy state indicator.  The busy state will be enabled anytime MarkBusy has been executed more often than MarkIdle */
    export interface IBusyIndicator {
        /** Marks the indicator service as busy */
        MarkBusy: () => void;

        /** Marks the indicator service as busy, without a time out delay */
        MarkBusyImediate: () => void;
        
        /** Marks the indicator service as idle */
        MarkIdle: () => void;
        
        /** True if MarkBusy has been run more often than MarkIdle */
        IsBusy: boolean;
    }

    export class _BusyIndicator {

        private _requests: number = 0;
        private _loadingClass: string = 'loading';
        private _$timeout: angular.ITimeoutService;

        /*@ngInject*/
        constructor($timeout: angular.ITimeoutService) {

            this._$timeout = $timeout;
        }

        public MarkBusy = () => {

            var self = this;
            self._requests++;

            self._$timeout(() => {
                if (self._requests >= 1
                    && !$("body").hasClass(self._loadingClass)) {

                    $("body").addClass(self._loadingClass);
                }
            }, 500);
        }

        public MarkBusyImediate = () => {

            var self = this;
            self._requests++;

            if (self._requests >= 1
                && !$("body").hasClass(self._loadingClass)) {

                $("body").addClass(self._loadingClass);
            }
        }

        public MarkIdle = () => {

            var self = this;
            if (self._requests > 0) {
                self._requests--;
            }
            if (self._requests === 0) {
                $("body").removeClass(self._loadingClass);
            }
        }

        public get IsBusy() : boolean {
            return this._requests >= 1;
        }
    }

    angular.module('cmp.ui.services').service('busyIndicator', _BusyIndicator);
}