﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="services-module.ts" />

namespace Cmp.Ui.Services {

    /** 
        A servers that exposes the http header so a consumer can modify it if needed
    */
    export interface IHttpheader {
        /**
            returns the object that is sent as the header on all requests
        */
        GetHeaderObject(): { [objName: string]: any; };
    }

    export class _HttpHeader {
        /*@ngInject*/
        constructor(private $http: angular.IHttpService) { }
        
        public GetHeaderObject(): { [objName: string]: any; }  {
			var self = this;
            return self.$http.defaults && self.$http.defaults.headers && self.$http.defaults.headers.common ? self.$http.defaults.headers.common : undefined;
        }
    }

    angular.module('cmp.ui.services').service('cmpHttpHeader', _HttpHeader);
}