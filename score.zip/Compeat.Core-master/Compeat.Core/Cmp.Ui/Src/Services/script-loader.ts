﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="services-module.ts" />
/// <reference path="../providers/version-provider.ts" />
/// <reference path="promise.ts" />

namespace Cmp.Ui.Services {

    /** provider that can be used to pull scripts from a server */
    export interface IScriptLoaderService {
        /** pulls the script from the url passed in */
        LoadScript: (scriptUrl: string) => cmp.IPromise<void>;
    }

    export class _ScriptLoaderService  implements IScriptLoaderService {

        private _cmpVersion: Cmp.Ui.Providers.VersionProvider;
        private _cmpPromise: Cmp.Ui.Services.PromiseService;

		/*@ngInject*/
        constructor(cmpVersion: Cmp.Ui.Providers.VersionProvider,
            cmpPromise: Cmp.Ui.Services.PromiseService) {

            this._cmpVersion = cmpVersion;
            this._cmpPromise = cmpPromise;
        }

        public LoadScript = (scriptUrl: string): cmp.IPromise<void> => {

			// convert the url based on whether debug or release and the current release number, for cache busting
            scriptUrl = this._cmpVersion.VersionedUrl(scriptUrl);

			return this._cmpPromise.Promise<void>((resolve, reject): void => {
                jQuery.ajax(
                    {
                        url: scriptUrl,
                        dataType: "script",
                        cache: true,
                        success: (script, textStatus, jqxhr) => {
                            resolve();
                        }
                    })
                    .fail((jqxhr, settings, exception) => {
                        reject(exception);
                    });
			});
		}
	}

    angular.module('cmp.ui.providers').service('scriptLoader', _ScriptLoaderService);
} 