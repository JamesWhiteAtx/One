﻿namespace Cmp.Ui.Services {
	angular.module('cmp.ui.services', [
		'ui.router'
	]);
}