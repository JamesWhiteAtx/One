﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="services-module.ts" />
/// <reference path="../services/data-service.ts" />
/// <reference path="http-header.ts" />

namespace Cmp.Ui.Services {

    /** A result type for checkToken */
    export class CheckTokenResult {
        constructor(
            public Success: boolean,
            public Token: string) {
        }
    }

    /** A helper function for checking the token in route configuration */
    export function CheckToken(
        dataService: Cmp.Ui.Services.IDataService,
        cmpPromise: Cmp.Ui.Services.PromiseService): cmp.IPromise<CheckTokenResult> {

        return cmpPromise.Promise<CheckTokenResult>((resolve, reject): void => {
            dataService.GetData<string>('Authentication/GetToken', {}).then((result: string): void => {
                if (result && result.length) {
                    resolve(new CheckTokenResult(true, result));
                } else {
                    resolve(new CheckTokenResult(false, ''));
                }
            }, (): void => {
                resolve(new CheckTokenResult(false, ''));
            });
        });
    }

    /** 
        A service to hold the auth token from the server
    */
    export interface IHttpToken {
        Token: string;
        SetToken: (token: string) => void;
        CheckToken: () => cmp.IPromise<CheckTokenResult>;
    }

    export class _HttpToken {

        public Token: string;
        private _cmpHttpHeader: Cmp.Ui.Services.IHttpheader;
        private _dataService: Cmp.Ui.Services.IDataService;
        private _cmpPromise: Cmp.Ui.Services.PromiseService;

        /*@ngInject*/
        constructor(
            cmpHttpHeader: Cmp.Ui.Services.IHttpheader,
            dataService: Cmp.Ui.Services.IDataService,
            cmpPromise: Cmp.Ui.Services.PromiseService) {

            var self = this;
            self._cmpHttpHeader = cmpHttpHeader;
            self._dataService = dataService;
            self._cmpPromise = cmpPromise;
        }
        
        /**
            Sets the auth token
        */
        public SetToken = (token: string) => {
            this.Token = token;
			var header = this._cmpHttpHeader.GetHeaderObject();
			header["token"] = token;
        }

        /**
            Asks the server for the token, if available
        */
        public CheckToken = (): cmp.IPromise<CheckTokenResult> => {
            var self = this;
            return Cmp.Ui.Services.CheckToken(this._dataService, this._cmpPromise)
                .then((value: CheckTokenResult) => {
                    if (value.Success) {
                        self.SetToken(value.Token);
                    }
                    return value;
                });
        }
    }

    angular.module('cmp.ui.services').service('cmpHttpToken', _HttpToken);
}