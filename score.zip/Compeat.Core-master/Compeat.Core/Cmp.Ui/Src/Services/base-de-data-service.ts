﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="services-module.ts" />
/// <reference path="promise.ts" />
/// <reference path="../interfaces/ajax-post-response.ts" />
/// <reference path="../interfaces/constructor.ts" />
/// <reference path="logger.ts" />
/// <reference path="../bases/base-de-controller.ts" />

namespace Cmp.Ui.Services {
		
	/** 
			access to a set of core services used often, 
			made to make model and controller injection shareable and simple
	*/
	export interface IBaseDeDataService<TEditModelType extends Cmp.Ui.Interfaces.IBaseDeModel,
		TListModelType extends Cmp.Js.Types.ICmpIdable> {
		/** */
		GetRecord(controller: Cmp.Ui.Bases.BaseDeController<TEditModelType, TListModelType>): cmp.IPromise<TEditModelType>;
	}

	export class _BaseDeDataService<TEditModelType extends Cmp.Ui.Interfaces.IBaseDeModel,
		TListModelType extends Cmp.Js.Types.ICmpIdable> implements IBaseDeDataService<TEditModelType, TListModelType> {


		/*@ngInject*/
		constructor(
			private $stateParams: angular.ui.IStateParamsService,
			private cmpPromise: Cmp.Ui.Services.IPromiseService,
			private baseTools: Cmp.Ui.Services.IBaseTools,
			private $timeout: angular.ITimeoutService) { }
				
		public GetRecord(controller: Cmp.Ui.Bases.BaseDeController<TEditModelType, TListModelType>): cmp.IPromise<TEditModelType>{
			var self = this;
			var id = self.$stateParams["id"];
			return self.cmpPromise.Promise<TEditModelType>((resolve, reject) => {
				if (id === "-1") {
					// create a new record

					// combobox binding was not working on new records unless there was an async here
					self.$timeout(() => {
						controller.Model = self.baseTools.CreateInstance<TEditModelType>(controller.GetConstructor());
						if (controller.SetNewRecordDefaults) {
							controller.SetNewRecordDefaults(controller.Model);
						}
						controller.GetRecordDone(controller.Model).then((model) => {
							resolve(model);
						}, reject);
					});
				} else {
					var url = controller.GetByIdUrl(controller);
					var args: any = controller.GetByIdArgs(controller, id);
					// edit an existing record
					controller.GetRecordData(url, args, controller.GetConstructor()).then(
						(result) => {
							controller.Model = result;
							controller.GetRecordDone(controller.Model).then((model) => {
								resolve(model);
							}, reject);
							//logger.Info("data loaded");
						}, reject);
				}
			})
		}
	}

	angular.module('cmp.ui.services').service('baseDeDataService', _BaseDeDataService);
}