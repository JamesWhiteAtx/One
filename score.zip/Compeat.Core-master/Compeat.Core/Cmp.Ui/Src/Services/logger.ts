﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="services-module.ts" />

namespace Cmp.Ui.Services {

	/** a logging service integrated with toastr for easy display in the ui */
	export interface ILoggerService {

		/** logs an error */
        Error: (message: string, data?: any) => void;

		/** logs an message */
		Info: (message: string, data?: any) => void;

		/** logs a success message */
		Success: (message: string, data?: any) => void;

		/** logs a warning */
		Warning: (message: string, data?: any) => void;
	}

	/** a logging service integrated with toastr for easy display in the ui */
	export class LoggerService implements ILoggerService {
		private _$log: angular.ILogService;
		private _toastr: Toastr;
		/*@ngInject*/
		constructor(
			$log: angular.ILogService,
			toastr: Toastr) {
			var self = this;
			self._$log = $log;
			self._toastr = toastr;

		}

		/** logs an error */
        public Error = (message: string, data?: any) => {
            // suppress 401 responses, they will already redirect the user to the login screen
            // by the authorization interceptor
            if (!data
                || data.status != 401) {

                this._toastr.error(message);
            }
			this._$log.error('Error: ' + message, data);
		}

		/** logs an message */
		public Info = (message: string, data?: any) => {
			this._toastr.info(message);
			this._$log.info('Info: ' + message, data);
		}

		/** logs a success message */
		public Success = (message: string, data?: any) => {
			this._toastr.success(message);
			this._$log.info('Success: ' + message, data);
		}

		/** logs a warning */
		public Warning = (message: string, data?: any) => {
			this._toastr.warning(message);
			this._$log.warn('Warning: ' + message, data);
        }
	}

	angular.module('cmp.ui.services').service('logger', LoggerService);

}