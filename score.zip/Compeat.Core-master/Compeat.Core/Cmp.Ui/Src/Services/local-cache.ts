﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="services-module.ts" />
/// <reference path="../services/data-service.ts" />
/// <reference path="promise.ts" />

namespace Cmp.Ui.Services {
	export interface ILocalCachePaths<CT> {
		GetPromisePath(key: CacheKey<CT>): string;
	}

	export interface ILocalCache<CT> {
		ClearWholeCache: () => void;
		GetCachePromise: <TReturnType>(iPaths: ILocalCachePaths<CT>, key: CacheKey<CT>, args?: any, classObj?: Function) => cmp.IPromise<TReturnType>;
	}

	/** A promise store, once a promise is cached it is possible to retreive its result later */
	export class _LocalCache<CT> implements ILocalCache<CT> {

		private _cache: Cmp.Js.Types.IStringMap<cmp.IPromise<any>>;
		private _dataService: Cmp.Ui.Services.IDataService;
		private _cmpPromise: Cmp.Ui.Services.PromiseService;
		
		/*@ngInject*/
		constructor(dataService: Cmp.Ui.Services.IDataService, cmpPromise: Cmp.Ui.Services.PromiseService) {
			var self = this;
			self.ClearWholeCache();
			self._dataService = dataService;
			self._cmpPromise = cmpPromise;
		}
				
		/** 
		@classObj {class} If the return object needs to be converted to a class, this is the class itself. if not defined, the raw object is passed back
		*/
		public GetCachePromise = <TReturnType>(iPaths: ILocalCachePaths<CT>, key: CacheKey<CT>, args?: any, classObj?: Function): cmp.IPromise<TReturnType> => {
			var self = this;
			var _guid = key.Guid();
			if (!self.GetCacheItem(_guid)) {
				var promise = self._cmpPromise.Promise<TReturnType>((resolve, reject): void => {
					self._dataService
						.GetData<TReturnType>(iPaths.GetPromisePath(key), args ? args : undefined, classObj)
						.then((data) => {
							resolve(data);
						}, () => {
							self.SetCacheItem(_guid, undefined);//clear the promise so new calls get a new one
							reject();
						});
				});
				self.SetCacheItem(_guid, promise);
			}
			return self.GetCacheItem(_guid);
		}

		private SetCacheItem = (guid: string, value: any) => {
			this._cache[guid] = value;
		}

		private GetCacheItem = (guid: string) => {
			return this._cache[guid];
		}

		/**
		clears all cached items
		*/
		public ClearWholeCache = () => {
			this._cache = {};
		}
	}

	angular.module('cmp.ui.services').service('cmpLocalCache', _LocalCache);

	/** an object that is meant to be unique to each caching type store combo */
	export class CacheKey<CT> {
		private _cacheType: CT;
		private _storeNum: number;
		private _strVal1: string;

		private _guid: string;

		constructor(cacheType: CT) {
			this._cacheType = cacheType;
		}

		/** returns this cache key's unique id */
		public Guid = (): string => {
			if (this._guid) {
				return this._guid;
			} else {
				this._guid = this._cacheType.toString() + (this._storeNum || this._storeNum == 0 ? '-' + this._storeNum.toString() : '') + (this._strVal1 ? '-' + this._strVal1 : '');
				return this._guid;
			}
		}

		get StoreNum(): number {
			return this._storeNum;
		}
		set StoreNum(value: number) {
			if (value !== this._storeNum) {
				this._guid = undefined;//reset since it changed
			}
			this._storeNum = value;
		}

		get StrVal1(): string {
			return this._strVal1;
		}
		set StrVal1(value: string) {
			if (value !== this._strVal1) {
				this._guid = undefined;//reset since it changed
			}
			this._strVal1 = value;
		}

		get CacheType(): CT {
			return this._cacheType;
		}
		set CacheType(value: CT) {
			if (value !== this._cacheType) {
				this._guid = undefined;//reset since it changed
			}
			this._cacheType = value;
		}
	}
}