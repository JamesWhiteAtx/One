﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="services-module.ts" />
/// <reference path="promise.ts" />
/// <reference path="../app/cmp-enums.ts" />
/// <reference path="../app/cmp-app-info.ts" />

namespace Cmp.Ui.Services {

	/** 
	  access to a set of core services used often, 
	  made to make model and controller injection shareable and simple
	*/
    export interface ICmpTools {

        /** Returns todays date with no time */
        Today: () => Date;

        /** return turns the first day of the week relative to the seedDate passd in*/
        GetFirstDayOfWeek: (seedDate: Date, firstDayOfWeek: Cmp.Ui.Enums.DayOfWeek) => Date;

        /** return turns the last day of the week relative to the seedDate passd in*/
        GetLastDayOfWeek: (seedDate: Date, firstDayOfWeek: Cmp.Ui.Enums.DayOfWeek) => Date;

		/** converts a date from utc to browser time */
        GetBrowserTimeFromUTC: (utcDate: Date) => Date;

        /** converts a date from browser to utc time */
        GetUTCFromBrowserTime: (browserDate: Date) => Date;
    }

    /** 
        access to a set of core services used often, 
        made to make model and controller injection shareable and simple
    */
    export class CmpTools implements ICmpTools {

        /*@ngInject*/
        constructor() {
        }
        
        /** Returns todays date with no time */
        public Today = (): Date => {
            var today = new Date();
            today.setHours(0, 0, 0, 0);
            return today;
        };

        /** return turns the first day of the week relative to the seedDate passd in*/
        public GetFirstDayOfWeek = (seedDate: Date, firstDayOfWeek: Cmp.Ui.Enums.DayOfWeek): Date => {
            if (seedDate) {
                var isoStartDate = moment(seedDate);
                if (isoStartDate.isValid()) {
                    isoStartDate = isoStartDate //returns as iso 8601 date, which means the date is a monday 
                        .startOf('isoWeek')
                        .add(firstDayOfWeek - 1, 'd');
                    return isoStartDate.toDate();
                } else {
                    return seedDate;
                }
            } else {
                return seedDate;
            }
        }

        /** return turns the last day of the week relative to the seedDate passd in*/
        public GetLastDayOfWeek = (seedDate: Date, firstDayOfWeek: Cmp.Ui.Enums.DayOfWeek): Date => {
			if (seedDate) {
				var firstDateOfWeek = this.GetFirstDayOfWeek(seedDate, firstDayOfWeek);
				return moment(firstDateOfWeek)
					.add(6, 'd')
					.toDate();
			} else {
				return seedDate;
			}
        }

	    /** converts a date from utc to browser time */
        public GetBrowserTimeFromUTC = (utcDate: Date): Date => {
            if (utcDate) {
                var formattedUtc: string = moment.utc(utcDate).format('MM/DD/YYYY hh:mm:ss');
                var localized = moment(formattedUtc, 'MM/DD/YYYY hh:mm:ss').toDate();
                return localized;
            } else {
                return utcDate;
            }
        }

        /** converts a date from browser to utc time */
        public GetUTCFromBrowserTime = (browserDate: Date): Date => {
            if (browserDate) {
                return moment.utc(browserDate).toDate();
            } else {
                return browserDate;
            }
        }
    }

    angular.module('cmp.ui.services').service('cmpTools', CmpTools);
}