﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="services-module.ts" />
/// <reference path="promise.ts" />
/// <reference path="../interfaces/ajax-post-response.ts" />
/// <reference path="../interfaces/constructor.ts" />
/// <reference path="logger.ts" />

namespace Cmp.Ui.Services {
		
	/** 
			access to a set of core services used often, 
			made to make model and controller injection shareable and simple
	*/
	export interface IBaseTools {
		/** calls $rootScope.$apply(); */
		RefreshObservers: () => cmp.IPromise<any>;
		/** 
				uses the angular injector to create and instance of the class object passed in 
				@classObj {class} Should be the class definition that the instance is needed for.
		*/
		CreateInstance: <T>(classObj: Cmp.Ui.Interfaces.IConstructor) => T;
		/** an instance of the promise service for convenience */
		CmpPromise: Cmp.Ui.Services.IPromiseService;
		/** 
				uses the angular injector to get an instance of the required service
				@name Should be the name of the service, i.e. "$location".
		*/
		GetInstance: <T>(name: string) => T;
		/** Process a typical ajax response */
		ProcessAjaxResponse: (response: Cmp.Ui.Interfaces.IAjaxPostResponse, codeToRun?: Function) => void;
		/** Return a value from a typical ajax response */
		ReturnAjaxResponse: <T>(response: Cmp.Ui.Interfaces.IAjaxPostResponse, codeToRun?: Function) => T;
		/**
		 Returns a new instance of a class after calling LoadFromRaw if its defined on the class
		 */
		GetFilledInstance<TReturnType>(url: string, rawData: any, classObj: Cmp.Ui.Interfaces.IConstructor): TReturnType;
	}

	export class _BaseTools implements IBaseTools {

		public CmpPromise: Cmp.Ui.Services.IPromiseService;

		/*@ngInject*/
		constructor(
			private $rootScope: angular.IRootScopeService,
			private $injector: angular.auto.IInjectorService,
			private $timeout: angular.ITimeoutService,
			private cmpPromise: Cmp.Ui.Services.IPromiseService) {

			this.CmpPromise = cmpPromise;
		}
				
		public RefreshObservers = () => {
			var self = this;
			return self.$timeout(() => {
				self.$rootScope.$apply();
			});
		}
				
		public CreateInstance<T>(classObj: Cmp.Ui.Interfaces.IConstructor) {
			return <T>this.$injector.instantiate(classObj);
		}

		public GetInstance<T>(name: string): any {
			return <T>this.$injector.get(name);
		}

		public GetFilledInstance<TReturnType>(url: string, rawData: any, classObj: Cmp.Ui.Interfaces.IConstructor): TReturnType {
			var self = this;
			var newInstance = self.CreateInstance<TReturnType>(classObj);
			if ((<any>newInstance).LoadFromRaw) {
				(<any>newInstance).LoadFromRaw(url, rawData);
			}
			return <TReturnType>newInstance;
		}

		public ProcessAjaxResponse = (response: Cmp.Ui.Interfaces.IAjaxPostResponse, codeToRun?: Function): void => {
			var self = this;

			var timeout = self.GetInstance<angular.ITimeoutService>("$timeout");
			var location = self.GetInstance<angular.ILocationService>("$location");
			var state = self.GetInstance<angular.ui.IStateService>("$state");
			var logger = self.GetInstance<Cmp.Ui.Services.LoggerService>("logger");

			if (response.Succeeded) {
				if (codeToRun) {
					codeToRun();
				} else {
					logger.Success(response.Message);

					// if they passed in a path, then go to it now that the action has succeeded
					if (response.SuccessPath) {
						location.path(response.SuccessPath);
						timeout(() => {
							state.reload();
						});
					}
				}
			} else {
				logger.Error(response.Message);

				// if they passed in a path, then go to it now that the action has failed
				if (response.FailurePath) {
					location.path(response.FailurePath);
					timeout(() => {
						state.reload();
					});
				}
			}
		}

		public ReturnAjaxResponse = <T>(response: Cmp.Ui.Interfaces.IAjaxPostResponse, codeToRun?: Function): T => {
			var self = this;

			var logger = self.GetInstance<Cmp.Ui.Services.LoggerService>("logger");

			if (response.Succeeded) {
				if (codeToRun) {
					return codeToRun();
				} else {
					logger.Success(response.Message);

					return <T>response.Data;
				}
			} else {
				logger.Error(response.Message);

				return <T>response.Data;
			}
		}

	}

	angular.module('cmp.ui.services').service('baseTools', _BaseTools);
}