﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="services-module.ts" />
/// <reference path="base-tools.ts" />
/// <reference path="logger.ts" />
/// <reference path="../interfaces/jsonable.ts" />
/// <reference path="../models/cmp-data-set.ts" />
/// <reference path="../interfaces/constructor.ts" />

namespace Cmp.Ui.Services {

	/** 
	All interaction with the server should happen through this service
*/
	export interface IDataService {

		/** 
				does a POST to the server using the url specified and can return an injected object
				@payload {any} the information to pass to the server
				@returnTypeClassObj {class} If the return object needs to be converted to a class, this is the class itself. if not defined, the raw object is passed back
		*/
		GetData: <TReturnType>(url: string, payload: any, classObj?: Cmp.Ui.Interfaces.IConstructor) => cmp.IPromise<TReturnType>;

		SendData: <TSendType, TReturnType>(url: string, payload: TSendType, returnTypeClassObj?: Cmp.Ui.Interfaces.IConstructor) => cmp.IPromise<TReturnType>;

		/** Sends an item that implements IJsonable to apply better client to server serialization */
		SendModel: <TReturnType>(url: string, model: Cmp.Ui.Interfaces.IJsonable, returnTypeClassObj?: Cmp.Ui.Interfaces.IConstructor) => cmp.IPromise<TReturnType>;

		/** 
				does a POST to the server using the url specified
				@payload {any} the information to pass to the server
				@classObj {class} If the return object needs to be converted to a class, this is the class itself. 
		*/
		GetDataList: <TReturnModelType>(url: string, payload: any, classObj: Cmp.Ui.Interfaces.IConstructor) => cmp.IPromise<Array<TReturnModelType>>;

		/** 
				does a POST to the server using the url specified
				@payload {any} the information to pass to the server
				@classObj {class} If the return object needs to be converted to a class, this is the class itself. 
		*/
        GetCmpDataSet: <TReturnModelType>(url: string, payload: any, classObj: Cmp.Ui.Interfaces.IConstructor) => cmp.IPromise<Cmp.Ui.Models.CmpDataSet<TReturnModelType>>;
	}

	/** Exposed only for unit testing */
	export class _DataService implements IDataService {

		private _$http: angular.IHttpService;
		private _baseTools: Cmp.Ui.Services.IBaseTools;
		private _logger: Cmp.Ui.Services.LoggerService;

		/*@ngInject*/
		constructor($http: angular.IHttpService, baseTools: Cmp.Ui.Services.IBaseTools, logger: Cmp.Ui.Services.LoggerService) {
			var self = this;
			self._$http = $http;
			self._baseTools = baseTools;
			self._logger = logger;
		}

		public GetData = <TReturnType>(url: string, payload: any, classObj?: Cmp.Ui.Interfaces.IConstructor): cmp.IPromise<TReturnType> => {
			return this.Send<any, TReturnType>(url, payload, classObj);
		};

		public SendData = <TSendType, TReturnType>(url: string, payload: TSendType, returnTypeClassObj?: Cmp.Ui.Interfaces.IConstructor): cmp.IPromise<TReturnType> => {
			return this.Send<TSendType, TReturnType>(url, payload, returnTypeClassObj);
		};

		public SendModel = <TReturnType>(url: string, model: Cmp.Ui.Interfaces.IJsonable, returnTypeClassObj?: Cmp.Ui.Interfaces.IConstructor): cmp.IPromise<TReturnType> => {
			return this.Send<Object, TReturnType>(url, model.ToJson(), returnTypeClassObj);
		};

		public GetDataList = <TReturnModelType>(url: string, payload: any, classObj: Cmp.Ui.Interfaces.IConstructor): cmp.IPromise<Array<TReturnModelType>> => {
			return this.SendReturnList<any, TReturnModelType>(url, payload, classObj);
		};

        public GetCmpDataSet = <TReturnModelType>(url: string, payload: any, classObj: Cmp.Ui.Interfaces.IConstructor): cmp.IPromise<Cmp.Ui.Models.CmpDataSet<TReturnModelType>> => {
			return this.SendReturnPagedList<any, TReturnModelType>(url, payload, classObj);
		};

		// does a POST to the server using the url specified
		private Send = <TSendType, TReturnType>(url: string, payload: TSendType, classObj: Cmp.Ui.Interfaces.IConstructor): cmp.IPromise<TReturnType> => {
			var self = this;

			return self._baseTools.CmpPromise.Promise<TReturnType>(
				(resolve: (incoming: TReturnType) => void, reject: any): void => {
					self._$http
						.post(url, payload)
						.then((incomingData: ng.IHttpPromiseCallbackArg<TReturnType>): void => {
							if (!Cmp.Js.IsNullOrUndefined(classObj) && !Cmp.Js.IsNullOrUndefined(incomingData.data)) {
								resolve(self._baseTools.GetFilledInstance<TReturnType>(url, incomingData.data, classObj));
							} else {
								resolve(incomingData.data);
							}
						}, (incomingData: ng.IHttpPromiseCallbackArg<TReturnType>) => {
							self._logger.Error((incomingData.statusText ? incomingData.statusText : (incomingData.status + ': ' + url)), incomingData);
							reject(incomingData);
						});
				});
		};

		private SendReturnList = <TSendType, TReturnType>(url: string, payload: TSendType, classObj: Cmp.Ui.Interfaces.IConstructor): cmp.IPromise<Array<TReturnType>> => {
			var self = this;

			return self._baseTools.CmpPromise.Promise<Array<TReturnType>>(
				(resolve: (incoming: Array<TReturnType>) => void, reject: any): void => {
					self._$http
						.post(url, payload)
						.then((incomingData: ng.IHttpPromiseCallbackArg<Array<TReturnType>>): void => {
							if (incomingData.data && incomingData.data.length) {
								var listData = incomingData.data;
								//run through angular injector
								var returnList = new Array<TReturnType>();
								for (var counter: number = 0; counter < listData.length; counter++) {
									returnList.push(self._baseTools.GetFilledInstance<TReturnType>(url, listData[counter], classObj));
								}
								resolve(returnList);
							} else {
								resolve(incomingData.data);
							}
						}, (incomingData: ng.IHttpPromiseCallbackArg<Array<TReturnType>>) => {
							self._logger.Error((incomingData.statusText ? incomingData.statusText : (incomingData.status + ': ' + url)), incomingData);
							reject(null);
						});
				});
		};

        private SendReturnPagedList = <TSendType, TReturnType>(url: string, payload: TSendType, classObj: Cmp.Ui.Interfaces.IConstructor): cmp.IPromise<Cmp.Ui.Models.CmpDataSet<TReturnType>> => {
			var self = this;

            return self._baseTools.CmpPromise.Promise<Cmp.Ui.Models.CmpDataSet<TReturnType>>(
                (resolve: (incoming: Cmp.Ui.Models.CmpDataSet<TReturnType>) => void, reject: any): void => {
					self._$http
						.post(url, payload)
                        .then((incomingData: ng.IHttpPromiseCallbackArg<Cmp.Ui.Models.CmpDataSet<TReturnType>>): void => {
							if (incomingData.data && incomingData.data.RowCount && incomingData.data.Data && incomingData.data.Data.length) {
								var listData = incomingData.data.Data;
								//run through angular injector
								var returnList = new Array<TReturnType>();
								for (var counter: number = 0; counter < listData.length; counter++) {
									returnList.push(self._baseTools.GetFilledInstance<TReturnType>(url, listData[counter], classObj));
								}
                                resolve(new Cmp.Ui.Models.CmpDataSet<TReturnType>(incomingData.data.RowCount, returnList));
							} else {
								resolve(incomingData.data);
							}
						}, (incomingData: ng.IHttpPromiseCallbackArg<TReturnType>) => {
							self._logger.Error((incomingData.statusText ? incomingData.statusText : (incomingData.status + ': ' + url)), incomingData);
							reject(null);
						});
				});
		};

	}

	angular.module('cmp.ui.services').service('dataService', _DataService);
}