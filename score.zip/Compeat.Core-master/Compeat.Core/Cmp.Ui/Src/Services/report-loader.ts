﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="services-module.ts" />
/// <reference path="../Features/report-nav-helpers.ts" />

namespace Cmp.Ui.Services {

    /** this service can load reports into a new browser tab/window */
	export class ReportLoader {
		/*@ngInject*/
		constructor() { }
        
		/** Creates a new empty browser window and injects a report request into contents. */
		public OpenReportLoaderWindow = (requestModel: Cmp.Ui.ReportModels.ReportRequestModel) => {
			Cmp.Ui.ReportNavHelpers.OpenReportLoaderWindow(requestModel);
		}
	}

	angular.module('cmp.ui.services').service('cmpReportLoader', ReportLoader);
}