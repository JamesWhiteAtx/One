﻿using Compeat.Data;
using Compeat.Demo.Data.Shared;

namespace Compeat.Demo.Data
{
	public partial interface IRepository : ISavableRepository
	{
		SharedRepository Shr { get; set; }
	}
}
