﻿using Compeat.Data.Framework.InternalUtils;
using Compeat.Demo.Data.Shared;

namespace Compeat.Demo.Data
{
	/// <summary>
	/// This repository houses the data elements in schemas other than 'shr'
	/// </summary>
	public partial class Repository : RepositoryBase, IRepository
	{
		public virtual SharedRepository Shr { get; set; }

		public Repository()
		{
			Shr = new SharedRepository();
        }
	}
}
