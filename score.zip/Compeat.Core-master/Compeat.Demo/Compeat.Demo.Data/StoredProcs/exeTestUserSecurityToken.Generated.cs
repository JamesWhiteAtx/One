﻿using Compeat.Data.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Compeat.Data.Framework.InternalUtils;
using Compeat.Demo.Data.Shared;
namespace Compeat.Demo.Data {

	#region Business Object
    
	/// <summary>
	/// Proc [exeTestUserSecurityToken] has no expected output, this class exists if the timeout needs to be overriden(see public GetTimeout in SqlBase)
	/// </summary>
	[Serializable]
	public partial class exeTestUserSecurityTokenDto : ProcBase {
		public exeTestUserSecurityTokenDto(){ }
	
		/// <summary>
		/// calls its instanced twin in cases where a static is needed
		/// </summary>
		/// <returns></returns>
		internal static int MyTimeout() {
			return (new Compeat.Demo.Data.exeTestUserSecurityTokenDto()).GetTimeout();
		}
		
		protected override string ObjName
		{
			get
			{
				return Compeat.Demo.Data.exeTestUserSecurityToken.PROC_NAME;
			}
		}
	}
	
	#endregion

	public partial class exeTestUserSecurityToken {
		internal const string PROC_NAME = "dbo.exeTestUserSecurityToken";
	
		#region Repo Turn Around
		/// <summary>
		/// Executes the procedure and returns nothing. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// Returns the number of rows affected
		/// </summary>
		public virtual int ExecuteOnly(SqlConnection conn, int? userid, Guid? currenttoken, ref bool? tokensmatch) {
			return _ExecuteOnly(conn,  userid,  currenttoken, ref  tokensmatch);
		}
		#endregion
	
		/// <summary>
		/// Executes the procedure and returns nothing. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// Returns the number of rows affected
		/// </summary>
		internal static int _ExecuteOnly(SqlConnection conn, int? userid, Guid? currenttoken, ref bool? tokensmatch) {
			int __retVal = 0;
			_ExecNow(
				(__parameters) => { __retVal = InternalTools.ProcRun(Compeat.Demo.Data.exeTestUserSecurityToken.PROC_NAME, conn, __parameters, Compeat.Demo.Data.exeTestUserSecurityTokenDto.MyTimeout());  } //runs after params set 
				,  userid,  currenttoken, ref  tokensmatch
			);
			return __retVal;
		}
		

		internal static void _ExecNow(Action<SqlParameter[]> __to_run, int? userid, Guid? currenttoken, ref bool? tokensmatch) {
			var __parameters = new SqlParameter[3];
			__parameters[0] = InternalTools.MakeParam("@userid", SqlDbType.Int, userid, true, ParameterDirection.Input);
			__parameters[1] = InternalTools.MakeParam("@currenttoken", SqlDbType.UniqueIdentifier, currenttoken, true, ParameterDirection.Input);
			__parameters[2] = InternalTools.MakeParam("@tokensmatch", SqlDbType.Bit, tokensmatch, true, ParameterDirection.InputOutput);
			__to_run(__parameters);
			
			tokensmatch = __parameters[2].Value == DBNull.Value ? (bool?)null : (bool?)__parameters[2].Value;
		}
	}
	
	#region Repository needs
	public partial interface IRepository {
		Compeat.Demo.Data.exeTestUserSecurityToken exeTestUserSecurityToken { get; }
	}

	public partial class Repository {
		private Compeat.Demo.Data.exeTestUserSecurityToken _exeTestUserSecurityToken = null;
		public Compeat.Demo.Data.exeTestUserSecurityToken exeTestUserSecurityToken {
			get {
				if(_exeTestUserSecurityToken == null) {
					_exeTestUserSecurityToken = new Compeat.Demo.Data.exeTestUserSecurityToken();
				}
				return _exeTestUserSecurityToken;
			}
		}
	}
	#endregion Repository needs
}
