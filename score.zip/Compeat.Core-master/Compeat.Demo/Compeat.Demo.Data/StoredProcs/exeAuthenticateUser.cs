﻿using Compeat.Data.Framework;
using Compeat.Data.Framework.InternalUtils;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Compeat.Demo.Data.Shared;
namespace Compeat.Demo.Data {
	public partial class exeAuthenticateUserDto {

	}
	
	public partial class exeAuthenticateUserDtoList {
	}
} 

