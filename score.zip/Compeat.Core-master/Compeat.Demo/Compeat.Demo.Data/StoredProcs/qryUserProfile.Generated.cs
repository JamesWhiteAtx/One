﻿using Compeat.Data.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Compeat.Data.Framework.InternalUtils;
using Compeat.Demo.Data.Shared;
namespace Compeat.Demo.Data {

	#region Business Object
    
	/// <summary>
	/// This is the first of [1] possible exiting result set(s) from the proc called [qryUserProfile]
	/// </summary>
	[Serializable]
	public partial class qryUserProfileDto : ProcBase {
		public qryUserProfileDto(){ }
	
		/// <summary>
		/// calls its private twin in cases where a static is needed
		/// </summary>
		/// <returns></returns>
		internal static int MyTimeout() {
			return (new Compeat.Demo.Data.qryUserProfileDto()).GetTimeout();
		}
		private int? _userid{ get; set; }
		public virtual int? userid { 
			get { return _userid; } 
			set { _userid = value; }
		}
		private byte[] _recstamp{ get; set; }
		public virtual string recstamp { 
			get { 
				return _recstamp == null ? null : Convert.ToBase64String(_recstamp); 
			}
			set {
				if(string.IsNullOrWhiteSpace(value)){
					_recstamp = null;
				}
				else{
					_recstamp = Convert.FromBase64String(value);
				}
			}
		}
		private string _username{ get; set; }
		public virtual string username { 
			get { return _username; } 
			set { _username = value; }
		}
		private string _fullname{ get; set; }
		public virtual string fullname { 
			get { return _fullname; } 
			set { _fullname = value; }
		}
		private string _description{ get; set; }
		public virtual string description { 
			get { return _description; } 
			set { _description = value; }
		}
		private string _password{ get; set; }
		public virtual string password { 
			get { return _password; } 
			set { _password = value; }
		}
		private string _lang{ get; set; }
		public virtual string lang { 
			get { return _lang; } 
			set { _lang = value; }
		}

		#region Loader  	  

		internal void Fill(SqlDataReader dr) {
			this._userid = (dr.IsDBNull(qryUserProfile.RESULT_INDEX_userid) ? (int?)null : dr.GetInt32(qryUserProfile.RESULT_INDEX_userid));
			this._recstamp = (byte[])(dr.IsDBNull(qryUserProfile.RESULT_INDEX_recstamp) ? (byte[])null : dr.GetValue(qryUserProfile.RESULT_INDEX_recstamp));
			this._username = (dr.IsDBNull(qryUserProfile.RESULT_INDEX_username) ? null : dr.GetString(qryUserProfile.RESULT_INDEX_username));
			this._fullname = (dr.IsDBNull(qryUserProfile.RESULT_INDEX_fullname) ? null : dr.GetString(qryUserProfile.RESULT_INDEX_fullname));
			this._description = (dr.IsDBNull(qryUserProfile.RESULT_INDEX_description) ? null : dr.GetString(qryUserProfile.RESULT_INDEX_description));
			this._password = (dr.IsDBNull(qryUserProfile.RESULT_INDEX_password) ? null : dr.GetString(qryUserProfile.RESULT_INDEX_password));
			this._lang = (dr.IsDBNull(qryUserProfile.RESULT_INDEX_lang) ? null : dr.GetString(qryUserProfile.RESULT_INDEX_lang));
		}
		
		#endregion Loader
		protected override string ObjName
		{
			get
			{
				return Compeat.Demo.Data.qryUserProfile.PROC_NAME;
			}
		}
	}
		
	

	[Serializable]
	public partial class qryUserProfileDtoList : List<Compeat.Demo.Data.qryUserProfileDto> { }
	#endregion

	public partial class qryUserProfile {
		internal const string PROC_NAME = "dbo.qryUserProfile";
		internal const int RESULT_INDEX_userid = 0, RESULT_INDEX_recstamp = 1, RESULT_INDEX_username = 2, RESULT_INDEX_fullname = 3, RESULT_INDEX_description = 4, RESULT_INDEX_password = 5, RESULT_INDEX_lang = 6;
	
		#region Repo Turn Around
		/// <summary>
		/// Executes the procedure and returns nothing. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// Returns the number of rows affected
		/// </summary>
		public virtual int ExecuteOnly(SqlConnection conn, int? userid) {
			return _ExecuteOnly(conn,  userid);
		}
	
		/// <summary>
		/// Executes the procedure and returns a single qryUserProfile. The reader will stop after pulling the first row since its a stored proc
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual Compeat.Demo.Data.qryUserProfileDto GetFirst(SqlConnection conn, int? userid) {
			return _GetFirst<Compeat.Demo.Data.qryUserProfileDto>(conn,  userid);
		}    	
		/// <summary>
		/// Executes the procedure and returns a single qryUserProfile. The reader will stop after pulling the first row since its a stored proc
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual Compeat.Demo.Data.qryUserProfileDto GetFirst<TItemType>(SqlConnection conn, int? userid) 
			where TItemType: Compeat.Demo.Data.qryUserProfileDto, new()
		{
			return _GetFirst<TItemType>(conn,  userid);
		}    

		/// <summary>
		/// Executes the procedure and returns a qryUserProfile. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual Compeat.Demo.Data.qryUserProfileDtoList GetList(SqlConnection conn, int? userid) {
			return _GetList<Compeat.Demo.Data.qryUserProfileDto, Compeat.Demo.Data.qryUserProfileDtoList>(conn,  userid);
		}
		/// <summary>
		/// Executes the procedure and returns a qryUserProfile. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual TCollectionType GetList<TItemType, TCollectionType>(SqlConnection conn, int? userid) 
			where TItemType: Compeat.Demo.Data.qryUserProfileDto, new()
			where TCollectionType: List<TItemType>, new()
		{
			return _GetList<TItemType, TCollectionType>(conn,  userid);
		}
		/// <summary>
		/// Executes the procedure and returns a [int?] which is the type and value of the first column of the first row of the results. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual int? GetScalar(SqlConnection conn, int? userid) {
			return _GetScalar(conn,  userid);
		}
		#endregion
	
		/// <summary>
		/// Executes the procedure and returns nothing. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// Returns the number of rows affected
		/// </summary>
		internal static int _ExecuteOnly(SqlConnection conn, int? userid) {
			int __retVal = 0;
			_ExecNow(
				(__parameters) => { __retVal = InternalTools.ProcRun(Compeat.Demo.Data.qryUserProfile.PROC_NAME, conn, __parameters, Compeat.Demo.Data.qryUserProfileDto.MyTimeout());  } //runs after params set 
				,  userid
			);
			return __retVal;
		}
		
	
		/// <summary>
		/// Executes the procedure and returns a single qryUserProfile. The reader will stop after pulling the first row since its a stored proc
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		internal static TItemType _GetFirst<TItemType>(SqlConnection conn, int? userid) 
			where TItemType: Compeat.Demo.Data.qryUserProfileDto, new()
		{
			var ret = _GetList<TItemType, List<TItemType>>(1, conn,  userid);
			if(ret != null){
				return ret.FirstOrDefault();
			}
			else{
				return null;
			}
		}    
		
		
		/// <summary>
		/// Executes the procedure and returns a qryUserProfile. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		internal static TCollectionType _GetList<TItemType, TCollectionType>(SqlConnection conn, int? userid) 
			where TItemType: Compeat.Demo.Data.qryUserProfileDto, new()
			where TCollectionType: List<TItemType>, new()
		{
			return _GetList<TItemType, TCollectionType>(ulong.MaxValue, conn,  userid);
		}
		
		
		internal static TCollectionType _GetList<TItemType, TCollectionType>(ulong __rows_to_read, SqlConnection conn, int? userid) 
			where TItemType: Compeat.Demo.Data.qryUserProfileDto, new()
			where TCollectionType: List<TItemType>, new()
		{
			var __retVal = new TCollectionType();
		
			_ExecNow(
				(__parameters) => { 
						InternalTools.ProcRunReader(Compeat.Demo.Data.qryUserProfile.PROC_NAME, conn, __parameters,
							(sdr) => {
								if (sdr.HasRows) {
									ulong rCnt = 0;
									while (sdr.Read()) {
										var newVal = new TItemType();
										newVal.Fill(sdr);
										__retVal.Add(newVal);
										if(++rCnt >= __rows_to_read) {
											break;
										}
									}
								}
							}
							, Compeat.Demo.Data.qryUserProfileDto.MyTimeout()
						);  //runs after params set
					}  
				,  userid
			);
			
			return __retVal;
		}
		/// <summary>
		/// Executes the procedure and returns a [int?] which is the type and value of the first column of the first row of the results. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		internal static int? _GetScalar(SqlConnection conn, int? userid) {
			int? __retVal = default(int?);
			_ExecNow(
				(__parameters) => { __retVal = InternalTools.ProcRunScalar<int?>(Compeat.Demo.Data.qryUserProfile.PROC_NAME, conn, __parameters, Compeat.Demo.Data.qryUserProfileDto.MyTimeout());  } //runs after params set 
				,  userid
			);
			return __retVal;
		}

		internal static void _ExecNow(Action<SqlParameter[]> __to_run, int? userid) {
			var __parameters = new SqlParameter[1];
			__parameters[0] = InternalTools.MakeParam("@userid", SqlDbType.Int, userid, true, ParameterDirection.Input);
			__to_run(__parameters);
			
		}
	}
	
	#region Repository needs
	public partial interface IRepository {
		Compeat.Demo.Data.qryUserProfile qryUserProfile { get; }
	}

	public partial class Repository {
		private Compeat.Demo.Data.qryUserProfile _qryUserProfile = null;
		public Compeat.Demo.Data.qryUserProfile qryUserProfile {
			get {
				if(_qryUserProfile == null) {
					_qryUserProfile = new Compeat.Demo.Data.qryUserProfile();
				}
				return _qryUserProfile;
			}
		}
	}
	#endregion Repository needs
}
