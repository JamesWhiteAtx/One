﻿//#define IsSavableProc
using Compeat.Data.Framework;
using Compeat.Data.Framework.InternalUtils;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Compeat.Demo.Data.Shared;
namespace Compeat.Demo.Data {
	public partial class qryUserRightsDto {

		#region Savable Implementation
		
		#if IsSavableProc
		
		//if the stock savable functionality is used, then this should return the table name to save to
		protected override string StockSaveTableName {
			get {
				throw new NotImplementedException();
				//return "TABLE_NAME"; //table name for the writing statements
			}
		}
		
		protected override bool HasPkSet {
			get {
				//change to return true if a pk is known, so the save function knows to call the update. 
				return false;
			}
		}

		private List<SqlParamHolder> __parameters { get; set;}
		protected override IEnumerable<SqlParamHolder> MyParameters {
			get {
				if(__parameters == null) {
				   __parameters = new List<SqlParamHolder>() {
						new SqlParamHolder(){ColumnName = "restaurantinventoryitems_menu", ParameterName = "@restaurantinventoryitems_menu", MyParamGetter = () => { return InternalTools.MakeParam("@restaurantinventoryitems_menu", SqlDbType.Bit, _restaurantinventoryitems_menu, true); } }, 
						new SqlParamHolder(){ColumnName = "eeocdefs_menu", ParameterName = "@eeocdefs_menu", MyParamGetter = () => { return InternalTools.MakeParam("@eeocdefs_menu", SqlDbType.Bit, _eeocdefs_menu, true); } }, 
						new SqlParamHolder(){ColumnName = "masterinventorylisting_report", ParameterName = "@masterinventorylisting_report", MyParamGetter = () => { return InternalTools.MakeParam("@masterinventorylisting_report", SqlDbType.Bit, _masterinventorylisting_report, true); } }, 
						new SqlParamHolder(){ColumnName = "restaurantinventorylisting_report", ParameterName = "@restaurantinventorylisting_report", MyParamGetter = () => { return InternalTools.MakeParam("@restaurantinventorylisting_report", SqlDbType.Bit, _restaurantinventorylisting_report, true); } }, 
						new SqlParamHolder(){ColumnName = "reports_menu", ParameterName = "@reports_menu", MyParamGetter = () => { return InternalTools.MakeParam("@reports_menu", SqlDbType.Bit, _reports_menu, true); } }, 
						new SqlParamHolder(){ColumnName = "setup_menu", ParameterName = "@setup_menu", MyParamGetter = () => { return InternalTools.MakeParam("@setup_menu", SqlDbType.Bit, _setup_menu, true); } }, 
						new SqlParamHolder(){ColumnName = "birthday_report", ParameterName = "@birthday_report", MyParamGetter = () => { return InternalTools.MakeParam("@birthday_report", SqlDbType.Bit, _birthday_report, true); } }, 
						new SqlParamHolder(){ColumnName = "weekly_schedule_report", ParameterName = "@weekly_schedule_report", MyParamGetter = () => { return InternalTools.MakeParam("@weekly_schedule_report", SqlDbType.Bit, _weekly_schedule_report, true); } } 
					};  			  
				}
				return __parameters;
			}
		}
		
		protected override void Update(SqlConnection conn) { 
			StockProcUpdate(conn); //will use StockSaveTableName and MyParameters to build an update statement where IsPrimaryKey is true
			
			////Or you can make your own below:
			//InternalTools.ScriptRun("your update sql here", conn, new SqlParameter[] { /*parms here*/ }, GetTimeout());
		}
		
		protected override void Insert(SqlConnection conn) { 
			StockProcInsert(conn); //will use StockSaveTableName and MyParameters to build an insert statement
			
			////Or you can make your own below:
			//InternalTools.ScriptRun("your insert sql here", conn, new SqlParameter[] { /*parms here*/ }, GetTimeout());
		}
		
		protected override void Delete(SqlConnection conn) { 
			StockProcDelete(conn);//will use StockSaveTableName and MyParameters to build a delete statement where IsPrimaryKey is true
			
			////Or you can make your own below:
			//InternalTools.ScriptRun("your delete sql here", conn, new SqlParameter[] { /*parms here*/ }, GetTimeout());
			
		}
		
		#endif
		
		#endregion

	}
	
	public partial class qryUserRightsDtoList {
	}
} 

