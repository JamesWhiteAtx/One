﻿//#define IsSavableProc
using Compeat.Data.Framework;
using Compeat.Data.Framework.InternalUtils;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Compeat.Demo.Data.Shared;
namespace Compeat.Demo.Data {
	public partial class rptBirthdaysDto {

		#region Savable Implementation
		
		#if IsSavableProc
		
		//if the stock savable functionality is used, then this should return the table name to save to
		protected override string StockSaveTableName {
			get {
				throw new NotImplementedException();
				//return "TABLE_NAME"; //table name for the writing statements
			}
		}
		
		protected override bool HasPkSet {
			get {
				//change to return true if a pk is known, so the save function knows to call the update. 
				return false;
			}
		}

		private List<SqlParamHolder> __parameters { get; set;}
		protected override IEnumerable<SqlParamHolder> MyParameters {
			get {
				if(__parameters == null) {
				   __parameters = new List<SqlParamHolder>() {
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "empname", ParameterName = "@empname", MyParamGetter = () => { return InternalTools.MakeParam("@empname", SqlDbType.VarChar, empname, true, 303); } }, 
						new SqlParamHolder(){ColumnName = "birthdate", ParameterName = "@birthdate", MyParamGetter = () => { return InternalTools.MakeParam("@birthdate", SqlDbType.DateTime, _birthdate, true); } } 
					};  			  
				}
				return __parameters;
			}
		}
		
		protected override void Update(SqlConnection conn) { 
			StockProcUpdate(conn); //will use StockSaveTableName and MyParameters to build an update statement where IsPrimaryKey is true
			
			////Or you can make your own below:
			//InternalTools.ScriptRun("your update sql here", conn, new SqlParameter[] { /*parms here*/ }, GetTimeout());
		}
		
		protected override void Insert(SqlConnection conn) { 
			StockProcInsert(conn); //will use StockSaveTableName and MyParameters to build an insert statement
			
			////Or you can make your own below:
			//InternalTools.ScriptRun("your insert sql here", conn, new SqlParameter[] { /*parms here*/ }, GetTimeout());
		}
		
		protected override void Delete(SqlConnection conn) { 
			StockProcDelete(conn);//will use StockSaveTableName and MyParameters to build a delete statement where IsPrimaryKey is true
			
			////Or you can make your own below:
			//InternalTools.ScriptRun("your delete sql here", conn, new SqlParameter[] { /*parms here*/ }, GetTimeout());
			
		}
		
		#endif
		
		#endregion

	}
	
	public partial class rptBirthdaysDtoList {
	}
} 

