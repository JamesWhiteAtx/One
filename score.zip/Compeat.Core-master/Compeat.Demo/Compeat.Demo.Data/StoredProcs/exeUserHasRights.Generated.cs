﻿using Compeat.Data.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Compeat.Data.Framework.InternalUtils;
using Compeat.Demo.Data.Shared;
namespace Compeat.Demo.Data {

	#region Business Object
    
	/// <summary>
	/// Proc [exeUserHasRights] has no expected output, this class exists if the timeout needs to be overriden(see public GetTimeout in SqlBase)
	/// </summary>
	[Serializable]
	public partial class exeUserHasRightsDto : ProcBase {
		public exeUserHasRightsDto(){ }
	
		/// <summary>
		/// calls its instanced twin in cases where a static is needed
		/// </summary>
		/// <returns></returns>
		internal static int MyTimeout() {
			return (new Compeat.Demo.Data.exeUserHasRightsDto()).GetTimeout();
		}
		
		protected override string ObjName
		{
			get
			{
				return Compeat.Demo.Data.exeUserHasRights.PROC_NAME;
			}
		}
	}
	
	#endregion

	public partial class exeUserHasRights {
		internal const string PROC_NAME = "dbo.exeUserHasRights";
	
		#region Repo Turn Around
		/// <summary>
		/// Executes the procedure and returns nothing. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// Returns the number of rows affected
		/// </summary>
		public virtual int ExecuteOnly(SqlConnection conn, int? userid, string rights, ref bool? has_rights) {
			return _ExecuteOnly(conn,  userid,  rights, ref  has_rights);
		}
		#endregion
	
		/// <summary>
		/// Executes the procedure and returns nothing. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// Returns the number of rows affected
		/// </summary>
		internal static int _ExecuteOnly(SqlConnection conn, int? userid, string rights, ref bool? has_rights) {
			int __retVal = 0;
			_ExecNow(
				(__parameters) => { __retVal = InternalTools.ProcRun(Compeat.Demo.Data.exeUserHasRights.PROC_NAME, conn, __parameters, Compeat.Demo.Data.exeUserHasRightsDto.MyTimeout());  } //runs after params set 
				,  userid,  rights, ref  has_rights
			);
			return __retVal;
		}
		

		internal static void _ExecNow(Action<SqlParameter[]> __to_run, int? userid, string rights, ref bool? has_rights) {
			var __parameters = new SqlParameter[3];
			__parameters[0] = InternalTools.MakeParam("@userid", SqlDbType.Int, userid, true, ParameterDirection.Input);
			__parameters[1] = InternalTools.MakeParam("@rights", SqlDbType.VarChar, rights, true, 4000, ParameterDirection.Input);
			__parameters[2] = InternalTools.MakeParam("@has_rights", SqlDbType.Bit, has_rights, true, ParameterDirection.InputOutput);
			__to_run(__parameters);
			
			has_rights = __parameters[2].Value == DBNull.Value ? (bool?)null : (bool?)__parameters[2].Value;
		}
	}
	
	#region Repository needs
	public partial interface IRepository {
		Compeat.Demo.Data.exeUserHasRights exeUserHasRights { get; }
	}

	public partial class Repository {
		private Compeat.Demo.Data.exeUserHasRights _exeUserHasRights = null;
		public Compeat.Demo.Data.exeUserHasRights exeUserHasRights {
			get {
				if(_exeUserHasRights == null) {
					_exeUserHasRights = new Compeat.Demo.Data.exeUserHasRights();
				}
				return _exeUserHasRights;
			}
		}
	}
	#endregion Repository needs
}
