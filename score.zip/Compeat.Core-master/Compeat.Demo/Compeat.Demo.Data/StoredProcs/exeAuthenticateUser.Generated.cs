﻿using Compeat.Data.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Compeat.Data.Framework.InternalUtils;
using Compeat.Demo.Data.Shared;
namespace Compeat.Demo.Data {

	#region Business Object
    
	/// <summary>
	/// Proc [exeAuthenticateUser] has no expected output, this class exists if the timeout needs to be overriden(see public GetTimeout in SqlBase)
	/// </summary>
	[Serializable]
	public partial class exeAuthenticateUserDto : ProcBase {
		public exeAuthenticateUserDto(){ }
	
		/// <summary>
		/// calls its instanced twin in cases where a static is needed
		/// </summary>
		/// <returns></returns>
		internal static int MyTimeout() {
			return (new Compeat.Demo.Data.exeAuthenticateUserDto()).GetTimeout();
		}
		
		protected override string ObjName
		{
			get
			{
				return Compeat.Demo.Data.exeAuthenticateUser.PROC_NAME;
			}
		}
	}
	
	#endregion

	public partial class exeAuthenticateUser {
		internal const string PROC_NAME = "dbo.exeAuthenticateUser";
	
		#region Repo Turn Around
		/// <summary>
		/// Executes the procedure and returns nothing. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// Returns the number of rows affected
		/// </summary>
		public virtual int ExecuteOnly(SqlConnection conn, string username, string password, ref int? founduserid, ref int? founddefaultentity, ref byte? authresult, ref Guid? securitytoken) {
			return _ExecuteOnly(conn,  username,  password, ref  founduserid, ref  founddefaultentity, ref  authresult, ref  securitytoken);
		}
		#endregion
	
		/// <summary>
		/// Executes the procedure and returns nothing. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// Returns the number of rows affected
		/// </summary>
		internal static int _ExecuteOnly(SqlConnection conn, string username, string password, ref int? founduserid, ref int? founddefaultentity, ref byte? authresult, ref Guid? securitytoken) {
			int __retVal = 0;
			_ExecNow(
				(__parameters) => { __retVal = InternalTools.ProcRun(Compeat.Demo.Data.exeAuthenticateUser.PROC_NAME, conn, __parameters, Compeat.Demo.Data.exeAuthenticateUserDto.MyTimeout());  } //runs after params set 
				,  username,  password, ref  founduserid, ref  founddefaultentity, ref  authresult, ref  securitytoken
			);
			return __retVal;
		}
		

		internal static void _ExecNow(Action<SqlParameter[]> __to_run, string username, string password, ref int? founduserid, ref int? founddefaultentity, ref byte? authresult, ref Guid? securitytoken) {
			var __parameters = new SqlParameter[6];
			__parameters[0] = InternalTools.MakeParam("@username", SqlDbType.VarChar, username, true, 20, ParameterDirection.Input);
			__parameters[1] = InternalTools.MakeParam("@password", SqlDbType.VarChar, password, true, 250, ParameterDirection.Input);
			__parameters[2] = InternalTools.MakeParam("@founduserid", SqlDbType.Int, founduserid, true, ParameterDirection.InputOutput);
			__parameters[3] = InternalTools.MakeParam("@founddefaultentity", SqlDbType.Int, founddefaultentity, true, ParameterDirection.InputOutput);
			__parameters[4] = InternalTools.MakeParam("@authresult", SqlDbType.TinyInt, authresult, true, ParameterDirection.InputOutput);
			__parameters[5] = InternalTools.MakeParam("@securitytoken", SqlDbType.UniqueIdentifier, securitytoken, true, ParameterDirection.InputOutput);
			__to_run(__parameters);
			
			founduserid = __parameters[2].Value == DBNull.Value ? (int?)null : (int?)__parameters[2].Value;
			founddefaultentity = __parameters[3].Value == DBNull.Value ? (int?)null : (int?)__parameters[3].Value;
			authresult = __parameters[4].Value == DBNull.Value ? (byte?)null : (byte?)__parameters[4].Value;
			securitytoken = __parameters[5].Value == DBNull.Value ? (Guid?)null : (Guid?)__parameters[5].Value;
		}
	}
	
	#region Repository needs
	public partial interface IRepository {
		Compeat.Demo.Data.exeAuthenticateUser exeAuthenticateUser { get; }
	}

	public partial class Repository {
		private Compeat.Demo.Data.exeAuthenticateUser _exeAuthenticateUser = null;
		public Compeat.Demo.Data.exeAuthenticateUser exeAuthenticateUser {
			get {
				if(_exeAuthenticateUser == null) {
					_exeAuthenticateUser = new Compeat.Demo.Data.exeAuthenticateUser();
				}
				return _exeAuthenticateUser;
			}
		}
	}
	#endregion Repository needs
}
