﻿using Compeat.Data.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Compeat.Data.Framework.InternalUtils;
using Compeat.Demo.Data.Shared;
namespace Compeat.Demo.Data {

	#region Business Object
    
	/// <summary>
	/// This is the first of [1] possible exiting result set(s) from the proc called [qryUserRights]
	/// </summary>
	[Serializable]
	public partial class qryUserRightsDto : ProcBase {
		public qryUserRightsDto(){ }
	
		/// <summary>
		/// calls its private twin in cases where a static is needed
		/// </summary>
		/// <returns></returns>
		internal static int MyTimeout() {
			return (new Compeat.Demo.Data.qryUserRightsDto()).GetTimeout();
		}
		private bool? _restaurantinventoryitems_menu{ get; set; }
		public virtual bool? restaurantinventoryitems_menu { 
			get { return _restaurantinventoryitems_menu; } 
			set { _restaurantinventoryitems_menu = value; }
		}
		private bool? _eeocdefs_menu{ get; set; }
		public virtual bool? eeocdefs_menu { 
			get { return _eeocdefs_menu; } 
			set { _eeocdefs_menu = value; }
		}
		private bool? _masterinventorylisting_report{ get; set; }
		public virtual bool? masterinventorylisting_report { 
			get { return _masterinventorylisting_report; } 
			set { _masterinventorylisting_report = value; }
		}
		private bool? _restaurantinventorylisting_report{ get; set; }
		public virtual bool? restaurantinventorylisting_report { 
			get { return _restaurantinventorylisting_report; } 
			set { _restaurantinventorylisting_report = value; }
		}
		private bool? _reports_menu{ get; set; }
		public virtual bool? reports_menu { 
			get { return _reports_menu; } 
			set { _reports_menu = value; }
		}
		private bool? _setup_menu{ get; set; }
		public virtual bool? setup_menu { 
			get { return _setup_menu; } 
			set { _setup_menu = value; }
		}
		private bool? _birthday_report{ get; set; }
		public virtual bool? birthday_report { 
			get { return _birthday_report; } 
			set { _birthday_report = value; }
		}
		private bool? _weekly_schedule_report{ get; set; }
		public virtual bool? weekly_schedule_report { 
			get { return _weekly_schedule_report; } 
			set { _weekly_schedule_report = value; }
		}

		#region Loader  	  

		internal void Fill(SqlDataReader dr) {
			this._restaurantinventoryitems_menu = (dr.IsDBNull(qryUserRights.RESULT_INDEX_restaurantinventoryitems_menu) ? (bool?)null : dr.GetBoolean(qryUserRights.RESULT_INDEX_restaurantinventoryitems_menu));
			this._eeocdefs_menu = (dr.IsDBNull(qryUserRights.RESULT_INDEX_eeocdefs_menu) ? (bool?)null : dr.GetBoolean(qryUserRights.RESULT_INDEX_eeocdefs_menu));
			this._masterinventorylisting_report = (dr.IsDBNull(qryUserRights.RESULT_INDEX_masterinventorylisting_report) ? (bool?)null : dr.GetBoolean(qryUserRights.RESULT_INDEX_masterinventorylisting_report));
			this._restaurantinventorylisting_report = (dr.IsDBNull(qryUserRights.RESULT_INDEX_restaurantinventorylisting_report) ? (bool?)null : dr.GetBoolean(qryUserRights.RESULT_INDEX_restaurantinventorylisting_report));
			this._reports_menu = (dr.IsDBNull(qryUserRights.RESULT_INDEX_reports_menu) ? (bool?)null : dr.GetBoolean(qryUserRights.RESULT_INDEX_reports_menu));
			this._setup_menu = (dr.IsDBNull(qryUserRights.RESULT_INDEX_setup_menu) ? (bool?)null : dr.GetBoolean(qryUserRights.RESULT_INDEX_setup_menu));
			this._birthday_report = (dr.IsDBNull(qryUserRights.RESULT_INDEX_birthday_report) ? (bool?)null : dr.GetBoolean(qryUserRights.RESULT_INDEX_birthday_report));
			this._weekly_schedule_report = (dr.IsDBNull(qryUserRights.RESULT_INDEX_weekly_schedule_report) ? (bool?)null : dr.GetBoolean(qryUserRights.RESULT_INDEX_weekly_schedule_report));
		}
		
		#endregion Loader
		protected override string ObjName
		{
			get
			{
				return Compeat.Demo.Data.qryUserRights.PROC_NAME;
			}
		}
	}
		
	

	[Serializable]
	public partial class qryUserRightsDtoList : List<Compeat.Demo.Data.qryUserRightsDto> { }
	#endregion

	public partial class qryUserRights {
		internal const string PROC_NAME = "dbo.qryUserRights";
		internal const int RESULT_INDEX_restaurantinventoryitems_menu = 0, RESULT_INDEX_eeocdefs_menu = 1, RESULT_INDEX_masterinventorylisting_report = 2, RESULT_INDEX_restaurantinventorylisting_report = 3, RESULT_INDEX_reports_menu = 4, RESULT_INDEX_setup_menu = 5, RESULT_INDEX_birthday_report = 6, RESULT_INDEX_weekly_schedule_report = 7;
	
		#region Repo Turn Around
		/// <summary>
		/// Executes the procedure and returns nothing. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// Returns the number of rows affected
		/// </summary>
		public virtual int ExecuteOnly(SqlConnection conn, int? userid) {
			return _ExecuteOnly(conn,  userid);
		}
	
		/// <summary>
		/// Executes the procedure and returns a single qryUserRights. The reader will stop after pulling the first row since its a stored proc
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual Compeat.Demo.Data.qryUserRightsDto GetFirst(SqlConnection conn, int? userid) {
			return _GetFirst<Compeat.Demo.Data.qryUserRightsDto>(conn,  userid);
		}    	
		/// <summary>
		/// Executes the procedure and returns a single qryUserRights. The reader will stop after pulling the first row since its a stored proc
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual Compeat.Demo.Data.qryUserRightsDto GetFirst<TItemType>(SqlConnection conn, int? userid) 
			where TItemType: Compeat.Demo.Data.qryUserRightsDto, new()
		{
			return _GetFirst<TItemType>(conn,  userid);
		}    

		/// <summary>
		/// Executes the procedure and returns a qryUserRights. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual Compeat.Demo.Data.qryUserRightsDtoList GetList(SqlConnection conn, int? userid) {
			return _GetList<Compeat.Demo.Data.qryUserRightsDto, Compeat.Demo.Data.qryUserRightsDtoList>(conn,  userid);
		}
		/// <summary>
		/// Executes the procedure and returns a qryUserRights. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual TCollectionType GetList<TItemType, TCollectionType>(SqlConnection conn, int? userid) 
			where TItemType: Compeat.Demo.Data.qryUserRightsDto, new()
			where TCollectionType: List<TItemType>, new()
		{
			return _GetList<TItemType, TCollectionType>(conn,  userid);
		}
		/// <summary>
		/// Executes the procedure and returns a [bool?] which is the type and value of the first column of the first row of the results. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual bool? GetScalar(SqlConnection conn, int? userid) {
			return _GetScalar(conn,  userid);
		}
		#endregion
	
		/// <summary>
		/// Executes the procedure and returns nothing. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// Returns the number of rows affected
		/// </summary>
		internal static int _ExecuteOnly(SqlConnection conn, int? userid) {
			int __retVal = 0;
			_ExecNow(
				(__parameters) => { __retVal = InternalTools.ProcRun(Compeat.Demo.Data.qryUserRights.PROC_NAME, conn, __parameters, Compeat.Demo.Data.qryUserRightsDto.MyTimeout());  } //runs after params set 
				,  userid
			);
			return __retVal;
		}
		
	
		/// <summary>
		/// Executes the procedure and returns a single qryUserRights. The reader will stop after pulling the first row since its a stored proc
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		internal static TItemType _GetFirst<TItemType>(SqlConnection conn, int? userid) 
			where TItemType: Compeat.Demo.Data.qryUserRightsDto, new()
		{
			var ret = _GetList<TItemType, List<TItemType>>(1, conn,  userid);
			if(ret != null){
				return ret.FirstOrDefault();
			}
			else{
				return null;
			}
		}    
		
		
		/// <summary>
		/// Executes the procedure and returns a qryUserRights. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		internal static TCollectionType _GetList<TItemType, TCollectionType>(SqlConnection conn, int? userid) 
			where TItemType: Compeat.Demo.Data.qryUserRightsDto, new()
			where TCollectionType: List<TItemType>, new()
		{
			return _GetList<TItemType, TCollectionType>(ulong.MaxValue, conn,  userid);
		}
		
		
		internal static TCollectionType _GetList<TItemType, TCollectionType>(ulong __rows_to_read, SqlConnection conn, int? userid) 
			where TItemType: Compeat.Demo.Data.qryUserRightsDto, new()
			where TCollectionType: List<TItemType>, new()
		{
			var __retVal = new TCollectionType();
		
			_ExecNow(
				(__parameters) => { 
						InternalTools.ProcRunReader(Compeat.Demo.Data.qryUserRights.PROC_NAME, conn, __parameters,
							(sdr) => {
								if (sdr.HasRows) {
									ulong rCnt = 0;
									while (sdr.Read()) {
										var newVal = new TItemType();
										newVal.Fill(sdr);
										__retVal.Add(newVal);
										if(++rCnt >= __rows_to_read) {
											break;
										}
									}
								}
							}
							, Compeat.Demo.Data.qryUserRightsDto.MyTimeout()
						);  //runs after params set
					}  
				,  userid
			);
			
			return __retVal;
		}
		/// <summary>
		/// Executes the procedure and returns a [bool?] which is the type and value of the first column of the first row of the results. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		internal static bool? _GetScalar(SqlConnection conn, int? userid) {
			bool? __retVal = default(bool?);
			_ExecNow(
				(__parameters) => { __retVal = InternalTools.ProcRunScalar<bool?>(Compeat.Demo.Data.qryUserRights.PROC_NAME, conn, __parameters, Compeat.Demo.Data.qryUserRightsDto.MyTimeout());  } //runs after params set 
				,  userid
			);
			return __retVal;
		}

		internal static void _ExecNow(Action<SqlParameter[]> __to_run, int? userid) {
			var __parameters = new SqlParameter[1];
			__parameters[0] = InternalTools.MakeParam("@userid", SqlDbType.Int, userid, true, ParameterDirection.Input);
			__to_run(__parameters);
			
		}
	}
	
	#region Repository needs
	public partial interface IRepository {
		Compeat.Demo.Data.qryUserRights qryUserRights { get; }
	}

	public partial class Repository {
		private Compeat.Demo.Data.qryUserRights _qryUserRights = null;
		public Compeat.Demo.Data.qryUserRights qryUserRights {
			get {
				if(_qryUserRights == null) {
					_qryUserRights = new Compeat.Demo.Data.qryUserRights();
				}
				return _qryUserRights;
			}
		}
	}
	#endregion Repository needs
}
