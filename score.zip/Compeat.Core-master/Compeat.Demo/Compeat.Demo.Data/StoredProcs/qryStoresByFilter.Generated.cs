﻿using Compeat.Data.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Compeat.Data.Framework.InternalUtils;
using Compeat.Demo.Data.Shared;
namespace Compeat.Demo.Data {

	#region Business Object
    
	/// <summary>
	/// This is the first of [1] possible exiting result set(s) from the proc called [qryStoresByFilter]
	/// </summary>
	[Serializable]
	public partial class qryStoresByFilterDto : ProcBase {
		public qryStoresByFilterDto(){ }
	
		/// <summary>
		/// calls its private twin in cases where a static is needed
		/// </summary>
		/// <returns></returns>
		internal static int MyTimeout() {
			return (new Compeat.Demo.Data.qryStoresByFilterDto()).GetTimeout();
		}
		private int? _storenum{ get; set; }
		public virtual int? storenum { 
			get { return _storenum; } 
			set { _storenum = value; }
		}
		private string _storename{ get; set; }
		public virtual string storename { 
			get { return _storename; } 
			set { _storename = value; }
		}

		#region Loader  	  

		internal void Fill(SqlDataReader dr) {
			this._storenum = (dr.IsDBNull(qryStoresByFilter.RESULT_INDEX_storenum) ? (int?)null : dr.GetInt32(qryStoresByFilter.RESULT_INDEX_storenum));
			this._storename = (dr.IsDBNull(qryStoresByFilter.RESULT_INDEX_storename) ? null : dr.GetString(qryStoresByFilter.RESULT_INDEX_storename));
		}
		
		#endregion Loader
		protected override string ObjName
		{
			get
			{
				return Compeat.Demo.Data.qryStoresByFilter.PROC_NAME;
			}
		}
	}
		
	

	[Serializable]
	public partial class qryStoresByFilterDtoList : List<Compeat.Demo.Data.qryStoresByFilterDto> { }
	#endregion

	public partial class qryStoresByFilter {
		internal const string PROC_NAME = "dbo.qryStoresByFilter";
		internal const int RESULT_INDEX_storenum = 0, RESULT_INDEX_storename = 1;
	
		#region Repo Turn Around
		/// <summary>
		/// Executes the procedure and returns nothing. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// Returns the number of rows affected
		/// </summary>
		public virtual int ExecuteOnly(SqlConnection conn, int? userid) {
			return _ExecuteOnly(conn,  userid);
		}
	
		/// <summary>
		/// Executes the procedure and returns a single qryStoresByFilter. The reader will stop after pulling the first row since its a stored proc
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual Compeat.Demo.Data.qryStoresByFilterDto GetFirst(SqlConnection conn, int? userid) {
			return _GetFirst<Compeat.Demo.Data.qryStoresByFilterDto>(conn,  userid);
		}    	
		/// <summary>
		/// Executes the procedure and returns a single qryStoresByFilter. The reader will stop after pulling the first row since its a stored proc
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual Compeat.Demo.Data.qryStoresByFilterDto GetFirst<TItemType>(SqlConnection conn, int? userid) 
			where TItemType: Compeat.Demo.Data.qryStoresByFilterDto, new()
		{
			return _GetFirst<TItemType>(conn,  userid);
		}    

		/// <summary>
		/// Executes the procedure and returns a qryStoresByFilter. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual Compeat.Demo.Data.qryStoresByFilterDtoList GetList(SqlConnection conn, int? userid) {
			return _GetList<Compeat.Demo.Data.qryStoresByFilterDto, Compeat.Demo.Data.qryStoresByFilterDtoList>(conn,  userid);
		}
		/// <summary>
		/// Executes the procedure and returns a qryStoresByFilter. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual TCollectionType GetList<TItemType, TCollectionType>(SqlConnection conn, int? userid) 
			where TItemType: Compeat.Demo.Data.qryStoresByFilterDto, new()
			where TCollectionType: List<TItemType>, new()
		{
			return _GetList<TItemType, TCollectionType>(conn,  userid);
		}
		/// <summary>
		/// Executes the procedure and returns a [int?] which is the type and value of the first column of the first row of the results. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual int? GetScalar(SqlConnection conn, int? userid) {
			return _GetScalar(conn,  userid);
		}
		#endregion
	
		/// <summary>
		/// Executes the procedure and returns nothing. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// Returns the number of rows affected
		/// </summary>
		internal static int _ExecuteOnly(SqlConnection conn, int? userid) {
			int __retVal = 0;
			_ExecNow(
				(__parameters) => { __retVal = InternalTools.ProcRun(Compeat.Demo.Data.qryStoresByFilter.PROC_NAME, conn, __parameters, Compeat.Demo.Data.qryStoresByFilterDto.MyTimeout());  } //runs after params set 
				,  userid
			);
			return __retVal;
		}
		
	
		/// <summary>
		/// Executes the procedure and returns a single qryStoresByFilter. The reader will stop after pulling the first row since its a stored proc
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		internal static TItemType _GetFirst<TItemType>(SqlConnection conn, int? userid) 
			where TItemType: Compeat.Demo.Data.qryStoresByFilterDto, new()
		{
			var ret = _GetList<TItemType, List<TItemType>>(1, conn,  userid);
			if(ret != null){
				return ret.FirstOrDefault();
			}
			else{
				return null;
			}
		}    
		
		
		/// <summary>
		/// Executes the procedure and returns a qryStoresByFilter. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		internal static TCollectionType _GetList<TItemType, TCollectionType>(SqlConnection conn, int? userid) 
			where TItemType: Compeat.Demo.Data.qryStoresByFilterDto, new()
			where TCollectionType: List<TItemType>, new()
		{
			return _GetList<TItemType, TCollectionType>(ulong.MaxValue, conn,  userid);
		}
		
		
		internal static TCollectionType _GetList<TItemType, TCollectionType>(ulong __rows_to_read, SqlConnection conn, int? userid) 
			where TItemType: Compeat.Demo.Data.qryStoresByFilterDto, new()
			where TCollectionType: List<TItemType>, new()
		{
			var __retVal = new TCollectionType();
		
			_ExecNow(
				(__parameters) => { 
						InternalTools.ProcRunReader(Compeat.Demo.Data.qryStoresByFilter.PROC_NAME, conn, __parameters,
							(sdr) => {
								if (sdr.HasRows) {
									ulong rCnt = 0;
									while (sdr.Read()) {
										var newVal = new TItemType();
										newVal.Fill(sdr);
										__retVal.Add(newVal);
										if(++rCnt >= __rows_to_read) {
											break;
										}
									}
								}
							}
							, Compeat.Demo.Data.qryStoresByFilterDto.MyTimeout()
						);  //runs after params set
					}  
				,  userid
			);
			
			return __retVal;
		}
		/// <summary>
		/// Executes the procedure and returns a [int?] which is the type and value of the first column of the first row of the results. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		internal static int? _GetScalar(SqlConnection conn, int? userid) {
			int? __retVal = default(int?);
			_ExecNow(
				(__parameters) => { __retVal = InternalTools.ProcRunScalar<int?>(Compeat.Demo.Data.qryStoresByFilter.PROC_NAME, conn, __parameters, Compeat.Demo.Data.qryStoresByFilterDto.MyTimeout());  } //runs after params set 
				,  userid
			);
			return __retVal;
		}

		internal static void _ExecNow(Action<SqlParameter[]> __to_run, int? userid) {
			var __parameters = new SqlParameter[1];
			__parameters[0] = InternalTools.MakeParam("@userid", SqlDbType.Int, userid, true, ParameterDirection.Input);
			__to_run(__parameters);
			
		}
	}
	
	#region Repository needs
	public partial interface IRepository {
		Compeat.Demo.Data.qryStoresByFilter qryStoresByFilter { get; }
	}

	public partial class Repository {
		private Compeat.Demo.Data.qryStoresByFilter _qryStoresByFilter = null;
		public Compeat.Demo.Data.qryStoresByFilter qryStoresByFilter {
			get {
				if(_qryStoresByFilter == null) {
					_qryStoresByFilter = new Compeat.Demo.Data.qryStoresByFilter();
				}
				return _qryStoresByFilter;
			}
		}
	}
	#endregion Repository needs
}
