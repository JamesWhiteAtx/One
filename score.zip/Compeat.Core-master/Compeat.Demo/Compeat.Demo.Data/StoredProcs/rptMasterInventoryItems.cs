﻿//#define IsSavableProc
using Compeat.Data.Framework;
using Compeat.Data.Framework.InternalUtils;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Compeat.Demo.Data.Shared;
namespace Compeat.Demo.Data {
	public partial class rptMasterInventoryItemsDto {

		#region Savable Implementation
		
		#if IsSavableProc
		
		//if the stock savable functionality is used, then this should return the table name to save to
		protected override string StockSaveTableName {
			get {
				throw new NotImplementedException();
				//return "TABLE_NAME"; //table name for the writing statements
			}
		}
		
		protected override bool HasPkSet {
			get {
				//change to return true if a pk is known, so the save function knows to call the update. 
				return false;
			}
		}

		private List<SqlParamHolder> __parameters { get; set;}
		protected override IEnumerable<SqlParamHolder> MyParameters {
			get {
				if(__parameters == null) {
				   __parameters = new List<SqlParamHolder>() {
						new SqlParamHolder(){IsPrimaryKey = false, IsIdentity = false, ColumnName = "item_id", ParameterName = "@item_id", MyParamGetter = () => { return InternalTools.MakeParam("@item_id", SqlDbType.Int, item_id, true); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "item_description", ParameterName = "@item_description", MyParamGetter = () => { return InternalTools.MakeParam("@item_description", SqlDbType.VarChar, item_description, true, 123); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "item_description2", ParameterName = "@item_description2", MyParamGetter = () => { return InternalTools.MakeParam("@item_description2", SqlDbType.VarChar, item_description2, true, 30); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, IsIdentity = false, ColumnName = "shelf_life", ParameterName = "@shelf_life", MyParamGetter = () => { return InternalTools.MakeParam("@shelf_life", SqlDbType.Int, shelf_life, true); } }, 
						new SqlParamHolder(){ColumnName = "is_catch_weight", ParameterName = "@is_catch_weight", MyParamGetter = () => { return InternalTools.MakeParam("@is_catch_weight", SqlDbType.Bit, _is_catch_weight, true); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "level1_desc", ParameterName = "@level1_desc", MyParamGetter = () => { return InternalTools.MakeParam("@level1_desc", SqlDbType.VarChar, level1_desc, true, 30); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, IsIdentity = false, ColumnName = "level1_sort_order", ParameterName = "@level1_sort_order", MyParamGetter = () => { return InternalTools.MakeParam("@level1_sort_order", SqlDbType.Int, level1_sort_order, true); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "level2_desc", ParameterName = "@level2_desc", MyParamGetter = () => { return InternalTools.MakeParam("@level2_desc", SqlDbType.VarChar, level2_desc, true, 30); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, IsIdentity = false, ColumnName = "level2_sort_order", ParameterName = "@level2_sort_order", MyParamGetter = () => { return InternalTools.MakeParam("@level2_sort_order", SqlDbType.Int, level2_sort_order, true); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "level3_desc", ParameterName = "@level3_desc", MyParamGetter = () => { return InternalTools.MakeParam("@level3_desc", SqlDbType.VarChar, level3_desc, true, 30); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, IsIdentity = false, ColumnName = "level3_sort_order", ParameterName = "@level3_sort_order", MyParamGetter = () => { return InternalTools.MakeParam("@level3_sort_order", SqlDbType.Int, level3_sort_order, true); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "upc_code", ParameterName = "@upc_code", MyParamGetter = () => { return InternalTools.MakeParam("@upc_code", SqlDbType.VarChar, upc_code, true, 20); } }, 
						new SqlParamHolder(){ColumnName = "conversion_inventory_unit_qty", ParameterName = "@conversion_inventory_unit_qty", MyParamGetter = () => { return InternalTools.MakeParam("@conversion_inventory_unit_qty", SqlDbType.Decimal, conversion_inventory_unit_qty, true, 18, 6); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "conversion_inventory_unit_desc", ParameterName = "@conversion_inventory_unit_desc", MyParamGetter = () => { return InternalTools.MakeParam("@conversion_inventory_unit_desc", SqlDbType.VarChar, conversion_inventory_unit_desc, true, 15); } }, 
						new SqlParamHolder(){ColumnName = "conversion_base_qty", ParameterName = "@conversion_base_qty", MyParamGetter = () => { return InternalTools.MakeParam("@conversion_base_qty", SqlDbType.Decimal, conversion_base_qty, true, 18, 6); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "conversion_base_description", ParameterName = "@conversion_base_description", MyParamGetter = () => { return InternalTools.MakeParam("@conversion_base_description", SqlDbType.VarChar, conversion_base_description, true, 15); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, IsIdentity = false, ColumnName = "coupon_value", ParameterName = "@coupon_value", MyParamGetter = () => { return InternalTools.MakeParam("@coupon_value", SqlDbType.Int, coupon_value, true); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "base_unit_description", ParameterName = "@base_unit_description", MyParamGetter = () => { return InternalTools.MakeParam("@base_unit_description", SqlDbType.VarChar, base_unit_description, true, 15); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "notes", ParameterName = "@notes", MyParamGetter = () => { return InternalTools.MakeParam("@notes", SqlDbType.NVarChar, notes, true, 2147483647); } } 
					};  			  
				}
				return __parameters;
			}
		}
		
		protected override void Update(SqlConnection conn) { 
			StockProcUpdate(conn); //will use StockSaveTableName and MyParameters to build an update statement where IsPrimaryKey is true
			
			////Or you can make your own below:
			//InternalTools.ScriptRun("your update sql here", conn, new SqlParameter[] { /*parms here*/ }, GetTimeout());
		}
		
		protected override void Insert(SqlConnection conn) { 
			StockProcInsert(conn); //will use StockSaveTableName and MyParameters to build an insert statement
			
			////Or you can make your own below:
			//InternalTools.ScriptRun("your insert sql here", conn, new SqlParameter[] { /*parms here*/ }, GetTimeout());
		}
		
		protected override void Delete(SqlConnection conn) { 
			StockProcDelete(conn);//will use StockSaveTableName and MyParameters to build a delete statement where IsPrimaryKey is true
			
			////Or you can make your own below:
			//InternalTools.ScriptRun("your delete sql here", conn, new SqlParameter[] { /*parms here*/ }, GetTimeout());
			
		}
		
		#endif
		
		#endregion

	}
	
	public partial class rptMasterInventoryItemsDtoList {
	}
} 

