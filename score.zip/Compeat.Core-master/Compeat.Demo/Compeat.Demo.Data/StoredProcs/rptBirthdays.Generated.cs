﻿using Compeat.Data.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Compeat.Data.Framework.InternalUtils;
using Compeat.Demo.Data.Shared;
namespace Compeat.Demo.Data {

	#region Business Object
    
	/// <summary>
	/// This is the first of [1] possible exiting result set(s) from the proc called [rptBirthdays]
	/// </summary>
	[Serializable]
	public partial class rptBirthdaysDto : ProcBase {
		public rptBirthdaysDto(){ }
	
		/// <summary>
		/// calls its private twin in cases where a static is needed
		/// </summary>
		/// <returns></returns>
		internal static int MyTimeout() {
			return (new Compeat.Demo.Data.rptBirthdaysDto()).GetTimeout();
		}
		private string _empname{ get; set; }
		public virtual string empname { 
			get { return _empname; } 
			set { _empname = value; }
		}
		private DateTime? _birthdate{ get; set; }
		public virtual DateTime? birthdate { 
			get { return _birthdate; } 
			set { _birthdate = value; }
		}

		#region Loader  	  

		internal void Fill(SqlDataReader dr) {
			this._empname = (dr.IsDBNull(rptBirthdays.RESULT_INDEX_empname) ? null : dr.GetString(rptBirthdays.RESULT_INDEX_empname));
			this._birthdate = (dr.IsDBNull(rptBirthdays.RESULT_INDEX_birthdate) ? (DateTime?)null : dr.GetDateTime(rptBirthdays.RESULT_INDEX_birthdate));
		}
		
		#endregion Loader
		protected override string ObjName
		{
			get
			{
				return Compeat.Demo.Data.rptBirthdays.PROC_NAME;
			}
		}
	}
		
	

	[Serializable]
	public partial class rptBirthdaysDtoList : List<Compeat.Demo.Data.rptBirthdaysDto> { }
	#endregion

	public partial class rptBirthdays {
		internal const string PROC_NAME = "dbo.rptBirthdays";
		internal const int RESULT_INDEX_empname = 0, RESULT_INDEX_birthdate = 1;
	
		#region Repo Turn Around
		/// <summary>
		/// Executes the procedure and returns nothing. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// Returns the number of rows affected
		/// </summary>
		public virtual int ExecuteOnly(SqlConnection conn, int? storenum, byte? month, bool? isPR) {
			return _ExecuteOnly(conn,  storenum,  month,  isPR);
		}
	
		/// <summary>
		/// Executes the procedure and returns a single rptBirthdays. The reader will stop after pulling the first row since its a stored proc
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual Compeat.Demo.Data.rptBirthdaysDto GetFirst(SqlConnection conn, int? storenum, byte? month, bool? isPR) {
			return _GetFirst<Compeat.Demo.Data.rptBirthdaysDto>(conn,  storenum,  month,  isPR);
		}    	
		/// <summary>
		/// Executes the procedure and returns a single rptBirthdays. The reader will stop after pulling the first row since its a stored proc
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual Compeat.Demo.Data.rptBirthdaysDto GetFirst<TItemType>(SqlConnection conn, int? storenum, byte? month, bool? isPR) 
			where TItemType: Compeat.Demo.Data.rptBirthdaysDto, new()
		{
			return _GetFirst<TItemType>(conn,  storenum,  month,  isPR);
		}    

		/// <summary>
		/// Executes the procedure and returns a rptBirthdays. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual Compeat.Demo.Data.rptBirthdaysDtoList GetList(SqlConnection conn, int? storenum, byte? month, bool? isPR) {
			return _GetList<Compeat.Demo.Data.rptBirthdaysDto, Compeat.Demo.Data.rptBirthdaysDtoList>(conn,  storenum,  month,  isPR);
		}
		/// <summary>
		/// Executes the procedure and returns a rptBirthdays. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual TCollectionType GetList<TItemType, TCollectionType>(SqlConnection conn, int? storenum, byte? month, bool? isPR) 
			where TItemType: Compeat.Demo.Data.rptBirthdaysDto, new()
			where TCollectionType: List<TItemType>, new()
		{
			return _GetList<TItemType, TCollectionType>(conn,  storenum,  month,  isPR);
		}
		/// <summary>
		/// Executes the procedure and returns a [string] which is the type and value of the first column of the first row of the results. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual string GetScalar(SqlConnection conn, int? storenum, byte? month, bool? isPR) {
			return _GetScalar(conn,  storenum,  month,  isPR);
		}
		#endregion
	
		/// <summary>
		/// Executes the procedure and returns nothing. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// Returns the number of rows affected
		/// </summary>
		internal static int _ExecuteOnly(SqlConnection conn, int? storenum, byte? month, bool? isPR) {
			int __retVal = 0;
			_ExecNow(
				(__parameters) => { __retVal = InternalTools.ProcRun(Compeat.Demo.Data.rptBirthdays.PROC_NAME, conn, __parameters, Compeat.Demo.Data.rptBirthdaysDto.MyTimeout());  } //runs after params set 
				,  storenum,  month,  isPR
			);
			return __retVal;
		}
		
	
		/// <summary>
		/// Executes the procedure and returns a single rptBirthdays. The reader will stop after pulling the first row since its a stored proc
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		internal static TItemType _GetFirst<TItemType>(SqlConnection conn, int? storenum, byte? month, bool? isPR) 
			where TItemType: Compeat.Demo.Data.rptBirthdaysDto, new()
		{
			var ret = _GetList<TItemType, List<TItemType>>(1, conn,  storenum,  month,  isPR);
			if(ret != null){
				return ret.FirstOrDefault();
			}
			else{
				return null;
			}
		}    
		
		
		/// <summary>
		/// Executes the procedure and returns a rptBirthdays. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		internal static TCollectionType _GetList<TItemType, TCollectionType>(SqlConnection conn, int? storenum, byte? month, bool? isPR) 
			where TItemType: Compeat.Demo.Data.rptBirthdaysDto, new()
			where TCollectionType: List<TItemType>, new()
		{
			return _GetList<TItemType, TCollectionType>(ulong.MaxValue, conn,  storenum,  month,  isPR);
		}
		
		
		internal static TCollectionType _GetList<TItemType, TCollectionType>(ulong __rows_to_read, SqlConnection conn, int? storenum, byte? month, bool? isPR) 
			where TItemType: Compeat.Demo.Data.rptBirthdaysDto, new()
			where TCollectionType: List<TItemType>, new()
		{
			var __retVal = new TCollectionType();
		
			_ExecNow(
				(__parameters) => { 
						InternalTools.ProcRunReader(Compeat.Demo.Data.rptBirthdays.PROC_NAME, conn, __parameters,
							(sdr) => {
								if (sdr.HasRows) {
									ulong rCnt = 0;
									while (sdr.Read()) {
										var newVal = new TItemType();
										newVal.Fill(sdr);
										__retVal.Add(newVal);
										if(++rCnt >= __rows_to_read) {
											break;
										}
									}
								}
							}
							, Compeat.Demo.Data.rptBirthdaysDto.MyTimeout()
						);  //runs after params set
					}  
				,  storenum,  month,  isPR
			);
			
			return __retVal;
		}
		/// <summary>
		/// Executes the procedure and returns a [string] which is the type and value of the first column of the first row of the results. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		internal static string _GetScalar(SqlConnection conn, int? storenum, byte? month, bool? isPR) {
			string __retVal = default(string);
			_ExecNow(
				(__parameters) => { __retVal = InternalTools.ProcRunScalar<string>(Compeat.Demo.Data.rptBirthdays.PROC_NAME, conn, __parameters, Compeat.Demo.Data.rptBirthdaysDto.MyTimeout());  } //runs after params set 
				,  storenum,  month,  isPR
			);
			return __retVal;
		}

		internal static void _ExecNow(Action<SqlParameter[]> __to_run, int? storenum, byte? month, bool? isPR) {
			var __parameters = new SqlParameter[3];
			__parameters[0] = InternalTools.MakeParam("@storenum", SqlDbType.Int, storenum, true, ParameterDirection.Input);
			__parameters[1] = InternalTools.MakeParam("@month", SqlDbType.TinyInt, month, true, ParameterDirection.Input);
			__parameters[2] = InternalTools.MakeParam("@isPR", SqlDbType.Bit, isPR, true, ParameterDirection.Input);
			__to_run(__parameters);
			
		}
	}
	
	#region Repository needs
	public partial interface IRepository {
		Compeat.Demo.Data.rptBirthdays rptBirthdays { get; }
	}

	public partial class Repository {
		private Compeat.Demo.Data.rptBirthdays _rptBirthdays = null;
		public Compeat.Demo.Data.rptBirthdays rptBirthdays {
			get {
				if(_rptBirthdays == null) {
					_rptBirthdays = new Compeat.Demo.Data.rptBirthdays();
				}
				return _rptBirthdays;
			}
		}
	}
	#endregion Repository needs
}
