﻿using Compeat.Data.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Compeat.Data.Framework.InternalUtils;
namespace Compeat.Demo.Data {

	#region Business Object
	/// <summary>
	/// This is the first of [1] possible exiting result set(s) from the proc called [qryGenericRecordList]
	/// </summary>
	[Serializable]
	public partial class qryGenericRecordListDto : ProcBase {
		/// <summary>
		/// calls its private twin in cases where a static is needed
		/// </summary>
		/// <returns></returns>
		internal static int MyTimeout() {
			return (new qryGenericRecordListDto()).GetTimeout();
		}
		private int? _id{ get; set; }
		public virtual int? id { 
			get { return _id; } 
			set { _id = value; }
		}
		private string _extid{ get; set; }
		public virtual string extid { 
			get { return _extid; } 
			set { _extid = value; }
		}
		private string _description{ get; set; }
		public virtual string description { 
			get { return _description; } 
			set { _description = value; }
		}
		private bool? _active{ get; set; }
		public virtual bool? active { 
			get { return _active; } 
			set { _active = value; }
		}

		#region Loader  	  

		internal static qryGenericRecordListDto Get(SqlDataReader dr) {
			var x = new qryGenericRecordListDto();

			x._id = (dr.IsDBNull(qryGenericRecordList.RESULT_INDEX_id) ? (int?)null : dr.GetInt32(qryGenericRecordList.RESULT_INDEX_id));
			x._extid = (dr.IsDBNull(qryGenericRecordList.RESULT_INDEX_extid) ? null : dr.GetString(qryGenericRecordList.RESULT_INDEX_extid));
			x._description = (dr.IsDBNull(qryGenericRecordList.RESULT_INDEX_description) ? null : dr.GetString(qryGenericRecordList.RESULT_INDEX_description));
			x._active = (dr.IsDBNull(qryGenericRecordList.RESULT_INDEX_active) ? (bool?)null : dr.GetBoolean(qryGenericRecordList.RESULT_INDEX_active));
	  
			return x;
		}
		
		#endregion Loader
		

		protected override string ObjName
		{
			get
			{
				return qryGenericRecordList.PROC_NAME;
			}
		}
	}
	

	[Serializable]
	public partial class qryGenericRecordListDtoList : List<qryGenericRecordListDto> {
	}
	#endregion
	
	#region Repository needs
	
	public partial interface IRepository {
		qryGenericRecordList qryGenericRecordList { get; }
	}
	
	public partial class Repository {
		private qryGenericRecordList _qryGenericRecordList = null;
		public qryGenericRecordList qryGenericRecordList {
			get{
				if(_qryGenericRecordList == null){
					_qryGenericRecordList = new qryGenericRecordList();
				}
				return _qryGenericRecordList;
			}
		}
	}
	
	#endregion Repository needs

	public partial class qryGenericRecordList {
		#region Repo Turn Around
		/// <summary>
		/// Executes the procedure and returns nothing. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// Returns the number of rows affected
		/// </summary>
		public virtual int ExecuteOnly(SqlConnection conn, byte? querytype, string tablename, string keyfield, string extidfield, string descfield, string activefield, string whereclause) {
			return qryGenericRecordList._ExecuteOnly(conn,  querytype,  tablename,  keyfield,  extidfield,  descfield,  activefield,  whereclause);
		}
		
	
		/// <summary>
		/// Executes the procedure and returns a single qryGenericRecordList. The reader will stop after pulling the first row since its a stored proc
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual qryGenericRecordListDto GetFirst(SqlConnection conn, byte? querytype, string tablename, string keyfield, string extidfield, string descfield, string activefield, string whereclause) {
			return qryGenericRecordList._GetFirst(conn,  querytype,  tablename,  keyfield,  extidfield,  descfield,  activefield,  whereclause);
		}    

		/// <summary>
		/// Executes the procedure and returns a qryGenericRecordList. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual qryGenericRecordListDtoList GetList(SqlConnection conn, byte? querytype, string tablename, string keyfield, string extidfield, string descfield, string activefield, string whereclause) {
			return qryGenericRecordList._GetList(conn,  querytype,  tablename,  keyfield,  extidfield,  descfield,  activefield,  whereclause);
		}
		/// <summary>
		/// Executes the procedure and returns a [int?] which is the type and value of the first column of the first row of the results. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual int? GetScalar(SqlConnection conn, byte? querytype, string tablename, string keyfield, string extidfield, string descfield, string activefield, string whereclause) {
			return qryGenericRecordList._GetScalar(conn,  querytype,  tablename,  keyfield,  extidfield,  descfield,  activefield,  whereclause);
		}
		#endregion

		internal const string PROC_NAME = "qryGenericRecordList";
		internal const int RESULT_INDEX_id = 0, RESULT_INDEX_extid = 1, RESULT_INDEX_description = 2, RESULT_INDEX_active = 3;

	
		/// <summary>
		/// Executes the procedure and returns nothing. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// Returns the number of rows affected
		/// </summary>
		internal static int _ExecuteOnly(SqlConnection conn, byte? querytype, string tablename, string keyfield, string extidfield, string descfield, string activefield, string whereclause) {
			int __retVal = 0;
			_ExecNow(
				(__parameters) => { __retVal = InternalTools.ProcRun(qryGenericRecordList.PROC_NAME, conn, __parameters, qryGenericRecordListDto.MyTimeout());  } //runs after params set 
				,  querytype,  tablename,  keyfield,  extidfield,  descfield,  activefield,  whereclause
			);
			return __retVal;
		}
		
	
	
		/// <summary>
		/// Executes the procedure and returns a single qryGenericRecordList. The reader will stop after pulling the first row since its a stored proc
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		internal static qryGenericRecordListDto _GetFirst(SqlConnection conn, byte? querytype, string tablename, string keyfield, string extidfield, string descfield, string activefield, string whereclause) {
			var ret = _GetList(1, conn,  querytype,  tablename,  keyfield,  extidfield,  descfield,  activefield,  whereclause);
			if(ret != null){
				return ret.FirstOrDefault();
			}
			else{
				return null;
			}
		}    

		/// <summary>
		/// Executes the procedure and returns a qryGenericRecordList. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		internal static qryGenericRecordListDtoList _GetList(SqlConnection conn, byte? querytype, string tablename, string keyfield, string extidfield, string descfield, string activefield, string whereclause) {
			return _GetList(ulong.MaxValue, conn,  querytype,  tablename,  keyfield,  extidfield,  descfield,  activefield,  whereclause);
		}

		internal static qryGenericRecordListDtoList _GetList(ulong __rows_to_read, SqlConnection conn, byte? querytype, string tablename, string keyfield, string extidfield, string descfield, string activefield, string whereclause) {
			var __retVal = new qryGenericRecordListDtoList();
		
			_ExecNow(
				(__parameters) => { 
						InternalTools.ProcRunReader(qryGenericRecordList.PROC_NAME, conn, __parameters,
							(sdr) => {
								if (sdr.HasRows) {
									ulong rCnt = 0;
									while (sdr.Read()) {
										__retVal.Add(qryGenericRecordListDto.Get(sdr));
										if(++rCnt >= __rows_to_read) {
											break;
										}
									}
								}
							}
							, qryGenericRecordListDto.MyTimeout()
						);  //runs after params set
					}  
				,  querytype,  tablename,  keyfield,  extidfield,  descfield,  activefield,  whereclause
			);
			
			return __retVal;
		}
		/// <summary>
		/// Executes the procedure and returns a [int?] which is the type and value of the first column of the first row of the results. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		internal static int? _GetScalar(SqlConnection conn, byte? querytype, string tablename, string keyfield, string extidfield, string descfield, string activefield, string whereclause) {
			int? __retVal = default(int?);
			_ExecNow(
				(__parameters) => { __retVal = InternalTools.ProcRunScalar<int?>(qryGenericRecordList.PROC_NAME, conn, __parameters, qryGenericRecordListDto.MyTimeout());  } //runs after params set 
				,  querytype,  tablename,  keyfield,  extidfield,  descfield,  activefield,  whereclause
			);
			return __retVal;
		}

		internal static void _ExecNow(Action<SqlParameter[]> __to_run, byte? querytype, string tablename, string keyfield, string extidfield, string descfield, string activefield, string whereclause) {
			SqlParameter[] __parameters = new SqlParameter[7];
			__parameters[0] = InternalTools.MakeParam("@querytype", SqlDbType.TinyInt, querytype, true, ParameterDirection.Input);
			__parameters[1] = InternalTools.MakeParam("@tablename", SqlDbType.VarChar, tablename, true, 50, ParameterDirection.Input);
			__parameters[2] = InternalTools.MakeParam("@keyfield", SqlDbType.VarChar, keyfield, true, 50, ParameterDirection.Input);
			__parameters[3] = InternalTools.MakeParam("@extidfield", SqlDbType.VarChar, extidfield, true, 50, ParameterDirection.Input);
			__parameters[4] = InternalTools.MakeParam("@descfield", SqlDbType.VarChar, descfield, true, 50, ParameterDirection.Input);
			__parameters[5] = InternalTools.MakeParam("@activefield", SqlDbType.VarChar, activefield, true, 50, ParameterDirection.Input);
			__parameters[6] = InternalTools.MakeParam("@whereclause", SqlDbType.VarChar, whereclause, true, -1, ParameterDirection.Input);

			__to_run(__parameters);
			


		}
		
  }
}
