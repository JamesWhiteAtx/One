﻿using Compeat.Data.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Compeat.Data.Framework.InternalUtils;
using Compeat.Demo.Data.Shared;
namespace Compeat.Demo.Data {

	#region Business Object
    
	/// <summary>
	/// This is the first of [1] possible exiting result set(s) from the proc called [rptRestaurantInventoryListing]
	/// </summary>
	[Serializable]
	public partial class rptRestaurantInventoryListingDto : ProcBase {
		public rptRestaurantInventoryListingDto(){ }
	
		/// <summary>
		/// calls its private twin in cases where a static is needed
		/// </summary>
		/// <returns></returns>
		internal static int MyTimeout() {
			return (new Compeat.Demo.Data.rptRestaurantInventoryListingDto()).GetTimeout();
		}
		private int? _row_type{ get; set; }
		public virtual int? row_type { 
			get { return _row_type; } 
			set { _row_type = value; }
		}
		private int? _level1_id{ get; set; }
		public virtual int? level1_id { 
			get { return _level1_id; } 
			set { _level1_id = value; }
		}
		private string _level1_desc{ get; set; }
		public virtual string level1_desc { 
			get { return _level1_desc; } 
			set { _level1_desc = value; }
		}
		private int? _level1_sortorder{ get; set; }
		public virtual int? level1_sortorder { 
			get { return _level1_sortorder; } 
			set { _level1_sortorder = value; }
		}
		private int? _level2_id{ get; set; }
		public virtual int? level2_id { 
			get { return _level2_id; } 
			set { _level2_id = value; }
		}
		private string _level2_desc{ get; set; }
		public virtual string level2_desc { 
			get { return _level2_desc; } 
			set { _level2_desc = value; }
		}
		private int? _level2_sortorder{ get; set; }
		public virtual int? level2_sortorder { 
			get { return _level2_sortorder; } 
			set { _level2_sortorder = value; }
		}
		private int? _level3_id{ get; set; }
		public virtual int? level3_id { 
			get { return _level3_id; } 
			set { _level3_id = value; }
		}
		private string _level3_desc{ get; set; }
		public virtual string level3_desc { 
			get { return _level3_desc; } 
			set { _level3_desc = value; }
		}
		private int? _level3_sortorder{ get; set; }
		public virtual int? level3_sortorder { 
			get { return _level3_sortorder; } 
			set { _level3_sortorder = value; }
		}
		private int? _item_id{ get; set; }
		public virtual int? item_id { 
			get { return _item_id; } 
			set { _item_id = value; }
		}
		private string _item_desc{ get; set; }
		public virtual string item_desc { 
			get { return _item_desc; } 
			set { _item_desc = value; }
		}
		private string _item_desc2{ get; set; }
		public virtual string item_desc2 { 
			get { return _item_desc2; } 
			set { _item_desc2 = value; }
		}
		private string _base_unit_desc{ get; set; }
		public virtual string base_unit_desc { 
			get { return _base_unit_desc; } 
			set { _base_unit_desc = value; }
		}
		private string _inventory_unit_desc{ get; set; }
		public virtual string inventory_unit_desc { 
			get { return _inventory_unit_desc; } 
			set { _inventory_unit_desc = value; }
		}
		private string _notes{ get; set; }
		public virtual string notes { 
			get { return _notes; } 
			set { _notes = value; }
		}
		private int? _class_type{ get; set; }
		public virtual int? class_type { 
			get { return _class_type; } 
			set { _class_type = value; }
		}
		private decimal? _conv_base_units_per_inv_unit{ get; set; }
		public virtual decimal? conv_base_units_per_inv_unit { 
			get { return _conv_base_units_per_inv_unit; } 
			set { _conv_base_units_per_inv_unit = value; }
		}
		private bool? _is_inventoried{ get; set; }
		public virtual bool? is_inventoried { 
			get { return _is_inventoried; } 
			set { _is_inventoried = value; }
		}
		private bool? _is_hot_item{ get; set; }
		public virtual bool? is_hot_item { 
			get { return _is_hot_item; } 
			set { _is_hot_item = value; }
		}
		private bool? _is_active{ get; set; }
		public virtual bool? is_active { 
			get { return _is_active; } 
			set { _is_active = value; }
		}
		private decimal? _qty_on_hand{ get; set; }
		public virtual decimal? qty_on_hand { 
			get { return _qty_on_hand; } 
			set { _qty_on_hand = value; }
		}
		private bool? _lockprice{ get; set; }
		public virtual bool? lockprice { 
			get { return _lockprice; } 
			set { _lockprice = value; }
		}
		private DateTime? _last_price_update{ get; set; }
		public virtual DateTime? last_price_update { 
			get { return _last_price_update; } 
			set { _last_price_update = value; }
		}
		private int? _storenum{ get; set; }
		public virtual int? storenum { 
			get { return _storenum; } 
			set { _storenum = value; }
		}
		private string _parlevel1desc{ get; set; }
		public virtual string parlevel1desc { 
			get { return _parlevel1desc; } 
			set { _parlevel1desc = value; }
		}
		private string _parlevel2desc{ get; set; }
		public virtual string parlevel2desc { 
			get { return _parlevel2desc; } 
			set { _parlevel2desc = value; }
		}
		private string _parlevel3desc{ get; set; }
		public virtual string parlevel3desc { 
			get { return _parlevel3desc; } 
			set { _parlevel3desc = value; }
		}
		private string _parlevel4desc{ get; set; }
		public virtual string parlevel4desc { 
			get { return _parlevel4desc; } 
			set { _parlevel4desc = value; }
		}
		private string _parlevel5desc{ get; set; }
		public virtual string parlevel5desc { 
			get { return _parlevel5desc; } 
			set { _parlevel5desc = value; }
		}
		private string _parlevel6desc{ get; set; }
		public virtual string parlevel6desc { 
			get { return _parlevel6desc; } 
			set { _parlevel6desc = value; }
		}
		private string _parlevel7desc{ get; set; }
		public virtual string parlevel7desc { 
			get { return _parlevel7desc; } 
			set { _parlevel7desc = value; }
		}
		private int? _stock1{ get; set; }
		public virtual int? stock1 { 
			get { return _stock1; } 
			set { _stock1 = value; }
		}
		private int? _stock2{ get; set; }
		public virtual int? stock2 { 
			get { return _stock2; } 
			set { _stock2 = value; }
		}
		private int? _stock3{ get; set; }
		public virtual int? stock3 { 
			get { return _stock3; } 
			set { _stock3 = value; }
		}
		private int? _stock4{ get; set; }
		public virtual int? stock4 { 
			get { return _stock4; } 
			set { _stock4 = value; }
		}
		private int? _stock5{ get; set; }
		public virtual int? stock5 { 
			get { return _stock5; } 
			set { _stock5 = value; }
		}
		private int? _stock6{ get; set; }
		public virtual int? stock6 { 
			get { return _stock6; } 
			set { _stock6 = value; }
		}
		private int? _stock7{ get; set; }
		public virtual int? stock7 { 
			get { return _stock7; } 
			set { _stock7 = value; }
		}
		private decimal? _reorder1{ get; set; }
		public virtual decimal? reorder1 { 
			get { return _reorder1; } 
			set { _reorder1 = value; }
		}
		private decimal? _reorder2{ get; set; }
		public virtual decimal? reorder2 { 
			get { return _reorder2; } 
			set { _reorder2 = value; }
		}
		private decimal? _reorder3{ get; set; }
		public virtual decimal? reorder3 { 
			get { return _reorder3; } 
			set { _reorder3 = value; }
		}
		private decimal? _reorder4{ get; set; }
		public virtual decimal? reorder4 { 
			get { return _reorder4; } 
			set { _reorder4 = value; }
		}
		private decimal? _reorder5{ get; set; }
		public virtual decimal? reorder5 { 
			get { return _reorder5; } 
			set { _reorder5 = value; }
		}
		private decimal? _reorder6{ get; set; }
		public virtual decimal? reorder6 { 
			get { return _reorder6; } 
			set { _reorder6 = value; }
		}
		private decimal? _reorder7{ get; set; }
		public virtual decimal? reorder7 { 
			get { return _reorder7; } 
			set { _reorder7 = value; }
		}
		private int? _inventory_unit_class{ get; set; }
		public virtual int? inventory_unit_class { 
			get { return _inventory_unit_class; } 
			set { _inventory_unit_class = value; }
		}
		private decimal? _factor{ get; set; }
		public virtual decimal? factor { 
			get { return _factor; } 
			set { _factor = value; }
		}
		private decimal? _cost_per_inv_unit{ get; set; }
		public virtual decimal? cost_per_inv_unit { 
			get { return _cost_per_inv_unit; } 
			set { _cost_per_inv_unit = value; }
		}
		private bool? _is_commissary_item{ get; set; }
		public virtual bool? is_commissary_item { 
			get { return _is_commissary_item; } 
			set { _is_commissary_item = value; }
		}
		private decimal? _fixedcost{ get; set; }
		public virtual decimal? fixedcost { 
			get { return _fixedcost; } 
			set { _fixedcost = value; }
		}
		private int? _fixedcostuom{ get; set; }
		public virtual int? fixedcostuom { 
			get { return _fixedcostuom; } 
			set { _fixedcostuom = value; }
		}
		private decimal? _markupdollars{ get; set; }
		public virtual decimal? markupdollars { 
			get { return _markupdollars; } 
			set { _markupdollars = value; }
		}
		private int? _markupuom{ get; set; }
		public virtual int? markupuom { 
			get { return _markupuom; } 
			set { _markupuom = value; }
		}
		private decimal? _markuppercent{ get; set; }
		public virtual decimal? markuppercent { 
			get { return _markuppercent; } 
			set { _markuppercent = value; }
		}
		private decimal? _fixedcostoo{ get; set; }
		public virtual decimal? fixedcostoo { 
			get { return _fixedcostoo; } 
			set { _fixedcostoo = value; }
		}
		private int? _fixedcostuomoo{ get; set; }
		public virtual int? fixedcostuomoo { 
			get { return _fixedcostuomoo; } 
			set { _fixedcostuomoo = value; }
		}
		private decimal? _markupdollarsoo{ get; set; }
		public virtual decimal? markupdollarsoo { 
			get { return _markupdollarsoo; } 
			set { _markupdollarsoo = value; }
		}
		private int? _markupuomoo{ get; set; }
		public virtual int? markupuomoo { 
			get { return _markupuomoo; } 
			set { _markupuomoo = value; }
		}
		private decimal? _markuppercentoo{ get; set; }
		public virtual decimal? markuppercentoo { 
			get { return _markuppercentoo; } 
			set { _markuppercentoo = value; }
		}
		private string _fixedcostuom_desc{ get; set; }
		public virtual string fixedcostuom_desc { 
			get { return _fixedcostuom_desc; } 
			set { _fixedcostuom_desc = value; }
		}
		private string _markupuom_desc{ get; set; }
		public virtual string markupuom_desc { 
			get { return _markupuom_desc; } 
			set { _markupuom_desc = value; }
		}
		private string _fixedcostuomoo_desc{ get; set; }
		public virtual string fixedcostuomoo_desc { 
			get { return _fixedcostuomoo_desc; } 
			set { _fixedcostuomoo_desc = value; }
		}
		private string _markupuomoo_desc{ get; set; }
		public virtual string markupuomoo_desc { 
			get { return _markupuomoo_desc; } 
			set { _markupuomoo_desc = value; }
		}
		private string _upc_code{ get; set; }
		public virtual string upc_code { 
			get { return _upc_code; } 
			set { _upc_code = value; }
		}
		private int? _unit_type{ get; set; }
		public virtual int? unit_type { 
			get { return _unit_type; } 
			set { _unit_type = value; }
		}
		private string _purchase_unit_desc{ get; set; }
		public virtual string purchase_unit_desc { 
			get { return _purchase_unit_desc; } 
			set { _purchase_unit_desc = value; }
		}
		private string _location_desc{ get; set; }
		public virtual string location_desc { 
			get { return _location_desc; } 
			set { _location_desc = value; }
		}
		private string _vendor_code{ get; set; }
		public virtual string vendor_code { 
			get { return _vendor_code; } 
			set { _vendor_code = value; }
		}
		private string _vendor_name{ get; set; }
		public virtual string vendor_name { 
			get { return _vendor_name; } 
			set { _vendor_name = value; }
		}
		private string _item_code{ get; set; }
		public virtual string item_code { 
			get { return _item_code; } 
			set { _item_code = value; }
		}
		private DateTime? _last_purchase_date{ get; set; }
		public virtual DateTime? last_purchase_date { 
			get { return _last_purchase_date; } 
			set { _last_purchase_date = value; }
		}
		private string _vendor_purch_unit_description{ get; set; }
		public virtual string vendor_purch_unit_description { 
			get { return _vendor_purch_unit_description; } 
			set { _vendor_purch_unit_description = value; }
		}
		private decimal? _unit_cost{ get; set; }
		public virtual decimal? unit_cost { 
			get { return _unit_cost; } 
			set { _unit_cost = value; }
		}
		private bool? _is_preferred{ get; set; }
		public virtual bool? is_preferred { 
			get { return _is_preferred; } 
			set { _is_preferred = value; }
		}
		private bool? _showpurchaseunits{ get; set; }
		public virtual bool? showpurchaseunits { 
			get { return _showpurchaseunits; } 
			set { _showpurchaseunits = value; }
		}
		private bool? _showlocations{ get; set; }
		public virtual bool? showlocations { 
			get { return _showlocations; } 
			set { _showlocations = value; }
		}
		private bool? _showparlevels{ get; set; }
		public virtual bool? showparlevels { 
			get { return _showparlevels; } 
			set { _showparlevels = value; }
		}
		private bool? _showvendorinfo{ get; set; }
		public virtual bool? showvendorinfo { 
			get { return _showvendorinfo; } 
			set { _showvendorinfo = value; }
		}
		private bool? _showcommissarydetail{ get; set; }
		public virtual bool? showcommissarydetail { 
			get { return _showcommissarydetail; } 
			set { _showcommissarydetail = value; }
		}
		private bool? _showupccodes{ get; set; }
		public virtual bool? showupccodes { 
			get { return _showupccodes; } 
			set { _showupccodes = value; }
		}

		#region Loader  	  

		internal void Fill(SqlDataReader dr) {
			this._row_type = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_row_type) ? (int?)null : dr.GetInt32(rptRestaurantInventoryListing.RESULT_INDEX_row_type));
			this._level1_id = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_level1_id) ? (int?)null : dr.GetInt32(rptRestaurantInventoryListing.RESULT_INDEX_level1_id));
			this._level1_desc = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_level1_desc) ? null : dr.GetString(rptRestaurantInventoryListing.RESULT_INDEX_level1_desc));
			this._level1_sortorder = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_level1_sortorder) ? (int?)null : dr.GetInt32(rptRestaurantInventoryListing.RESULT_INDEX_level1_sortorder));
			this._level2_id = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_level2_id) ? (int?)null : dr.GetInt32(rptRestaurantInventoryListing.RESULT_INDEX_level2_id));
			this._level2_desc = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_level2_desc) ? null : dr.GetString(rptRestaurantInventoryListing.RESULT_INDEX_level2_desc));
			this._level2_sortorder = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_level2_sortorder) ? (int?)null : dr.GetInt32(rptRestaurantInventoryListing.RESULT_INDEX_level2_sortorder));
			this._level3_id = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_level3_id) ? (int?)null : dr.GetInt32(rptRestaurantInventoryListing.RESULT_INDEX_level3_id));
			this._level3_desc = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_level3_desc) ? null : dr.GetString(rptRestaurantInventoryListing.RESULT_INDEX_level3_desc));
			this._level3_sortorder = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_level3_sortorder) ? (int?)null : dr.GetInt32(rptRestaurantInventoryListing.RESULT_INDEX_level3_sortorder));
			this._item_id = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_item_id) ? (int?)null : dr.GetInt32(rptRestaurantInventoryListing.RESULT_INDEX_item_id));
			this._item_desc = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_item_desc) ? null : dr.GetString(rptRestaurantInventoryListing.RESULT_INDEX_item_desc));
			this._item_desc2 = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_item_desc2) ? null : dr.GetString(rptRestaurantInventoryListing.RESULT_INDEX_item_desc2));
			this._base_unit_desc = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_base_unit_desc) ? null : dr.GetString(rptRestaurantInventoryListing.RESULT_INDEX_base_unit_desc));
			this._inventory_unit_desc = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_inventory_unit_desc) ? null : dr.GetString(rptRestaurantInventoryListing.RESULT_INDEX_inventory_unit_desc));
			this._notes = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_notes) ? null : dr.GetString(rptRestaurantInventoryListing.RESULT_INDEX_notes));
			this._class_type = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_class_type) ? (int?)null : dr.GetInt32(rptRestaurantInventoryListing.RESULT_INDEX_class_type));
			this._conv_base_units_per_inv_unit = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_conv_base_units_per_inv_unit) ? (decimal?)null : dr.GetDecimal(rptRestaurantInventoryListing.RESULT_INDEX_conv_base_units_per_inv_unit));
			this._is_inventoried = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_is_inventoried) ? (bool?)null : dr.GetBoolean(rptRestaurantInventoryListing.RESULT_INDEX_is_inventoried));
			this._is_hot_item = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_is_hot_item) ? (bool?)null : dr.GetBoolean(rptRestaurantInventoryListing.RESULT_INDEX_is_hot_item));
			this._is_active = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_is_active) ? (bool?)null : dr.GetBoolean(rptRestaurantInventoryListing.RESULT_INDEX_is_active));
			this._qty_on_hand = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_qty_on_hand) ? (decimal?)null : dr.GetDecimal(rptRestaurantInventoryListing.RESULT_INDEX_qty_on_hand));
			this._lockprice = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_lockprice) ? (bool?)null : dr.GetBoolean(rptRestaurantInventoryListing.RESULT_INDEX_lockprice));
			this._last_price_update = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_last_price_update) ? (DateTime?)null : dr.GetDateTime(rptRestaurantInventoryListing.RESULT_INDEX_last_price_update));
			this._storenum = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_storenum) ? (int?)null : dr.GetInt32(rptRestaurantInventoryListing.RESULT_INDEX_storenum));
			this._parlevel1desc = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_parlevel1desc) ? null : dr.GetString(rptRestaurantInventoryListing.RESULT_INDEX_parlevel1desc));
			this._parlevel2desc = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_parlevel2desc) ? null : dr.GetString(rptRestaurantInventoryListing.RESULT_INDEX_parlevel2desc));
			this._parlevel3desc = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_parlevel3desc) ? null : dr.GetString(rptRestaurantInventoryListing.RESULT_INDEX_parlevel3desc));
			this._parlevel4desc = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_parlevel4desc) ? null : dr.GetString(rptRestaurantInventoryListing.RESULT_INDEX_parlevel4desc));
			this._parlevel5desc = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_parlevel5desc) ? null : dr.GetString(rptRestaurantInventoryListing.RESULT_INDEX_parlevel5desc));
			this._parlevel6desc = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_parlevel6desc) ? null : dr.GetString(rptRestaurantInventoryListing.RESULT_INDEX_parlevel6desc));
			this._parlevel7desc = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_parlevel7desc) ? null : dr.GetString(rptRestaurantInventoryListing.RESULT_INDEX_parlevel7desc));
			this._stock1 = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_stock1) ? (int?)null : dr.GetInt32(rptRestaurantInventoryListing.RESULT_INDEX_stock1));
			this._stock2 = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_stock2) ? (int?)null : dr.GetInt32(rptRestaurantInventoryListing.RESULT_INDEX_stock2));
			this._stock3 = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_stock3) ? (int?)null : dr.GetInt32(rptRestaurantInventoryListing.RESULT_INDEX_stock3));
			this._stock4 = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_stock4) ? (int?)null : dr.GetInt32(rptRestaurantInventoryListing.RESULT_INDEX_stock4));
			this._stock5 = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_stock5) ? (int?)null : dr.GetInt32(rptRestaurantInventoryListing.RESULT_INDEX_stock5));
			this._stock6 = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_stock6) ? (int?)null : dr.GetInt32(rptRestaurantInventoryListing.RESULT_INDEX_stock6));
			this._stock7 = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_stock7) ? (int?)null : dr.GetInt32(rptRestaurantInventoryListing.RESULT_INDEX_stock7));
			this._reorder1 = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_reorder1) ? (decimal?)null : dr.GetDecimal(rptRestaurantInventoryListing.RESULT_INDEX_reorder1));
			this._reorder2 = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_reorder2) ? (decimal?)null : dr.GetDecimal(rptRestaurantInventoryListing.RESULT_INDEX_reorder2));
			this._reorder3 = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_reorder3) ? (decimal?)null : dr.GetDecimal(rptRestaurantInventoryListing.RESULT_INDEX_reorder3));
			this._reorder4 = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_reorder4) ? (decimal?)null : dr.GetDecimal(rptRestaurantInventoryListing.RESULT_INDEX_reorder4));
			this._reorder5 = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_reorder5) ? (decimal?)null : dr.GetDecimal(rptRestaurantInventoryListing.RESULT_INDEX_reorder5));
			this._reorder6 = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_reorder6) ? (decimal?)null : dr.GetDecimal(rptRestaurantInventoryListing.RESULT_INDEX_reorder6));
			this._reorder7 = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_reorder7) ? (decimal?)null : dr.GetDecimal(rptRestaurantInventoryListing.RESULT_INDEX_reorder7));
			this._inventory_unit_class = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_inventory_unit_class) ? (int?)null : dr.GetInt32(rptRestaurantInventoryListing.RESULT_INDEX_inventory_unit_class));
			this._factor = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_factor) ? (decimal?)null : dr.GetDecimal(rptRestaurantInventoryListing.RESULT_INDEX_factor));
			this._cost_per_inv_unit = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_cost_per_inv_unit) ? (decimal?)null : dr.GetDecimal(rptRestaurantInventoryListing.RESULT_INDEX_cost_per_inv_unit));
			this._is_commissary_item = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_is_commissary_item) ? (bool?)null : dr.GetBoolean(rptRestaurantInventoryListing.RESULT_INDEX_is_commissary_item));
			this._fixedcost = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_fixedcost) ? (decimal?)null : dr.GetDecimal(rptRestaurantInventoryListing.RESULT_INDEX_fixedcost));
			this._fixedcostuom = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_fixedcostuom) ? (int?)null : dr.GetInt32(rptRestaurantInventoryListing.RESULT_INDEX_fixedcostuom));
			this._markupdollars = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_markupdollars) ? (decimal?)null : dr.GetDecimal(rptRestaurantInventoryListing.RESULT_INDEX_markupdollars));
			this._markupuom = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_markupuom) ? (int?)null : dr.GetInt32(rptRestaurantInventoryListing.RESULT_INDEX_markupuom));
			this._markuppercent = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_markuppercent) ? (decimal?)null : dr.GetDecimal(rptRestaurantInventoryListing.RESULT_INDEX_markuppercent));
			this._fixedcostoo = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_fixedcostoo) ? (decimal?)null : dr.GetDecimal(rptRestaurantInventoryListing.RESULT_INDEX_fixedcostoo));
			this._fixedcostuomoo = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_fixedcostuomoo) ? (int?)null : dr.GetInt32(rptRestaurantInventoryListing.RESULT_INDEX_fixedcostuomoo));
			this._markupdollarsoo = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_markupdollarsoo) ? (decimal?)null : dr.GetDecimal(rptRestaurantInventoryListing.RESULT_INDEX_markupdollarsoo));
			this._markupuomoo = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_markupuomoo) ? (int?)null : dr.GetInt32(rptRestaurantInventoryListing.RESULT_INDEX_markupuomoo));
			this._markuppercentoo = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_markuppercentoo) ? (decimal?)null : dr.GetDecimal(rptRestaurantInventoryListing.RESULT_INDEX_markuppercentoo));
			this._fixedcostuom_desc = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_fixedcostuom_desc) ? null : dr.GetString(rptRestaurantInventoryListing.RESULT_INDEX_fixedcostuom_desc));
			this._markupuom_desc = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_markupuom_desc) ? null : dr.GetString(rptRestaurantInventoryListing.RESULT_INDEX_markupuom_desc));
			this._fixedcostuomoo_desc = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_fixedcostuomoo_desc) ? null : dr.GetString(rptRestaurantInventoryListing.RESULT_INDEX_fixedcostuomoo_desc));
			this._markupuomoo_desc = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_markupuomoo_desc) ? null : dr.GetString(rptRestaurantInventoryListing.RESULT_INDEX_markupuomoo_desc));
			this._upc_code = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_upc_code) ? null : dr.GetString(rptRestaurantInventoryListing.RESULT_INDEX_upc_code));
			this._unit_type = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_unit_type) ? (int?)null : dr.GetInt32(rptRestaurantInventoryListing.RESULT_INDEX_unit_type));
			this._purchase_unit_desc = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_purchase_unit_desc) ? null : dr.GetString(rptRestaurantInventoryListing.RESULT_INDEX_purchase_unit_desc));
			this._location_desc = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_location_desc) ? null : dr.GetString(rptRestaurantInventoryListing.RESULT_INDEX_location_desc));
			this._vendor_code = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_vendor_code) ? null : dr.GetString(rptRestaurantInventoryListing.RESULT_INDEX_vendor_code));
			this._vendor_name = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_vendor_name) ? null : dr.GetString(rptRestaurantInventoryListing.RESULT_INDEX_vendor_name));
			this._item_code = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_item_code) ? null : dr.GetString(rptRestaurantInventoryListing.RESULT_INDEX_item_code));
			this._last_purchase_date = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_last_purchase_date) ? (DateTime?)null : dr.GetDateTime(rptRestaurantInventoryListing.RESULT_INDEX_last_purchase_date));
			this._vendor_purch_unit_description = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_vendor_purch_unit_description) ? null : dr.GetString(rptRestaurantInventoryListing.RESULT_INDEX_vendor_purch_unit_description));
			this._unit_cost = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_unit_cost) ? (decimal?)null : dr.GetDecimal(rptRestaurantInventoryListing.RESULT_INDEX_unit_cost));
			this._is_preferred = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_is_preferred) ? (bool?)null : dr.GetBoolean(rptRestaurantInventoryListing.RESULT_INDEX_is_preferred));
			this._showpurchaseunits = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_showpurchaseunits) ? (bool?)null : dr.GetBoolean(rptRestaurantInventoryListing.RESULT_INDEX_showpurchaseunits));
			this._showlocations = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_showlocations) ? (bool?)null : dr.GetBoolean(rptRestaurantInventoryListing.RESULT_INDEX_showlocations));
			this._showparlevels = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_showparlevels) ? (bool?)null : dr.GetBoolean(rptRestaurantInventoryListing.RESULT_INDEX_showparlevels));
			this._showvendorinfo = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_showvendorinfo) ? (bool?)null : dr.GetBoolean(rptRestaurantInventoryListing.RESULT_INDEX_showvendorinfo));
			this._showcommissarydetail = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_showcommissarydetail) ? (bool?)null : dr.GetBoolean(rptRestaurantInventoryListing.RESULT_INDEX_showcommissarydetail));
			this._showupccodes = (dr.IsDBNull(rptRestaurantInventoryListing.RESULT_INDEX_showupccodes) ? (bool?)null : dr.GetBoolean(rptRestaurantInventoryListing.RESULT_INDEX_showupccodes));
		}
		
		#endregion Loader
		protected override string ObjName
		{
			get
			{
				return Compeat.Demo.Data.rptRestaurantInventoryListing.PROC_NAME;
			}
		}
	}
		
	

	[Serializable]
	public partial class rptRestaurantInventoryListingDtoList : List<Compeat.Demo.Data.rptRestaurantInventoryListingDto> { }
	#endregion

	public partial class rptRestaurantInventoryListing {
		internal const string PROC_NAME = "dbo.rptRestaurantInventoryListing";
		internal const int RESULT_INDEX_row_type = 0, RESULT_INDEX_level1_id = 1, RESULT_INDEX_level1_desc = 2, RESULT_INDEX_level1_sortorder = 3, RESULT_INDEX_level2_id = 4, RESULT_INDEX_level2_desc = 5, RESULT_INDEX_level2_sortorder = 6, RESULT_INDEX_level3_id = 7, RESULT_INDEX_level3_desc = 8, RESULT_INDEX_level3_sortorder = 9, RESULT_INDEX_item_id = 10, RESULT_INDEX_item_desc = 11, RESULT_INDEX_item_desc2 = 12, RESULT_INDEX_base_unit_desc = 13, RESULT_INDEX_inventory_unit_desc = 14, RESULT_INDEX_notes = 15, RESULT_INDEX_class_type = 16, RESULT_INDEX_conv_base_units_per_inv_unit = 17, RESULT_INDEX_is_inventoried = 18, RESULT_INDEX_is_hot_item = 19, RESULT_INDEX_is_active = 20, RESULT_INDEX_qty_on_hand = 21, RESULT_INDEX_lockprice = 22, RESULT_INDEX_last_price_update = 23, RESULT_INDEX_storenum = 24, RESULT_INDEX_parlevel1desc = 25, RESULT_INDEX_parlevel2desc = 26, RESULT_INDEX_parlevel3desc = 27, RESULT_INDEX_parlevel4desc = 28, RESULT_INDEX_parlevel5desc = 29, RESULT_INDEX_parlevel6desc = 30, RESULT_INDEX_parlevel7desc = 31, RESULT_INDEX_stock1 = 32, RESULT_INDEX_stock2 = 33, RESULT_INDEX_stock3 = 34, RESULT_INDEX_stock4 = 35, RESULT_INDEX_stock5 = 36, RESULT_INDEX_stock6 = 37, RESULT_INDEX_stock7 = 38, RESULT_INDEX_reorder1 = 39, RESULT_INDEX_reorder2 = 40, RESULT_INDEX_reorder3 = 41, RESULT_INDEX_reorder4 = 42, RESULT_INDEX_reorder5 = 43, RESULT_INDEX_reorder6 = 44, RESULT_INDEX_reorder7 = 45, RESULT_INDEX_inventory_unit_class = 46, RESULT_INDEX_factor = 47, RESULT_INDEX_cost_per_inv_unit = 48, RESULT_INDEX_is_commissary_item = 49, RESULT_INDEX_fixedcost = 50, RESULT_INDEX_fixedcostuom = 51, RESULT_INDEX_markupdollars = 52, RESULT_INDEX_markupuom = 53, RESULT_INDEX_markuppercent = 54, RESULT_INDEX_fixedcostoo = 55, RESULT_INDEX_fixedcostuomoo = 56, RESULT_INDEX_markupdollarsoo = 57, RESULT_INDEX_markupuomoo = 58, RESULT_INDEX_markuppercentoo = 59, RESULT_INDEX_fixedcostuom_desc = 60, RESULT_INDEX_markupuom_desc = 61, RESULT_INDEX_fixedcostuomoo_desc = 62, RESULT_INDEX_markupuomoo_desc = 63, RESULT_INDEX_upc_code = 64, RESULT_INDEX_unit_type = 65, RESULT_INDEX_purchase_unit_desc = 66, RESULT_INDEX_location_desc = 67, RESULT_INDEX_vendor_code = 68, RESULT_INDEX_vendor_name = 69, RESULT_INDEX_item_code = 70, RESULT_INDEX_last_purchase_date = 71, RESULT_INDEX_vendor_purch_unit_description = 72, RESULT_INDEX_unit_cost = 73, RESULT_INDEX_is_preferred = 74, RESULT_INDEX_showpurchaseunits = 75, RESULT_INDEX_showlocations = 76, RESULT_INDEX_showparlevels = 77, RESULT_INDEX_showvendorinfo = 78, RESULT_INDEX_showcommissarydetail = 79, RESULT_INDEX_showupccodes = 80;
	
		#region Repo Turn Around
		/// <summary>
		/// Executes the procedure and returns nothing. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// Returns the number of rows affected
		/// </summary>
		public virtual int ExecuteOnly(SqlConnection conn, int? storenum, int? userid, int? invlevel1, int? invlevel2, int? invlevel3, int? fromid, int? toid, bool? activeonly, bool? inventoriedonly, bool? hotitemsonly, bool? showpurchaseunits, bool? showlocations, bool? showparlevels, bool? showvendorinfo, bool? showcommissarydetail, bool? showupccodes, bool? includelevel2, bool? includelevel3) {
			return _ExecuteOnly(conn,  storenum,  userid,  invlevel1,  invlevel2,  invlevel3,  fromid,  toid,  activeonly,  inventoriedonly,  hotitemsonly,  showpurchaseunits,  showlocations,  showparlevels,  showvendorinfo,  showcommissarydetail,  showupccodes,  includelevel2,  includelevel3);
		}
	
		/// <summary>
		/// Executes the procedure and returns a single rptRestaurantInventoryListing. The reader will stop after pulling the first row since its a stored proc
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual Compeat.Demo.Data.rptRestaurantInventoryListingDto GetFirst(SqlConnection conn, int? storenum, int? userid, int? invlevel1, int? invlevel2, int? invlevel3, int? fromid, int? toid, bool? activeonly, bool? inventoriedonly, bool? hotitemsonly, bool? showpurchaseunits, bool? showlocations, bool? showparlevels, bool? showvendorinfo, bool? showcommissarydetail, bool? showupccodes, bool? includelevel2, bool? includelevel3) {
			return _GetFirst<Compeat.Demo.Data.rptRestaurantInventoryListingDto>(conn,  storenum,  userid,  invlevel1,  invlevel2,  invlevel3,  fromid,  toid,  activeonly,  inventoriedonly,  hotitemsonly,  showpurchaseunits,  showlocations,  showparlevels,  showvendorinfo,  showcommissarydetail,  showupccodes,  includelevel2,  includelevel3);
		}    	
		/// <summary>
		/// Executes the procedure and returns a single rptRestaurantInventoryListing. The reader will stop after pulling the first row since its a stored proc
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual Compeat.Demo.Data.rptRestaurantInventoryListingDto GetFirst<TItemType>(SqlConnection conn, int? storenum, int? userid, int? invlevel1, int? invlevel2, int? invlevel3, int? fromid, int? toid, bool? activeonly, bool? inventoriedonly, bool? hotitemsonly, bool? showpurchaseunits, bool? showlocations, bool? showparlevels, bool? showvendorinfo, bool? showcommissarydetail, bool? showupccodes, bool? includelevel2, bool? includelevel3) 
			where TItemType: Compeat.Demo.Data.rptRestaurantInventoryListingDto, new()
		{
			return _GetFirst<TItemType>(conn,  storenum,  userid,  invlevel1,  invlevel2,  invlevel3,  fromid,  toid,  activeonly,  inventoriedonly,  hotitemsonly,  showpurchaseunits,  showlocations,  showparlevels,  showvendorinfo,  showcommissarydetail,  showupccodes,  includelevel2,  includelevel3);
		}    

		/// <summary>
		/// Executes the procedure and returns a rptRestaurantInventoryListing. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual Compeat.Demo.Data.rptRestaurantInventoryListingDtoList GetList(SqlConnection conn, int? storenum, int? userid, int? invlevel1, int? invlevel2, int? invlevel3, int? fromid, int? toid, bool? activeonly, bool? inventoriedonly, bool? hotitemsonly, bool? showpurchaseunits, bool? showlocations, bool? showparlevels, bool? showvendorinfo, bool? showcommissarydetail, bool? showupccodes, bool? includelevel2, bool? includelevel3) {
			return _GetList<Compeat.Demo.Data.rptRestaurantInventoryListingDto, Compeat.Demo.Data.rptRestaurantInventoryListingDtoList>(conn,  storenum,  userid,  invlevel1,  invlevel2,  invlevel3,  fromid,  toid,  activeonly,  inventoriedonly,  hotitemsonly,  showpurchaseunits,  showlocations,  showparlevels,  showvendorinfo,  showcommissarydetail,  showupccodes,  includelevel2,  includelevel3);
		}
		/// <summary>
		/// Executes the procedure and returns a rptRestaurantInventoryListing. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual TCollectionType GetList<TItemType, TCollectionType>(SqlConnection conn, int? storenum, int? userid, int? invlevel1, int? invlevel2, int? invlevel3, int? fromid, int? toid, bool? activeonly, bool? inventoriedonly, bool? hotitemsonly, bool? showpurchaseunits, bool? showlocations, bool? showparlevels, bool? showvendorinfo, bool? showcommissarydetail, bool? showupccodes, bool? includelevel2, bool? includelevel3) 
			where TItemType: Compeat.Demo.Data.rptRestaurantInventoryListingDto, new()
			where TCollectionType: List<TItemType>, new()
		{
			return _GetList<TItemType, TCollectionType>(conn,  storenum,  userid,  invlevel1,  invlevel2,  invlevel3,  fromid,  toid,  activeonly,  inventoriedonly,  hotitemsonly,  showpurchaseunits,  showlocations,  showparlevels,  showvendorinfo,  showcommissarydetail,  showupccodes,  includelevel2,  includelevel3);
		}
		/// <summary>
		/// Executes the procedure and returns a [int?] which is the type and value of the first column of the first row of the results. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual int? GetScalar(SqlConnection conn, int? storenum, int? userid, int? invlevel1, int? invlevel2, int? invlevel3, int? fromid, int? toid, bool? activeonly, bool? inventoriedonly, bool? hotitemsonly, bool? showpurchaseunits, bool? showlocations, bool? showparlevels, bool? showvendorinfo, bool? showcommissarydetail, bool? showupccodes, bool? includelevel2, bool? includelevel3) {
			return _GetScalar(conn,  storenum,  userid,  invlevel1,  invlevel2,  invlevel3,  fromid,  toid,  activeonly,  inventoriedonly,  hotitemsonly,  showpurchaseunits,  showlocations,  showparlevels,  showvendorinfo,  showcommissarydetail,  showupccodes,  includelevel2,  includelevel3);
		}
		#endregion
	
		/// <summary>
		/// Executes the procedure and returns nothing. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// Returns the number of rows affected
		/// </summary>
		internal static int _ExecuteOnly(SqlConnection conn, int? storenum, int? userid, int? invlevel1, int? invlevel2, int? invlevel3, int? fromid, int? toid, bool? activeonly, bool? inventoriedonly, bool? hotitemsonly, bool? showpurchaseunits, bool? showlocations, bool? showparlevels, bool? showvendorinfo, bool? showcommissarydetail, bool? showupccodes, bool? includelevel2, bool? includelevel3) {
			int __retVal = 0;
			_ExecNow(
				(__parameters) => { __retVal = InternalTools.ProcRun(Compeat.Demo.Data.rptRestaurantInventoryListing.PROC_NAME, conn, __parameters, Compeat.Demo.Data.rptRestaurantInventoryListingDto.MyTimeout());  } //runs after params set 
				,  storenum,  userid,  invlevel1,  invlevel2,  invlevel3,  fromid,  toid,  activeonly,  inventoriedonly,  hotitemsonly,  showpurchaseunits,  showlocations,  showparlevels,  showvendorinfo,  showcommissarydetail,  showupccodes,  includelevel2,  includelevel3
			);
			return __retVal;
		}
		
	
		/// <summary>
		/// Executes the procedure and returns a single rptRestaurantInventoryListing. The reader will stop after pulling the first row since its a stored proc
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		internal static TItemType _GetFirst<TItemType>(SqlConnection conn, int? storenum, int? userid, int? invlevel1, int? invlevel2, int? invlevel3, int? fromid, int? toid, bool? activeonly, bool? inventoriedonly, bool? hotitemsonly, bool? showpurchaseunits, bool? showlocations, bool? showparlevels, bool? showvendorinfo, bool? showcommissarydetail, bool? showupccodes, bool? includelevel2, bool? includelevel3) 
			where TItemType: Compeat.Demo.Data.rptRestaurantInventoryListingDto, new()
		{
			var ret = _GetList<TItemType, List<TItemType>>(1, conn,  storenum,  userid,  invlevel1,  invlevel2,  invlevel3,  fromid,  toid,  activeonly,  inventoriedonly,  hotitemsonly,  showpurchaseunits,  showlocations,  showparlevels,  showvendorinfo,  showcommissarydetail,  showupccodes,  includelevel2,  includelevel3);
			if(ret != null){
				return ret.FirstOrDefault();
			}
			else{
				return null;
			}
		}    
		
		
		/// <summary>
		/// Executes the procedure and returns a rptRestaurantInventoryListing. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		internal static TCollectionType _GetList<TItemType, TCollectionType>(SqlConnection conn, int? storenum, int? userid, int? invlevel1, int? invlevel2, int? invlevel3, int? fromid, int? toid, bool? activeonly, bool? inventoriedonly, bool? hotitemsonly, bool? showpurchaseunits, bool? showlocations, bool? showparlevels, bool? showvendorinfo, bool? showcommissarydetail, bool? showupccodes, bool? includelevel2, bool? includelevel3) 
			where TItemType: Compeat.Demo.Data.rptRestaurantInventoryListingDto, new()
			where TCollectionType: List<TItemType>, new()
		{
			return _GetList<TItemType, TCollectionType>(ulong.MaxValue, conn,  storenum,  userid,  invlevel1,  invlevel2,  invlevel3,  fromid,  toid,  activeonly,  inventoriedonly,  hotitemsonly,  showpurchaseunits,  showlocations,  showparlevels,  showvendorinfo,  showcommissarydetail,  showupccodes,  includelevel2,  includelevel3);
		}
		
		
		internal static TCollectionType _GetList<TItemType, TCollectionType>(ulong __rows_to_read, SqlConnection conn, int? storenum, int? userid, int? invlevel1, int? invlevel2, int? invlevel3, int? fromid, int? toid, bool? activeonly, bool? inventoriedonly, bool? hotitemsonly, bool? showpurchaseunits, bool? showlocations, bool? showparlevels, bool? showvendorinfo, bool? showcommissarydetail, bool? showupccodes, bool? includelevel2, bool? includelevel3) 
			where TItemType: Compeat.Demo.Data.rptRestaurantInventoryListingDto, new()
			where TCollectionType: List<TItemType>, new()
		{
			var __retVal = new TCollectionType();
		
			_ExecNow(
				(__parameters) => { 
						InternalTools.ProcRunReader(Compeat.Demo.Data.rptRestaurantInventoryListing.PROC_NAME, conn, __parameters,
							(sdr) => {
								if (sdr.HasRows) {
									ulong rCnt = 0;
									while (sdr.Read()) {
										var newVal = new TItemType();
										newVal.Fill(sdr);
										__retVal.Add(newVal);
										if(++rCnt >= __rows_to_read) {
											break;
										}
									}
								}
							}
							, Compeat.Demo.Data.rptRestaurantInventoryListingDto.MyTimeout()
						);  //runs after params set
					}  
				,  storenum,  userid,  invlevel1,  invlevel2,  invlevel3,  fromid,  toid,  activeonly,  inventoriedonly,  hotitemsonly,  showpurchaseunits,  showlocations,  showparlevels,  showvendorinfo,  showcommissarydetail,  showupccodes,  includelevel2,  includelevel3
			);
			
			return __retVal;
		}
		/// <summary>
		/// Executes the procedure and returns a [int?] which is the type and value of the first column of the first row of the results. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		internal static int? _GetScalar(SqlConnection conn, int? storenum, int? userid, int? invlevel1, int? invlevel2, int? invlevel3, int? fromid, int? toid, bool? activeonly, bool? inventoriedonly, bool? hotitemsonly, bool? showpurchaseunits, bool? showlocations, bool? showparlevels, bool? showvendorinfo, bool? showcommissarydetail, bool? showupccodes, bool? includelevel2, bool? includelevel3) {
			int? __retVal = default(int?);
			_ExecNow(
				(__parameters) => { __retVal = InternalTools.ProcRunScalar<int?>(Compeat.Demo.Data.rptRestaurantInventoryListing.PROC_NAME, conn, __parameters, Compeat.Demo.Data.rptRestaurantInventoryListingDto.MyTimeout());  } //runs after params set 
				,  storenum,  userid,  invlevel1,  invlevel2,  invlevel3,  fromid,  toid,  activeonly,  inventoriedonly,  hotitemsonly,  showpurchaseunits,  showlocations,  showparlevels,  showvendorinfo,  showcommissarydetail,  showupccodes,  includelevel2,  includelevel3
			);
			return __retVal;
		}

		internal static void _ExecNow(Action<SqlParameter[]> __to_run, int? storenum, int? userid, int? invlevel1, int? invlevel2, int? invlevel3, int? fromid, int? toid, bool? activeonly, bool? inventoriedonly, bool? hotitemsonly, bool? showpurchaseunits, bool? showlocations, bool? showparlevels, bool? showvendorinfo, bool? showcommissarydetail, bool? showupccodes, bool? includelevel2, bool? includelevel3) {
			var __parameters = new SqlParameter[18];
			__parameters[0] = InternalTools.MakeParam("@storenum", SqlDbType.Int, storenum, true, ParameterDirection.Input);
			__parameters[1] = InternalTools.MakeParam("@userid", SqlDbType.Int, userid, true, ParameterDirection.Input);
			__parameters[2] = InternalTools.MakeParam("@invlevel1", SqlDbType.Int, invlevel1, true, ParameterDirection.Input);
			__parameters[3] = InternalTools.MakeParam("@invlevel2", SqlDbType.Int, invlevel2, true, ParameterDirection.Input);
			__parameters[4] = InternalTools.MakeParam("@invlevel3", SqlDbType.Int, invlevel3, true, ParameterDirection.Input);
			__parameters[5] = InternalTools.MakeParam("@fromid", SqlDbType.Int, fromid, true, ParameterDirection.Input);
			__parameters[6] = InternalTools.MakeParam("@toid", SqlDbType.Int, toid, true, ParameterDirection.Input);
			__parameters[7] = InternalTools.MakeParam("@activeonly", SqlDbType.Bit, activeonly, true, ParameterDirection.Input);
			__parameters[8] = InternalTools.MakeParam("@inventoriedonly", SqlDbType.Bit, inventoriedonly, true, ParameterDirection.Input);
			__parameters[9] = InternalTools.MakeParam("@hotitemsonly", SqlDbType.Bit, hotitemsonly, true, ParameterDirection.Input);
			__parameters[10] = InternalTools.MakeParam("@showpurchaseunits", SqlDbType.Bit, showpurchaseunits, true, ParameterDirection.Input);
			__parameters[11] = InternalTools.MakeParam("@showlocations", SqlDbType.Bit, showlocations, true, ParameterDirection.Input);
			__parameters[12] = InternalTools.MakeParam("@showparlevels", SqlDbType.Bit, showparlevels, true, ParameterDirection.Input);
			__parameters[13] = InternalTools.MakeParam("@showvendorinfo", SqlDbType.Bit, showvendorinfo, true, ParameterDirection.Input);
			__parameters[14] = InternalTools.MakeParam("@showcommissarydetail", SqlDbType.Bit, showcommissarydetail, true, ParameterDirection.Input);
			__parameters[15] = InternalTools.MakeParam("@showupccodes", SqlDbType.Bit, showupccodes, true, ParameterDirection.Input);
			__parameters[16] = InternalTools.MakeParam("@includelevel2", SqlDbType.Bit, includelevel2, true, ParameterDirection.Input);
			__parameters[17] = InternalTools.MakeParam("@includelevel3", SqlDbType.Bit, includelevel3, true, ParameterDirection.Input);
			__to_run(__parameters);
			
		}
	}
	
	#region Repository needs
	public partial interface IRepository {
		Compeat.Demo.Data.rptRestaurantInventoryListing rptRestaurantInventoryListing { get; }
	}

	public partial class Repository {
		private Compeat.Demo.Data.rptRestaurantInventoryListing _rptRestaurantInventoryListing = null;
		public Compeat.Demo.Data.rptRestaurantInventoryListing rptRestaurantInventoryListing {
			get {
				if(_rptRestaurantInventoryListing == null) {
					_rptRestaurantInventoryListing = new Compeat.Demo.Data.rptRestaurantInventoryListing();
				}
				return _rptRestaurantInventoryListing;
			}
		}
	}
	#endregion Repository needs
}
