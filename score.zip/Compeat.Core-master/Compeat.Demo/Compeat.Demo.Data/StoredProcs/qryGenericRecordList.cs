﻿//#define IsSavableProc
using Compeat.Data.Framework;
using Compeat.Data.Framework.InternalUtils;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
namespace Compeat.Demo.Data {
	public partial class qryGenericRecordListDto {

		#region Savable Implementation
		
		#if IsSavableProc
		
		//if the stock savable functionality is used, then this should return the table name to save to
		protected override string StockSaveTableName {
			get {
				throw new NotImplementedException();
				//return "TABLE_NAME"; //table name for the writing statements
			}
		}
		
		protected override bool HasPkSet {
			get {
				//change to return true if a pk is known, so the save function knows to call the update. 
				return false;
				//return id != null;
			}
		}

		private List<SqlParamHolder> __parameters { get; set;}
		protected override IEnumerable<SqlParamHolder> MyParameters {
			get {
				if(__parameters == null) {
				   __parameters = new List<SqlParamHolder>() {
						new SqlParamHolder(){IsPrimaryKey = true, IsIdentity = true, ColumnName = "id", ParameterName = "@id", MyParamGetter = () => { return InternalTools.MakeParam("@id", SqlDbType.Int, id, true); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "extid", ParameterName = "@extid", MyParamGetter = () => { return InternalTools.MakeParam("@extid", SqlDbType.VarChar, extid, true, 1); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "description", ParameterName = "@description", MyParamGetter = () => { return InternalTools.MakeParam("@description", SqlDbType.VarChar, description, true, 1); } }, 
						new SqlParamHolder(){ColumnName = "active", ParameterName = "@active", MyParamGetter = () => { return InternalTools.MakeParam("@active", SqlDbType.Bit, _active, true); } } 
					};  			  
				}
				return __parameters;
			}
		}
		
		protected override void Update(SqlConnection conn) { 
			StockProcUpdate(conn); //will use StockSaveTableName and MyParameters to build an update statement where IsPrimaryKey is true
			
			////Or you can make your own below:
			//InternalTools.ScriptRun("your update sql here", conn, new SqlParameter[] { /*parms here*/ }, GetTimeout());
		}
		
		protected override void Insert(SqlConnection conn) { 
			StockProcInsert(conn); //will use StockSaveTableName and MyParameters to build an insert statement
			
			////Or you can make your own below:
			//InternalTools.ScriptRun("your insert sql here", conn, new SqlParameter[] { /*parms here*/ }, GetTimeout());
		}
		
		protected override void Delete(SqlConnection conn) { 
			StockProcDelete(conn);//will use StockSaveTableName and MyParameters to build a delete statement where IsPrimaryKey is true
			
			////Or you can make your own below:
			//InternalTools.ScriptRun("your delete sql here", conn, new SqlParameter[] { /*parms here*/ }, GetTimeout());
			
		}
		
		#endif
		
		#endregion

	}
	
	public partial class qryGenericRecordListDtoList {
		public enum QueryTypes : byte
		{
			GeneralTable = 1
		}
	}
} 

