﻿//#define IsSavableProc
using Compeat.Data.Framework;
using Compeat.Data.Framework.InternalUtils;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Compeat.Demo.Data.Shared;
namespace Compeat.Demo.Data {
	public partial class rptRestaurantInventoryListingDto {

		#region Savable Implementation
		
		#if IsSavableProc
		
		//if the stock savable functionality is used, then this should return the table name to save to
		protected override string StockSaveTableName {
			get {
				throw new NotImplementedException();
				//return "TABLE_NAME"; //table name for the writing statements
			}
		}
		
		protected override bool HasPkSet {
			get {
				//change to return true if a pk is known, so the save function knows to call the update. 
				return false;
			}
		}

		private List<SqlParamHolder> __parameters { get; set;}
		protected override IEnumerable<SqlParamHolder> MyParameters {
			get {
				if(__parameters == null) {
				   __parameters = new List<SqlParamHolder>() {
						new SqlParamHolder(){IsPrimaryKey = false, IsIdentity = false, ColumnName = "row_type", ParameterName = "@row_type", MyParamGetter = () => { return InternalTools.MakeParam("@row_type", SqlDbType.Int, row_type, true); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, IsIdentity = false, ColumnName = "level1_id", ParameterName = "@level1_id", MyParamGetter = () => { return InternalTools.MakeParam("@level1_id", SqlDbType.Int, level1_id, true); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "level1_desc", ParameterName = "@level1_desc", MyParamGetter = () => { return InternalTools.MakeParam("@level1_desc", SqlDbType.VarChar, level1_desc, true, 2147483647); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, IsIdentity = false, ColumnName = "level1_sortorder", ParameterName = "@level1_sortorder", MyParamGetter = () => { return InternalTools.MakeParam("@level1_sortorder", SqlDbType.Int, level1_sortorder, true); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, IsIdentity = false, ColumnName = "level2_id", ParameterName = "@level2_id", MyParamGetter = () => { return InternalTools.MakeParam("@level2_id", SqlDbType.Int, level2_id, true); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "level2_desc", ParameterName = "@level2_desc", MyParamGetter = () => { return InternalTools.MakeParam("@level2_desc", SqlDbType.VarChar, level2_desc, true, 2147483647); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, IsIdentity = false, ColumnName = "level2_sortorder", ParameterName = "@level2_sortorder", MyParamGetter = () => { return InternalTools.MakeParam("@level2_sortorder", SqlDbType.Int, level2_sortorder, true); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, IsIdentity = false, ColumnName = "level3_id", ParameterName = "@level3_id", MyParamGetter = () => { return InternalTools.MakeParam("@level3_id", SqlDbType.Int, level3_id, true); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "level3_desc", ParameterName = "@level3_desc", MyParamGetter = () => { return InternalTools.MakeParam("@level3_desc", SqlDbType.VarChar, level3_desc, true, 2147483647); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, IsIdentity = false, ColumnName = "level3_sortorder", ParameterName = "@level3_sortorder", MyParamGetter = () => { return InternalTools.MakeParam("@level3_sortorder", SqlDbType.Int, level3_sortorder, true); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, IsIdentity = false, ColumnName = "item_id", ParameterName = "@item_id", MyParamGetter = () => { return InternalTools.MakeParam("@item_id", SqlDbType.Int, item_id, true); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "item_desc", ParameterName = "@item_desc", MyParamGetter = () => { return InternalTools.MakeParam("@item_desc", SqlDbType.VarChar, item_desc, true, 2147483647); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "item_desc2", ParameterName = "@item_desc2", MyParamGetter = () => { return InternalTools.MakeParam("@item_desc2", SqlDbType.VarChar, item_desc2, true, 2147483647); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "base_unit_desc", ParameterName = "@base_unit_desc", MyParamGetter = () => { return InternalTools.MakeParam("@base_unit_desc", SqlDbType.VarChar, base_unit_desc, true, 2147483647); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "inventory_unit_desc", ParameterName = "@inventory_unit_desc", MyParamGetter = () => { return InternalTools.MakeParam("@inventory_unit_desc", SqlDbType.VarChar, inventory_unit_desc, true, 2147483647); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "notes", ParameterName = "@notes", MyParamGetter = () => { return InternalTools.MakeParam("@notes", SqlDbType.VarChar, notes, true, 2147483647); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, IsIdentity = false, ColumnName = "class_type", ParameterName = "@class_type", MyParamGetter = () => { return InternalTools.MakeParam("@class_type", SqlDbType.Int, class_type, true); } }, 
						new SqlParamHolder(){ColumnName = "conv_base_units_per_inv_unit", ParameterName = "@conv_base_units_per_inv_unit", MyParamGetter = () => { return InternalTools.MakeParam("@conv_base_units_per_inv_unit", SqlDbType.Decimal, conv_base_units_per_inv_unit, true, 19, 10); } }, 
						new SqlParamHolder(){ColumnName = "is_inventoried", ParameterName = "@is_inventoried", MyParamGetter = () => { return InternalTools.MakeParam("@is_inventoried", SqlDbType.Bit, _is_inventoried, true); } }, 
						new SqlParamHolder(){ColumnName = "is_hot_item", ParameterName = "@is_hot_item", MyParamGetter = () => { return InternalTools.MakeParam("@is_hot_item", SqlDbType.Bit, _is_hot_item, true); } }, 
						new SqlParamHolder(){ColumnName = "is_active", ParameterName = "@is_active", MyParamGetter = () => { return InternalTools.MakeParam("@is_active", SqlDbType.Bit, _is_active, true); } }, 
						new SqlParamHolder(){ColumnName = "qty_on_hand", ParameterName = "@qty_on_hand", MyParamGetter = () => { return InternalTools.MakeParam("@qty_on_hand", SqlDbType.Decimal, qty_on_hand, true, 19, 6); } }, 
						new SqlParamHolder(){ColumnName = "lockprice", ParameterName = "@lockprice", MyParamGetter = () => { return InternalTools.MakeParam("@lockprice", SqlDbType.Bit, _lockprice, true); } }, 
						new SqlParamHolder(){ColumnName = "last_price_update", ParameterName = "@last_price_update", MyParamGetter = () => { return InternalTools.MakeParam("@last_price_update", SqlDbType.DateTime, _last_price_update, true); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, IsIdentity = false, ColumnName = "storenum", ParameterName = "@storenum", MyParamGetter = () => { return InternalTools.MakeParam("@storenum", SqlDbType.Int, storenum, true); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "parlevel1desc", ParameterName = "@parlevel1desc", MyParamGetter = () => { return InternalTools.MakeParam("@parlevel1desc", SqlDbType.VarChar, parlevel1desc, true, 2147483647); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "parlevel2desc", ParameterName = "@parlevel2desc", MyParamGetter = () => { return InternalTools.MakeParam("@parlevel2desc", SqlDbType.VarChar, parlevel2desc, true, 2147483647); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "parlevel3desc", ParameterName = "@parlevel3desc", MyParamGetter = () => { return InternalTools.MakeParam("@parlevel3desc", SqlDbType.VarChar, parlevel3desc, true, 2147483647); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "parlevel4desc", ParameterName = "@parlevel4desc", MyParamGetter = () => { return InternalTools.MakeParam("@parlevel4desc", SqlDbType.VarChar, parlevel4desc, true, 2147483647); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "parlevel5desc", ParameterName = "@parlevel5desc", MyParamGetter = () => { return InternalTools.MakeParam("@parlevel5desc", SqlDbType.VarChar, parlevel5desc, true, 2147483647); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "parlevel6desc", ParameterName = "@parlevel6desc", MyParamGetter = () => { return InternalTools.MakeParam("@parlevel6desc", SqlDbType.VarChar, parlevel6desc, true, 2147483647); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "parlevel7desc", ParameterName = "@parlevel7desc", MyParamGetter = () => { return InternalTools.MakeParam("@parlevel7desc", SqlDbType.VarChar, parlevel7desc, true, 2147483647); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, IsIdentity = false, ColumnName = "stock1", ParameterName = "@stock1", MyParamGetter = () => { return InternalTools.MakeParam("@stock1", SqlDbType.Int, stock1, true); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, IsIdentity = false, ColumnName = "stock2", ParameterName = "@stock2", MyParamGetter = () => { return InternalTools.MakeParam("@stock2", SqlDbType.Int, stock2, true); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, IsIdentity = false, ColumnName = "stock3", ParameterName = "@stock3", MyParamGetter = () => { return InternalTools.MakeParam("@stock3", SqlDbType.Int, stock3, true); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, IsIdentity = false, ColumnName = "stock4", ParameterName = "@stock4", MyParamGetter = () => { return InternalTools.MakeParam("@stock4", SqlDbType.Int, stock4, true); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, IsIdentity = false, ColumnName = "stock5", ParameterName = "@stock5", MyParamGetter = () => { return InternalTools.MakeParam("@stock5", SqlDbType.Int, stock5, true); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, IsIdentity = false, ColumnName = "stock6", ParameterName = "@stock6", MyParamGetter = () => { return InternalTools.MakeParam("@stock6", SqlDbType.Int, stock6, true); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, IsIdentity = false, ColumnName = "stock7", ParameterName = "@stock7", MyParamGetter = () => { return InternalTools.MakeParam("@stock7", SqlDbType.Int, stock7, true); } }, 
						new SqlParamHolder(){ColumnName = "reorder1", ParameterName = "@reorder1", MyParamGetter = () => { return InternalTools.MakeParam("@reorder1", SqlDbType.Decimal, reorder1, true, 9, 2); } }, 
						new SqlParamHolder(){ColumnName = "reorder2", ParameterName = "@reorder2", MyParamGetter = () => { return InternalTools.MakeParam("@reorder2", SqlDbType.Decimal, reorder2, true, 9, 2); } }, 
						new SqlParamHolder(){ColumnName = "reorder3", ParameterName = "@reorder3", MyParamGetter = () => { return InternalTools.MakeParam("@reorder3", SqlDbType.Decimal, reorder3, true, 9, 2); } }, 
						new SqlParamHolder(){ColumnName = "reorder4", ParameterName = "@reorder4", MyParamGetter = () => { return InternalTools.MakeParam("@reorder4", SqlDbType.Decimal, reorder4, true, 9, 2); } }, 
						new SqlParamHolder(){ColumnName = "reorder5", ParameterName = "@reorder5", MyParamGetter = () => { return InternalTools.MakeParam("@reorder5", SqlDbType.Decimal, reorder5, true, 9, 2); } }, 
						new SqlParamHolder(){ColumnName = "reorder6", ParameterName = "@reorder6", MyParamGetter = () => { return InternalTools.MakeParam("@reorder6", SqlDbType.Decimal, reorder6, true, 9, 2); } }, 
						new SqlParamHolder(){ColumnName = "reorder7", ParameterName = "@reorder7", MyParamGetter = () => { return InternalTools.MakeParam("@reorder7", SqlDbType.Decimal, reorder7, true, 9, 2); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, IsIdentity = false, ColumnName = "inventory_unit_class", ParameterName = "@inventory_unit_class", MyParamGetter = () => { return InternalTools.MakeParam("@inventory_unit_class", SqlDbType.Int, inventory_unit_class, true); } }, 
						new SqlParamHolder(){ColumnName = "factor", ParameterName = "@factor", MyParamGetter = () => { return InternalTools.MakeParam("@factor", SqlDbType.Decimal, factor, true, 19, 6); } }, 
						new SqlParamHolder(){ColumnName = "cost_per_inv_unit", ParameterName = "@cost_per_inv_unit", MyParamGetter = () => { return InternalTools.MakeParam("@cost_per_inv_unit", SqlDbType.Decimal, cost_per_inv_unit, true, 19, 6); } }, 
						new SqlParamHolder(){ColumnName = "is_commissary_item", ParameterName = "@is_commissary_item", MyParamGetter = () => { return InternalTools.MakeParam("@is_commissary_item", SqlDbType.Bit, _is_commissary_item, true); } }, 
						new SqlParamHolder(){ColumnName = "fixedcost", ParameterName = "@fixedcost", MyParamGetter = () => { return InternalTools.MakeParam("@fixedcost", SqlDbType.Decimal, fixedcost, true, 9, 2); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, IsIdentity = false, ColumnName = "fixedcostuom", ParameterName = "@fixedcostuom", MyParamGetter = () => { return InternalTools.MakeParam("@fixedcostuom", SqlDbType.Int, fixedcostuom, true); } }, 
						new SqlParamHolder(){ColumnName = "markupdollars", ParameterName = "@markupdollars", MyParamGetter = () => { return InternalTools.MakeParam("@markupdollars", SqlDbType.Decimal, markupdollars, true, 9, 2); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, IsIdentity = false, ColumnName = "markupuom", ParameterName = "@markupuom", MyParamGetter = () => { return InternalTools.MakeParam("@markupuom", SqlDbType.Int, markupuom, true); } }, 
						new SqlParamHolder(){ColumnName = "markuppercent", ParameterName = "@markuppercent", MyParamGetter = () => { return InternalTools.MakeParam("@markuppercent", SqlDbType.Decimal, markuppercent, true, 9, 2); } }, 
						new SqlParamHolder(){ColumnName = "fixedcostoo", ParameterName = "@fixedcostoo", MyParamGetter = () => { return InternalTools.MakeParam("@fixedcostoo", SqlDbType.Decimal, fixedcostoo, true, 9, 2); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, IsIdentity = false, ColumnName = "fixedcostuomoo", ParameterName = "@fixedcostuomoo", MyParamGetter = () => { return InternalTools.MakeParam("@fixedcostuomoo", SqlDbType.Int, fixedcostuomoo, true); } }, 
						new SqlParamHolder(){ColumnName = "markupdollarsoo", ParameterName = "@markupdollarsoo", MyParamGetter = () => { return InternalTools.MakeParam("@markupdollarsoo", SqlDbType.Decimal, markupdollarsoo, true, 9, 2); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, IsIdentity = false, ColumnName = "markupuomoo", ParameterName = "@markupuomoo", MyParamGetter = () => { return InternalTools.MakeParam("@markupuomoo", SqlDbType.Int, markupuomoo, true); } }, 
						new SqlParamHolder(){ColumnName = "markuppercentoo", ParameterName = "@markuppercentoo", MyParamGetter = () => { return InternalTools.MakeParam("@markuppercentoo", SqlDbType.Decimal, markuppercentoo, true, 9, 2); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "fixedcostuom_desc", ParameterName = "@fixedcostuom_desc", MyParamGetter = () => { return InternalTools.MakeParam("@fixedcostuom_desc", SqlDbType.VarChar, fixedcostuom_desc, true, 2147483647); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "markupuom_desc", ParameterName = "@markupuom_desc", MyParamGetter = () => { return InternalTools.MakeParam("@markupuom_desc", SqlDbType.VarChar, markupuom_desc, true, 2147483647); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "fixedcostuomoo_desc", ParameterName = "@fixedcostuomoo_desc", MyParamGetter = () => { return InternalTools.MakeParam("@fixedcostuomoo_desc", SqlDbType.VarChar, fixedcostuomoo_desc, true, 2147483647); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "markupuomoo_desc", ParameterName = "@markupuomoo_desc", MyParamGetter = () => { return InternalTools.MakeParam("@markupuomoo_desc", SqlDbType.VarChar, markupuomoo_desc, true, 2147483647); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "upc_code", ParameterName = "@upc_code", MyParamGetter = () => { return InternalTools.MakeParam("@upc_code", SqlDbType.VarChar, upc_code, true, 2147483647); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, IsIdentity = false, ColumnName = "unit_type", ParameterName = "@unit_type", MyParamGetter = () => { return InternalTools.MakeParam("@unit_type", SqlDbType.Int, unit_type, true); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "purchase_unit_desc", ParameterName = "@purchase_unit_desc", MyParamGetter = () => { return InternalTools.MakeParam("@purchase_unit_desc", SqlDbType.VarChar, purchase_unit_desc, true, 2147483647); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "location_desc", ParameterName = "@location_desc", MyParamGetter = () => { return InternalTools.MakeParam("@location_desc", SqlDbType.VarChar, location_desc, true, 2147483647); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "vendor_code", ParameterName = "@vendor_code", MyParamGetter = () => { return InternalTools.MakeParam("@vendor_code", SqlDbType.VarChar, vendor_code, true, 2147483647); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "vendor_name", ParameterName = "@vendor_name", MyParamGetter = () => { return InternalTools.MakeParam("@vendor_name", SqlDbType.VarChar, vendor_name, true, 2147483647); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "item_code", ParameterName = "@item_code", MyParamGetter = () => { return InternalTools.MakeParam("@item_code", SqlDbType.VarChar, item_code, true, 2147483647); } }, 
						new SqlParamHolder(){ColumnName = "last_purchase_date", ParameterName = "@last_purchase_date", MyParamGetter = () => { return InternalTools.MakeParam("@last_purchase_date", SqlDbType.DateTime, _last_purchase_date, true); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "vendor_purch_unit_description", ParameterName = "@vendor_purch_unit_description", MyParamGetter = () => { return InternalTools.MakeParam("@vendor_purch_unit_description", SqlDbType.VarChar, vendor_purch_unit_description, true, 2147483647); } }, 
						new SqlParamHolder(){ColumnName = "unit_cost", ParameterName = "@unit_cost", MyParamGetter = () => { return InternalTools.MakeParam("@unit_cost", SqlDbType.Money, _unit_cost, true); } }, 
						new SqlParamHolder(){ColumnName = "is_preferred", ParameterName = "@is_preferred", MyParamGetter = () => { return InternalTools.MakeParam("@is_preferred", SqlDbType.Bit, _is_preferred, true); } }, 
						new SqlParamHolder(){ColumnName = "showpurchaseunits", ParameterName = "@showpurchaseunits", MyParamGetter = () => { return InternalTools.MakeParam("@showpurchaseunits", SqlDbType.Bit, _showpurchaseunits, true); } }, 
						new SqlParamHolder(){ColumnName = "showlocations", ParameterName = "@showlocations", MyParamGetter = () => { return InternalTools.MakeParam("@showlocations", SqlDbType.Bit, _showlocations, true); } }, 
						new SqlParamHolder(){ColumnName = "showparlevels", ParameterName = "@showparlevels", MyParamGetter = () => { return InternalTools.MakeParam("@showparlevels", SqlDbType.Bit, _showparlevels, true); } }, 
						new SqlParamHolder(){ColumnName = "showvendorinfo", ParameterName = "@showvendorinfo", MyParamGetter = () => { return InternalTools.MakeParam("@showvendorinfo", SqlDbType.Bit, _showvendorinfo, true); } }, 
						new SqlParamHolder(){ColumnName = "showcommissarydetail", ParameterName = "@showcommissarydetail", MyParamGetter = () => { return InternalTools.MakeParam("@showcommissarydetail", SqlDbType.Bit, _showcommissarydetail, true); } }, 
						new SqlParamHolder(){ColumnName = "showupccodes", ParameterName = "@showupccodes", MyParamGetter = () => { return InternalTools.MakeParam("@showupccodes", SqlDbType.Bit, _showupccodes, true); } } 
					};  			  
				}
				return __parameters;
			}
		}
		
		protected override void Update(SqlConnection conn) { 
			StockProcUpdate(conn); //will use StockSaveTableName and MyParameters to build an update statement where IsPrimaryKey is true
			
			////Or you can make your own below:
			//InternalTools.ScriptRun("your update sql here", conn, new SqlParameter[] { /*parms here*/ }, GetTimeout());
		}
		
		protected override void Insert(SqlConnection conn) { 
			StockProcInsert(conn); //will use StockSaveTableName and MyParameters to build an insert statement
			
			////Or you can make your own below:
			//InternalTools.ScriptRun("your insert sql here", conn, new SqlParameter[] { /*parms here*/ }, GetTimeout());
		}
		
		protected override void Delete(SqlConnection conn) { 
			StockProcDelete(conn);//will use StockSaveTableName and MyParameters to build a delete statement where IsPrimaryKey is true
			
			////Or you can make your own below:
			//InternalTools.ScriptRun("your delete sql here", conn, new SqlParameter[] { /*parms here*/ }, GetTimeout());
			
		}
		
		#endif
		
		#endregion

	}
	
	public partial class rptRestaurantInventoryListingDtoList {
	}
} 

