﻿using Compeat.Data.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Compeat.Data.Framework.InternalUtils;
using Compeat.Demo.Data.Shared;
namespace Compeat.Demo.Data {

	#region Business Object
    
	/// <summary>
	/// This is the first of [1] possible exiting result set(s) from the proc called [rptMasterInventoryItems]
	/// </summary>
	[Serializable]
	public partial class rptMasterInventoryItemsDto : ProcBase {
		public rptMasterInventoryItemsDto(){ }
	
		/// <summary>
		/// calls its private twin in cases where a static is needed
		/// </summary>
		/// <returns></returns>
		internal static int MyTimeout() {
			return (new Compeat.Demo.Data.rptMasterInventoryItemsDto()).GetTimeout();
		}
		private int? _item_id{ get; set; }
		public virtual int? item_id { 
			get { return _item_id; } 
			set { _item_id = value; }
		}
		private string _item_description{ get; set; }
		public virtual string item_description { 
			get { return _item_description; } 
			set { _item_description = value; }
		}
		private string _item_description2{ get; set; }
		public virtual string item_description2 { 
			get { return _item_description2; } 
			set { _item_description2 = value; }
		}
		private int? _shelf_life{ get; set; }
		public virtual int? shelf_life { 
			get { return _shelf_life; } 
			set { _shelf_life = value; }
		}
		private bool? _is_catch_weight{ get; set; }
		public virtual bool? is_catch_weight { 
			get { return _is_catch_weight; } 
			set { _is_catch_weight = value; }
		}
		private string _level1_desc{ get; set; }
		public virtual string level1_desc { 
			get { return _level1_desc; } 
			set { _level1_desc = value; }
		}
		private int? _level1_sort_order{ get; set; }
		public virtual int? level1_sort_order { 
			get { return _level1_sort_order; } 
			set { _level1_sort_order = value; }
		}
		private string _level2_desc{ get; set; }
		public virtual string level2_desc { 
			get { return _level2_desc; } 
			set { _level2_desc = value; }
		}
		private int? _level2_sort_order{ get; set; }
		public virtual int? level2_sort_order { 
			get { return _level2_sort_order; } 
			set { _level2_sort_order = value; }
		}
		private string _level3_desc{ get; set; }
		public virtual string level3_desc { 
			get { return _level3_desc; } 
			set { _level3_desc = value; }
		}
		private int? _level3_sort_order{ get; set; }
		public virtual int? level3_sort_order { 
			get { return _level3_sort_order; } 
			set { _level3_sort_order = value; }
		}
		private string _upc_code{ get; set; }
		public virtual string upc_code { 
			get { return _upc_code; } 
			set { _upc_code = value; }
		}
		private decimal? _conversion_inventory_unit_qty{ get; set; }
		public virtual decimal? conversion_inventory_unit_qty { 
			get { return _conversion_inventory_unit_qty; } 
			set { _conversion_inventory_unit_qty = value; }
		}
		private string _conversion_inventory_unit_desc{ get; set; }
		public virtual string conversion_inventory_unit_desc { 
			get { return _conversion_inventory_unit_desc; } 
			set { _conversion_inventory_unit_desc = value; }
		}
		private decimal? _conversion_base_qty{ get; set; }
		public virtual decimal? conversion_base_qty { 
			get { return _conversion_base_qty; } 
			set { _conversion_base_qty = value; }
		}
		private string _conversion_base_description{ get; set; }
		public virtual string conversion_base_description { 
			get { return _conversion_base_description; } 
			set { _conversion_base_description = value; }
		}
		private int? _coupon_value{ get; set; }
		public virtual int? coupon_value { 
			get { return _coupon_value; } 
			set { _coupon_value = value; }
		}
		private string _base_unit_description{ get; set; }
		public virtual string base_unit_description { 
			get { return _base_unit_description; } 
			set { _base_unit_description = value; }
		}
		private string _notes{ get; set; }
		public virtual string notes { 
			get { return _notes; } 
			set { _notes = value; }
		}

		#region Loader  	  

		internal void Fill(SqlDataReader dr) {
			this._item_id = (dr.IsDBNull(rptMasterInventoryItems.RESULT_INDEX_item_id) ? (int?)null : dr.GetInt32(rptMasterInventoryItems.RESULT_INDEX_item_id));
			this._item_description = (dr.IsDBNull(rptMasterInventoryItems.RESULT_INDEX_item_description) ? null : dr.GetString(rptMasterInventoryItems.RESULT_INDEX_item_description));
			this._item_description2 = (dr.IsDBNull(rptMasterInventoryItems.RESULT_INDEX_item_description2) ? null : dr.GetString(rptMasterInventoryItems.RESULT_INDEX_item_description2));
			this._shelf_life = (dr.IsDBNull(rptMasterInventoryItems.RESULT_INDEX_shelf_life) ? (int?)null : dr.GetInt32(rptMasterInventoryItems.RESULT_INDEX_shelf_life));
			this._is_catch_weight = (dr.IsDBNull(rptMasterInventoryItems.RESULT_INDEX_is_catch_weight) ? (bool?)null : dr.GetBoolean(rptMasterInventoryItems.RESULT_INDEX_is_catch_weight));
			this._level1_desc = (dr.IsDBNull(rptMasterInventoryItems.RESULT_INDEX_level1_desc) ? null : dr.GetString(rptMasterInventoryItems.RESULT_INDEX_level1_desc));
			this._level1_sort_order = (dr.IsDBNull(rptMasterInventoryItems.RESULT_INDEX_level1_sort_order) ? (int?)null : dr.GetInt32(rptMasterInventoryItems.RESULT_INDEX_level1_sort_order));
			this._level2_desc = (dr.IsDBNull(rptMasterInventoryItems.RESULT_INDEX_level2_desc) ? null : dr.GetString(rptMasterInventoryItems.RESULT_INDEX_level2_desc));
			this._level2_sort_order = (dr.IsDBNull(rptMasterInventoryItems.RESULT_INDEX_level2_sort_order) ? (int?)null : dr.GetInt32(rptMasterInventoryItems.RESULT_INDEX_level2_sort_order));
			this._level3_desc = (dr.IsDBNull(rptMasterInventoryItems.RESULT_INDEX_level3_desc) ? null : dr.GetString(rptMasterInventoryItems.RESULT_INDEX_level3_desc));
			this._level3_sort_order = (dr.IsDBNull(rptMasterInventoryItems.RESULT_INDEX_level3_sort_order) ? (int?)null : dr.GetInt32(rptMasterInventoryItems.RESULT_INDEX_level3_sort_order));
			this._upc_code = (dr.IsDBNull(rptMasterInventoryItems.RESULT_INDEX_upc_code) ? null : dr.GetString(rptMasterInventoryItems.RESULT_INDEX_upc_code));
			this._conversion_inventory_unit_qty = (dr.IsDBNull(rptMasterInventoryItems.RESULT_INDEX_conversion_inventory_unit_qty) ? (decimal?)null : dr.GetDecimal(rptMasterInventoryItems.RESULT_INDEX_conversion_inventory_unit_qty));
			this._conversion_inventory_unit_desc = (dr.IsDBNull(rptMasterInventoryItems.RESULT_INDEX_conversion_inventory_unit_desc) ? null : dr.GetString(rptMasterInventoryItems.RESULT_INDEX_conversion_inventory_unit_desc));
			this._conversion_base_qty = (dr.IsDBNull(rptMasterInventoryItems.RESULT_INDEX_conversion_base_qty) ? (decimal?)null : dr.GetDecimal(rptMasterInventoryItems.RESULT_INDEX_conversion_base_qty));
			this._conversion_base_description = (dr.IsDBNull(rptMasterInventoryItems.RESULT_INDEX_conversion_base_description) ? null : dr.GetString(rptMasterInventoryItems.RESULT_INDEX_conversion_base_description));
			this._coupon_value = (dr.IsDBNull(rptMasterInventoryItems.RESULT_INDEX_coupon_value) ? (int?)null : dr.GetInt32(rptMasterInventoryItems.RESULT_INDEX_coupon_value));
			this._base_unit_description = (dr.IsDBNull(rptMasterInventoryItems.RESULT_INDEX_base_unit_description) ? null : dr.GetString(rptMasterInventoryItems.RESULT_INDEX_base_unit_description));
			this._notes = (dr.IsDBNull(rptMasterInventoryItems.RESULT_INDEX_notes) ? null : dr.GetString(rptMasterInventoryItems.RESULT_INDEX_notes));
		}
		
		#endregion Loader
		protected override string ObjName
		{
			get
			{
				return Compeat.Demo.Data.rptMasterInventoryItems.PROC_NAME;
			}
		}
	}
		
	

	[Serializable]
	public partial class rptMasterInventoryItemsDtoList : List<Compeat.Demo.Data.rptMasterInventoryItemsDto> { }
	#endregion

	public partial class rptMasterInventoryItems {
		internal const string PROC_NAME = "dbo.rptMasterInventoryItems";
		internal const int RESULT_INDEX_item_id = 0, RESULT_INDEX_item_description = 1, RESULT_INDEX_item_description2 = 2, RESULT_INDEX_shelf_life = 3, RESULT_INDEX_is_catch_weight = 4, RESULT_INDEX_level1_desc = 5, RESULT_INDEX_level1_sort_order = 6, RESULT_INDEX_level2_desc = 7, RESULT_INDEX_level2_sort_order = 8, RESULT_INDEX_level3_desc = 9, RESULT_INDEX_level3_sort_order = 10, RESULT_INDEX_upc_code = 11, RESULT_INDEX_conversion_inventory_unit_qty = 12, RESULT_INDEX_conversion_inventory_unit_desc = 13, RESULT_INDEX_conversion_base_qty = 14, RESULT_INDEX_conversion_base_description = 15, RESULT_INDEX_coupon_value = 16, RESULT_INDEX_base_unit_description = 17, RESULT_INDEX_notes = 18;
	
		#region Repo Turn Around
		/// <summary>
		/// Executes the procedure and returns nothing. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// Returns the number of rows affected
		/// </summary>
		public virtual int ExecuteOnly(SqlConnection conn, int? userid, bool? includelevel2, bool? includelevel3, int? invlevel1, int? invlevel2, int? invlevel3, int? fromid, int? toid, int? classtype) {
			return _ExecuteOnly(conn,  userid,  includelevel2,  includelevel3,  invlevel1,  invlevel2,  invlevel3,  fromid,  toid,  classtype);
		}
	
		/// <summary>
		/// Executes the procedure and returns a single rptMasterInventoryItems. The reader will stop after pulling the first row since its a stored proc
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual Compeat.Demo.Data.rptMasterInventoryItemsDto GetFirst(SqlConnection conn, int? userid, bool? includelevel2, bool? includelevel3, int? invlevel1, int? invlevel2, int? invlevel3, int? fromid, int? toid, int? classtype) {
			return _GetFirst<Compeat.Demo.Data.rptMasterInventoryItemsDto>(conn,  userid,  includelevel2,  includelevel3,  invlevel1,  invlevel2,  invlevel3,  fromid,  toid,  classtype);
		}    	
		/// <summary>
		/// Executes the procedure and returns a single rptMasterInventoryItems. The reader will stop after pulling the first row since its a stored proc
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual Compeat.Demo.Data.rptMasterInventoryItemsDto GetFirst<TItemType>(SqlConnection conn, int? userid, bool? includelevel2, bool? includelevel3, int? invlevel1, int? invlevel2, int? invlevel3, int? fromid, int? toid, int? classtype) 
			where TItemType: Compeat.Demo.Data.rptMasterInventoryItemsDto, new()
		{
			return _GetFirst<TItemType>(conn,  userid,  includelevel2,  includelevel3,  invlevel1,  invlevel2,  invlevel3,  fromid,  toid,  classtype);
		}    

		/// <summary>
		/// Executes the procedure and returns a rptMasterInventoryItems. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual Compeat.Demo.Data.rptMasterInventoryItemsDtoList GetList(SqlConnection conn, int? userid, bool? includelevel2, bool? includelevel3, int? invlevel1, int? invlevel2, int? invlevel3, int? fromid, int? toid, int? classtype) {
			return _GetList<Compeat.Demo.Data.rptMasterInventoryItemsDto, Compeat.Demo.Data.rptMasterInventoryItemsDtoList>(conn,  userid,  includelevel2,  includelevel3,  invlevel1,  invlevel2,  invlevel3,  fromid,  toid,  classtype);
		}
		/// <summary>
		/// Executes the procedure and returns a rptMasterInventoryItems. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual TCollectionType GetList<TItemType, TCollectionType>(SqlConnection conn, int? userid, bool? includelevel2, bool? includelevel3, int? invlevel1, int? invlevel2, int? invlevel3, int? fromid, int? toid, int? classtype) 
			where TItemType: Compeat.Demo.Data.rptMasterInventoryItemsDto, new()
			where TCollectionType: List<TItemType>, new()
		{
			return _GetList<TItemType, TCollectionType>(conn,  userid,  includelevel2,  includelevel3,  invlevel1,  invlevel2,  invlevel3,  fromid,  toid,  classtype);
		}
		/// <summary>
		/// Executes the procedure and returns a [int?] which is the type and value of the first column of the first row of the results. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		public virtual int? GetScalar(SqlConnection conn, int? userid, bool? includelevel2, bool? includelevel3, int? invlevel1, int? invlevel2, int? invlevel3, int? fromid, int? toid, int? classtype) {
			return _GetScalar(conn,  userid,  includelevel2,  includelevel3,  invlevel1,  invlevel2,  invlevel3,  fromid,  toid,  classtype);
		}
		#endregion
	
		/// <summary>
		/// Executes the procedure and returns nothing. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// Returns the number of rows affected
		/// </summary>
		internal static int _ExecuteOnly(SqlConnection conn, int? userid, bool? includelevel2, bool? includelevel3, int? invlevel1, int? invlevel2, int? invlevel3, int? fromid, int? toid, int? classtype) {
			int __retVal = 0;
			_ExecNow(
				(__parameters) => { __retVal = InternalTools.ProcRun(Compeat.Demo.Data.rptMasterInventoryItems.PROC_NAME, conn, __parameters, Compeat.Demo.Data.rptMasterInventoryItemsDto.MyTimeout());  } //runs after params set 
				,  userid,  includelevel2,  includelevel3,  invlevel1,  invlevel2,  invlevel3,  fromid,  toid,  classtype
			);
			return __retVal;
		}
		
	
		/// <summary>
		/// Executes the procedure and returns a single rptMasterInventoryItems. The reader will stop after pulling the first row since its a stored proc
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		internal static TItemType _GetFirst<TItemType>(SqlConnection conn, int? userid, bool? includelevel2, bool? includelevel3, int? invlevel1, int? invlevel2, int? invlevel3, int? fromid, int? toid, int? classtype) 
			where TItemType: Compeat.Demo.Data.rptMasterInventoryItemsDto, new()
		{
			var ret = _GetList<TItemType, List<TItemType>>(1, conn,  userid,  includelevel2,  includelevel3,  invlevel1,  invlevel2,  invlevel3,  fromid,  toid,  classtype);
			if(ret != null){
				return ret.FirstOrDefault();
			}
			else{
				return null;
			}
		}    
		
		
		/// <summary>
		/// Executes the procedure and returns a rptMasterInventoryItems. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		internal static TCollectionType _GetList<TItemType, TCollectionType>(SqlConnection conn, int? userid, bool? includelevel2, bool? includelevel3, int? invlevel1, int? invlevel2, int? invlevel3, int? fromid, int? toid, int? classtype) 
			where TItemType: Compeat.Demo.Data.rptMasterInventoryItemsDto, new()
			where TCollectionType: List<TItemType>, new()
		{
			return _GetList<TItemType, TCollectionType>(ulong.MaxValue, conn,  userid,  includelevel2,  includelevel3,  invlevel1,  invlevel2,  invlevel3,  fromid,  toid,  classtype);
		}
		
		
		internal static TCollectionType _GetList<TItemType, TCollectionType>(ulong __rows_to_read, SqlConnection conn, int? userid, bool? includelevel2, bool? includelevel3, int? invlevel1, int? invlevel2, int? invlevel3, int? fromid, int? toid, int? classtype) 
			where TItemType: Compeat.Demo.Data.rptMasterInventoryItemsDto, new()
			where TCollectionType: List<TItemType>, new()
		{
			var __retVal = new TCollectionType();
		
			_ExecNow(
				(__parameters) => { 
						InternalTools.ProcRunReader(Compeat.Demo.Data.rptMasterInventoryItems.PROC_NAME, conn, __parameters,
							(sdr) => {
								if (sdr.HasRows) {
									ulong rCnt = 0;
									while (sdr.Read()) {
										var newVal = new TItemType();
										newVal.Fill(sdr);
										__retVal.Add(newVal);
										if(++rCnt >= __rows_to_read) {
											break;
										}
									}
								}
							}
							, Compeat.Demo.Data.rptMasterInventoryItemsDto.MyTimeout()
						);  //runs after params set
					}  
				,  userid,  includelevel2,  includelevel3,  invlevel1,  invlevel2,  invlevel3,  fromid,  toid,  classtype
			);
			
			return __retVal;
		}
		/// <summary>
		/// Executes the procedure and returns a [int?] which is the type and value of the first column of the first row of the results. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// </summary>
		internal static int? _GetScalar(SqlConnection conn, int? userid, bool? includelevel2, bool? includelevel3, int? invlevel1, int? invlevel2, int? invlevel3, int? fromid, int? toid, int? classtype) {
			int? __retVal = default(int?);
			_ExecNow(
				(__parameters) => { __retVal = InternalTools.ProcRunScalar<int?>(Compeat.Demo.Data.rptMasterInventoryItems.PROC_NAME, conn, __parameters, Compeat.Demo.Data.rptMasterInventoryItemsDto.MyTimeout());  } //runs after params set 
				,  userid,  includelevel2,  includelevel3,  invlevel1,  invlevel2,  invlevel3,  fromid,  toid,  classtype
			);
			return __retVal;
		}

		internal static void _ExecNow(Action<SqlParameter[]> __to_run, int? userid, bool? includelevel2, bool? includelevel3, int? invlevel1, int? invlevel2, int? invlevel3, int? fromid, int? toid, int? classtype) {
			var __parameters = new SqlParameter[9];
			__parameters[0] = InternalTools.MakeParam("@userid", SqlDbType.Int, userid, true, ParameterDirection.Input);
			__parameters[1] = InternalTools.MakeParam("@includelevel2", SqlDbType.Bit, includelevel2, true, ParameterDirection.Input);
			__parameters[2] = InternalTools.MakeParam("@includelevel3", SqlDbType.Bit, includelevel3, true, ParameterDirection.Input);
			__parameters[3] = InternalTools.MakeParam("@invlevel1", SqlDbType.Int, invlevel1, true, ParameterDirection.Input);
			__parameters[4] = InternalTools.MakeParam("@invlevel2", SqlDbType.Int, invlevel2, true, ParameterDirection.Input);
			__parameters[5] = InternalTools.MakeParam("@invlevel3", SqlDbType.Int, invlevel3, true, ParameterDirection.Input);
			__parameters[6] = InternalTools.MakeParam("@fromid", SqlDbType.Int, fromid, true, ParameterDirection.Input);
			__parameters[7] = InternalTools.MakeParam("@toid", SqlDbType.Int, toid, true, ParameterDirection.Input);
			__parameters[8] = InternalTools.MakeParam("@classtype", SqlDbType.Int, classtype, true, ParameterDirection.Input);
			__to_run(__parameters);
			
		}
	}
	
	#region Repository needs
	public partial interface IRepository {
		Compeat.Demo.Data.rptMasterInventoryItems rptMasterInventoryItems { get; }
	}

	public partial class Repository {
		private Compeat.Demo.Data.rptMasterInventoryItems _rptMasterInventoryItems = null;
		public Compeat.Demo.Data.rptMasterInventoryItems rptMasterInventoryItems {
			get {
				if(_rptMasterInventoryItems == null) {
					_rptMasterInventoryItems = new Compeat.Demo.Data.rptMasterInventoryItems();
				}
				return _rptMasterInventoryItems;
			}
		}
	}
	#endregion Repository needs
}
