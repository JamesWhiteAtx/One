﻿using Compeat.Data.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Compeat.Data.Framework.InternalUtils;
using Compeat.Demo.Data.Shared;
namespace Compeat.Demo.Data {

	#region Business Object
    
	/// <summary>
	/// Proc [exeGetLoggedInValues] has no expected output, this class exists if the timeout needs to be overriden(see public GetTimeout in SqlBase)
	/// </summary>
	[Serializable]
	public partial class exeGetLoggedInValuesDto : ProcBase {
		public exeGetLoggedInValuesDto(){ }
	
		/// <summary>
		/// calls its instanced twin in cases where a static is needed
		/// </summary>
		/// <returns></returns>
		internal static int MyTimeout() {
			return (new Compeat.Demo.Data.exeGetLoggedInValuesDto()).GetTimeout();
		}
		
		protected override string ObjName
		{
			get
			{
				return Compeat.Demo.Data.exeGetLoggedInValues.PROC_NAME;
			}
		}
	}
	
	#endregion

	public partial class exeGetLoggedInValues {
		internal const string PROC_NAME = "dbo.exeGetLoggedInValues";
	
		#region Repo Turn Around
		/// <summary>
		/// Executes the procedure and returns nothing. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// Returns the number of rows affected
		/// </summary>
		public virtual int ExecuteOnly(SqlConnection conn, int? userid, int? currentstorenum, ref int? newcurrentstorenum, ref int? defaultstore, ref bool? promptforrestaurant, ref string currentStoreName, ref string currentUserName) {
			return _ExecuteOnly(conn,  userid,  currentstorenum, ref  newcurrentstorenum, ref  defaultstore, ref  promptforrestaurant, ref  currentStoreName, ref  currentUserName);
		}
		#endregion
	
		/// <summary>
		/// Executes the procedure and returns nothing. 
		/// Parameters passed by ref may be modified depending on the procedure.
		/// Returns the number of rows affected
		/// </summary>
		internal static int _ExecuteOnly(SqlConnection conn, int? userid, int? currentstorenum, ref int? newcurrentstorenum, ref int? defaultstore, ref bool? promptforrestaurant, ref string currentStoreName, ref string currentUserName) {
			int __retVal = 0;
			_ExecNow(
				(__parameters) => { __retVal = InternalTools.ProcRun(Compeat.Demo.Data.exeGetLoggedInValues.PROC_NAME, conn, __parameters, Compeat.Demo.Data.exeGetLoggedInValuesDto.MyTimeout());  } //runs after params set 
				,  userid,  currentstorenum, ref  newcurrentstorenum, ref  defaultstore, ref  promptforrestaurant, ref  currentStoreName, ref  currentUserName
			);
			return __retVal;
		}
		

		internal static void _ExecNow(Action<SqlParameter[]> __to_run, int? userid, int? currentstorenum, ref int? newcurrentstorenum, ref int? defaultstore, ref bool? promptforrestaurant, ref string currentStoreName, ref string currentUserName) {
			var __parameters = new SqlParameter[7];
			__parameters[0] = InternalTools.MakeParam("@userid", SqlDbType.Int, userid, true, ParameterDirection.Input);
			__parameters[1] = InternalTools.MakeParam("@currentstorenum", SqlDbType.Int, currentstorenum, true, ParameterDirection.Input);
			__parameters[2] = InternalTools.MakeParam("@newcurrentstorenum", SqlDbType.Int, newcurrentstorenum, true, ParameterDirection.InputOutput);
			__parameters[3] = InternalTools.MakeParam("@defaultstore", SqlDbType.Int, defaultstore, true, ParameterDirection.InputOutput);
			__parameters[4] = InternalTools.MakeParam("@promptforrestaurant", SqlDbType.Bit, promptforrestaurant, true, ParameterDirection.InputOutput);
			__parameters[5] = InternalTools.MakeParam("@currentStoreName", SqlDbType.VarChar, currentStoreName, true, 70, ParameterDirection.InputOutput);
			__parameters[6] = InternalTools.MakeParam("@currentUserName", SqlDbType.VarChar, currentUserName, true, 20, ParameterDirection.InputOutput);
			__to_run(__parameters);
			
			newcurrentstorenum = __parameters[2].Value == DBNull.Value ? (int?)null : (int?)__parameters[2].Value;
			defaultstore = __parameters[3].Value == DBNull.Value ? (int?)null : (int?)__parameters[3].Value;
			promptforrestaurant = __parameters[4].Value == DBNull.Value ? (bool?)null : (bool?)__parameters[4].Value;
			currentStoreName = __parameters[5].Value == DBNull.Value ? (string)null : (string)__parameters[5].Value;
			currentUserName = __parameters[6].Value == DBNull.Value ? (string)null : (string)__parameters[6].Value;
		}
	}
	
	#region Repository needs
	public partial interface IRepository {
		Compeat.Demo.Data.exeGetLoggedInValues exeGetLoggedInValues { get; }
	}

	public partial class Repository {
		private Compeat.Demo.Data.exeGetLoggedInValues _exeGetLoggedInValues = null;
		public Compeat.Demo.Data.exeGetLoggedInValues exeGetLoggedInValues {
			get {
				if(_exeGetLoggedInValues == null) {
					_exeGetLoggedInValues = new Compeat.Demo.Data.exeGetLoggedInValues();
				}
				return _exeGetLoggedInValues;
			}
		}
	}
	#endregion Repository needs
}
