﻿#define IsSavableProc
using Compeat.Data.Framework;
using Compeat.Data.Framework.InternalUtils;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
namespace Compeat.Demo.Data {
	public partial class qryUserProfileDto {

		#region Savable Implementation
		
		#if IsSavableProc
		
		//if the stock savable functionality is used, then this should return the table name to save to
		protected override string StockSaveTableName {
			get {
				return "users";
			}
		}
		
		protected override bool HasPkSet {
			get {
				//change to return true if a pk is known, so the save function knows to call the update. 
				return this.userid.GetValueOrDefault(0) > 0;
			}
		}

		private List<SqlParamHolder> __parameters { get; set;}
		protected override IEnumerable<SqlParamHolder> MyParameters {
			get {
				if(__parameters == null) {
				   __parameters = new List<SqlParamHolder>() {
						new SqlParamHolder(){IsPrimaryKey = true, IsIdentity = false, ColumnName = "userid", ParameterName = "@userid", MyParamGetter = () => { return InternalTools.MakeParam("@userid", SqlDbType.Int, userid, true); } }, 
						new SqlParamHolder(){IsTimestamp = true, ColumnName = "recstamp", ParameterName = "@recstamp", MyParamGetter = () => { return InternalTools.MakeParam("@recstamp", SqlDbType.Timestamp, _recstamp, true); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "username", ParameterName = "@username", MyParamGetter = () => { return InternalTools.MakeParam("@username", SqlDbType.VarChar, username, true, 20); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "fullname", ParameterName = "@fullname", MyParamGetter = () => { return InternalTools.MakeParam("@fullname", SqlDbType.VarChar, fullname, true, 100); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "description", ParameterName = "@description", MyParamGetter = () => { return InternalTools.MakeParam("@description", SqlDbType.VarChar, description, true, 100); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "password", ParameterName = "@password", MyParamGetter = () => { return InternalTools.MakeParam("@password", SqlDbType.VarChar, password, true, 250); } }, 
						new SqlParamHolder(){IsPrimaryKey = false, ColumnName = "lang", ParameterName = "@lang", MyParamGetter = () => { return InternalTools.MakeParam("@lang", SqlDbType.VarChar, lang, true, 5); } } 
					};  			  
				}
				return __parameters;
			}
		}
		
		protected override void Update(SqlConnection conn) { 
			StockProcUpdate(conn); //will use StockSaveTableName and MyParameters to build an update statement where IsPrimaryKey is true
			
			////Or you can make your own below:
			//InternalTools.ScriptRun("your update sql here", conn, new SqlParameter[] { /*parms here*/ }, GetTimeout());
		}
		
		protected override void Insert(SqlConnection conn) { 
			StockProcInsert(conn); //will use StockSaveTableName and MyParameters to build an insert statement
			
			////Or you can make your own below:
			//InternalTools.ScriptRun("your insert sql here", conn, new SqlParameter[] { /*parms here*/ }, GetTimeout());
		}
		
		protected override void Delete(SqlConnection conn) { 
			StockProcDelete(conn);//will use StockSaveTableName and MyParameters to build a delete statement where IsPrimaryKey is true
			
			////Or you can make your own below:
			//InternalTools.ScriptRun("your delete sql here", conn, new SqlParameter[] { /*parms here*/ }, GetTimeout());
			
		}
		
		#endif
		
		#endregion

	}
	
	public partial class qryUserProfileDtoList {
	}
} 

