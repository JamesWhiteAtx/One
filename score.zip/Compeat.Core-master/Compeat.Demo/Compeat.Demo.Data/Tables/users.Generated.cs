﻿using Compeat.Data.Framework;
using Compeat.Data.Framework.InternalUtils;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using Compeat.Demo.Data.Shared;
namespace Compeat.Demo.Data {
	[Serializable]
	public partial class usersDto : TableBase<Compeat.Demo.Data.usersDto, int?> {
		
		public virtual IEnumerable<Compeat.Demo.Data.userstorelinksDto> userStoreLinks {  get; set; }
		protected override System.Collections.Generic.IEnumerable<SavableMapper> StockChildCollections {
			get {
				yield return new SavableMapper() { 
					MyPropName = "userStoreLinks"
					, Obj = () => { return userStoreLinks; }
					, MapPk = () => 
						{ 
							if(userStoreLinks != null){
								foreach(var _child in userStoreLinks){
									_child.userid = MyPk.GetValueOrDefault();
								}
							}   						 
						}
					, MapLoadFromFk = (conn) => 
						{ 
							var pkGetter = MyPk_param_getter();
							userStoreLinks = Compeat.Demo.Data.userstorelinks._GetList(conn, Compeat.Demo.Data.userstorelinks._SELECT,
													new TableWhereParamsAndOrder() { WhereClause = string.Format("[userid] = {0}", pkGetter.ParameterName), OrderBy = null, ParamList = new[] { pkGetter } }, ulong.MaxValue); 
						}
				};
				yield break;
			}
		}   
	
	
		/// <summary>
		/// calls its private twin in cases where a static is needed
		/// </summary>
		/// <returns></returns>
		internal static int MyTimeout() {
			return (new Compeat.Demo.Data.usersDto()).GetTimeout();
		}
		
		#region Constants
		internal const int COLUMN_COUNT = 48;
		protected override int ColumnCount { get { return COLUMN_COUNT; } }
		public const int COLUMN_INDEX_userid = 0, COLUMN_INDEX_username = 1, COLUMN_INDEX_fullname = 2, COLUMN_INDEX_description = 3, COLUMN_INDEX_defaultstore = 4, COLUMN_INDEX_promptforrestaurant = 5, COLUMN_INDEX_recstamp = 6, COLUMN_INDEX_password = 7, COLUMN_INDEX_email = 8, COLUMN_INDEX_failedpasswordattemptstart = 9, COLUMN_INDEX_failedpasswordattemptcount = 10, COLUMN_INDEX_lastpasswordchange = 11, COLUMN_INDEX_mustchangepassword = 12, COLUMN_INDEX_active = 13, COLUMN_INDEX_theme = 14, COLUMN_INDEX_defaultgroup = 15, COLUMN_INDEX_promptformenu = 16, COLUMN_INDEX_showscheduledcostsummary = 17, COLUMN_INDEX_scheduledcostsummaryorder = 18, COLUMN_INDEX_showscheduledhoursfordeptsummary = 19, COLUMN_INDEX_scheduledhoursfordeptsummaryorder = 20, COLUMN_INDEX_showforecastedsalessummary = 21, COLUMN_INDEX_forecastedsalessummaryorder = 22, COLUMN_INDEX_showscheduledhourssummary = 23, COLUMN_INDEX_scheduledhourssummaryorder = 24, COLUMN_INDEX_showallscheduledhourssummary = 25, COLUMN_INDEX_allscheduledhourssummaryorder = 26, COLUMN_INDEX_showsalesperlaborhoursummary = 27, COLUMN_INDEX_salesperlaborhoursummaryorder = 28, COLUMN_INDEX_showallscheduledcostsummary = 29, COLUMN_INDEX_allscheduledcostsummaryorder = 30, COLUMN_INDEX_showscheduledcostpercentsummary = 31, COLUMN_INDEX_scheduledcostpercentsummaryorder = 32, COLUMN_INDEX_showallscheduledcostpercentsummary = 33, COLUMN_INDEX_allscheduledcostpercentsummaryorder = 34, COLUMN_INDEX_showscheduledcostsfordeptsummary = 35, COLUMN_INDEX_scheduledcostsfordeptsummaryorder = 36, COLUMN_INDEX_securitytoken = 37, COLUMN_INDEX_showscheduledshiftcountssummary = 38, COLUMN_INDEX_scheduledshiftcountssummaryorder = 39, COLUMN_INDEX_lang = 40, COLUMN_INDEX_mgrtimeoffalerts = 41, COLUMN_INDEX_mgrswapalerts = 42, COLUMN_INDEX_mgrdroppickupalerts = 43, COLUMN_INDEX_mgrautocheckinout = 44, COLUMN_INDEX_mobilephone = 45, COLUMN_INDEX_alertviaemail = 46, COLUMN_INDEX_alertviasms = 47;
		public const string COLUMN_NAME_userid = "userid", COLUMN_NAME_username = "username", COLUMN_NAME_fullname = "fullname", COLUMN_NAME_description = "description", COLUMN_NAME_defaultstore = "defaultstore", COLUMN_NAME_promptforrestaurant = "promptforrestaurant", COLUMN_NAME_recstamp = "recstamp", COLUMN_NAME_password = "password", COLUMN_NAME_email = "email", COLUMN_NAME_failedpasswordattemptstart = "failedpasswordattemptstart", COLUMN_NAME_failedpasswordattemptcount = "failedpasswordattemptcount", COLUMN_NAME_lastpasswordchange = "lastpasswordchange", COLUMN_NAME_mustchangepassword = "mustchangepassword", COLUMN_NAME_active = "active", COLUMN_NAME_theme = "theme", COLUMN_NAME_defaultgroup = "defaultgroup", COLUMN_NAME_promptformenu = "promptformenu", COLUMN_NAME_showscheduledcostsummary = "showscheduledcostsummary", COLUMN_NAME_scheduledcostsummaryorder = "scheduledcostsummaryorder", COLUMN_NAME_showscheduledhoursfordeptsummary = "showscheduledhoursfordeptsummary", COLUMN_NAME_scheduledhoursfordeptsummaryorder = "scheduledhoursfordeptsummaryorder", COLUMN_NAME_showforecastedsalessummary = "showforecastedsalessummary", COLUMN_NAME_forecastedsalessummaryorder = "forecastedsalessummaryorder", COLUMN_NAME_showscheduledhourssummary = "showscheduledhourssummary", COLUMN_NAME_scheduledhourssummaryorder = "scheduledhourssummaryorder", COLUMN_NAME_showallscheduledhourssummary = "showallscheduledhourssummary", COLUMN_NAME_allscheduledhourssummaryorder = "allscheduledhourssummaryorder", COLUMN_NAME_showsalesperlaborhoursummary = "showsalesperlaborhoursummary", COLUMN_NAME_salesperlaborhoursummaryorder = "salesperlaborhoursummaryorder", COLUMN_NAME_showallscheduledcostsummary = "showallscheduledcostsummary", COLUMN_NAME_allscheduledcostsummaryorder = "allscheduledcostsummaryorder", COLUMN_NAME_showscheduledcostpercentsummary = "showscheduledcostpercentsummary", COLUMN_NAME_scheduledcostpercentsummaryorder = "scheduledcostpercentsummaryorder", COLUMN_NAME_showallscheduledcostpercentsummary = "showallscheduledcostpercentsummary", COLUMN_NAME_allscheduledcostpercentsummaryorder = "allscheduledcostpercentsummaryorder", COLUMN_NAME_showscheduledcostsfordeptsummary = "showscheduledcostsfordeptsummary", COLUMN_NAME_scheduledcostsfordeptsummaryorder = "scheduledcostsfordeptsummaryorder", COLUMN_NAME_securitytoken = "securitytoken", COLUMN_NAME_showscheduledshiftcountssummary = "showscheduledshiftcountssummary", COLUMN_NAME_scheduledshiftcountssummaryorder = "scheduledshiftcountssummaryorder", COLUMN_NAME_lang = "lang", COLUMN_NAME_mgrtimeoffalerts = "mgrtimeoffalerts", COLUMN_NAME_mgrswapalerts = "mgrswapalerts", COLUMN_NAME_mgrdroppickupalerts = "mgrdroppickupalerts", COLUMN_NAME_mgrautocheckinout = "mgrautocheckinout", COLUMN_NAME_mobilephone = "mobilephone", COLUMN_NAME_alertviaemail = "alertviaemail", COLUMN_NAME_alertviasms = "alertviasms";
		public const string PARAMETER_NAME_userid = "@userid", PARAMETER_NAME_username = "@username", PARAMETER_NAME_fullname = "@fullname", PARAMETER_NAME_description = "@description", PARAMETER_NAME_defaultstore = "@defaultstore", PARAMETER_NAME_promptforrestaurant = "@promptforrestaurant", PARAMETER_NAME_recstamp = "@recstamp", PARAMETER_NAME_password = "@password", PARAMETER_NAME_email = "@email", PARAMETER_NAME_failedpasswordattemptstart = "@failedpasswordattemptstart", PARAMETER_NAME_failedpasswordattemptcount = "@failedpasswordattemptcount", PARAMETER_NAME_lastpasswordchange = "@lastpasswordchange", PARAMETER_NAME_mustchangepassword = "@mustchangepassword", PARAMETER_NAME_active = "@active", PARAMETER_NAME_theme = "@theme", PARAMETER_NAME_defaultgroup = "@defaultgroup", PARAMETER_NAME_promptformenu = "@promptformenu", PARAMETER_NAME_showscheduledcostsummary = "@showscheduledcostsummary", PARAMETER_NAME_scheduledcostsummaryorder = "@scheduledcostsummaryorder", PARAMETER_NAME_showscheduledhoursfordeptsummary = "@showscheduledhoursfordeptsummary", PARAMETER_NAME_scheduledhoursfordeptsummaryorder = "@scheduledhoursfordeptsummaryorder", PARAMETER_NAME_showforecastedsalessummary = "@showforecastedsalessummary", PARAMETER_NAME_forecastedsalessummaryorder = "@forecastedsalessummaryorder", PARAMETER_NAME_showscheduledhourssummary = "@showscheduledhourssummary", PARAMETER_NAME_scheduledhourssummaryorder = "@scheduledhourssummaryorder", PARAMETER_NAME_showallscheduledhourssummary = "@showallscheduledhourssummary", PARAMETER_NAME_allscheduledhourssummaryorder = "@allscheduledhourssummaryorder", PARAMETER_NAME_showsalesperlaborhoursummary = "@showsalesperlaborhoursummary", PARAMETER_NAME_salesperlaborhoursummaryorder = "@salesperlaborhoursummaryorder", PARAMETER_NAME_showallscheduledcostsummary = "@showallscheduledcostsummary", PARAMETER_NAME_allscheduledcostsummaryorder = "@allscheduledcostsummaryorder", PARAMETER_NAME_showscheduledcostpercentsummary = "@showscheduledcostpercentsummary", PARAMETER_NAME_scheduledcostpercentsummaryorder = "@scheduledcostpercentsummaryorder", PARAMETER_NAME_showallscheduledcostpercentsummary = "@showallscheduledcostpercentsummary", PARAMETER_NAME_allscheduledcostpercentsummaryorder = "@allscheduledcostpercentsummaryorder", PARAMETER_NAME_showscheduledcostsfordeptsummary = "@showscheduledcostsfordeptsummary", PARAMETER_NAME_scheduledcostsfordeptsummaryorder = "@scheduledcostsfordeptsummaryorder", PARAMETER_NAME_securitytoken = "@securitytoken", PARAMETER_NAME_showscheduledshiftcountssummary = "@showscheduledshiftcountssummary", PARAMETER_NAME_scheduledshiftcountssummaryorder = "@scheduledshiftcountssummaryorder", PARAMETER_NAME_lang = "@lang", PARAMETER_NAME_mgrtimeoffalerts = "@mgrtimeoffalerts", PARAMETER_NAME_mgrswapalerts = "@mgrswapalerts", PARAMETER_NAME_mgrdroppickupalerts = "@mgrdroppickupalerts", PARAMETER_NAME_mgrautocheckinout = "@mgrautocheckinout", PARAMETER_NAME_mobilephone = "@mobilephone", PARAMETER_NAME_alertviaemail = "@alertviaemail", PARAMETER_NAME_alertviasms = "@alertviasms";
	
		internal const string _PK_COLUMN_NAME = COLUMN_NAME_userid;
		internal const string _PK_PARAMETER_NAME = "@PK_PARAM";
		internal const string _TIMESTAMP_COLUMN_NAME = COLUMN_NAME_recstamp;
		internal const string _TIMESTAMP_PARAMETER_NAME = PARAMETER_NAME_recstamp;
		internal const string _DELETE = "DELETE FROM [dbo].[users] WHERE [userid] = @PK_PARAM";
		internal const string _INSERT = "insert into [dbo].[users] ([userid], [username], [fullname], [description], [defaultstore], [promptforrestaurant], [password], [email], [failedpasswordattemptstart], [failedpasswordattemptcount], [lastpasswordchange], [mustchangepassword], [active], [theme], [defaultgroup], [promptformenu], [showscheduledcostsummary], [scheduledcostsummaryorder], [showscheduledhoursfordeptsummary], [scheduledhoursfordeptsummaryorder], [showforecastedsalessummary], [forecastedsalessummaryorder], [showscheduledhourssummary], [scheduledhourssummaryorder], [showallscheduledhourssummary], [allscheduledhourssummaryorder], [showsalesperlaborhoursummary], [salesperlaborhoursummaryorder], [showallscheduledcostsummary], [allscheduledcostsummaryorder], [showscheduledcostpercentsummary], [scheduledcostpercentsummaryorder], [showallscheduledcostpercentsummary], [allscheduledcostpercentsummaryorder], [showscheduledcostsfordeptsummary], [scheduledcostsfordeptsummaryorder], [securitytoken], [showscheduledshiftcountssummary], [scheduledshiftcountssummaryorder], [lang], [mgrtimeoffalerts], [mgrswapalerts], [mgrdroppickupalerts], [mgrautocheckinout], [mobilephone], [alertviaemail], [alertviasms]) values (@userid, @username, @fullname, @description, @defaultstore, @promptforrestaurant, @password, @email, @failedpasswordattemptstart, @failedpasswordattemptcount, @lastpasswordchange, @mustchangepassword, @active, @theme, @defaultgroup, @promptformenu, @showscheduledcostsummary, @scheduledcostsummaryorder, @showscheduledhoursfordeptsummary, @scheduledhoursfordeptsummaryorder, @showforecastedsalessummary, @forecastedsalessummaryorder, @showscheduledhourssummary, @scheduledhourssummaryorder, @showallscheduledhourssummary, @allscheduledhourssummaryorder, @showsalesperlaborhoursummary, @salesperlaborhoursummaryorder, @showallscheduledcostsummary, @allscheduledcostsummaryorder, @showscheduledcostpercentsummary, @scheduledcostpercentsummaryorder, @showallscheduledcostpercentsummary, @allscheduledcostpercentsummaryorder, @showscheduledcostsfordeptsummary, @scheduledcostsfordeptsummaryorder, @securitytoken, @showscheduledshiftcountssummary, @scheduledshiftcountssummaryorder, @lang, @mgrtimeoffalerts, @mgrswapalerts, @mgrdroppickupalerts, @mgrautocheckinout, @mobilephone, @alertviaemail, @alertviasms); select top 1 [recstamp] from [dbo].[users] where [userid] = @PK_PARAM;";
		internal const string _UPDATE = "update [dbo].[users] set {0} where [userid] = @PK_PARAM and [recstamp] = @recstamp;select top 1 [recstamp] from [dbo].[users] where [userid] = @PK_PARAM;";
		internal const string _UPDATE_FULL = "update [dbo].[users] set [userid]=@userid, [username]=@username, [fullname]=@fullname, [description]=@description, [defaultstore]=@defaultstore, [promptforrestaurant]=@promptforrestaurant, [password]=@password, [email]=@email, [failedpasswordattemptstart]=@failedpasswordattemptstart, [failedpasswordattemptcount]=@failedpasswordattemptcount, [lastpasswordchange]=@lastpasswordchange, [mustchangepassword]=@mustchangepassword, [active]=@active, [theme]=@theme, [defaultgroup]=@defaultgroup, [promptformenu]=@promptformenu, [showscheduledcostsummary]=@showscheduledcostsummary, [scheduledcostsummaryorder]=@scheduledcostsummaryorder, [showscheduledhoursfordeptsummary]=@showscheduledhoursfordeptsummary, [scheduledhoursfordeptsummaryorder]=@scheduledhoursfordeptsummaryorder, [showforecastedsalessummary]=@showforecastedsalessummary, [forecastedsalessummaryorder]=@forecastedsalessummaryorder, [showscheduledhourssummary]=@showscheduledhourssummary, [scheduledhourssummaryorder]=@scheduledhourssummaryorder, [showallscheduledhourssummary]=@showallscheduledhourssummary, [allscheduledhourssummaryorder]=@allscheduledhourssummaryorder, [showsalesperlaborhoursummary]=@showsalesperlaborhoursummary, [salesperlaborhoursummaryorder]=@salesperlaborhoursummaryorder, [showallscheduledcostsummary]=@showallscheduledcostsummary, [allscheduledcostsummaryorder]=@allscheduledcostsummaryorder, [showscheduledcostpercentsummary]=@showscheduledcostpercentsummary, [scheduledcostpercentsummaryorder]=@scheduledcostpercentsummaryorder, [showallscheduledcostpercentsummary]=@showallscheduledcostpercentsummary, [allscheduledcostpercentsummaryorder]=@allscheduledcostpercentsummaryorder, [showscheduledcostsfordeptsummary]=@showscheduledcostsfordeptsummary, [scheduledcostsfordeptsummaryorder]=@scheduledcostsfordeptsummaryorder, [securitytoken]=@securitytoken, [showscheduledshiftcountssummary]=@showscheduledshiftcountssummary, [scheduledshiftcountssummaryorder]=@scheduledshiftcountssummaryorder, [lang]=@lang, [mgrtimeoffalerts]=@mgrtimeoffalerts, [mgrswapalerts]=@mgrswapalerts, [mgrdroppickupalerts]=@mgrdroppickupalerts, [mgrautocheckinout]=@mgrautocheckinout, [mobilephone]=@mobilephone, [alertviaemail]=@alertviaemail, [alertviasms]=@alertviasms where [userid] = @PK_PARAM and [recstamp] = @recstamp;select top 1 [recstamp] from [dbo].[users] where [userid] = @PK_PARAM;";
		#endregion
		
		/// <summary>
		/// Will Update, not skinny safe, meaning if an update is done, it will update all columns
		/// </summary>
		public usersDto() : this(true) {
			//not skinny safe
		}
			
		/// <summary>
		/// Will Insert
		/// </summary>
		public static Compeat.Demo.Data.usersDto create() {
			var newInstance = new Compeat.Demo.Data.usersDto();
			newInstance.CmpNew = true;
			return newInstance;
		}    
		/// <summary>
		/// skinny safe: meaning if an update is done, it will only update the fields that had their setters called.
		/// </summary>
		public usersDto(int my_pk, string my_timestamp) : base(){
			//skinny safe
			IsSkinnySafe = true;
			MyPk = my_pk;
			MyTimeStamp = my_timestamp;
		}

		internal usersDto(bool allow_default_set) : base() {
			//not skinny safe
			if(allow_default_set) {
				#region Gen'd DB defaults
				this.promptforrestaurant=true;
				this.mustchangepassword=false;
				this.active=true;
				this.promptformenu=false;
				this.showscheduledcostsummary=true;
				this.showscheduledhoursfordeptsummary=true;
				this.showforecastedsalessummary=true;
				this.showscheduledhourssummary=true;
				this.showallscheduledhourssummary=true;
				this.showsalesperlaborhoursummary=true;
				this.showallscheduledcostsummary=true;
				this.showscheduledcostpercentsummary=true;
				this.showallscheduledcostpercentsummary=true;
				this.showscheduledcostsfordeptsummary=true;
				this.showscheduledshiftcountssummary=true;
				this.mgrtimeoffalerts=true;
				this.mgrswapalerts=true;
				this.mgrdroppickupalerts=true;
				this.mgrautocheckinout=true;
				this.alertviaemail=false;
				this.alertviasms=false;
				#endregion
	 
				SetDefaults();
			}
		}
   
		#region Loaders 		
		internal static Compeat.Demo.Data.usersDto GetFromReader(SqlDataReader dr) {
			var x = new Compeat.Demo.Data.usersDto(false);

			x._myPk = dr.GetInt32(COLUMN_INDEX_userid);
			x._userid = dr.GetInt32(COLUMN_INDEX_userid);
			x._username = (dr.IsDBNull(COLUMN_INDEX_username) ? null : dr.GetString(COLUMN_INDEX_username));
			x._fullname = (dr.IsDBNull(COLUMN_INDEX_fullname) ? null : dr.GetString(COLUMN_INDEX_fullname));
			x._description = (dr.IsDBNull(COLUMN_INDEX_description) ? null : dr.GetString(COLUMN_INDEX_description));
			x._defaultstore = (dr.IsDBNull(COLUMN_INDEX_defaultstore) ? (int?)null : dr.GetInt32(COLUMN_INDEX_defaultstore));
			x._promptforrestaurant = dr.GetBoolean(COLUMN_INDEX_promptforrestaurant);
			x._recstamp = (byte[])dr.GetValue(COLUMN_INDEX_recstamp);
			x._password = (dr.IsDBNull(COLUMN_INDEX_password) ? null : dr.GetString(COLUMN_INDEX_password));
			x._email = (dr.IsDBNull(COLUMN_INDEX_email) ? null : dr.GetString(COLUMN_INDEX_email));
			x._failedpasswordattemptstart = (dr.IsDBNull(COLUMN_INDEX_failedpasswordattemptstart) ? (DateTime?)null : dr.GetDateTime(COLUMN_INDEX_failedpasswordattemptstart));
			x._failedpasswordattemptcount = (dr.IsDBNull(COLUMN_INDEX_failedpasswordattemptcount) ? (int?)null : dr.GetInt32(COLUMN_INDEX_failedpasswordattemptcount));
			x._lastpasswordchange = (dr.IsDBNull(COLUMN_INDEX_lastpasswordchange) ? (DateTime?)null : dr.GetDateTime(COLUMN_INDEX_lastpasswordchange));
			x._mustchangepassword = dr.GetBoolean(COLUMN_INDEX_mustchangepassword);
			x._active = dr.GetBoolean(COLUMN_INDEX_active);
			x._theme = (dr.IsDBNull(COLUMN_INDEX_theme) ? (byte?)null : dr.GetByte(COLUMN_INDEX_theme));
			x._defaultgroup = (dr.IsDBNull(COLUMN_INDEX_defaultgroup) ? (int?)null : dr.GetInt32(COLUMN_INDEX_defaultgroup));
			x._promptformenu = dr.GetBoolean(COLUMN_INDEX_promptformenu);
			x._showscheduledcostsummary = dr.GetBoolean(COLUMN_INDEX_showscheduledcostsummary);
			x._scheduledcostsummaryorder = (dr.IsDBNull(COLUMN_INDEX_scheduledcostsummaryorder) ? (int?)null : dr.GetInt32(COLUMN_INDEX_scheduledcostsummaryorder));
			x._showscheduledhoursfordeptsummary = dr.GetBoolean(COLUMN_INDEX_showscheduledhoursfordeptsummary);
			x._scheduledhoursfordeptsummaryorder = (dr.IsDBNull(COLUMN_INDEX_scheduledhoursfordeptsummaryorder) ? (int?)null : dr.GetInt32(COLUMN_INDEX_scheduledhoursfordeptsummaryorder));
			x._showforecastedsalessummary = dr.GetBoolean(COLUMN_INDEX_showforecastedsalessummary);
			x._forecastedsalessummaryorder = (dr.IsDBNull(COLUMN_INDEX_forecastedsalessummaryorder) ? (int?)null : dr.GetInt32(COLUMN_INDEX_forecastedsalessummaryorder));
			x._showscheduledhourssummary = dr.GetBoolean(COLUMN_INDEX_showscheduledhourssummary);
			x._scheduledhourssummaryorder = (dr.IsDBNull(COLUMN_INDEX_scheduledhourssummaryorder) ? (int?)null : dr.GetInt32(COLUMN_INDEX_scheduledhourssummaryorder));
			x._showallscheduledhourssummary = dr.GetBoolean(COLUMN_INDEX_showallscheduledhourssummary);
			x._allscheduledhourssummaryorder = (dr.IsDBNull(COLUMN_INDEX_allscheduledhourssummaryorder) ? (int?)null : dr.GetInt32(COLUMN_INDEX_allscheduledhourssummaryorder));
			x._showsalesperlaborhoursummary = dr.GetBoolean(COLUMN_INDEX_showsalesperlaborhoursummary);
			x._salesperlaborhoursummaryorder = (dr.IsDBNull(COLUMN_INDEX_salesperlaborhoursummaryorder) ? (int?)null : dr.GetInt32(COLUMN_INDEX_salesperlaborhoursummaryorder));
			x._showallscheduledcostsummary = dr.GetBoolean(COLUMN_INDEX_showallscheduledcostsummary);
			x._allscheduledcostsummaryorder = (dr.IsDBNull(COLUMN_INDEX_allscheduledcostsummaryorder) ? (int?)null : dr.GetInt32(COLUMN_INDEX_allscheduledcostsummaryorder));
			x._showscheduledcostpercentsummary = dr.GetBoolean(COLUMN_INDEX_showscheduledcostpercentsummary);
			x._scheduledcostpercentsummaryorder = (dr.IsDBNull(COLUMN_INDEX_scheduledcostpercentsummaryorder) ? (int?)null : dr.GetInt32(COLUMN_INDEX_scheduledcostpercentsummaryorder));
			x._showallscheduledcostpercentsummary = dr.GetBoolean(COLUMN_INDEX_showallscheduledcostpercentsummary);
			x._allscheduledcostpercentsummaryorder = (dr.IsDBNull(COLUMN_INDEX_allscheduledcostpercentsummaryorder) ? (int?)null : dr.GetInt32(COLUMN_INDEX_allscheduledcostpercentsummaryorder));
			x._showscheduledcostsfordeptsummary = dr.GetBoolean(COLUMN_INDEX_showscheduledcostsfordeptsummary);
			x._scheduledcostsfordeptsummaryorder = (dr.IsDBNull(COLUMN_INDEX_scheduledcostsfordeptsummaryorder) ? (int?)null : dr.GetInt32(COLUMN_INDEX_scheduledcostsfordeptsummaryorder));
			x._securitytoken = (dr.IsDBNull(COLUMN_INDEX_securitytoken) ? (Guid?)null : dr.GetGuid(COLUMN_INDEX_securitytoken));
			x._showscheduledshiftcountssummary = dr.GetBoolean(COLUMN_INDEX_showscheduledshiftcountssummary);
			x._scheduledshiftcountssummaryorder = (dr.IsDBNull(COLUMN_INDEX_scheduledshiftcountssummaryorder) ? (int?)null : dr.GetInt32(COLUMN_INDEX_scheduledshiftcountssummaryorder));
			x._lang = (dr.IsDBNull(COLUMN_INDEX_lang) ? null : dr.GetString(COLUMN_INDEX_lang));
			x._mgrtimeoffalerts = dr.GetBoolean(COLUMN_INDEX_mgrtimeoffalerts);
			x._mgrswapalerts = dr.GetBoolean(COLUMN_INDEX_mgrswapalerts);
			x._mgrdroppickupalerts = dr.GetBoolean(COLUMN_INDEX_mgrdroppickupalerts);
			x._mgrautocheckinout = dr.GetBoolean(COLUMN_INDEX_mgrautocheckinout);
			x._mobilephone = (dr.IsDBNull(COLUMN_INDEX_mobilephone) ? null : dr.GetString(COLUMN_INDEX_mobilephone));
			x._alertviaemail = dr.GetBoolean(COLUMN_INDEX_alertviaemail);
			x._alertviasms = dr.GetBoolean(COLUMN_INDEX_alertviasms);
			//skinny safe since loaded from reader
			x.IsSkinnySafe = true;
			return x;
		}   
		
		internal void LoadChildProperty(SqlConnection conn, IEnumerable<string> collectionsToLoad)
		{
			ChildLoaderList<Compeat.Demo.Data.usersDto>.LoadProperty(conn, collectionsToLoad, AllChildCollections);
		}  
		
		#endregion Loaders   
		
		#region Writing
		
		
		protected override void Insert(SqlConnection conn) {
			SqlParameter[] parm_list = 
				new SqlParameter[] { 
				 MyPk_param_getter()
						
					, _userid_param_getter()
					, _username_param_getter()
					, _fullname_param_getter()
					, _description_param_getter()
					, _defaultstore_param_getter()
					, _promptforrestaurant_param_getter()
					, _password_param_getter()
					, _email_param_getter()
					, _failedpasswordattemptstart_param_getter()
					, _failedpasswordattemptcount_param_getter()
					, _lastpasswordchange_param_getter()
					, _mustchangepassword_param_getter()
					, _active_param_getter()
					, _theme_param_getter()
					, _defaultgroup_param_getter()
					, _promptformenu_param_getter()
					, _showscheduledcostsummary_param_getter()
					, _scheduledcostsummaryorder_param_getter()
					, _showscheduledhoursfordeptsummary_param_getter()
					, _scheduledhoursfordeptsummaryorder_param_getter()
					, _showforecastedsalessummary_param_getter()
					, _forecastedsalessummaryorder_param_getter()
					, _showscheduledhourssummary_param_getter()
					, _scheduledhourssummaryorder_param_getter()
					, _showallscheduledhourssummary_param_getter()
					, _allscheduledhourssummaryorder_param_getter()
					, _showsalesperlaborhoursummary_param_getter()
					, _salesperlaborhoursummaryorder_param_getter()
					, _showallscheduledcostsummary_param_getter()
					, _allscheduledcostsummaryorder_param_getter()
					, _showscheduledcostpercentsummary_param_getter()
					, _scheduledcostpercentsummaryorder_param_getter()
					, _showallscheduledcostpercentsummary_param_getter()
					, _allscheduledcostpercentsummaryorder_param_getter()
					, _showscheduledcostsfordeptsummary_param_getter()
					, _scheduledcostsfordeptsummaryorder_param_getter()
					, _securitytoken_param_getter()
					, _showscheduledshiftcountssummary_param_getter()
					, _scheduledshiftcountssummaryorder_param_getter()
					, _lang_param_getter()
					, _mgrtimeoffalerts_param_getter()
					, _mgrswapalerts_param_getter()
					, _mgrdroppickupalerts_param_getter()
					, _mgrautocheckinout_param_getter()
					, _mobilephone_param_getter()
					, _alertviaemail_param_getter()
					, _alertviasms_param_getter()
				};
				
			InternalTools.ScriptRunReader(SqlEnums.SqlActivityType.INSERT, _INSERT, conn, parm_list
				, (sdr) => {	   
						if (!sdr.HasRows || !sdr.Read()) {
							throw new DbUpdateFailedNoChangesMade("Insert into users, but now new rows were detected using PK or identity fields.", conn, null);
						}else{
							_recstamp = (byte[])sdr.GetValue(0);//refresh the timestamp
						}
					}
				, GetTimeout());
		
		}  
		
		protected override void Update(SqlConnection conn) {
			if(IsSkinnySafe && UpdatedProperties.Count() == 0) {
				throw new DbUpdateFailedNoChangesMade("Update to users, but no values have changed. Verify InSavableState before calling.", conn, null);
			}
			if(MyPk == null) {
				throw new DbUpdateFailedPkMissing(_UPDATE, conn, null);
			}
			if(MyTimeStamp == null) {
				throw new DbUpdateFailedTimestampMissing(_UPDATE, conn, null);
			}
			
			  
			if(IsSkinnySafe) {
				AddChangedProperty(true, false, false, _PK_COLUMN_NAME, _PK_PARAMETER_NAME, this.MyPk_param_getter);    

				AddChangedProperty(false, false, true, _TIMESTAMP_COLUMN_NAME, _TIMESTAMP_PARAMETER_NAME, this.MyTimeStamp_param_getter);

				if(!UpdatedProperties.Any(s => !s.IsPrimaryKey && !s.IsIdentity && !s.IsTimestamp)) {
					return; //nothing changed
				}
				var parm_list = UpdatedProperties
									.Where(s => !s.IsIdentity && s.ParameterName != _PK_PARAMETER_NAME && !s.IsTimestamp && s.ParameterName != _TIMESTAMP_PARAMETER_NAME)
									.Select(s => s.MyParamGetter())
									.ToList();  
				parm_list.Add(MyPk_param_getter());
				string formatted_update = string.Format(_UPDATE, string.Join(",", UpdatedProperties.Where(s => !s.IsIdentity && !s.IsTimestamp).Select(s => s.UpdateCombo) ) );
				InternalTools.ScriptRunReader(SqlEnums.SqlActivityType.UPDATE, formatted_update, conn, parm_list.ToArray()
					, (sdr) => {	 
						if (!sdr.HasRows || !sdr.Read()) {
							throw new DbUpdateFailedNoChangesMade("Insert into users, but now new rows were detected using PK or identity fields.", conn, null);
						}else{
							_recstamp = (byte[])sdr.GetValue(0);//refresh the timestamp
						}
					}
				, GetTimeout());
			}
			else {
				SqlParameter[] parm_list = 
					new SqlParameter[] { 
						MyPk_param_getter()
						, MyTimeStamp_param_getter()
						, _userid_param_getter()
						, _username_param_getter()
						, _fullname_param_getter()
						, _description_param_getter()
						, _defaultstore_param_getter()
						, _promptforrestaurant_param_getter()
						, _password_param_getter()
						, _email_param_getter()
						, _failedpasswordattemptstart_param_getter()
						, _failedpasswordattemptcount_param_getter()
						, _lastpasswordchange_param_getter()
						, _mustchangepassword_param_getter()
						, _active_param_getter()
						, _theme_param_getter()
						, _defaultgroup_param_getter()
						, _promptformenu_param_getter()
						, _showscheduledcostsummary_param_getter()
						, _scheduledcostsummaryorder_param_getter()
						, _showscheduledhoursfordeptsummary_param_getter()
						, _scheduledhoursfordeptsummaryorder_param_getter()
						, _showforecastedsalessummary_param_getter()
						, _forecastedsalessummaryorder_param_getter()
						, _showscheduledhourssummary_param_getter()
						, _scheduledhourssummaryorder_param_getter()
						, _showallscheduledhourssummary_param_getter()
						, _allscheduledhourssummaryorder_param_getter()
						, _showsalesperlaborhoursummary_param_getter()
						, _salesperlaborhoursummaryorder_param_getter()
						, _showallscheduledcostsummary_param_getter()
						, _allscheduledcostsummaryorder_param_getter()
						, _showscheduledcostpercentsummary_param_getter()
						, _scheduledcostpercentsummaryorder_param_getter()
						, _showallscheduledcostpercentsummary_param_getter()
						, _allscheduledcostpercentsummaryorder_param_getter()
						, _showscheduledcostsfordeptsummary_param_getter()
						, _scheduledcostsfordeptsummaryorder_param_getter()
						, _securitytoken_param_getter()
						, _showscheduledshiftcountssummary_param_getter()
						, _scheduledshiftcountssummaryorder_param_getter()
						, _lang_param_getter()
						, _mgrtimeoffalerts_param_getter()
						, _mgrswapalerts_param_getter()
						, _mgrdroppickupalerts_param_getter()
						, _mgrautocheckinout_param_getter()
						, _mobilephone_param_getter()
						, _alertviaemail_param_getter()
						, _alertviasms_param_getter()
					};
				InternalTools.ScriptRunReader(SqlEnums.SqlActivityType.UPDATE, _UPDATE_FULL, conn, parm_list
					, (sdr) => {	 
						if (!sdr.HasRows || !sdr.Read()) {
							throw new DbUpdateFailedNoChangesMade("Insert into users, but now new rows were detected using PK or identity fields.", conn, null);
						}else{
							_recstamp = (byte[])sdr.GetValue(0);//refresh the timestamp
						}
					}
				, GetTimeout());
			}
		}
		protected override void Delete(SqlConnection conn) {
			InternalTools.ScriptRun(SqlEnums.SqlActivityType.DELETE, _DELETE, conn, new[] { MyPk_param_getter() }, GetTimeout());
			
		}    

		#endregion Writing
		
		#region Gen'd Fields in table
		
		internal static Func<int?, SqlParameter> _myPk_param_getter { 
			get {
				return (pk_val) => { return InternalTools.MakeParam(_PK_PARAMETER_NAME, SqlDbType.Int, pk_val, false);};				
				
			}
		}
		
		internal Func<SqlParameter> MyPk_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(_PK_PARAMETER_NAME, SqlDbType.Int, MyPk, false);};
			}
		}
		
		internal int? _myPk{ get; set; }    
		protected override int? MyPk {
			get{ 
				if(IsSkinnySafe){
					return _myPk; 
				}else{
					return userid; 
				}
			}
			set{ 
				if(IsSkinnySafe){
					_myPk = value; 
				}
				userid = value;
				
			}
		}
		
		internal Func<SqlParameter> MyTimeStamp_param_getter { 
			get {
				return _recstamp_param_getter;
			}
		}
		protected override bool RequireTimeStamp { get{ return true; } }
		protected override string MyTimeStamp {
			get{ return recstamp; }
			set{ recstamp = value; }
		}
		
			
		internal int? _userid{ get; set; }    
		internal Func<SqlParameter> _userid_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_userid, SqlDbType.Int, _userid, false);};
			}
		}   

		public virtual int? userid { 
			get { return _userid; } 
			set {
				_userid = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_userid, PARAMETER_NAME_userid, _userid_param_getter);
				}
			}
		}			
		internal string _username{ get; set; }    
		internal Func<SqlParameter> _username_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_username, SqlDbType.VarChar, _username, true, 20);};
			}
		}   

		public virtual string username { 
			get { return _username; } 
			set {
				_username = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_username, PARAMETER_NAME_username, _username_param_getter);
				}
			}
		}			
		internal string _fullname{ get; set; }    
		internal Func<SqlParameter> _fullname_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_fullname, SqlDbType.VarChar, _fullname, true, 100);};
			}
		}   

		public virtual string fullname { 
			get { return _fullname; } 
			set {
				_fullname = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_fullname, PARAMETER_NAME_fullname, _fullname_param_getter);
				}
			}
		}			
		internal string _description{ get; set; }    
		internal Func<SqlParameter> _description_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_description, SqlDbType.VarChar, _description, true, 100);};
			}
		}   

		public virtual string description { 
			get { return _description; } 
			set {
				_description = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_description, PARAMETER_NAME_description, _description_param_getter);
				}
			}
		}			
		internal int? _defaultstore{ get; set; }    
		internal Func<SqlParameter> _defaultstore_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_defaultstore, SqlDbType.Int, _defaultstore, true);};
			}
		}   

		public virtual int? defaultstore { 
			get { return _defaultstore; } 
			set {
				_defaultstore = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_defaultstore, PARAMETER_NAME_defaultstore, _defaultstore_param_getter);
				}
			}
		}			
		internal bool _promptforrestaurant{ get; set; }    
		internal Func<SqlParameter> _promptforrestaurant_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_promptforrestaurant, SqlDbType.Bit, _promptforrestaurant, false);};
			}
		}   

		public virtual bool promptforrestaurant { 
			get { return _promptforrestaurant; } 
			set {
				_promptforrestaurant = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_promptforrestaurant, PARAMETER_NAME_promptforrestaurant, _promptforrestaurant_param_getter);
				}
			}
		}			
		internal byte[] _recstamp{ get; set; }    
		internal Func<SqlParameter> _recstamp_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_recstamp, SqlDbType.Timestamp, _recstamp, false);};
			}
		}   
		public virtual string recstamp { 
			get { 
				return _recstamp == null ? null : Convert.ToBase64String(_recstamp); 
			}
			set {
				if(string.IsNullOrWhiteSpace(value)){
					_recstamp = null;
				}
				else {
					_recstamp = Convert.FromBase64String(value);
				}
				if(IsSkinnySafe){
					AddChangedProperty(false, false, true, COLUMN_NAME_recstamp, PARAMETER_NAME_recstamp, _recstamp_param_getter);
				}
			}
		}			
		internal string _password{ get; set; }    
		internal Func<SqlParameter> _password_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_password, SqlDbType.VarChar, _password, true, 250);};
			}
		}   

		public virtual string password { 
			get { return _password; } 
			set {
				_password = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_password, PARAMETER_NAME_password, _password_param_getter);
				}
			}
		}			
		internal string _email{ get; set; }    
		internal Func<SqlParameter> _email_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_email, SqlDbType.VarChar, _email, true, 100);};
			}
		}   

		public virtual string email { 
			get { return _email; } 
			set {
				_email = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_email, PARAMETER_NAME_email, _email_param_getter);
				}
			}
		}			
		internal DateTime? _failedpasswordattemptstart{ get; set; }    
		internal Func<SqlParameter> _failedpasswordattemptstart_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_failedpasswordattemptstart, SqlDbType.DateTime, _failedpasswordattemptstart, true);};
			}
		}   

		public virtual DateTime? failedpasswordattemptstart { 
			get { return _failedpasswordattemptstart; } 
			set {
				_failedpasswordattemptstart = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_failedpasswordattemptstart, PARAMETER_NAME_failedpasswordattemptstart, _failedpasswordattemptstart_param_getter);
				}
			}
		}			
		internal int? _failedpasswordattemptcount{ get; set; }    
		internal Func<SqlParameter> _failedpasswordattemptcount_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_failedpasswordattemptcount, SqlDbType.Int, _failedpasswordattemptcount, true);};
			}
		}   

		public virtual int? failedpasswordattemptcount { 
			get { return _failedpasswordattemptcount; } 
			set {
				_failedpasswordattemptcount = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_failedpasswordattemptcount, PARAMETER_NAME_failedpasswordattemptcount, _failedpasswordattemptcount_param_getter);
				}
			}
		}			
		internal DateTime? _lastpasswordchange{ get; set; }    
		internal Func<SqlParameter> _lastpasswordchange_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastpasswordchange, SqlDbType.DateTime, _lastpasswordchange, true);};
			}
		}   

		public virtual DateTime? lastpasswordchange { 
			get { return _lastpasswordchange; } 
			set {
				_lastpasswordchange = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastpasswordchange, PARAMETER_NAME_lastpasswordchange, _lastpasswordchange_param_getter);
				}
			}
		}			
		internal bool _mustchangepassword{ get; set; }    
		internal Func<SqlParameter> _mustchangepassword_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_mustchangepassword, SqlDbType.Bit, _mustchangepassword, false);};
			}
		}   

		public virtual bool mustchangepassword { 
			get { return _mustchangepassword; } 
			set {
				_mustchangepassword = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_mustchangepassword, PARAMETER_NAME_mustchangepassword, _mustchangepassword_param_getter);
				}
			}
		}			
		internal bool _active{ get; set; }    
		internal Func<SqlParameter> _active_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_active, SqlDbType.Bit, _active, false);};
			}
		}   

		public virtual bool active { 
			get { return _active; } 
			set {
				_active = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_active, PARAMETER_NAME_active, _active_param_getter);
				}
			}
		}			
		internal byte? _theme{ get; set; }    
		internal Func<SqlParameter> _theme_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_theme, SqlDbType.TinyInt, _theme, true);};
			}
		}   

		public virtual byte? theme { 
			get { return _theme; } 
			set {
				_theme = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_theme, PARAMETER_NAME_theme, _theme_param_getter);
				}
			}
		}			
		internal int? _defaultgroup{ get; set; }    
		internal Func<SqlParameter> _defaultgroup_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_defaultgroup, SqlDbType.Int, _defaultgroup, true);};
			}
		}   

		public virtual int? defaultgroup { 
			get { return _defaultgroup; } 
			set {
				_defaultgroup = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_defaultgroup, PARAMETER_NAME_defaultgroup, _defaultgroup_param_getter);
				}
			}
		}			
		internal bool _promptformenu{ get; set; }    
		internal Func<SqlParameter> _promptformenu_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_promptformenu, SqlDbType.Bit, _promptformenu, false);};
			}
		}   

		public virtual bool promptformenu { 
			get { return _promptformenu; } 
			set {
				_promptformenu = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_promptformenu, PARAMETER_NAME_promptformenu, _promptformenu_param_getter);
				}
			}
		}			
		internal bool _showscheduledcostsummary{ get; set; }    
		internal Func<SqlParameter> _showscheduledcostsummary_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_showscheduledcostsummary, SqlDbType.Bit, _showscheduledcostsummary, false);};
			}
		}   

		public virtual bool showscheduledcostsummary { 
			get { return _showscheduledcostsummary; } 
			set {
				_showscheduledcostsummary = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_showscheduledcostsummary, PARAMETER_NAME_showscheduledcostsummary, _showscheduledcostsummary_param_getter);
				}
			}
		}			
		internal int? _scheduledcostsummaryorder{ get; set; }    
		internal Func<SqlParameter> _scheduledcostsummaryorder_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_scheduledcostsummaryorder, SqlDbType.Int, _scheduledcostsummaryorder, true);};
			}
		}   

		public virtual int? scheduledcostsummaryorder { 
			get { return _scheduledcostsummaryorder; } 
			set {
				_scheduledcostsummaryorder = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_scheduledcostsummaryorder, PARAMETER_NAME_scheduledcostsummaryorder, _scheduledcostsummaryorder_param_getter);
				}
			}
		}			
		internal bool _showscheduledhoursfordeptsummary{ get; set; }    
		internal Func<SqlParameter> _showscheduledhoursfordeptsummary_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_showscheduledhoursfordeptsummary, SqlDbType.Bit, _showscheduledhoursfordeptsummary, false);};
			}
		}   

		public virtual bool showscheduledhoursfordeptsummary { 
			get { return _showscheduledhoursfordeptsummary; } 
			set {
				_showscheduledhoursfordeptsummary = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_showscheduledhoursfordeptsummary, PARAMETER_NAME_showscheduledhoursfordeptsummary, _showscheduledhoursfordeptsummary_param_getter);
				}
			}
		}			
		internal int? _scheduledhoursfordeptsummaryorder{ get; set; }    
		internal Func<SqlParameter> _scheduledhoursfordeptsummaryorder_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_scheduledhoursfordeptsummaryorder, SqlDbType.Int, _scheduledhoursfordeptsummaryorder, true);};
			}
		}   

		public virtual int? scheduledhoursfordeptsummaryorder { 
			get { return _scheduledhoursfordeptsummaryorder; } 
			set {
				_scheduledhoursfordeptsummaryorder = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_scheduledhoursfordeptsummaryorder, PARAMETER_NAME_scheduledhoursfordeptsummaryorder, _scheduledhoursfordeptsummaryorder_param_getter);
				}
			}
		}			
		internal bool _showforecastedsalessummary{ get; set; }    
		internal Func<SqlParameter> _showforecastedsalessummary_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_showforecastedsalessummary, SqlDbType.Bit, _showforecastedsalessummary, false);};
			}
		}   

		public virtual bool showforecastedsalessummary { 
			get { return _showforecastedsalessummary; } 
			set {
				_showforecastedsalessummary = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_showforecastedsalessummary, PARAMETER_NAME_showforecastedsalessummary, _showforecastedsalessummary_param_getter);
				}
			}
		}			
		internal int? _forecastedsalessummaryorder{ get; set; }    
		internal Func<SqlParameter> _forecastedsalessummaryorder_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_forecastedsalessummaryorder, SqlDbType.Int, _forecastedsalessummaryorder, true);};
			}
		}   

		public virtual int? forecastedsalessummaryorder { 
			get { return _forecastedsalessummaryorder; } 
			set {
				_forecastedsalessummaryorder = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_forecastedsalessummaryorder, PARAMETER_NAME_forecastedsalessummaryorder, _forecastedsalessummaryorder_param_getter);
				}
			}
		}			
		internal bool _showscheduledhourssummary{ get; set; }    
		internal Func<SqlParameter> _showscheduledhourssummary_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_showscheduledhourssummary, SqlDbType.Bit, _showscheduledhourssummary, false);};
			}
		}   

		public virtual bool showscheduledhourssummary { 
			get { return _showscheduledhourssummary; } 
			set {
				_showscheduledhourssummary = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_showscheduledhourssummary, PARAMETER_NAME_showscheduledhourssummary, _showscheduledhourssummary_param_getter);
				}
			}
		}			
		internal int? _scheduledhourssummaryorder{ get; set; }    
		internal Func<SqlParameter> _scheduledhourssummaryorder_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_scheduledhourssummaryorder, SqlDbType.Int, _scheduledhourssummaryorder, true);};
			}
		}   

		public virtual int? scheduledhourssummaryorder { 
			get { return _scheduledhourssummaryorder; } 
			set {
				_scheduledhourssummaryorder = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_scheduledhourssummaryorder, PARAMETER_NAME_scheduledhourssummaryorder, _scheduledhourssummaryorder_param_getter);
				}
			}
		}			
		internal bool _showallscheduledhourssummary{ get; set; }    
		internal Func<SqlParameter> _showallscheduledhourssummary_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_showallscheduledhourssummary, SqlDbType.Bit, _showallscheduledhourssummary, false);};
			}
		}   

		public virtual bool showallscheduledhourssummary { 
			get { return _showallscheduledhourssummary; } 
			set {
				_showallscheduledhourssummary = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_showallscheduledhourssummary, PARAMETER_NAME_showallscheduledhourssummary, _showallscheduledhourssummary_param_getter);
				}
			}
		}			
		internal int? _allscheduledhourssummaryorder{ get; set; }    
		internal Func<SqlParameter> _allscheduledhourssummaryorder_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_allscheduledhourssummaryorder, SqlDbType.Int, _allscheduledhourssummaryorder, true);};
			}
		}   

		public virtual int? allscheduledhourssummaryorder { 
			get { return _allscheduledhourssummaryorder; } 
			set {
				_allscheduledhourssummaryorder = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_allscheduledhourssummaryorder, PARAMETER_NAME_allscheduledhourssummaryorder, _allscheduledhourssummaryorder_param_getter);
				}
			}
		}			
		internal bool _showsalesperlaborhoursummary{ get; set; }    
		internal Func<SqlParameter> _showsalesperlaborhoursummary_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_showsalesperlaborhoursummary, SqlDbType.Bit, _showsalesperlaborhoursummary, false);};
			}
		}   

		public virtual bool showsalesperlaborhoursummary { 
			get { return _showsalesperlaborhoursummary; } 
			set {
				_showsalesperlaborhoursummary = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_showsalesperlaborhoursummary, PARAMETER_NAME_showsalesperlaborhoursummary, _showsalesperlaborhoursummary_param_getter);
				}
			}
		}			
		internal int? _salesperlaborhoursummaryorder{ get; set; }    
		internal Func<SqlParameter> _salesperlaborhoursummaryorder_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_salesperlaborhoursummaryorder, SqlDbType.Int, _salesperlaborhoursummaryorder, true);};
			}
		}   

		public virtual int? salesperlaborhoursummaryorder { 
			get { return _salesperlaborhoursummaryorder; } 
			set {
				_salesperlaborhoursummaryorder = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_salesperlaborhoursummaryorder, PARAMETER_NAME_salesperlaborhoursummaryorder, _salesperlaborhoursummaryorder_param_getter);
				}
			}
		}			
		internal bool _showallscheduledcostsummary{ get; set; }    
		internal Func<SqlParameter> _showallscheduledcostsummary_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_showallscheduledcostsummary, SqlDbType.Bit, _showallscheduledcostsummary, false);};
			}
		}   

		public virtual bool showallscheduledcostsummary { 
			get { return _showallscheduledcostsummary; } 
			set {
				_showallscheduledcostsummary = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_showallscheduledcostsummary, PARAMETER_NAME_showallscheduledcostsummary, _showallscheduledcostsummary_param_getter);
				}
			}
		}			
		internal int? _allscheduledcostsummaryorder{ get; set; }    
		internal Func<SqlParameter> _allscheduledcostsummaryorder_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_allscheduledcostsummaryorder, SqlDbType.Int, _allscheduledcostsummaryorder, true);};
			}
		}   

		public virtual int? allscheduledcostsummaryorder { 
			get { return _allscheduledcostsummaryorder; } 
			set {
				_allscheduledcostsummaryorder = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_allscheduledcostsummaryorder, PARAMETER_NAME_allscheduledcostsummaryorder, _allscheduledcostsummaryorder_param_getter);
				}
			}
		}			
		internal bool _showscheduledcostpercentsummary{ get; set; }    
		internal Func<SqlParameter> _showscheduledcostpercentsummary_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_showscheduledcostpercentsummary, SqlDbType.Bit, _showscheduledcostpercentsummary, false);};
			}
		}   

		public virtual bool showscheduledcostpercentsummary { 
			get { return _showscheduledcostpercentsummary; } 
			set {
				_showscheduledcostpercentsummary = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_showscheduledcostpercentsummary, PARAMETER_NAME_showscheduledcostpercentsummary, _showscheduledcostpercentsummary_param_getter);
				}
			}
		}			
		internal int? _scheduledcostpercentsummaryorder{ get; set; }    
		internal Func<SqlParameter> _scheduledcostpercentsummaryorder_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_scheduledcostpercentsummaryorder, SqlDbType.Int, _scheduledcostpercentsummaryorder, true);};
			}
		}   

		public virtual int? scheduledcostpercentsummaryorder { 
			get { return _scheduledcostpercentsummaryorder; } 
			set {
				_scheduledcostpercentsummaryorder = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_scheduledcostpercentsummaryorder, PARAMETER_NAME_scheduledcostpercentsummaryorder, _scheduledcostpercentsummaryorder_param_getter);
				}
			}
		}			
		internal bool _showallscheduledcostpercentsummary{ get; set; }    
		internal Func<SqlParameter> _showallscheduledcostpercentsummary_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_showallscheduledcostpercentsummary, SqlDbType.Bit, _showallscheduledcostpercentsummary, false);};
			}
		}   

		public virtual bool showallscheduledcostpercentsummary { 
			get { return _showallscheduledcostpercentsummary; } 
			set {
				_showallscheduledcostpercentsummary = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_showallscheduledcostpercentsummary, PARAMETER_NAME_showallscheduledcostpercentsummary, _showallscheduledcostpercentsummary_param_getter);
				}
			}
		}			
		internal int? _allscheduledcostpercentsummaryorder{ get; set; }    
		internal Func<SqlParameter> _allscheduledcostpercentsummaryorder_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_allscheduledcostpercentsummaryorder, SqlDbType.Int, _allscheduledcostpercentsummaryorder, true);};
			}
		}   

		public virtual int? allscheduledcostpercentsummaryorder { 
			get { return _allscheduledcostpercentsummaryorder; } 
			set {
				_allscheduledcostpercentsummaryorder = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_allscheduledcostpercentsummaryorder, PARAMETER_NAME_allscheduledcostpercentsummaryorder, _allscheduledcostpercentsummaryorder_param_getter);
				}
			}
		}			
		internal bool _showscheduledcostsfordeptsummary{ get; set; }    
		internal Func<SqlParameter> _showscheduledcostsfordeptsummary_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_showscheduledcostsfordeptsummary, SqlDbType.Bit, _showscheduledcostsfordeptsummary, false);};
			}
		}   

		public virtual bool showscheduledcostsfordeptsummary { 
			get { return _showscheduledcostsfordeptsummary; } 
			set {
				_showscheduledcostsfordeptsummary = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_showscheduledcostsfordeptsummary, PARAMETER_NAME_showscheduledcostsfordeptsummary, _showscheduledcostsfordeptsummary_param_getter);
				}
			}
		}			
		internal int? _scheduledcostsfordeptsummaryorder{ get; set; }    
		internal Func<SqlParameter> _scheduledcostsfordeptsummaryorder_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_scheduledcostsfordeptsummaryorder, SqlDbType.Int, _scheduledcostsfordeptsummaryorder, true);};
			}
		}   

		public virtual int? scheduledcostsfordeptsummaryorder { 
			get { return _scheduledcostsfordeptsummaryorder; } 
			set {
				_scheduledcostsfordeptsummaryorder = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_scheduledcostsfordeptsummaryorder, PARAMETER_NAME_scheduledcostsfordeptsummaryorder, _scheduledcostsfordeptsummaryorder_param_getter);
				}
			}
		}			
		internal Guid? _securitytoken{ get; set; }    
		internal Func<SqlParameter> _securitytoken_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_securitytoken, SqlDbType.UniqueIdentifier, _securitytoken, true);};
			}
		}   

		public virtual Guid? securitytoken { 
			get { return _securitytoken; } 
			set {
				_securitytoken = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_securitytoken, PARAMETER_NAME_securitytoken, _securitytoken_param_getter);
				}
			}
		}			
		internal bool _showscheduledshiftcountssummary{ get; set; }    
		internal Func<SqlParameter> _showscheduledshiftcountssummary_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_showscheduledshiftcountssummary, SqlDbType.Bit, _showscheduledshiftcountssummary, false);};
			}
		}   

		public virtual bool showscheduledshiftcountssummary { 
			get { return _showscheduledshiftcountssummary; } 
			set {
				_showscheduledshiftcountssummary = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_showscheduledshiftcountssummary, PARAMETER_NAME_showscheduledshiftcountssummary, _showscheduledshiftcountssummary_param_getter);
				}
			}
		}			
		internal int? _scheduledshiftcountssummaryorder{ get; set; }    
		internal Func<SqlParameter> _scheduledshiftcountssummaryorder_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_scheduledshiftcountssummaryorder, SqlDbType.Int, _scheduledshiftcountssummaryorder, true);};
			}
		}   

		public virtual int? scheduledshiftcountssummaryorder { 
			get { return _scheduledshiftcountssummaryorder; } 
			set {
				_scheduledshiftcountssummaryorder = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_scheduledshiftcountssummaryorder, PARAMETER_NAME_scheduledshiftcountssummaryorder, _scheduledshiftcountssummaryorder_param_getter);
				}
			}
		}			
		internal string _lang{ get; set; }    
		internal Func<SqlParameter> _lang_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lang, SqlDbType.VarChar, _lang, true, 5);};
			}
		}   

		public virtual string lang { 
			get { return _lang; } 
			set {
				_lang = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lang, PARAMETER_NAME_lang, _lang_param_getter);
				}
			}
		}			
		internal bool _mgrtimeoffalerts{ get; set; }    
		internal Func<SqlParameter> _mgrtimeoffalerts_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_mgrtimeoffalerts, SqlDbType.Bit, _mgrtimeoffalerts, false);};
			}
		}   

		public virtual bool mgrtimeoffalerts { 
			get { return _mgrtimeoffalerts; } 
			set {
				_mgrtimeoffalerts = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_mgrtimeoffalerts, PARAMETER_NAME_mgrtimeoffalerts, _mgrtimeoffalerts_param_getter);
				}
			}
		}			
		internal bool _mgrswapalerts{ get; set; }    
		internal Func<SqlParameter> _mgrswapalerts_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_mgrswapalerts, SqlDbType.Bit, _mgrswapalerts, false);};
			}
		}   

		public virtual bool mgrswapalerts { 
			get { return _mgrswapalerts; } 
			set {
				_mgrswapalerts = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_mgrswapalerts, PARAMETER_NAME_mgrswapalerts, _mgrswapalerts_param_getter);
				}
			}
		}			
		internal bool _mgrdroppickupalerts{ get; set; }    
		internal Func<SqlParameter> _mgrdroppickupalerts_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_mgrdroppickupalerts, SqlDbType.Bit, _mgrdroppickupalerts, false);};
			}
		}   

		public virtual bool mgrdroppickupalerts { 
			get { return _mgrdroppickupalerts; } 
			set {
				_mgrdroppickupalerts = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_mgrdroppickupalerts, PARAMETER_NAME_mgrdroppickupalerts, _mgrdroppickupalerts_param_getter);
				}
			}
		}			
		internal bool _mgrautocheckinout{ get; set; }    
		internal Func<SqlParameter> _mgrautocheckinout_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_mgrautocheckinout, SqlDbType.Bit, _mgrautocheckinout, false);};
			}
		}   

		public virtual bool mgrautocheckinout { 
			get { return _mgrautocheckinout; } 
			set {
				_mgrautocheckinout = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_mgrautocheckinout, PARAMETER_NAME_mgrautocheckinout, _mgrautocheckinout_param_getter);
				}
			}
		}			
		internal string _mobilephone{ get; set; }    
		internal Func<SqlParameter> _mobilephone_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_mobilephone, SqlDbType.VarChar, _mobilephone, true, 20);};
			}
		}   

		public virtual string mobilephone { 
			get { return _mobilephone; } 
			set {
				_mobilephone = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_mobilephone, PARAMETER_NAME_mobilephone, _mobilephone_param_getter);
				}
			}
		}			
		internal bool _alertviaemail{ get; set; }    
		internal Func<SqlParameter> _alertviaemail_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_alertviaemail, SqlDbType.Bit, _alertviaemail, false);};
			}
		}   

		public virtual bool alertviaemail { 
			get { return _alertviaemail; } 
			set {
				_alertviaemail = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_alertviaemail, PARAMETER_NAME_alertviaemail, _alertviaemail_param_getter);
				}
			}
		}			
		internal bool _alertviasms{ get; set; }    
		internal Func<SqlParameter> _alertviasms_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_alertviasms, SqlDbType.Bit, _alertviasms, false);};
			}
		}   

		public virtual bool alertviasms { 
			get { return _alertviasms; } 
			set {
				_alertviasms = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_alertviasms, PARAMETER_NAME_alertviasms, _alertviasms_param_getter);
				}
			}
		} 
		#endregion  Gen'd Fields in table

		public override string GetTableName() { 
				return "dbo.users";
		}
	
	
	}
	
	public partial class users : BaseRepositoryTableReader<Repository, Compeat.Demo.Data.usersDto, int?>
	{

		#region Repo Turn Around
		 /// <summary>
		/// This will return the table object with the id that was passed in.
		/// </summary>
		/// <param name="conn">the open sql connection</param>
		/// <param name="pk_val">the Pk value for the desired row</param>
		/// <param name="collectionsToLoad">child collections to load. ex: new ChildLoaderList&lt;apiemployeesDto&gt;() { x => x.children_apiemployeeassignments, x => x.children_apiemployeecustomfields }</param>
		/// <param name="collectionToLoadUsingStrings">list of collection properties to load for earch returned item, similar to collectionsToLoad but delivered differently</param>
		/// <param name="recursiveDepth">children collection depth to load, 0 means no recursive loading.</param>
		/// <returns>a single instance of the table object</returns>
		public override Compeat.Demo.Data.usersDto Get(SqlConnection conn, int? pk_val, ChildLoaderList<Compeat.Demo.Data.usersDto> collectionsToLoad = null, IEnumerable<string> collectionToLoadUsingStrings = null, int recursiveDepth = 0)
		{
			var lst = _GetList(conn, _SELECT, new TableWhereParamsAndOrder(){ WhereClause = string.Format("[{0}] = {1}", Compeat.Demo.Data.usersDto._PK_COLUMN_NAME, Compeat.Demo.Data.usersDto._PK_PARAMETER_NAME), OrderBy = null, ParamList = new[] { Compeat.Demo.Data.usersDto._myPk_param_getter(pk_val) } }, 1, recursiveDepth > 0, recursiveDepth, collectionsToLoad, collectionToLoadUsingStrings);
			if (lst == null)
			{
				return null;
			}
			else { 
				return lst.FirstOrDefault();
			}			
		}   
		
		/// <summary>
		/// This will return the table object with the where clause that was passed in.
		/// </summary>
		/// <param name="conn">the open sql connection</param>
		/// <param name="whereClause">the where clause value for the desired row, the 'where' itself is not required here, it will be added</param>
		/// <param name="orderBy">the order by to pass through to sql, the 'order by' itself is not required here, it will be added </param>
		/// <param name="collectionsToLoad">child collections to load. ex: new ChildLoaderList&lt;apiemployeesDto&gt;() { x => x.children_apiemployeeassignments, x => x.children_apiemployeecustomfields }</param>
		/// <param name="collectionToLoadUsingStrings">list of collection properties to load for earch returned item, similar to collectionsToLoad but delivered differently</param>
		/// <param name="paramList">raw sql parameters  if needed </param>
		/// <param name="recursiveDepth">children collection depth to load, 0 means no recursive loading.</param>
		/// <returns>a single instance of the table object</returns>
		public override Compeat.Demo.Data.usersDto GetFirst(SqlConnection conn, string whereClause = null, string orderBy = null, ChildLoaderList<Compeat.Demo.Data.usersDto> collectionsToLoad = null, IEnumerable<string> collectionToLoadUsingStrings = null, SqlParameter[] paramList = null, int recursiveDepth = 0) {
			var lst = _GetList(conn, _SELECT, new TableWhereParamsAndOrder(){ WhereClause = whereClause, OrderBy = orderBy, ParamList = paramList }, 1, recursiveDepth > 0, recursiveDepth, collectionsToLoad, collectionToLoadUsingStrings);
			if (lst == null)
			{
				return null;
			}
			else { 
				return lst.FirstOrDefault();
			}			
		}
		
		/// <summary>
		/// This will return the table object list with the where clause that was passed in.
		/// </summary>
		/// <param name="conn">the open sql connection</param>
		/// <param name="whereClause">the where clause value for the desired row, the 'where' itself is not required here, it will be added</param>
		/// <param name="orderBy">the order by to pass through to sql, the 'order by' itself is not required here, it will be added </param>
		/// <param name="collectionsToLoad">child collections to load. ex: new ChildLoaderList&lt;apiemployeesDto&gt;() { x => x.children_apiemployeeassignments, x => x.children_apiemployeecustomfields }</param>
		/// <param name="collectionToLoadUsingStrings">list of collection properties to load for earch returned item, similar to collectionsToLoad but delivered differently</param>
		/// <param name="paramList">raw sql parameters  if needed </param>
		/// <param name="recursiveDepth">children collection depth to load, 0 means no recursive loading.</param>
		/// <returns>a single instance of the table object</returns>
		public override List<Compeat.Demo.Data.usersDto> GetList(SqlConnection conn, string whereClause = null, string orderBy = null, ChildLoaderList<Compeat.Demo.Data.usersDto> collectionsToLoad = null, IEnumerable<string> collectionToLoadUsingStrings = null, SqlParameter[] paramList = null, int recursiveDepth = 0) {
			return _GetList(conn, _SELECT, new TableWhereParamsAndOrder(){ WhereClause = whereClause, OrderBy = orderBy, ParamList = paramList }, ulong.MaxValue, recursiveDepth > 0, recursiveDepth, collectionsToLoad, collectionToLoadUsingStrings);
			
		}
		
		/// <summary>
		/// This will return the table object list with the where expression and information that was passed in.
		/// </summary>
		/// <param name="conn">the open sql connection</param>
		/// <param name="whereExpression">the lambda expression that will be used as the sql where clause, keep it simple for now. </param>
		/// <param name="orderBy">the order by to pass through to sql, the 'order by' itself is not required here, it will be added </param>
		/// <param name="additional_whereClause">THIS WILL BE 'AND'd after the whereExpression. the where clause value for the desired row, the 'where' itself is not required here, it will be added</param>
		/// <param name="collectionsToLoad">child collections to load. ex: new ChildLoaderList&lt;apiemployeesDto&gt;() { x => x.children_apiemployeeassignments, x => x.children_apiemployeecustomfields }</param>
		/// <param name="collectionToLoadUsingStrings">list of collection properties to load for earch returned item, similar to collectionsToLoad but delivered differently</param>
		/// <param name="paramList">raw sql parameters  if needed </param>
		/// <param name="recursiveDepth">children collection depth to load, 0 means no recursive loading.</param>
		/// <returns>a single instance of the table object</returns>
		public override List<Compeat.Demo.Data.usersDto> GetList(SqlConnection conn, Expression<Func<Compeat.Demo.Data.usersDto, bool>> whereExpression, string orderBy = null, string additional_whereClause = null, ChildLoaderList<Compeat.Demo.Data.usersDto> collectionsToLoad = null, IEnumerable<string> collectionToLoadUsingStrings = null, SqlParameter[] paramList = null, int recursiveDepth = 0) {
			return _GetList(conn, _SELECT, InternalTools.ProcessLambda<Compeat.Demo.Data.usersDto>("dbo.users", whereExpression, additional_whereClause, orderBy, paramList), ulong.MaxValue, recursiveDepth > 0, recursiveDepth, collectionsToLoad, collectionToLoadUsingStrings);
		}   	
		#endregion
	
		#region Reading 
		internal const string _SELECT = "select{0} [userid], [username], [fullname], [description], [defaultstore], [promptforrestaurant], [recstamp], [password], [email], [failedpasswordattemptstart], [failedpasswordattemptcount], [lastpasswordchange], [mustchangepassword], [active], [theme], [defaultgroup], [promptformenu], [showscheduledcostsummary], [scheduledcostsummaryorder], [showscheduledhoursfordeptsummary], [scheduledhoursfordeptsummaryorder], [showforecastedsalessummary], [forecastedsalessummaryorder], [showscheduledhourssummary], [scheduledhourssummaryorder], [showallscheduledhourssummary], [allscheduledhourssummaryorder], [showsalesperlaborhoursummary], [salesperlaborhoursummaryorder], [showallscheduledcostsummary], [allscheduledcostsummaryorder], [showscheduledcostpercentsummary], [scheduledcostpercentsummaryorder], [showallscheduledcostpercentsummary], [allscheduledcostpercentsummaryorder], [showscheduledcostsfordeptsummary], [scheduledcostsfordeptsummaryorder], [securitytoken], [showscheduledshiftcountssummary], [scheduledshiftcountssummaryorder], [lang], [mgrtimeoffalerts], [mgrswapalerts], [mgrdroppickupalerts], [mgrautocheckinout], [mobilephone], [alertviaemail], [alertviasms] from [dbo].[users] {1} {2}; ";
		
		internal static List<Compeat.Demo.Data.usersDto> _GetList(SqlConnection conn, string statement, TableWhereParamsAndOrder where, ulong row_count, bool loadRecursive = false, int recursiveDepth = int.MaxValue, ChildLoaderList<Compeat.Demo.Data.usersDto> collectionsToLoad = null, IEnumerable<string> collectionToLoadUsingStrings = null) {
			var __retVal = new List<Compeat.Demo.Data.usersDto>();
			string sql = string.Format(
										statement
										, row_count == ulong.MaxValue ? "" : string.Format(" top {0}", row_count)
										, string.IsNullOrWhiteSpace(where.WhereClause) ? "" : String.Format("where {0}", where.WhereClause)
										, string.IsNullOrWhiteSpace(where.OrderBy) ? "" : String.Format("order by {0}", where.OrderBy)
								);
								
			InternalTools.ScriptRunReader(
				SqlEnums.SqlActivityType.SELECT 
				, sql
				, conn
				, where.ParamList
				, (sdr) => {
						if (sdr.HasRows) {
							while (sdr.Read())
							{
								__retVal.Add(Compeat.Demo.Data.usersDto.GetFromReader(sdr));
							}
						}
					}
				, Compeat.Demo.Data.usersDto.MyTimeout());

			if(__retVal != null){
				if(collectionsToLoad != null) {
					foreach(var __itm in __retVal){
						var properties = collectionsToLoad.Select(s => s.Body.ToString().Replace(string.Format("{0}.", s.Parameters[0].Name), ""));
						__itm.LoadChildProperty(conn, properties);
					}
				} 
				if(collectionToLoadUsingStrings != null) {
					foreach(var __itm in __retVal){
						__itm.LoadChildProperty(conn, collectionToLoadUsingStrings);
					}
				} 
				if(loadRecursive) {
					foreach(var __itm in __retVal){
						__itm.LoadChildren(conn, recursiveDepth);
					}
				}
			}
			
			return __retVal;
		}
		
		#endregion Reading

	}
	
	
	#region Repository needs
	
	public partial interface IRepository {
		Compeat.Demo.Data.users users { get; }
	}
	
	public partial class Repository {
		internal Compeat.Demo.Data.users _users  = null;
		public Compeat.Demo.Data.users users  {
			get{
				if(_users == null){
					_users = new Compeat.Demo.Data.users ();
				}
				return _users ;
			}
		}
	}
	#endregion Repository needs

}
