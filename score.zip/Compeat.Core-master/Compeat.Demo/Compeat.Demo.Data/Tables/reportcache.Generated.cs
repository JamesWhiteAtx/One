﻿using Compeat.Data.Framework;
using Compeat.Data.Framework.InternalUtils;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using Compeat.Demo.Data.Shared;
namespace Compeat.Demo.Data {
	[Serializable]
	public partial class reportcacheDto : TableBase<Compeat.Demo.Data.reportcacheDto, Guid?> {
		
	
	
		/// <summary>
		/// calls its private twin in cases where a static is needed
		/// </summary>
		/// <returns></returns>
		internal static int MyTimeout() {
			return (new Compeat.Demo.Data.reportcacheDto()).GetTimeout();
		}
		
		#region Constants
		internal const int COLUMN_COUNT = 3;
		protected override int ColumnCount { get { return COLUMN_COUNT; } }
		public const int COLUMN_INDEX_id = 0, COLUMN_INDEX_requesttimeutc = 1, COLUMN_INDEX_data = 2;
		public const string COLUMN_NAME_id = "id", COLUMN_NAME_requesttimeutc = "requesttimeutc", COLUMN_NAME_data = "data";
		public const string PARAMETER_NAME_id = "@id", PARAMETER_NAME_requesttimeutc = "@requesttimeutc", PARAMETER_NAME_data = "@data";
	
		internal const string _PK_COLUMN_NAME = COLUMN_NAME_id;
		internal const string _PK_PARAMETER_NAME = "@PK_PARAM";
		internal const string _DELETE = "DELETE FROM [dbo].[reportcache] WHERE [id] = @PK_PARAM";
		internal const string _INSERT = "insert into [dbo].[reportcache] ([id], [requesttimeutc], [data]) values (@id, @requesttimeutc, @data);";
		internal const string _UPDATE = "update [dbo].[reportcache] set {0} where [id] = @PK_PARAM;";
		internal const string _UPDATE_FULL = "update [dbo].[reportcache] set [id]=@id, [requesttimeutc]=@requesttimeutc, [data]=@data where [id] = @PK_PARAM;";
		#endregion
		
		/// <summary>
		/// Will Update, not skinny safe, meaning if an update is done, it will update all columns
		/// </summary>
		public reportcacheDto() : this(true) {
			//not skinny safe
		}
			
		/// <summary>
		/// Will Insert
		/// </summary>
		public static Compeat.Demo.Data.reportcacheDto create() {
			var newInstance = new Compeat.Demo.Data.reportcacheDto();
			newInstance.CmpNew = true;
			return newInstance;
		}    
		/// <summary>
		/// skinny safe: meaning if an update is done, it will only update the fields that had their setters called.
		/// </summary>
		public reportcacheDto(Guid my_pk) : base(){
			//skinny safe
			IsSkinnySafe = true;
			MyPk = my_pk;
		}

		internal reportcacheDto(bool allow_default_set) : base() {
			//not skinny safe
			if(allow_default_set) {
				#region Gen'd DB defaults
				//this.requesttimeutc=(getutcdate()); //DateTime? defaults not yet handled
				#endregion
	 
				SetDefaults();
			}
		}
   
		#region Loaders 		
		internal static Compeat.Demo.Data.reportcacheDto GetFromReader(SqlDataReader dr) {
			var x = new Compeat.Demo.Data.reportcacheDto(false);

			x._myPk = dr.GetGuid(COLUMN_INDEX_id);
			x._id = dr.GetGuid(COLUMN_INDEX_id);
			x._requesttimeutc = DateTime.SpecifyKind(dr.GetDateTime(COLUMN_INDEX_requesttimeutc), DateTimeKind.Utc);
			x._data = (byte[])(dr.IsDBNull(COLUMN_INDEX_data) ? (byte[])null : dr.GetValue(COLUMN_INDEX_data));
			//skinny safe since loaded from reader
			x.IsSkinnySafe = true;
			return x;
		}   
		
		internal void LoadChildProperty(SqlConnection conn, IEnumerable<string> collectionsToLoad)
		{
			ChildLoaderList<Compeat.Demo.Data.reportcacheDto>.LoadProperty(conn, collectionsToLoad, AllChildCollections);
		}  
		
		#endregion Loaders   
		
		#region Writing
		
		
		protected override void Insert(SqlConnection conn) {
			SqlParameter[] parm_list = 
				new SqlParameter[] { 
				 MyPk_param_getter()
						
					, _id_param_getter()
					, _requesttimeutc_param_getter()
					, _data_param_getter()
				};
				
			InternalTools.ScriptRun(SqlEnums.SqlActivityType.INSERT, _INSERT, conn, parm_list, GetTimeout());   	 
		
		}  
		
		protected override void Update(SqlConnection conn) {
			if(IsSkinnySafe && UpdatedProperties.Count() == 0) {
				throw new DbUpdateFailedNoChangesMade("Update to reportcache, but no values have changed. Verify InSavableState before calling.", conn, null);
			}
			if(MyPk == null) {
				throw new DbUpdateFailedPkMissing(_UPDATE, conn, null);
			}
			
			  
			if(IsSkinnySafe) {
				AddChangedProperty(true, false, false, _PK_COLUMN_NAME, _PK_PARAMETER_NAME, this.MyPk_param_getter);    


				if(!UpdatedProperties.Any(s => !s.IsPrimaryKey)) {
					return; //nothing changed
				}
				var parm_list = UpdatedProperties  
									.Where(s => !s.IsIdentity && s.ParameterName != _PK_PARAMETER_NAME)
									.Select(s => s.MyParamGetter())
									.ToList();  
				parm_list.Add(MyPk_param_getter());
				string formatted_update = string.Format(_UPDATE, string.Join(",", UpdatedProperties.Where(s => !s.IsIdentity).Select(s => s.UpdateCombo) ) );
				if(InternalTools.ScriptRun(SqlEnums.SqlActivityType.UPDATE, formatted_update, conn, parm_list.ToArray(), GetTimeout()) <= 0){
					throw new DbUpdateFailedNoChangesMade(formatted_update, conn, parm_list.ToArray());
				}
			}
			else {
				SqlParameter[] parm_list = 
					new SqlParameter[] { 
						MyPk_param_getter()
						, _id_param_getter()
						, _requesttimeutc_param_getter()
						, _data_param_getter()
					};
				if(InternalTools.ScriptRun(SqlEnums.SqlActivityType.UPDATE, _UPDATE_FULL, conn, parm_list, GetTimeout()) <= 0) {
					throw new DbUpdateFailedNoChangesMade(_UPDATE_FULL, conn, parm_list);
				}
			}
		}
		protected override void Delete(SqlConnection conn) {
			InternalTools.ScriptRun(SqlEnums.SqlActivityType.DELETE, _DELETE, conn, new[] { MyPk_param_getter() }, GetTimeout());
			
		}    

		#endregion Writing
		
		#region Gen'd Fields in table
		
		internal static Func<Guid?, SqlParameter> _myPk_param_getter { 
			get {
				return (pk_val) => { return InternalTools.MakeParam(_PK_PARAMETER_NAME, SqlDbType.UniqueIdentifier, pk_val, false);};				
				
			}
		}
		
		internal Func<SqlParameter> MyPk_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(_PK_PARAMETER_NAME, SqlDbType.UniqueIdentifier, MyPk, false);};
			}
		}
		
		internal Guid? _myPk{ get; set; }    
		protected override Guid? MyPk {
			get{ 
				if(IsSkinnySafe){
					return _myPk; 
				}else{
					return id; 
				}
			}
			set{ 
				if(IsSkinnySafe){
					_myPk = value; 
				}
				id = value;
				
			}
		}
		
		protected override bool RequireTimeStamp { get{ return false; } }
		protected override string MyTimeStamp { get{return null;} set{} }
		
			
		internal Guid? _id{ get; set; }    
		internal Func<SqlParameter> _id_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_id, SqlDbType.UniqueIdentifier, _id, false);};
			}
		}   

		public virtual Guid? id { 
			get { return _id; } 
			set {
				_id = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_id, PARAMETER_NAME_id, _id_param_getter);
				}
			}
		}			
		internal DateTime _requesttimeutc{ get; set; }    
		internal Func<SqlParameter> _requesttimeutc_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_requesttimeutc, SqlDbType.DateTime, _requesttimeutc, false);};
			}
		}   

		public virtual DateTime requesttimeutc { 
			get { return _requesttimeutc; } 
			set {
				_requesttimeutc = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_requesttimeutc, PARAMETER_NAME_requesttimeutc, _requesttimeutc_param_getter);
				}
			}
		}			
		internal byte[] _data{ get; set; }    
		internal Func<SqlParameter> _data_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_data, SqlDbType.VarBinary, _data, true);};
			}
		}   

		public virtual byte[] data { 
			get { return _data; } 
			set {
				_data = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_data, PARAMETER_NAME_data, _data_param_getter);
				}
			}
		} 
		#endregion  Gen'd Fields in table

		public override string GetTableName() { 
				return "dbo.reportcache";
		}
	
	
	}
	
	public partial class reportcache : BaseRepositoryTableReader<Repository, Compeat.Demo.Data.reportcacheDto, Guid?>
	{

		#region Repo Turn Around
		 /// <summary>
		/// This will return the table object with the id that was passed in.
		/// </summary>
		/// <param name="conn">the open sql connection</param>
		/// <param name="pk_val">the Pk value for the desired row</param>
		/// <param name="collectionsToLoad">child collections to load. ex: new ChildLoaderList&lt;apiemployeesDto&gt;() { x => x.children_apiemployeeassignments, x => x.children_apiemployeecustomfields }</param>
		/// <param name="collectionToLoadUsingStrings">list of collection properties to load for earch returned item, similar to collectionsToLoad but delivered differently</param>
		/// <param name="recursiveDepth">children collection depth to load, 0 means no recursive loading.</param>
		/// <returns>a single instance of the table object</returns>
		public override Compeat.Demo.Data.reportcacheDto Get(SqlConnection conn, Guid? pk_val, ChildLoaderList<Compeat.Demo.Data.reportcacheDto> collectionsToLoad = null, IEnumerable<string> collectionToLoadUsingStrings = null, int recursiveDepth = 0)
		{
			var lst = _GetList(conn, _SELECT, new TableWhereParamsAndOrder(){ WhereClause = string.Format("[{0}] = {1}", Compeat.Demo.Data.reportcacheDto._PK_COLUMN_NAME, Compeat.Demo.Data.reportcacheDto._PK_PARAMETER_NAME), OrderBy = null, ParamList = new[] { Compeat.Demo.Data.reportcacheDto._myPk_param_getter(pk_val) } }, 1, recursiveDepth > 0, recursiveDepth, collectionsToLoad, collectionToLoadUsingStrings);
			if (lst == null)
			{
				return null;
			}
			else { 
				return lst.FirstOrDefault();
			}			
		}   
		
		/// <summary>
		/// This will return the table object with the where clause that was passed in.
		/// </summary>
		/// <param name="conn">the open sql connection</param>
		/// <param name="whereClause">the where clause value for the desired row, the 'where' itself is not required here, it will be added</param>
		/// <param name="orderBy">the order by to pass through to sql, the 'order by' itself is not required here, it will be added </param>
		/// <param name="collectionsToLoad">child collections to load. ex: new ChildLoaderList&lt;apiemployeesDto&gt;() { x => x.children_apiemployeeassignments, x => x.children_apiemployeecustomfields }</param>
		/// <param name="collectionToLoadUsingStrings">list of collection properties to load for earch returned item, similar to collectionsToLoad but delivered differently</param>
		/// <param name="paramList">raw sql parameters  if needed </param>
		/// <param name="recursiveDepth">children collection depth to load, 0 means no recursive loading.</param>
		/// <returns>a single instance of the table object</returns>
		public override Compeat.Demo.Data.reportcacheDto GetFirst(SqlConnection conn, string whereClause = null, string orderBy = null, ChildLoaderList<Compeat.Demo.Data.reportcacheDto> collectionsToLoad = null, IEnumerable<string> collectionToLoadUsingStrings = null, SqlParameter[] paramList = null, int recursiveDepth = 0) {
			var lst = _GetList(conn, _SELECT, new TableWhereParamsAndOrder(){ WhereClause = whereClause, OrderBy = orderBy, ParamList = paramList }, 1, recursiveDepth > 0, recursiveDepth, collectionsToLoad, collectionToLoadUsingStrings);
			if (lst == null)
			{
				return null;
			}
			else { 
				return lst.FirstOrDefault();
			}			
		}
		
		/// <summary>
		/// This will return the table object list with the where clause that was passed in.
		/// </summary>
		/// <param name="conn">the open sql connection</param>
		/// <param name="whereClause">the where clause value for the desired row, the 'where' itself is not required here, it will be added</param>
		/// <param name="orderBy">the order by to pass through to sql, the 'order by' itself is not required here, it will be added </param>
		/// <param name="collectionsToLoad">child collections to load. ex: new ChildLoaderList&lt;apiemployeesDto&gt;() { x => x.children_apiemployeeassignments, x => x.children_apiemployeecustomfields }</param>
		/// <param name="collectionToLoadUsingStrings">list of collection properties to load for earch returned item, similar to collectionsToLoad but delivered differently</param>
		/// <param name="paramList">raw sql parameters  if needed </param>
		/// <param name="recursiveDepth">children collection depth to load, 0 means no recursive loading.</param>
		/// <returns>a single instance of the table object</returns>
		public override List<Compeat.Demo.Data.reportcacheDto> GetList(SqlConnection conn, string whereClause = null, string orderBy = null, ChildLoaderList<Compeat.Demo.Data.reportcacheDto> collectionsToLoad = null, IEnumerable<string> collectionToLoadUsingStrings = null, SqlParameter[] paramList = null, int recursiveDepth = 0) {
			return _GetList(conn, _SELECT, new TableWhereParamsAndOrder(){ WhereClause = whereClause, OrderBy = orderBy, ParamList = paramList }, ulong.MaxValue, recursiveDepth > 0, recursiveDepth, collectionsToLoad, collectionToLoadUsingStrings);
			
		}
		
		/// <summary>
		/// This will return the table object list with the where expression and information that was passed in.
		/// </summary>
		/// <param name="conn">the open sql connection</param>
		/// <param name="whereExpression">the lambda expression that will be used as the sql where clause, keep it simple for now. </param>
		/// <param name="orderBy">the order by to pass through to sql, the 'order by' itself is not required here, it will be added </param>
		/// <param name="additional_whereClause">THIS WILL BE 'AND'd after the whereExpression. the where clause value for the desired row, the 'where' itself is not required here, it will be added</param>
		/// <param name="collectionsToLoad">child collections to load. ex: new ChildLoaderList&lt;apiemployeesDto&gt;() { x => x.children_apiemployeeassignments, x => x.children_apiemployeecustomfields }</param>
		/// <param name="collectionToLoadUsingStrings">list of collection properties to load for earch returned item, similar to collectionsToLoad but delivered differently</param>
		/// <param name="paramList">raw sql parameters  if needed </param>
		/// <param name="recursiveDepth">children collection depth to load, 0 means no recursive loading.</param>
		/// <returns>a single instance of the table object</returns>
		public override List<Compeat.Demo.Data.reportcacheDto> GetList(SqlConnection conn, Expression<Func<Compeat.Demo.Data.reportcacheDto, bool>> whereExpression, string orderBy = null, string additional_whereClause = null, ChildLoaderList<Compeat.Demo.Data.reportcacheDto> collectionsToLoad = null, IEnumerable<string> collectionToLoadUsingStrings = null, SqlParameter[] paramList = null, int recursiveDepth = 0) {
			return _GetList(conn, _SELECT, InternalTools.ProcessLambda<Compeat.Demo.Data.reportcacheDto>("dbo.reportcache", whereExpression, additional_whereClause, orderBy, paramList), ulong.MaxValue, recursiveDepth > 0, recursiveDepth, collectionsToLoad, collectionToLoadUsingStrings);
		}   	
		#endregion
	
		#region Reading 
		internal const string _SELECT = "select{0} [id], [requesttimeutc], [data] from [dbo].[reportcache] {1} {2}; ";
		
		internal static List<Compeat.Demo.Data.reportcacheDto> _GetList(SqlConnection conn, string statement, TableWhereParamsAndOrder where, ulong row_count, bool loadRecursive = false, int recursiveDepth = int.MaxValue, ChildLoaderList<Compeat.Demo.Data.reportcacheDto> collectionsToLoad = null, IEnumerable<string> collectionToLoadUsingStrings = null) {
			var __retVal = new List<Compeat.Demo.Data.reportcacheDto>();
			string sql = string.Format(
										statement
										, row_count == ulong.MaxValue ? "" : string.Format(" top {0}", row_count)
										, string.IsNullOrWhiteSpace(where.WhereClause) ? "" : String.Format("where {0}", where.WhereClause)
										, string.IsNullOrWhiteSpace(where.OrderBy) ? "" : String.Format("order by {0}", where.OrderBy)
								);
								
			InternalTools.ScriptRunReader(
				SqlEnums.SqlActivityType.SELECT 
				, sql
				, conn
				, where.ParamList
				, (sdr) => {
						if (sdr.HasRows) {
							while (sdr.Read())
							{
								__retVal.Add(Compeat.Demo.Data.reportcacheDto.GetFromReader(sdr));
							}
						}
					}
				, Compeat.Demo.Data.reportcacheDto.MyTimeout());

			if(__retVal != null){
				if(collectionsToLoad != null) {
					foreach(var __itm in __retVal){
						var properties = collectionsToLoad.Select(s => s.Body.ToString().Replace(string.Format("{0}.", s.Parameters[0].Name), ""));
						__itm.LoadChildProperty(conn, properties);
					}
				} 
				if(collectionToLoadUsingStrings != null) {
					foreach(var __itm in __retVal){
						__itm.LoadChildProperty(conn, collectionToLoadUsingStrings);
					}
				} 
				if(loadRecursive) {
					foreach(var __itm in __retVal){
						__itm.LoadChildren(conn, recursiveDepth);
					}
				}
			}
			
			return __retVal;
		}
		
		#endregion Reading

	}
	
	
	#region Repository needs
	
	public partial interface IRepository {
		Compeat.Demo.Data.reportcache reportcache { get; }
	}
	
	public partial class Repository {
		internal Compeat.Demo.Data.reportcache _reportcache  = null;
		public Compeat.Demo.Data.reportcache reportcache  {
			get{
				if(_reportcache == null){
					_reportcache = new Compeat.Demo.Data.reportcache ();
				}
				return _reportcache ;
			}
		}
	}
	#endregion Repository needs

}
