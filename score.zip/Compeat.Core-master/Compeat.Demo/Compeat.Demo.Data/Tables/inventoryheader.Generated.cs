﻿using Compeat.Data.Framework;
using Compeat.Data.Framework.InternalUtils;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using Compeat.Demo.Data.Shared;
namespace Compeat.Demo.Data {
	[Serializable]
	public partial class inventoryheaderDto : TableBase<Compeat.Demo.Data.inventoryheaderDto, int?> {
		
	
	
		/// <summary>
		/// calls its private twin in cases where a static is needed
		/// </summary>
		/// <returns></returns>
		internal static int MyTimeout() {
			return (new Compeat.Demo.Data.inventoryheaderDto()).GetTimeout();
		}
		
		#region Constants
		internal const int COLUMN_COUNT = 39;
		protected override int ColumnCount { get { return COLUMN_COUNT; } }
		public const int COLUMN_INDEX_id = 0, COLUMN_INDEX_description = 1, COLUMN_INDEX_description2 = 2, COLUMN_INDEX_upccode = 3, COLUMN_INDEX_class = 4, COLUMN_INDEX_shelf = 5, COLUMN_INDEX_available = 6, COLUMN_INDEX_invclass = 7, COLUMN_INDEX_convbasenum = 8, COLUMN_INDEX_convbaseuom = 9, COLUMN_INDEX_convinvnum = 10, COLUMN_INDEX_convinvuom = 11, COLUMN_INDEX_convbaseunitsperinvunit = 12, COLUMN_INDEX_level1 = 13, COLUMN_INDEX_level2 = 14, COLUMN_INDEX_level3 = 15, COLUMN_INDEX_recipe = 16, COLUMN_INDEX_prepitem = 17, COLUMN_INDEX_prepitemproduom = 18, COLUMN_INDEX_prepiteminvuom = 19, COLUMN_INDEX_prepiteminvunitsperprodunit = 20, COLUMN_INDEX_modified = 21, COLUMN_INDEX_modifiedby = 22, COLUMN_INDEX_catchweight = 23, COLUMN_INDEX_limitcountstoinvunit = 24, COLUMN_INDEX_prepprodfactor = 25, COLUMN_INDEX_prepprodlaborminutes = 26, COLUMN_INDEX_recstamp = 27, COLUMN_INDEX_couponvalue = 28, COLUMN_INDEX_notes = 29, COLUMN_INDEX_approved = 30, COLUMN_INDEX_unitcostsellingprice = 31, COLUMN_INDEX_royaltypercent = 32, COLUMN_INDEX_modifier1 = 33, COLUMN_INDEX_modifier2 = 34, COLUMN_INDEX_modifier3 = 35, COLUMN_INDEX_custlevelsmodifydesc = 36, COLUMN_INDEX_instructionsuri = 37, COLUMN_INDEX_itemtype = 38;
		public const string COLUMN_NAME_id = "id", COLUMN_NAME_description = "description", COLUMN_NAME_description2 = "description2", COLUMN_NAME_upccode = "upccode", COLUMN_NAME_class = "class", COLUMN_NAME_shelf = "shelf", COLUMN_NAME_available = "available", COLUMN_NAME_invclass = "invclass", COLUMN_NAME_convbasenum = "convbasenum", COLUMN_NAME_convbaseuom = "convbaseuom", COLUMN_NAME_convinvnum = "convinvnum", COLUMN_NAME_convinvuom = "convinvuom", COLUMN_NAME_convbaseunitsperinvunit = "convbaseunitsperinvunit", COLUMN_NAME_level1 = "level1", COLUMN_NAME_level2 = "level2", COLUMN_NAME_level3 = "level3", COLUMN_NAME_recipe = "recipe", COLUMN_NAME_prepitem = "prepitem", COLUMN_NAME_prepitemproduom = "prepitemproduom", COLUMN_NAME_prepiteminvuom = "prepiteminvuom", COLUMN_NAME_prepiteminvunitsperprodunit = "prepiteminvunitsperprodunit", COLUMN_NAME_modified = "modified", COLUMN_NAME_modifiedby = "modifiedby", COLUMN_NAME_catchweight = "catchweight", COLUMN_NAME_limitcountstoinvunit = "limitcountstoinvunit", COLUMN_NAME_prepprodfactor = "prepprodfactor", COLUMN_NAME_prepprodlaborminutes = "prepprodlaborminutes", COLUMN_NAME_recstamp = "recstamp", COLUMN_NAME_couponvalue = "couponvalue", COLUMN_NAME_notes = "notes", COLUMN_NAME_approved = "approved", COLUMN_NAME_unitcostsellingprice = "unitcostsellingprice", COLUMN_NAME_royaltypercent = "royaltypercent", COLUMN_NAME_modifier1 = "modifier1", COLUMN_NAME_modifier2 = "modifier2", COLUMN_NAME_modifier3 = "modifier3", COLUMN_NAME_custlevelsmodifydesc = "custlevelsmodifydesc", COLUMN_NAME_instructionsuri = "instructionsuri", COLUMN_NAME_itemtype = "itemtype";
		public const string PARAMETER_NAME_id = "@id", PARAMETER_NAME_description = "@description", PARAMETER_NAME_description2 = "@description2", PARAMETER_NAME_upccode = "@upccode", PARAMETER_NAME_class = "@class", PARAMETER_NAME_shelf = "@shelf", PARAMETER_NAME_available = "@available", PARAMETER_NAME_invclass = "@invclass", PARAMETER_NAME_convbasenum = "@convbasenum", PARAMETER_NAME_convbaseuom = "@convbaseuom", PARAMETER_NAME_convinvnum = "@convinvnum", PARAMETER_NAME_convinvuom = "@convinvuom", PARAMETER_NAME_convbaseunitsperinvunit = "@convbaseunitsperinvunit", PARAMETER_NAME_level1 = "@level1", PARAMETER_NAME_level2 = "@level2", PARAMETER_NAME_level3 = "@level3", PARAMETER_NAME_recipe = "@recipe", PARAMETER_NAME_prepitem = "@prepitem", PARAMETER_NAME_prepitemproduom = "@prepitemproduom", PARAMETER_NAME_prepiteminvuom = "@prepiteminvuom", PARAMETER_NAME_prepiteminvunitsperprodunit = "@prepiteminvunitsperprodunit", PARAMETER_NAME_modified = "@modified", PARAMETER_NAME_modifiedby = "@modifiedby", PARAMETER_NAME_catchweight = "@catchweight", PARAMETER_NAME_limitcountstoinvunit = "@limitcountstoinvunit", PARAMETER_NAME_prepprodfactor = "@prepprodfactor", PARAMETER_NAME_prepprodlaborminutes = "@prepprodlaborminutes", PARAMETER_NAME_recstamp = "@recstamp", PARAMETER_NAME_couponvalue = "@couponvalue", PARAMETER_NAME_notes = "@notes", PARAMETER_NAME_approved = "@approved", PARAMETER_NAME_unitcostsellingprice = "@unitcostsellingprice", PARAMETER_NAME_royaltypercent = "@royaltypercent", PARAMETER_NAME_modifier1 = "@modifier1", PARAMETER_NAME_modifier2 = "@modifier2", PARAMETER_NAME_modifier3 = "@modifier3", PARAMETER_NAME_custlevelsmodifydesc = "@custlevelsmodifydesc", PARAMETER_NAME_instructionsuri = "@instructionsuri", PARAMETER_NAME_itemtype = "@itemtype";
	
		internal const string _PK_COLUMN_NAME = COLUMN_NAME_id;
		internal const string _PK_PARAMETER_NAME = "@PK_PARAM";
		internal const string _TIMESTAMP_COLUMN_NAME = COLUMN_NAME_recstamp;
		internal const string _TIMESTAMP_PARAMETER_NAME = PARAMETER_NAME_recstamp;
		internal const string _DELETE = "DELETE FROM [dbo].[inventoryheader] WHERE [id] = @PK_PARAM";
		internal const string _INSERT = "insert into [dbo].[inventoryheader] ([id], [description], [description2], [upccode], [class], [shelf], [available], [invclass], [convbasenum], [convbaseuom], [convinvnum], [convinvuom], [convbaseunitsperinvunit], [level1], [level2], [level3], [recipe], [prepitem], [prepitemproduom], [prepiteminvuom], [prepiteminvunitsperprodunit], [modified], [modifiedby], [catchweight], [limitcountstoinvunit], [prepprodfactor], [prepprodlaborminutes], [couponvalue], [notes], [approved], [unitcostsellingprice], [royaltypercent], [modifier1], [modifier2], [modifier3], [custlevelsmodifydesc], [instructionsuri], [itemtype]) values (@id, @description, @description2, @upccode, @class, @shelf, @available, @invclass, @convbasenum, @convbaseuom, @convinvnum, @convinvuom, @convbaseunitsperinvunit, @level1, @level2, @level3, @recipe, @prepitem, @prepitemproduom, @prepiteminvuom, @prepiteminvunitsperprodunit, @modified, @modifiedby, @catchweight, @limitcountstoinvunit, @prepprodfactor, @prepprodlaborminutes, @couponvalue, @notes, @approved, @unitcostsellingprice, @royaltypercent, @modifier1, @modifier2, @modifier3, @custlevelsmodifydesc, @instructionsuri, @itemtype); select top 1 [recstamp] from [dbo].[inventoryheader] where [id] = @PK_PARAM;";
		internal const string _UPDATE = "update [dbo].[inventoryheader] set {0} where [id] = @PK_PARAM and [recstamp] = @recstamp;select top 1 [recstamp] from [dbo].[inventoryheader] where [id] = @PK_PARAM;";
		internal const string _UPDATE_FULL = "update [dbo].[inventoryheader] set [id]=@id, [description]=@description, [description2]=@description2, [upccode]=@upccode, [class]=@class, [shelf]=@shelf, [available]=@available, [invclass]=@invclass, [convbasenum]=@convbasenum, [convbaseuom]=@convbaseuom, [convinvnum]=@convinvnum, [convinvuom]=@convinvuom, [convbaseunitsperinvunit]=@convbaseunitsperinvunit, [level1]=@level1, [level2]=@level2, [level3]=@level3, [recipe]=@recipe, [prepitem]=@prepitem, [prepitemproduom]=@prepitemproduom, [prepiteminvuom]=@prepiteminvuom, [prepiteminvunitsperprodunit]=@prepiteminvunitsperprodunit, [modified]=@modified, [modifiedby]=@modifiedby, [catchweight]=@catchweight, [limitcountstoinvunit]=@limitcountstoinvunit, [prepprodfactor]=@prepprodfactor, [prepprodlaborminutes]=@prepprodlaborminutes, [couponvalue]=@couponvalue, [notes]=@notes, [approved]=@approved, [unitcostsellingprice]=@unitcostsellingprice, [royaltypercent]=@royaltypercent, [modifier1]=@modifier1, [modifier2]=@modifier2, [modifier3]=@modifier3, [custlevelsmodifydesc]=@custlevelsmodifydesc, [instructionsuri]=@instructionsuri, [itemtype]=@itemtype where [id] = @PK_PARAM and [recstamp] = @recstamp;select top 1 [recstamp] from [dbo].[inventoryheader] where [id] = @PK_PARAM;";
		#endregion
		
		/// <summary>
		/// Will Update, not skinny safe, meaning if an update is done, it will update all columns
		/// </summary>
		public inventoryheaderDto() : this(true) {
			//not skinny safe
		}
			
		/// <summary>
		/// Will Insert
		/// </summary>
		public static Compeat.Demo.Data.inventoryheaderDto create() {
			var newInstance = new Compeat.Demo.Data.inventoryheaderDto();
			newInstance.CmpNew = true;
			return newInstance;
		}    
		/// <summary>
		/// skinny safe: meaning if an update is done, it will only update the fields that had their setters called.
		/// </summary>
		public inventoryheaderDto(int my_pk, string my_timestamp) : base(){
			//skinny safe
			IsSkinnySafe = true;
			MyPk = my_pk;
			MyTimeStamp = my_timestamp;
		}

		internal inventoryheaderDto(bool allow_default_set) : base() {
			//not skinny safe
			if(allow_default_set) {
				#region Gen'd DB defaults
				this.xclass=1;
				this.available=true;
				this.convbaseunitsperinvunit=1m;
				this.prepiteminvunitsperprodunit=1m;
				this.catchweight=false;
				this.limitcountstoinvunit=false;
				this.prepprodfactor=1m;
				this.approved=true;
				this.unitcostsellingprice=1;
				this.custlevelsmodifydesc=false;
				this.itemtype=1;
				#endregion
	 
				SetDefaults();
			}
		}
   
		#region Loaders 		
		internal static Compeat.Demo.Data.inventoryheaderDto GetFromReader(SqlDataReader dr) {
			var x = new Compeat.Demo.Data.inventoryheaderDto(false);

			x._myPk = dr.GetInt32(COLUMN_INDEX_id);
			x._id = dr.GetInt32(COLUMN_INDEX_id);
			x._description = (dr.IsDBNull(COLUMN_INDEX_description) ? null : dr.GetString(COLUMN_INDEX_description));
			x._description2 = (dr.IsDBNull(COLUMN_INDEX_description2) ? null : dr.GetString(COLUMN_INDEX_description2));
			x._upccode = (dr.IsDBNull(COLUMN_INDEX_upccode) ? null : dr.GetString(COLUMN_INDEX_upccode));
			x._class = dr.GetInt32(COLUMN_INDEX_class);
			x._shelf = (dr.IsDBNull(COLUMN_INDEX_shelf) ? (int?)null : dr.GetInt32(COLUMN_INDEX_shelf));
			x._available = dr.GetBoolean(COLUMN_INDEX_available);
			x._invclass = (dr.IsDBNull(COLUMN_INDEX_invclass) ? (int?)null : dr.GetInt32(COLUMN_INDEX_invclass));
			x._convbasenum = (dr.IsDBNull(COLUMN_INDEX_convbasenum) ? (decimal?)null : dr.GetDecimal(COLUMN_INDEX_convbasenum));
			x._convbaseuom = (dr.IsDBNull(COLUMN_INDEX_convbaseuom) ? (int?)null : dr.GetInt32(COLUMN_INDEX_convbaseuom));
			x._convinvnum = (dr.IsDBNull(COLUMN_INDEX_convinvnum) ? (decimal?)null : dr.GetDecimal(COLUMN_INDEX_convinvnum));
			x._convinvuom = (dr.IsDBNull(COLUMN_INDEX_convinvuom) ? (int?)null : dr.GetInt32(COLUMN_INDEX_convinvuom));
			x._convbaseunitsperinvunit = dr.GetDecimal(COLUMN_INDEX_convbaseunitsperinvunit);
			x._level1 = (dr.IsDBNull(COLUMN_INDEX_level1) ? (int?)null : dr.GetInt32(COLUMN_INDEX_level1));
			x._level2 = (dr.IsDBNull(COLUMN_INDEX_level2) ? (int?)null : dr.GetInt32(COLUMN_INDEX_level2));
			x._level3 = (dr.IsDBNull(COLUMN_INDEX_level3) ? (int?)null : dr.GetInt32(COLUMN_INDEX_level3));
			x._recipe = (dr.IsDBNull(COLUMN_INDEX_recipe) ? null : dr.GetString(COLUMN_INDEX_recipe));
			x._prepitem = dr.GetBoolean(COLUMN_INDEX_prepitem);
			x._prepitemproduom = (dr.IsDBNull(COLUMN_INDEX_prepitemproduom) ? (int?)null : dr.GetInt32(COLUMN_INDEX_prepitemproduom));
			x._prepiteminvuom = (dr.IsDBNull(COLUMN_INDEX_prepiteminvuom) ? (int?)null : dr.GetInt32(COLUMN_INDEX_prepiteminvuom));
			x._prepiteminvunitsperprodunit = dr.GetDecimal(COLUMN_INDEX_prepiteminvunitsperprodunit);
			x._modified = (dr.IsDBNull(COLUMN_INDEX_modified) ? (DateTime?)null : dr.GetDateTime(COLUMN_INDEX_modified));
			x._modifiedby = (dr.IsDBNull(COLUMN_INDEX_modifiedby) ? null : dr.GetString(COLUMN_INDEX_modifiedby));
			x._catchweight = dr.GetBoolean(COLUMN_INDEX_catchweight);
			x._limitcountstoinvunit = dr.GetBoolean(COLUMN_INDEX_limitcountstoinvunit);
			x._prepprodfactor = dr.GetDecimal(COLUMN_INDEX_prepprodfactor);
			x._prepprodlaborminutes = (dr.IsDBNull(COLUMN_INDEX_prepprodlaborminutes) ? (int?)null : dr.GetInt32(COLUMN_INDEX_prepprodlaborminutes));
			x._recstamp = (byte[])dr.GetValue(COLUMN_INDEX_recstamp);
			x._couponvalue = (dr.IsDBNull(COLUMN_INDEX_couponvalue) ? (int?)null : dr.GetInt32(COLUMN_INDEX_couponvalue));
			x._notes = (dr.IsDBNull(COLUMN_INDEX_notes) ? null : dr.GetString(COLUMN_INDEX_notes));
			x._approved = dr.GetBoolean(COLUMN_INDEX_approved);
			x._unitcostsellingprice = dr.GetByte(COLUMN_INDEX_unitcostsellingprice);
			x._royaltypercent = (dr.IsDBNull(COLUMN_INDEX_royaltypercent) ? (decimal?)null : dr.GetDecimal(COLUMN_INDEX_royaltypercent));
			x._modifier1 = (dr.IsDBNull(COLUMN_INDEX_modifier1) ? (int?)null : dr.GetInt32(COLUMN_INDEX_modifier1));
			x._modifier2 = (dr.IsDBNull(COLUMN_INDEX_modifier2) ? (int?)null : dr.GetInt32(COLUMN_INDEX_modifier2));
			x._modifier3 = (dr.IsDBNull(COLUMN_INDEX_modifier3) ? (int?)null : dr.GetInt32(COLUMN_INDEX_modifier3));
			x._custlevelsmodifydesc = dr.GetBoolean(COLUMN_INDEX_custlevelsmodifydesc);
			x._instructionsuri = (dr.IsDBNull(COLUMN_INDEX_instructionsuri) ? null : dr.GetString(COLUMN_INDEX_instructionsuri));
			x._itemtype = dr.GetInt32(COLUMN_INDEX_itemtype);
			//skinny safe since loaded from reader
			x.IsSkinnySafe = true;
			return x;
		}   
		
		internal void LoadChildProperty(SqlConnection conn, IEnumerable<string> collectionsToLoad)
		{
			ChildLoaderList<Compeat.Demo.Data.inventoryheaderDto>.LoadProperty(conn, collectionsToLoad, AllChildCollections);
		}  
		
		#endregion Loaders   
		
		#region Writing
		
		
		protected override void Insert(SqlConnection conn) {
			SqlParameter[] parm_list = 
				new SqlParameter[] { 
				 MyPk_param_getter()
						
					, _id_param_getter()
					, _description_param_getter()
					, _description2_param_getter()
					, _upccode_param_getter()
					, _class_param_getter()
					, _shelf_param_getter()
					, _available_param_getter()
					, _invclass_param_getter()
					, _convbasenum_param_getter()
					, _convbaseuom_param_getter()
					, _convinvnum_param_getter()
					, _convinvuom_param_getter()
					, _convbaseunitsperinvunit_param_getter()
					, _level1_param_getter()
					, _level2_param_getter()
					, _level3_param_getter()
					, _recipe_param_getter()
					, _prepitem_param_getter()
					, _prepitemproduom_param_getter()
					, _prepiteminvuom_param_getter()
					, _prepiteminvunitsperprodunit_param_getter()
					, _modified_param_getter()
					, _modifiedby_param_getter()
					, _catchweight_param_getter()
					, _limitcountstoinvunit_param_getter()
					, _prepprodfactor_param_getter()
					, _prepprodlaborminutes_param_getter()
					, _couponvalue_param_getter()
					, _notes_param_getter()
					, _approved_param_getter()
					, _unitcostsellingprice_param_getter()
					, _royaltypercent_param_getter()
					, _modifier1_param_getter()
					, _modifier2_param_getter()
					, _modifier3_param_getter()
					, _custlevelsmodifydesc_param_getter()
					, _instructionsuri_param_getter()
					, _itemtype_param_getter()
				};
				
			InternalTools.ScriptRunReader(SqlEnums.SqlActivityType.INSERT, _INSERT, conn, parm_list
				, (sdr) => {	   
						if (!sdr.HasRows || !sdr.Read()) {
							throw new DbUpdateFailedNoChangesMade("Insert into inventoryheader, but now new rows were detected using PK or identity fields.", conn, null);
						}else{
							_recstamp = (byte[])sdr.GetValue(0);//refresh the timestamp
						}
					}
				, GetTimeout());
		
		}  
		
		protected override void Update(SqlConnection conn) {
			if(IsSkinnySafe && UpdatedProperties.Count() == 0) {
				throw new DbUpdateFailedNoChangesMade("Update to inventoryheader, but no values have changed. Verify InSavableState before calling.", conn, null);
			}
			if(MyPk == null) {
				throw new DbUpdateFailedPkMissing(_UPDATE, conn, null);
			}
			if(MyTimeStamp == null) {
				throw new DbUpdateFailedTimestampMissing(_UPDATE, conn, null);
			}
			
			  
			if(IsSkinnySafe) {
				AddChangedProperty(true, false, false, _PK_COLUMN_NAME, _PK_PARAMETER_NAME, this.MyPk_param_getter);    

				AddChangedProperty(false, false, true, _TIMESTAMP_COLUMN_NAME, _TIMESTAMP_PARAMETER_NAME, this.MyTimeStamp_param_getter);

				if(!UpdatedProperties.Any(s => !s.IsPrimaryKey && !s.IsIdentity && !s.IsTimestamp)) {
					return; //nothing changed
				}
				var parm_list = UpdatedProperties
									.Where(s => !s.IsIdentity && s.ParameterName != _PK_PARAMETER_NAME && !s.IsTimestamp && s.ParameterName != _TIMESTAMP_PARAMETER_NAME)
									.Select(s => s.MyParamGetter())
									.ToList();  
				parm_list.Add(MyPk_param_getter());
				string formatted_update = string.Format(_UPDATE, string.Join(",", UpdatedProperties.Where(s => !s.IsIdentity && !s.IsTimestamp).Select(s => s.UpdateCombo) ) );
				InternalTools.ScriptRunReader(SqlEnums.SqlActivityType.UPDATE, formatted_update, conn, parm_list.ToArray()
					, (sdr) => {	 
						if (!sdr.HasRows || !sdr.Read()) {
							throw new DbUpdateFailedNoChangesMade("Insert into inventoryheader, but now new rows were detected using PK or identity fields.", conn, null);
						}else{
							_recstamp = (byte[])sdr.GetValue(0);//refresh the timestamp
						}
					}
				, GetTimeout());
			}
			else {
				SqlParameter[] parm_list = 
					new SqlParameter[] { 
						MyPk_param_getter()
						, MyTimeStamp_param_getter()
						, _id_param_getter()
						, _description_param_getter()
						, _description2_param_getter()
						, _upccode_param_getter()
						, _class_param_getter()
						, _shelf_param_getter()
						, _available_param_getter()
						, _invclass_param_getter()
						, _convbasenum_param_getter()
						, _convbaseuom_param_getter()
						, _convinvnum_param_getter()
						, _convinvuom_param_getter()
						, _convbaseunitsperinvunit_param_getter()
						, _level1_param_getter()
						, _level2_param_getter()
						, _level3_param_getter()
						, _recipe_param_getter()
						, _prepitem_param_getter()
						, _prepitemproduom_param_getter()
						, _prepiteminvuom_param_getter()
						, _prepiteminvunitsperprodunit_param_getter()
						, _modified_param_getter()
						, _modifiedby_param_getter()
						, _catchweight_param_getter()
						, _limitcountstoinvunit_param_getter()
						, _prepprodfactor_param_getter()
						, _prepprodlaborminutes_param_getter()
						, _couponvalue_param_getter()
						, _notes_param_getter()
						, _approved_param_getter()
						, _unitcostsellingprice_param_getter()
						, _royaltypercent_param_getter()
						, _modifier1_param_getter()
						, _modifier2_param_getter()
						, _modifier3_param_getter()
						, _custlevelsmodifydesc_param_getter()
						, _instructionsuri_param_getter()
						, _itemtype_param_getter()
					};
				InternalTools.ScriptRunReader(SqlEnums.SqlActivityType.UPDATE, _UPDATE_FULL, conn, parm_list
					, (sdr) => {	 
						if (!sdr.HasRows || !sdr.Read()) {
							throw new DbUpdateFailedNoChangesMade("Insert into inventoryheader, but now new rows were detected using PK or identity fields.", conn, null);
						}else{
							_recstamp = (byte[])sdr.GetValue(0);//refresh the timestamp
						}
					}
				, GetTimeout());
			}
		}
		protected override void Delete(SqlConnection conn) {
			InternalTools.ScriptRun(SqlEnums.SqlActivityType.DELETE, _DELETE, conn, new[] { MyPk_param_getter() }, GetTimeout());
			
		}    

		#endregion Writing
		
		#region Gen'd Fields in table
		
		internal static Func<int?, SqlParameter> _myPk_param_getter { 
			get {
				return (pk_val) => { return InternalTools.MakeParam(_PK_PARAMETER_NAME, SqlDbType.Int, pk_val, false);};				
				
			}
		}
		
		internal Func<SqlParameter> MyPk_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(_PK_PARAMETER_NAME, SqlDbType.Int, MyPk, false);};
			}
		}
		
		internal int? _myPk{ get; set; }    
		protected override int? MyPk {
			get{ 
				if(IsSkinnySafe){
					return _myPk; 
				}else{
					return id; 
				}
			}
			set{ 
				if(IsSkinnySafe){
					_myPk = value; 
				}
				id = value;
				
			}
		}
		
		internal Func<SqlParameter> MyTimeStamp_param_getter { 
			get {
				return _recstamp_param_getter;
			}
		}
		protected override bool RequireTimeStamp { get{ return true; } }
		protected override string MyTimeStamp {
			get{ return recstamp; }
			set{ recstamp = value; }
		}
		
			
		internal int? _id{ get; set; }    
		internal Func<SqlParameter> _id_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_id, SqlDbType.Int, _id, false);};
			}
		}   

		public virtual int? id { 
			get { return _id; } 
			set {
				_id = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_id, PARAMETER_NAME_id, _id_param_getter);
				}
			}
		}			
		internal string _description{ get; set; }    
		internal Func<SqlParameter> _description_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_description, SqlDbType.VarChar, _description, true, 30);};
			}
		}   

		public virtual string description { 
			get { return _description; } 
			set {
				_description = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_description, PARAMETER_NAME_description, _description_param_getter);
				}
			}
		}			
		internal string _description2{ get; set; }    
		internal Func<SqlParameter> _description2_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_description2, SqlDbType.VarChar, _description2, true, 30);};
			}
		}   

		public virtual string description2 { 
			get { return _description2; } 
			set {
				_description2 = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_description2, PARAMETER_NAME_description2, _description2_param_getter);
				}
			}
		}			
		internal string _upccode{ get; set; }    
		internal Func<SqlParameter> _upccode_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_upccode, SqlDbType.VarChar, _upccode, true, 20);};
			}
		}   

		public virtual string upccode { 
			get { return _upccode; } 
			set {
				_upccode = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_upccode, PARAMETER_NAME_upccode, _upccode_param_getter);
				}
			}
		}			
		internal int _class{ get; set; }    
		internal Func<SqlParameter> _class_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_class, SqlDbType.Int, _class, false);};
			}
		}   

		public virtual int xclass { 
			get { return _class; } 
			set {
				_class = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_class, PARAMETER_NAME_class, _class_param_getter);
				}
			}
		}			
		internal int? _shelf{ get; set; }    
		internal Func<SqlParameter> _shelf_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_shelf, SqlDbType.Int, _shelf, true);};
			}
		}   

		public virtual int? shelf { 
			get { return _shelf; } 
			set {
				_shelf = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_shelf, PARAMETER_NAME_shelf, _shelf_param_getter);
				}
			}
		}			
		internal bool _available{ get; set; }    
		internal Func<SqlParameter> _available_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_available, SqlDbType.Bit, _available, false);};
			}
		}   

		public virtual bool available { 
			get { return _available; } 
			set {
				_available = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_available, PARAMETER_NAME_available, _available_param_getter);
				}
			}
		}			
		internal int? _invclass{ get; set; }    
		internal Func<SqlParameter> _invclass_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_invclass, SqlDbType.Int, _invclass, true);};
			}
		}   

		public virtual int? invclass { 
			get { return _invclass; } 
			set {
				_invclass = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_invclass, PARAMETER_NAME_invclass, _invclass_param_getter);
				}
			}
		}			
		internal decimal? _convbasenum{ get; set; }    
		internal Func<SqlParameter> _convbasenum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_convbasenum, SqlDbType.Decimal, _convbasenum, true, 18, 6);};
			}
		}   

		public virtual decimal? convbasenum { 
			get { return _convbasenum; } 
			set {
				_convbasenum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_convbasenum, PARAMETER_NAME_convbasenum, _convbasenum_param_getter);
				}
			}
		}			
		internal int? _convbaseuom{ get; set; }    
		internal Func<SqlParameter> _convbaseuom_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_convbaseuom, SqlDbType.Int, _convbaseuom, true);};
			}
		}   

		public virtual int? convbaseuom { 
			get { return _convbaseuom; } 
			set {
				_convbaseuom = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_convbaseuom, PARAMETER_NAME_convbaseuom, _convbaseuom_param_getter);
				}
			}
		}			
		internal decimal? _convinvnum{ get; set; }    
		internal Func<SqlParameter> _convinvnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_convinvnum, SqlDbType.Decimal, _convinvnum, true, 18, 6);};
			}
		}   

		public virtual decimal? convinvnum { 
			get { return _convinvnum; } 
			set {
				_convinvnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_convinvnum, PARAMETER_NAME_convinvnum, _convinvnum_param_getter);
				}
			}
		}			
		internal int? _convinvuom{ get; set; }    
		internal Func<SqlParameter> _convinvuom_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_convinvuom, SqlDbType.Int, _convinvuom, true);};
			}
		}   

		public virtual int? convinvuom { 
			get { return _convinvuom; } 
			set {
				_convinvuom = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_convinvuom, PARAMETER_NAME_convinvuom, _convinvuom_param_getter);
				}
			}
		}			
		internal decimal _convbaseunitsperinvunit{ get; set; }    
		internal Func<SqlParameter> _convbaseunitsperinvunit_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_convbaseunitsperinvunit, SqlDbType.Decimal, _convbaseunitsperinvunit, false, 19, 10);};
			}
		}   

		public virtual decimal convbaseunitsperinvunit { 
			get { return _convbaseunitsperinvunit; } 
			set {
				_convbaseunitsperinvunit = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_convbaseunitsperinvunit, PARAMETER_NAME_convbaseunitsperinvunit, _convbaseunitsperinvunit_param_getter);
				}
			}
		}			
		internal int? _level1{ get; set; }    
		internal Func<SqlParameter> _level1_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_level1, SqlDbType.Int, _level1, true);};
			}
		}   

		public virtual int? level1 { 
			get { return _level1; } 
			set {
				_level1 = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_level1, PARAMETER_NAME_level1, _level1_param_getter);
				}
			}
		}			
		internal int? _level2{ get; set; }    
		internal Func<SqlParameter> _level2_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_level2, SqlDbType.Int, _level2, true);};
			}
		}   

		public virtual int? level2 { 
			get { return _level2; } 
			set {
				_level2 = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_level2, PARAMETER_NAME_level2, _level2_param_getter);
				}
			}
		}			
		internal int? _level3{ get; set; }    
		internal Func<SqlParameter> _level3_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_level3, SqlDbType.Int, _level3, true);};
			}
		}   

		public virtual int? level3 { 
			get { return _level3; } 
			set {
				_level3 = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_level3, PARAMETER_NAME_level3, _level3_param_getter);
				}
			}
		}			
		internal string _recipe{ get; set; }    
		internal Func<SqlParameter> _recipe_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_recipe, SqlDbType.Text, _recipe, true);};
			}
		}   

		public virtual string recipe { 
			get { return _recipe; } 
			set {
				_recipe = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_recipe, PARAMETER_NAME_recipe, _recipe_param_getter);
				}
			}
		}			
		internal bool _prepitem{ get; set; }    
		internal Func<SqlParameter> _prepitem_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_prepitem, SqlDbType.Bit, _prepitem, false);};
			}
		}   

		public virtual bool prepitem { 
			get { return _prepitem; } 
			set {
				_prepitem = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_prepitem, PARAMETER_NAME_prepitem, _prepitem_param_getter);
				}
			}
		}			
		internal int? _prepitemproduom{ get; set; }    
		internal Func<SqlParameter> _prepitemproduom_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_prepitemproduom, SqlDbType.Int, _prepitemproduom, true);};
			}
		}   

		public virtual int? prepitemproduom { 
			get { return _prepitemproduom; } 
			set {
				_prepitemproduom = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_prepitemproduom, PARAMETER_NAME_prepitemproduom, _prepitemproduom_param_getter);
				}
			}
		}			
		internal int? _prepiteminvuom{ get; set; }    
		internal Func<SqlParameter> _prepiteminvuom_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_prepiteminvuom, SqlDbType.Int, _prepiteminvuom, true);};
			}
		}   

		public virtual int? prepiteminvuom { 
			get { return _prepiteminvuom; } 
			set {
				_prepiteminvuom = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_prepiteminvuom, PARAMETER_NAME_prepiteminvuom, _prepiteminvuom_param_getter);
				}
			}
		}			
		internal decimal _prepiteminvunitsperprodunit{ get; set; }    
		internal Func<SqlParameter> _prepiteminvunitsperprodunit_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_prepiteminvunitsperprodunit, SqlDbType.Decimal, _prepiteminvunitsperprodunit, false, 19, 10);};
			}
		}   

		public virtual decimal prepiteminvunitsperprodunit { 
			get { return _prepiteminvunitsperprodunit; } 
			set {
				_prepiteminvunitsperprodunit = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_prepiteminvunitsperprodunit, PARAMETER_NAME_prepiteminvunitsperprodunit, _prepiteminvunitsperprodunit_param_getter);
				}
			}
		}			
		internal DateTime? _modified{ get; set; }    
		internal Func<SqlParameter> _modified_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_modified, SqlDbType.DateTime, _modified, true);};
			}
		}   

		public virtual DateTime? modified { 
			get { return _modified; } 
			set {
				_modified = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_modified, PARAMETER_NAME_modified, _modified_param_getter);
				}
			}
		}			
		internal string _modifiedby{ get; set; }    
		internal Func<SqlParameter> _modifiedby_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_modifiedby, SqlDbType.VarChar, _modifiedby, true, 20);};
			}
		}   

		public virtual string modifiedby { 
			get { return _modifiedby; } 
			set {
				_modifiedby = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_modifiedby, PARAMETER_NAME_modifiedby, _modifiedby_param_getter);
				}
			}
		}			
		internal bool _catchweight{ get; set; }    
		internal Func<SqlParameter> _catchweight_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_catchweight, SqlDbType.Bit, _catchweight, false);};
			}
		}   

		public virtual bool catchweight { 
			get { return _catchweight; } 
			set {
				_catchweight = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_catchweight, PARAMETER_NAME_catchweight, _catchweight_param_getter);
				}
			}
		}			
		internal bool _limitcountstoinvunit{ get; set; }    
		internal Func<SqlParameter> _limitcountstoinvunit_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_limitcountstoinvunit, SqlDbType.Bit, _limitcountstoinvunit, false);};
			}
		}   

		public virtual bool limitcountstoinvunit { 
			get { return _limitcountstoinvunit; } 
			set {
				_limitcountstoinvunit = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_limitcountstoinvunit, PARAMETER_NAME_limitcountstoinvunit, _limitcountstoinvunit_param_getter);
				}
			}
		}			
		internal decimal _prepprodfactor{ get; set; }    
		internal Func<SqlParameter> _prepprodfactor_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_prepprodfactor, SqlDbType.Decimal, _prepprodfactor, false, 19, 6);};
			}
		}   

		public virtual decimal prepprodfactor { 
			get { return _prepprodfactor; } 
			set {
				_prepprodfactor = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_prepprodfactor, PARAMETER_NAME_prepprodfactor, _prepprodfactor_param_getter);
				}
			}
		}			
		internal int? _prepprodlaborminutes{ get; set; }    
		internal Func<SqlParameter> _prepprodlaborminutes_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_prepprodlaborminutes, SqlDbType.Int, _prepprodlaborminutes, true);};
			}
		}   

		public virtual int? prepprodlaborminutes { 
			get { return _prepprodlaborminutes; } 
			set {
				_prepprodlaborminutes = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_prepprodlaborminutes, PARAMETER_NAME_prepprodlaborminutes, _prepprodlaborminutes_param_getter);
				}
			}
		}			
		internal byte[] _recstamp{ get; set; }    
		internal Func<SqlParameter> _recstamp_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_recstamp, SqlDbType.Timestamp, _recstamp, false);};
			}
		}   
		public virtual string recstamp { 
			get { 
				return _recstamp == null ? null : Convert.ToBase64String(_recstamp); 
			}
			set {
				if(string.IsNullOrWhiteSpace(value)){
					_recstamp = null;
				}
				else {
					_recstamp = Convert.FromBase64String(value);
				}
				if(IsSkinnySafe){
					AddChangedProperty(false, false, true, COLUMN_NAME_recstamp, PARAMETER_NAME_recstamp, _recstamp_param_getter);
				}
			}
		}			
		internal int? _couponvalue{ get; set; }    
		internal Func<SqlParameter> _couponvalue_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_couponvalue, SqlDbType.Int, _couponvalue, true);};
			}
		}   

		public virtual int? couponvalue { 
			get { return _couponvalue; } 
			set {
				_couponvalue = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_couponvalue, PARAMETER_NAME_couponvalue, _couponvalue_param_getter);
				}
			}
		}			
		internal string _notes{ get; set; }    
		internal Func<SqlParameter> _notes_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_notes, SqlDbType.Text, _notes, true);};
			}
		}   

		public virtual string notes { 
			get { return _notes; } 
			set {
				_notes = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_notes, PARAMETER_NAME_notes, _notes_param_getter);
				}
			}
		}			
		internal bool _approved{ get; set; }    
		internal Func<SqlParameter> _approved_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_approved, SqlDbType.Bit, _approved, false);};
			}
		}   

		public virtual bool approved { 
			get { return _approved; } 
			set {
				_approved = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_approved, PARAMETER_NAME_approved, _approved_param_getter);
				}
			}
		}			
		internal byte _unitcostsellingprice{ get; set; }    
		internal Func<SqlParameter> _unitcostsellingprice_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_unitcostsellingprice, SqlDbType.TinyInt, _unitcostsellingprice, false);};
			}
		}   

		public virtual byte unitcostsellingprice { 
			get { return _unitcostsellingprice; } 
			set {
				_unitcostsellingprice = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_unitcostsellingprice, PARAMETER_NAME_unitcostsellingprice, _unitcostsellingprice_param_getter);
				}
			}
		}			
		internal decimal? _royaltypercent{ get; set; }    
		internal Func<SqlParameter> _royaltypercent_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_royaltypercent, SqlDbType.Decimal, _royaltypercent, true, 9, 2);};
			}
		}   

		public virtual decimal? royaltypercent { 
			get { return _royaltypercent; } 
			set {
				_royaltypercent = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_royaltypercent, PARAMETER_NAME_royaltypercent, _royaltypercent_param_getter);
				}
			}
		}			
		internal int? _modifier1{ get; set; }    
		internal Func<SqlParameter> _modifier1_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_modifier1, SqlDbType.Int, _modifier1, true);};
			}
		}   

		public virtual int? modifier1 { 
			get { return _modifier1; } 
			set {
				_modifier1 = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_modifier1, PARAMETER_NAME_modifier1, _modifier1_param_getter);
				}
			}
		}			
		internal int? _modifier2{ get; set; }    
		internal Func<SqlParameter> _modifier2_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_modifier2, SqlDbType.Int, _modifier2, true);};
			}
		}   

		public virtual int? modifier2 { 
			get { return _modifier2; } 
			set {
				_modifier2 = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_modifier2, PARAMETER_NAME_modifier2, _modifier2_param_getter);
				}
			}
		}			
		internal int? _modifier3{ get; set; }    
		internal Func<SqlParameter> _modifier3_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_modifier3, SqlDbType.Int, _modifier3, true);};
			}
		}   

		public virtual int? modifier3 { 
			get { return _modifier3; } 
			set {
				_modifier3 = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_modifier3, PARAMETER_NAME_modifier3, _modifier3_param_getter);
				}
			}
		}			
		internal bool _custlevelsmodifydesc{ get; set; }    
		internal Func<SqlParameter> _custlevelsmodifydesc_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_custlevelsmodifydesc, SqlDbType.Bit, _custlevelsmodifydesc, false);};
			}
		}   

		public virtual bool custlevelsmodifydesc { 
			get { return _custlevelsmodifydesc; } 
			set {
				_custlevelsmodifydesc = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_custlevelsmodifydesc, PARAMETER_NAME_custlevelsmodifydesc, _custlevelsmodifydesc_param_getter);
				}
			}
		}			
		internal string _instructionsuri{ get; set; }    
		internal Func<SqlParameter> _instructionsuri_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_instructionsuri, SqlDbType.VarChar, _instructionsuri, true, 250);};
			}
		}   

		public virtual string instructionsuri { 
			get { return _instructionsuri; } 
			set {
				_instructionsuri = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_instructionsuri, PARAMETER_NAME_instructionsuri, _instructionsuri_param_getter);
				}
			}
		}			
		internal int _itemtype{ get; set; }    
		internal Func<SqlParameter> _itemtype_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_itemtype, SqlDbType.Int, _itemtype, false);};
			}
		}   

		public virtual int itemtype { 
			get { return _itemtype; } 
			set {
				_itemtype = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_itemtype, PARAMETER_NAME_itemtype, _itemtype_param_getter);
				}
			}
		} 
		#endregion  Gen'd Fields in table

		public override string GetTableName() { 
				return "dbo.inventoryheader";
		}
	
	
	}
	
	public partial class inventoryheader : BaseRepositoryTableReader<Repository, Compeat.Demo.Data.inventoryheaderDto, int?>
	{

		#region Repo Turn Around
		 /// <summary>
		/// This will return the table object with the id that was passed in.
		/// </summary>
		/// <param name="conn">the open sql connection</param>
		/// <param name="pk_val">the Pk value for the desired row</param>
		/// <param name="collectionsToLoad">child collections to load. ex: new ChildLoaderList&lt;apiemployeesDto&gt;() { x => x.children_apiemployeeassignments, x => x.children_apiemployeecustomfields }</param>
		/// <param name="collectionToLoadUsingStrings">list of collection properties to load for earch returned item, similar to collectionsToLoad but delivered differently</param>
		/// <param name="recursiveDepth">children collection depth to load, 0 means no recursive loading.</param>
		/// <returns>a single instance of the table object</returns>
		public override Compeat.Demo.Data.inventoryheaderDto Get(SqlConnection conn, int? pk_val, ChildLoaderList<Compeat.Demo.Data.inventoryheaderDto> collectionsToLoad = null, IEnumerable<string> collectionToLoadUsingStrings = null, int recursiveDepth = 0)
		{
			var lst = _GetList(conn, _SELECT, new TableWhereParamsAndOrder(){ WhereClause = string.Format("[{0}] = {1}", Compeat.Demo.Data.inventoryheaderDto._PK_COLUMN_NAME, Compeat.Demo.Data.inventoryheaderDto._PK_PARAMETER_NAME), OrderBy = null, ParamList = new[] { Compeat.Demo.Data.inventoryheaderDto._myPk_param_getter(pk_val) } }, 1, recursiveDepth > 0, recursiveDepth, collectionsToLoad, collectionToLoadUsingStrings);
			if (lst == null)
			{
				return null;
			}
			else { 
				return lst.FirstOrDefault();
			}			
		}   
		
		/// <summary>
		/// This will return the table object with the where clause that was passed in.
		/// </summary>
		/// <param name="conn">the open sql connection</param>
		/// <param name="whereClause">the where clause value for the desired row, the 'where' itself is not required here, it will be added</param>
		/// <param name="orderBy">the order by to pass through to sql, the 'order by' itself is not required here, it will be added </param>
		/// <param name="collectionsToLoad">child collections to load. ex: new ChildLoaderList&lt;apiemployeesDto&gt;() { x => x.children_apiemployeeassignments, x => x.children_apiemployeecustomfields }</param>
		/// <param name="collectionToLoadUsingStrings">list of collection properties to load for earch returned item, similar to collectionsToLoad but delivered differently</param>
		/// <param name="paramList">raw sql parameters  if needed </param>
		/// <param name="recursiveDepth">children collection depth to load, 0 means no recursive loading.</param>
		/// <returns>a single instance of the table object</returns>
		public override Compeat.Demo.Data.inventoryheaderDto GetFirst(SqlConnection conn, string whereClause = null, string orderBy = null, ChildLoaderList<Compeat.Demo.Data.inventoryheaderDto> collectionsToLoad = null, IEnumerable<string> collectionToLoadUsingStrings = null, SqlParameter[] paramList = null, int recursiveDepth = 0) {
			var lst = _GetList(conn, _SELECT, new TableWhereParamsAndOrder(){ WhereClause = whereClause, OrderBy = orderBy, ParamList = paramList }, 1, recursiveDepth > 0, recursiveDepth, collectionsToLoad, collectionToLoadUsingStrings);
			if (lst == null)
			{
				return null;
			}
			else { 
				return lst.FirstOrDefault();
			}			
		}
		
		/// <summary>
		/// This will return the table object list with the where clause that was passed in.
		/// </summary>
		/// <param name="conn">the open sql connection</param>
		/// <param name="whereClause">the where clause value for the desired row, the 'where' itself is not required here, it will be added</param>
		/// <param name="orderBy">the order by to pass through to sql, the 'order by' itself is not required here, it will be added </param>
		/// <param name="collectionsToLoad">child collections to load. ex: new ChildLoaderList&lt;apiemployeesDto&gt;() { x => x.children_apiemployeeassignments, x => x.children_apiemployeecustomfields }</param>
		/// <param name="collectionToLoadUsingStrings">list of collection properties to load for earch returned item, similar to collectionsToLoad but delivered differently</param>
		/// <param name="paramList">raw sql parameters  if needed </param>
		/// <param name="recursiveDepth">children collection depth to load, 0 means no recursive loading.</param>
		/// <returns>a single instance of the table object</returns>
		public override List<Compeat.Demo.Data.inventoryheaderDto> GetList(SqlConnection conn, string whereClause = null, string orderBy = null, ChildLoaderList<Compeat.Demo.Data.inventoryheaderDto> collectionsToLoad = null, IEnumerable<string> collectionToLoadUsingStrings = null, SqlParameter[] paramList = null, int recursiveDepth = 0) {
			return _GetList(conn, _SELECT, new TableWhereParamsAndOrder(){ WhereClause = whereClause, OrderBy = orderBy, ParamList = paramList }, ulong.MaxValue, recursiveDepth > 0, recursiveDepth, collectionsToLoad, collectionToLoadUsingStrings);
			
		}
		
		/// <summary>
		/// This will return the table object list with the where expression and information that was passed in.
		/// </summary>
		/// <param name="conn">the open sql connection</param>
		/// <param name="whereExpression">the lambda expression that will be used as the sql where clause, keep it simple for now. </param>
		/// <param name="orderBy">the order by to pass through to sql, the 'order by' itself is not required here, it will be added </param>
		/// <param name="additional_whereClause">THIS WILL BE 'AND'd after the whereExpression. the where clause value for the desired row, the 'where' itself is not required here, it will be added</param>
		/// <param name="collectionsToLoad">child collections to load. ex: new ChildLoaderList&lt;apiemployeesDto&gt;() { x => x.children_apiemployeeassignments, x => x.children_apiemployeecustomfields }</param>
		/// <param name="collectionToLoadUsingStrings">list of collection properties to load for earch returned item, similar to collectionsToLoad but delivered differently</param>
		/// <param name="paramList">raw sql parameters  if needed </param>
		/// <param name="recursiveDepth">children collection depth to load, 0 means no recursive loading.</param>
		/// <returns>a single instance of the table object</returns>
		public override List<Compeat.Demo.Data.inventoryheaderDto> GetList(SqlConnection conn, Expression<Func<Compeat.Demo.Data.inventoryheaderDto, bool>> whereExpression, string orderBy = null, string additional_whereClause = null, ChildLoaderList<Compeat.Demo.Data.inventoryheaderDto> collectionsToLoad = null, IEnumerable<string> collectionToLoadUsingStrings = null, SqlParameter[] paramList = null, int recursiveDepth = 0) {
			return _GetList(conn, _SELECT, InternalTools.ProcessLambda<Compeat.Demo.Data.inventoryheaderDto>("dbo.inventoryheader", whereExpression, additional_whereClause, orderBy, paramList), ulong.MaxValue, recursiveDepth > 0, recursiveDepth, collectionsToLoad, collectionToLoadUsingStrings);
		}   	
		#endregion
	
		#region Reading 
		internal const string _SELECT = "select{0} [id], [description], [description2], [upccode], [class], [shelf], [available], [invclass], [convbasenum], [convbaseuom], [convinvnum], [convinvuom], [convbaseunitsperinvunit], [level1], [level2], [level3], [recipe], [prepitem], [prepitemproduom], [prepiteminvuom], [prepiteminvunitsperprodunit], [modified], [modifiedby], [catchweight], [limitcountstoinvunit], [prepprodfactor], [prepprodlaborminutes], [recstamp], [couponvalue], [notes], [approved], [unitcostsellingprice], [royaltypercent], [modifier1], [modifier2], [modifier3], [custlevelsmodifydesc], [instructionsuri], [itemtype] from [dbo].[inventoryheader] {1} {2}; ";
		
		internal static List<Compeat.Demo.Data.inventoryheaderDto> _GetList(SqlConnection conn, string statement, TableWhereParamsAndOrder where, ulong row_count, bool loadRecursive = false, int recursiveDepth = int.MaxValue, ChildLoaderList<Compeat.Demo.Data.inventoryheaderDto> collectionsToLoad = null, IEnumerable<string> collectionToLoadUsingStrings = null) {
			var __retVal = new List<Compeat.Demo.Data.inventoryheaderDto>();
			string sql = string.Format(
										statement
										, row_count == ulong.MaxValue ? "" : string.Format(" top {0}", row_count)
										, string.IsNullOrWhiteSpace(where.WhereClause) ? "" : String.Format("where {0}", where.WhereClause)
										, string.IsNullOrWhiteSpace(where.OrderBy) ? "" : String.Format("order by {0}", where.OrderBy)
								);
								
			InternalTools.ScriptRunReader(
				SqlEnums.SqlActivityType.SELECT 
				, sql
				, conn
				, where.ParamList
				, (sdr) => {
						if (sdr.HasRows) {
							while (sdr.Read())
							{
								__retVal.Add(Compeat.Demo.Data.inventoryheaderDto.GetFromReader(sdr));
							}
						}
					}
				, Compeat.Demo.Data.inventoryheaderDto.MyTimeout());

			if(__retVal != null){
				if(collectionsToLoad != null) {
					foreach(var __itm in __retVal){
						var properties = collectionsToLoad.Select(s => s.Body.ToString().Replace(string.Format("{0}.", s.Parameters[0].Name), ""));
						__itm.LoadChildProperty(conn, properties);
					}
				} 
				if(collectionToLoadUsingStrings != null) {
					foreach(var __itm in __retVal){
						__itm.LoadChildProperty(conn, collectionToLoadUsingStrings);
					}
				} 
				if(loadRecursive) {
					foreach(var __itm in __retVal){
						__itm.LoadChildren(conn, recursiveDepth);
					}
				}
			}
			
			return __retVal;
		}
		
		#endregion Reading

	}
	
	
	#region Repository needs
	
	public partial interface IRepository {
		Compeat.Demo.Data.inventoryheader inventoryheader { get; }
	}
	
	public partial class Repository {
		internal Compeat.Demo.Data.inventoryheader _inventoryheader  = null;
		public Compeat.Demo.Data.inventoryheader inventoryheader  {
			get{
				if(_inventoryheader == null){
					_inventoryheader = new Compeat.Demo.Data.inventoryheader ();
				}
				return _inventoryheader ;
			}
		}
	}
	#endregion Repository needs

}
