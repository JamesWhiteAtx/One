﻿
//#define AllowCustomChildCollections

using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using Compeat.Data.Framework;
using Compeat.Data.Framework.InternalUtils;
using Compeat.Demo.Data.Shared;
namespace Compeat.Demo.Data {
	public partial class usersDto {

		#region Child Collections 
		#if AllowCustomChildCollections
		

		#error Replace "ExampleTableDto", "children_ExampleTable", "exampleFk", "examplePkParent"  with the names for the sub collection you are trying to represent
		
		public virtual IEnumerable<ExampleTableDto> children_ExampleTable {  get; set; }
  	  
		
		protected override System.Collections.Generic.IEnumerable<SavableMapper> ChildCollections {
			get {
 
					yield return new SavableMapper() { 
						MyPropName = "children_ExampleTable"
						, Obj = () => { return children_ExampleTable; }
						, MapPk = () => 
							{ 
								//only needed if new sub items can be created or the pk of the parent is not being passed back for some reason
								if(children_ExampleTable != null){
									foreach(var _child in children_ExampleTable){
										_child.exampleFk = this.examplePkParent;
									}
								}   						 
							}
						, MapLoadFromFk = (conn) => 
							{ 
								var pkGetter = MyPk_param_getter();
								children_ExampleTable = ExampleTable._GetList(conn, ExampleTable._SELECT,
													new TableWhereParamsAndOrder() { WhereClause = string.Format("[exampleFk] = {0}", pkGetter.ParameterName), OrderBy = null, ParamList = new[] { pkGetter } }, ulong.MaxValue); 
							}
					};  	
 
				yield break;
			}
		}   
		#endif
		#endregion Child Collections 
		/*
		
		public override void SetDefaults(){
			//this runs when a new instance of this class is made in order to setup defaults
			
		}
		*/
	}
}  
