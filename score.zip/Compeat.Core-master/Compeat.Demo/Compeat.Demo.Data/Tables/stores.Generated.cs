﻿using Compeat.Data.Framework;
using Compeat.Data.Framework.InternalUtils;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using Compeat.Demo.Data.Shared;
namespace Compeat.Demo.Data {
	[Serializable]
	public partial class storesDto : TableBase<Compeat.Demo.Data.storesDto, int?> {
		
	
	
		/// <summary>
		/// calls its private twin in cases where a static is needed
		/// </summary>
		/// <returns></returns>
		internal static int MyTimeout() {
			return (new Compeat.Demo.Data.storesDto()).GetTimeout();
		}
		
		#region Constants
		internal const int COLUMN_COUNT = 139;
		protected override int ColumnCount { get { return COLUMN_COUNT; } }
		public const int COLUMN_INDEX_storenum = 0, COLUMN_INDEX_name = 1, COLUMN_INDEX_addr1 = 2, COLUMN_INDEX_addr2 = 3, COLUMN_INDEX_city = 4, COLUMN_INDEX_state = 5, COLUMN_INDEX_zip = 6, COLUMN_INDEX_phone = 7, COLUMN_INDEX_fax = 8, COLUMN_INDEX_manager = 9, COLUMN_INDEX_squarefootage = 10, COLUMN_INDEX_seats = 11, COLUMN_INDEX_dateopened = 12, COLUMN_INDEX_datereopened = 13, COLUMN_INDEX_dateclosed = 14, COLUMN_INDEX_storegroup1 = 15, COLUMN_INDEX_storegroup2 = 16, COLUMN_INDEX_openmondays = 17, COLUMN_INDEX_opentuesdays = 18, COLUMN_INDEX_openwednesdays = 19, COLUMN_INDEX_openthursdays = 20, COLUMN_INDEX_openfridays = 21, COLUMN_INDEX_opensaturdays = 22, COLUMN_INDEX_opensundays = 23, COLUMN_INDEX_pos = 24, COLUMN_INDEX_federalidnumber = 25, COLUMN_INDEX_topmargin = 26, COLUMN_INDEX_leftmargin = 27, COLUMN_INDEX_bottommargin = 28, COLUMN_INDEX_backgroundcolor = 29, COLUMN_INDEX_lastinvoicebatchnum = 30, COLUMN_INDEX_lastinvoicevouchernum = 31, COLUMN_INDEX_lastcheckbatchnum = 32, COLUMN_INDEX_lastcheckvouchernum = 33, COLUMN_INDEX_lastgjbatchnum = 34, COLUMN_INDEX_lastgjjournalctrlno = 35, COLUMN_INDEX_lastinvbatchnum = 36, COLUMN_INDEX_lastpaybatchnum = 37, COLUMN_INDEX_lastponum = 38, COLUMN_INDEX_lastpmtbatchcode = 39, COLUMN_INDEX_lastpmtbatchpostnum = 40, COLUMN_INDEX_lastreconcilebatchnum = 41, COLUMN_INDEX_lastreconcilejournalnum = 42, COLUMN_INDEX_lastvoidccbatchnum = 43, COLUMN_INDEX_lastvoidmcbatchnum = 44, COLUMN_INDEX_lastvoidinvbatchnum = 45, COLUMN_INDEX_lasthcbatchnum = 46, COLUMN_INDEX_lastprbatchnum = 47, COLUMN_INDEX_lastmpbatchnum = 48, COLUMN_INDEX_lastgcbatchnum = 49, COLUMN_INDEX_greatplainsdbname = 50, COLUMN_INDEX_greatplainsmchekbkid = 51, COLUMN_INDEX_greatplainsmcglacctnum = 52, COLUMN_INDEX_lastpayrollbatchnum = 53, COLUMN_INDEX_lastepbatchnum = 54, COLUMN_INDEX_lastvoidepbatchnum = 55, COLUMN_INDEX_dynamicssystemdsn = 56, COLUMN_INDEX_lastprepitemcostupdate = 57, COLUMN_INDEX_externalstorenum = 58, COLUMN_INDEX_lastcommbatchnum = 59, COLUMN_INDEX_greatplainsmccurridx = 60, COLUMN_INDEX_greatplainsmccurncyid = 61, COLUMN_INDEX_lastvoidpyrbatchnum = 62, COLUMN_INDEX_lastpradjustbatchnum = 63, COLUMN_INDEX_lastistnum = 64, COLUMN_INDEX_lastwastenum = 65, COLUMN_INDEX_lastcustinvbatchnum = 66, COLUMN_INDEX_lastprepbatchnum = 67, COLUMN_INDEX_entitytype = 68, COLUMN_INDEX_commissarynum = 69, COLUMN_INDEX_allowdirecttransfers = 70, COLUMN_INDEX_lastportioncutbatchnum = 71, COLUMN_INDEX_shippingmethod = 72, COLUMN_INDEX_lastcommorderbatchnum = 73, COLUMN_INDEX_allowcommqtychange = 74, COLUMN_INDEX_lasthcinvoicenum = 75, COLUMN_INDEX_lastvoidgjbatchnum = 76, COLUMN_INDEX_allowcomminvdelete = 77, COLUMN_INDEX_lastistbatchnum = 78, COLUMN_INDEX_lastunshipcommbatchnum = 79, COLUMN_INDEX_lastunshipistbatchnum = 80, COLUMN_INDEX_usfoodvendorcode = 81, COLUMN_INDEX_lastoutsideordernum = 82, COLUMN_INDEX_lastcomminvoicenum = 83, COLUMN_INDEX_lastvoidarpaymentbatchnum = 84, COLUMN_INDEX_lastpayliabbatchnum = 85, COLUMN_INDEX_lastprepitemtreebuild = 86, COLUMN_INDEX_metafileverticaladjust = 87, COLUMN_INDEX_metafilehorizontaladjust = 88, COLUMN_INDEX_esyscovendorcode = 89, COLUMN_INDEX_allowoutsideorders = 90, COLUMN_INDEX_allowuserstomodifylineitemdescriptions = 91, COLUMN_INDEX_allowaddcustsoutorders = 92, COLUMN_INDEX_commsalestax = 93, COLUMN_INDEX_lastvoidagencyliabbatchnum = 94, COLUMN_INDEX_adpstorenum = 95, COLUMN_INDEX_recstamp = 96, COLUMN_INDEX_bekvendorcode = 97, COLUMN_INDEX_cheneybrosvendorcode = 98, COLUMN_INDEX_fsavendorcode = 99, COLUMN_INDEX_gfsvendorcode = 100, COLUMN_INDEX_pfgvendorcode = 101, COLUMN_INDEX_shamrockfoodsvendorcode = 102, COLUMN_INDEX_efoodusavendorcode = 103, COLUMN_INDEX_commprepaidsalesacct = 104, COLUMN_INDEX_agarsupplyvendorcode = 105, COLUMN_INDEX_edwarddonvendorcode = 106, COLUMN_INDEX_mbmvendorcode = 107, COLUMN_INDEX_forcedirecttransfers = 108, COLUMN_INDEX_lastecabatchnum = 109, COLUMN_INDEX_mobilelicensekey = 110, COLUMN_INDEX_lastvoidpcbatchnum = 111, COLUMN_INDEX_lastvoidwdbatchnum = 112, COLUMN_INDEX_lastvoiddsrbatchnum = 113, COLUMN_INDEX_lastbankrecloadbatchnum = 114, COLUMN_INDEX_lastvoidctbatchnum = 115, COLUMN_INDEX_lasttaxablewageadjbatchnum = 116, COLUMN_INDEX_lastdsrbatchnum = 117, COLUMN_INDEX_lastvoidpaybatchnum = 118, COLUMN_INDEX_federalidnumberencrypt = 119, COLUMN_INDEX_lastachnum = 120, COLUMN_INDEX_lastloadarbatchcode = 121, COLUMN_INDEX_consolidationentity = 122, COLUMN_INDEX_isconsolidationentity = 123, COLUMN_INDEX_currencyid = 124, COLUMN_INDEX_countryid = 125, COLUMN_INDEX_timezone = 126, COLUMN_INDEX_adjustfordst = 127, COLUMN_INDEX_backofficelicensekey = 128, COLUMN_INDEX_payrolllicensekey = 129, COLUMN_INDEX_laborlicensekey = 130, COLUMN_INDEX_advantagelicensekey = 131, COLUMN_INDEX_posmtpconfigid = 132, COLUMN_INDEX_reqsmtpconfigid = 133, COLUMN_INDEX_hotshotcomments = 134, COLUMN_INDEX_lastrequisitionnum = 135, COLUMN_INDEX_lastvoidbrbatchnum = 136, COLUMN_INDEX_timeandattendancelicensekey = 137, COLUMN_INDEX_schedulinglicensekey = 138;
		public const string COLUMN_NAME_storenum = "storenum", COLUMN_NAME_name = "name", COLUMN_NAME_addr1 = "addr1", COLUMN_NAME_addr2 = "addr2", COLUMN_NAME_city = "city", COLUMN_NAME_state = "state", COLUMN_NAME_zip = "zip", COLUMN_NAME_phone = "phone", COLUMN_NAME_fax = "fax", COLUMN_NAME_manager = "manager", COLUMN_NAME_squarefootage = "squarefootage", COLUMN_NAME_seats = "seats", COLUMN_NAME_dateopened = "dateopened", COLUMN_NAME_datereopened = "datereopened", COLUMN_NAME_dateclosed = "dateclosed", COLUMN_NAME_storegroup1 = "storegroup1", COLUMN_NAME_storegroup2 = "storegroup2", COLUMN_NAME_openmondays = "openmondays", COLUMN_NAME_opentuesdays = "opentuesdays", COLUMN_NAME_openwednesdays = "openwednesdays", COLUMN_NAME_openthursdays = "openthursdays", COLUMN_NAME_openfridays = "openfridays", COLUMN_NAME_opensaturdays = "opensaturdays", COLUMN_NAME_opensundays = "opensundays", COLUMN_NAME_pos = "pos", COLUMN_NAME_federalidnumber = "federalidnumber", COLUMN_NAME_topmargin = "topmargin", COLUMN_NAME_leftmargin = "leftmargin", COLUMN_NAME_bottommargin = "bottommargin", COLUMN_NAME_backgroundcolor = "backgroundcolor", COLUMN_NAME_lastinvoicebatchnum = "lastinvoicebatchnum", COLUMN_NAME_lastinvoicevouchernum = "lastinvoicevouchernum", COLUMN_NAME_lastcheckbatchnum = "lastcheckbatchnum", COLUMN_NAME_lastcheckvouchernum = "lastcheckvouchernum", COLUMN_NAME_lastgjbatchnum = "lastgjbatchnum", COLUMN_NAME_lastgjjournalctrlno = "lastgjjournalctrlno", COLUMN_NAME_lastinvbatchnum = "lastinvbatchnum", COLUMN_NAME_lastpaybatchnum = "lastpaybatchnum", COLUMN_NAME_lastponum = "lastponum", COLUMN_NAME_lastpmtbatchcode = "lastpmtbatchcode", COLUMN_NAME_lastpmtbatchpostnum = "lastpmtbatchpostnum", COLUMN_NAME_lastreconcilebatchnum = "lastreconcilebatchnum", COLUMN_NAME_lastreconcilejournalnum = "lastreconcilejournalnum", COLUMN_NAME_lastvoidccbatchnum = "lastvoidccbatchnum", COLUMN_NAME_lastvoidmcbatchnum = "lastvoidmcbatchnum", COLUMN_NAME_lastvoidinvbatchnum = "lastvoidinvbatchnum", COLUMN_NAME_lasthcbatchnum = "lasthcbatchnum", COLUMN_NAME_lastprbatchnum = "lastprbatchnum", COLUMN_NAME_lastmpbatchnum = "lastmpbatchnum", COLUMN_NAME_lastgcbatchnum = "lastgcbatchnum", COLUMN_NAME_greatplainsdbname = "greatplainsdbname", COLUMN_NAME_greatplainsmchekbkid = "greatplainsmchekbkid", COLUMN_NAME_greatplainsmcglacctnum = "greatplainsmcglacctnum", COLUMN_NAME_lastpayrollbatchnum = "lastpayrollbatchnum", COLUMN_NAME_lastepbatchnum = "lastepbatchnum", COLUMN_NAME_lastvoidepbatchnum = "lastvoidepbatchnum", COLUMN_NAME_dynamicssystemdsn = "dynamicssystemdsn", COLUMN_NAME_lastprepitemcostupdate = "lastprepitemcostupdate", COLUMN_NAME_externalstorenum = "externalstorenum", COLUMN_NAME_lastcommbatchnum = "lastcommbatchnum", COLUMN_NAME_greatplainsmccurridx = "greatplainsmccurridx", COLUMN_NAME_greatplainsmccurncyid = "greatplainsmccurncyid", COLUMN_NAME_lastvoidpyrbatchnum = "lastvoidpyrbatchnum", COLUMN_NAME_lastpradjustbatchnum = "lastpradjustbatchnum", COLUMN_NAME_lastistnum = "lastistnum", COLUMN_NAME_lastwastenum = "lastwastenum", COLUMN_NAME_lastcustinvbatchnum = "lastcustinvbatchnum", COLUMN_NAME_lastprepbatchnum = "lastprepbatchnum", COLUMN_NAME_entitytype = "entitytype", COLUMN_NAME_commissarynum = "commissarynum", COLUMN_NAME_allowdirecttransfers = "allowdirecttransfers", COLUMN_NAME_lastportioncutbatchnum = "lastportioncutbatchnum", COLUMN_NAME_shippingmethod = "shippingmethod", COLUMN_NAME_lastcommorderbatchnum = "lastcommorderbatchnum", COLUMN_NAME_allowcommqtychange = "allowcommqtychange", COLUMN_NAME_lasthcinvoicenum = "lasthcinvoicenum", COLUMN_NAME_lastvoidgjbatchnum = "lastvoidgjbatchnum", COLUMN_NAME_allowcomminvdelete = "allowcomminvdelete", COLUMN_NAME_lastistbatchnum = "lastistbatchnum", COLUMN_NAME_lastunshipcommbatchnum = "lastunshipcommbatchnum", COLUMN_NAME_lastunshipistbatchnum = "lastunshipistbatchnum", COLUMN_NAME_usfoodvendorcode = "usfoodvendorcode", COLUMN_NAME_lastoutsideordernum = "lastoutsideordernum", COLUMN_NAME_lastcomminvoicenum = "lastcomminvoicenum", COLUMN_NAME_lastvoidarpaymentbatchnum = "lastvoidarpaymentbatchnum", COLUMN_NAME_lastpayliabbatchnum = "lastpayliabbatchnum", COLUMN_NAME_lastprepitemtreebuild = "lastprepitemtreebuild", COLUMN_NAME_metafileverticaladjust = "metafileverticaladjust", COLUMN_NAME_metafilehorizontaladjust = "metafilehorizontaladjust", COLUMN_NAME_esyscovendorcode = "esyscovendorcode", COLUMN_NAME_allowoutsideorders = "allowoutsideorders", COLUMN_NAME_allowuserstomodifylineitemdescriptions = "allowuserstomodifylineitemdescriptions", COLUMN_NAME_allowaddcustsoutorders = "allowaddcustsoutorders", COLUMN_NAME_commsalestax = "commsalestax", COLUMN_NAME_lastvoidagencyliabbatchnum = "lastvoidagencyliabbatchnum", COLUMN_NAME_adpstorenum = "adpstorenum", COLUMN_NAME_recstamp = "recstamp", COLUMN_NAME_bekvendorcode = "bekvendorcode", COLUMN_NAME_cheneybrosvendorcode = "cheneybrosvendorcode", COLUMN_NAME_fsavendorcode = "fsavendorcode", COLUMN_NAME_gfsvendorcode = "gfsvendorcode", COLUMN_NAME_pfgvendorcode = "pfgvendorcode", COLUMN_NAME_shamrockfoodsvendorcode = "shamrockfoodsvendorcode", COLUMN_NAME_efoodusavendorcode = "efoodusavendorcode", COLUMN_NAME_commprepaidsalesacct = "commprepaidsalesacct", COLUMN_NAME_agarsupplyvendorcode = "agarsupplyvendorcode", COLUMN_NAME_edwarddonvendorcode = "edwarddonvendorcode", COLUMN_NAME_mbmvendorcode = "mbmvendorcode", COLUMN_NAME_forcedirecttransfers = "forcedirecttransfers", COLUMN_NAME_lastecabatchnum = "lastecabatchnum", COLUMN_NAME_mobilelicensekey = "mobilelicensekey", COLUMN_NAME_lastvoidpcbatchnum = "lastvoidpcbatchnum", COLUMN_NAME_lastvoidwdbatchnum = "lastvoidwdbatchnum", COLUMN_NAME_lastvoiddsrbatchnum = "lastvoiddsrbatchnum", COLUMN_NAME_lastbankrecloadbatchnum = "lastbankrecloadbatchnum", COLUMN_NAME_lastvoidctbatchnum = "lastvoidctbatchnum", COLUMN_NAME_lasttaxablewageadjbatchnum = "lasttaxablewageadjbatchnum", COLUMN_NAME_lastdsrbatchnum = "lastdsrbatchnum", COLUMN_NAME_lastvoidpaybatchnum = "lastvoidpaybatchnum", COLUMN_NAME_federalidnumberencrypt = "federalidnumberencrypt", COLUMN_NAME_lastachnum = "lastachnum", COLUMN_NAME_lastloadarbatchcode = "lastloadarbatchcode", COLUMN_NAME_consolidationentity = "consolidationentity", COLUMN_NAME_isconsolidationentity = "isconsolidationentity", COLUMN_NAME_currencyid = "currencyid", COLUMN_NAME_countryid = "countryid", COLUMN_NAME_timezone = "timezone", COLUMN_NAME_adjustfordst = "adjustfordst", COLUMN_NAME_backofficelicensekey = "backofficelicensekey", COLUMN_NAME_payrolllicensekey = "payrolllicensekey", COLUMN_NAME_laborlicensekey = "laborlicensekey", COLUMN_NAME_advantagelicensekey = "advantagelicensekey", COLUMN_NAME_posmtpconfigid = "posmtpconfigid", COLUMN_NAME_reqsmtpconfigid = "reqsmtpconfigid", COLUMN_NAME_hotshotcomments = "hotshotcomments", COLUMN_NAME_lastrequisitionnum = "lastrequisitionnum", COLUMN_NAME_lastvoidbrbatchnum = "lastvoidbrbatchnum", COLUMN_NAME_timeandattendancelicensekey = "timeandattendancelicensekey", COLUMN_NAME_schedulinglicensekey = "schedulinglicensekey";
		public const string PARAMETER_NAME_storenum = "@storenum", PARAMETER_NAME_name = "@name", PARAMETER_NAME_addr1 = "@addr1", PARAMETER_NAME_addr2 = "@addr2", PARAMETER_NAME_city = "@city", PARAMETER_NAME_state = "@state", PARAMETER_NAME_zip = "@zip", PARAMETER_NAME_phone = "@phone", PARAMETER_NAME_fax = "@fax", PARAMETER_NAME_manager = "@manager", PARAMETER_NAME_squarefootage = "@squarefootage", PARAMETER_NAME_seats = "@seats", PARAMETER_NAME_dateopened = "@dateopened", PARAMETER_NAME_datereopened = "@datereopened", PARAMETER_NAME_dateclosed = "@dateclosed", PARAMETER_NAME_storegroup1 = "@storegroup1", PARAMETER_NAME_storegroup2 = "@storegroup2", PARAMETER_NAME_openmondays = "@openmondays", PARAMETER_NAME_opentuesdays = "@opentuesdays", PARAMETER_NAME_openwednesdays = "@openwednesdays", PARAMETER_NAME_openthursdays = "@openthursdays", PARAMETER_NAME_openfridays = "@openfridays", PARAMETER_NAME_opensaturdays = "@opensaturdays", PARAMETER_NAME_opensundays = "@opensundays", PARAMETER_NAME_pos = "@pos", PARAMETER_NAME_federalidnumber = "@federalidnumber", PARAMETER_NAME_topmargin = "@topmargin", PARAMETER_NAME_leftmargin = "@leftmargin", PARAMETER_NAME_bottommargin = "@bottommargin", PARAMETER_NAME_backgroundcolor = "@backgroundcolor", PARAMETER_NAME_lastinvoicebatchnum = "@lastinvoicebatchnum", PARAMETER_NAME_lastinvoicevouchernum = "@lastinvoicevouchernum", PARAMETER_NAME_lastcheckbatchnum = "@lastcheckbatchnum", PARAMETER_NAME_lastcheckvouchernum = "@lastcheckvouchernum", PARAMETER_NAME_lastgjbatchnum = "@lastgjbatchnum", PARAMETER_NAME_lastgjjournalctrlno = "@lastgjjournalctrlno", PARAMETER_NAME_lastinvbatchnum = "@lastinvbatchnum", PARAMETER_NAME_lastpaybatchnum = "@lastpaybatchnum", PARAMETER_NAME_lastponum = "@lastponum", PARAMETER_NAME_lastpmtbatchcode = "@lastpmtbatchcode", PARAMETER_NAME_lastpmtbatchpostnum = "@lastpmtbatchpostnum", PARAMETER_NAME_lastreconcilebatchnum = "@lastreconcilebatchnum", PARAMETER_NAME_lastreconcilejournalnum = "@lastreconcilejournalnum", PARAMETER_NAME_lastvoidccbatchnum = "@lastvoidccbatchnum", PARAMETER_NAME_lastvoidmcbatchnum = "@lastvoidmcbatchnum", PARAMETER_NAME_lastvoidinvbatchnum = "@lastvoidinvbatchnum", PARAMETER_NAME_lasthcbatchnum = "@lasthcbatchnum", PARAMETER_NAME_lastprbatchnum = "@lastprbatchnum", PARAMETER_NAME_lastmpbatchnum = "@lastmpbatchnum", PARAMETER_NAME_lastgcbatchnum = "@lastgcbatchnum", PARAMETER_NAME_greatplainsdbname = "@greatplainsdbname", PARAMETER_NAME_greatplainsmchekbkid = "@greatplainsmchekbkid", PARAMETER_NAME_greatplainsmcglacctnum = "@greatplainsmcglacctnum", PARAMETER_NAME_lastpayrollbatchnum = "@lastpayrollbatchnum", PARAMETER_NAME_lastepbatchnum = "@lastepbatchnum", PARAMETER_NAME_lastvoidepbatchnum = "@lastvoidepbatchnum", PARAMETER_NAME_dynamicssystemdsn = "@dynamicssystemdsn", PARAMETER_NAME_lastprepitemcostupdate = "@lastprepitemcostupdate", PARAMETER_NAME_externalstorenum = "@externalstorenum", PARAMETER_NAME_lastcommbatchnum = "@lastcommbatchnum", PARAMETER_NAME_greatplainsmccurridx = "@greatplainsmccurridx", PARAMETER_NAME_greatplainsmccurncyid = "@greatplainsmccurncyid", PARAMETER_NAME_lastvoidpyrbatchnum = "@lastvoidpyrbatchnum", PARAMETER_NAME_lastpradjustbatchnum = "@lastpradjustbatchnum", PARAMETER_NAME_lastistnum = "@lastistnum", PARAMETER_NAME_lastwastenum = "@lastwastenum", PARAMETER_NAME_lastcustinvbatchnum = "@lastcustinvbatchnum", PARAMETER_NAME_lastprepbatchnum = "@lastprepbatchnum", PARAMETER_NAME_entitytype = "@entitytype", PARAMETER_NAME_commissarynum = "@commissarynum", PARAMETER_NAME_allowdirecttransfers = "@allowdirecttransfers", PARAMETER_NAME_lastportioncutbatchnum = "@lastportioncutbatchnum", PARAMETER_NAME_shippingmethod = "@shippingmethod", PARAMETER_NAME_lastcommorderbatchnum = "@lastcommorderbatchnum", PARAMETER_NAME_allowcommqtychange = "@allowcommqtychange", PARAMETER_NAME_lasthcinvoicenum = "@lasthcinvoicenum", PARAMETER_NAME_lastvoidgjbatchnum = "@lastvoidgjbatchnum", PARAMETER_NAME_allowcomminvdelete = "@allowcomminvdelete", PARAMETER_NAME_lastistbatchnum = "@lastistbatchnum", PARAMETER_NAME_lastunshipcommbatchnum = "@lastunshipcommbatchnum", PARAMETER_NAME_lastunshipistbatchnum = "@lastunshipistbatchnum", PARAMETER_NAME_usfoodvendorcode = "@usfoodvendorcode", PARAMETER_NAME_lastoutsideordernum = "@lastoutsideordernum", PARAMETER_NAME_lastcomminvoicenum = "@lastcomminvoicenum", PARAMETER_NAME_lastvoidarpaymentbatchnum = "@lastvoidarpaymentbatchnum", PARAMETER_NAME_lastpayliabbatchnum = "@lastpayliabbatchnum", PARAMETER_NAME_lastprepitemtreebuild = "@lastprepitemtreebuild", PARAMETER_NAME_metafileverticaladjust = "@metafileverticaladjust", PARAMETER_NAME_metafilehorizontaladjust = "@metafilehorizontaladjust", PARAMETER_NAME_esyscovendorcode = "@esyscovendorcode", PARAMETER_NAME_allowoutsideorders = "@allowoutsideorders", PARAMETER_NAME_allowuserstomodifylineitemdescriptions = "@allowuserstomodifylineitemdescriptions", PARAMETER_NAME_allowaddcustsoutorders = "@allowaddcustsoutorders", PARAMETER_NAME_commsalestax = "@commsalestax", PARAMETER_NAME_lastvoidagencyliabbatchnum = "@lastvoidagencyliabbatchnum", PARAMETER_NAME_adpstorenum = "@adpstorenum", PARAMETER_NAME_recstamp = "@recstamp", PARAMETER_NAME_bekvendorcode = "@bekvendorcode", PARAMETER_NAME_cheneybrosvendorcode = "@cheneybrosvendorcode", PARAMETER_NAME_fsavendorcode = "@fsavendorcode", PARAMETER_NAME_gfsvendorcode = "@gfsvendorcode", PARAMETER_NAME_pfgvendorcode = "@pfgvendorcode", PARAMETER_NAME_shamrockfoodsvendorcode = "@shamrockfoodsvendorcode", PARAMETER_NAME_efoodusavendorcode = "@efoodusavendorcode", PARAMETER_NAME_commprepaidsalesacct = "@commprepaidsalesacct", PARAMETER_NAME_agarsupplyvendorcode = "@agarsupplyvendorcode", PARAMETER_NAME_edwarddonvendorcode = "@edwarddonvendorcode", PARAMETER_NAME_mbmvendorcode = "@mbmvendorcode", PARAMETER_NAME_forcedirecttransfers = "@forcedirecttransfers", PARAMETER_NAME_lastecabatchnum = "@lastecabatchnum", PARAMETER_NAME_mobilelicensekey = "@mobilelicensekey", PARAMETER_NAME_lastvoidpcbatchnum = "@lastvoidpcbatchnum", PARAMETER_NAME_lastvoidwdbatchnum = "@lastvoidwdbatchnum", PARAMETER_NAME_lastvoiddsrbatchnum = "@lastvoiddsrbatchnum", PARAMETER_NAME_lastbankrecloadbatchnum = "@lastbankrecloadbatchnum", PARAMETER_NAME_lastvoidctbatchnum = "@lastvoidctbatchnum", PARAMETER_NAME_lasttaxablewageadjbatchnum = "@lasttaxablewageadjbatchnum", PARAMETER_NAME_lastdsrbatchnum = "@lastdsrbatchnum", PARAMETER_NAME_lastvoidpaybatchnum = "@lastvoidpaybatchnum", PARAMETER_NAME_federalidnumberencrypt = "@federalidnumberencrypt", PARAMETER_NAME_lastachnum = "@lastachnum", PARAMETER_NAME_lastloadarbatchcode = "@lastloadarbatchcode", PARAMETER_NAME_consolidationentity = "@consolidationentity", PARAMETER_NAME_isconsolidationentity = "@isconsolidationentity", PARAMETER_NAME_currencyid = "@currencyid", PARAMETER_NAME_countryid = "@countryid", PARAMETER_NAME_timezone = "@timezone", PARAMETER_NAME_adjustfordst = "@adjustfordst", PARAMETER_NAME_backofficelicensekey = "@backofficelicensekey", PARAMETER_NAME_payrolllicensekey = "@payrolllicensekey", PARAMETER_NAME_laborlicensekey = "@laborlicensekey", PARAMETER_NAME_advantagelicensekey = "@advantagelicensekey", PARAMETER_NAME_posmtpconfigid = "@posmtpconfigid", PARAMETER_NAME_reqsmtpconfigid = "@reqsmtpconfigid", PARAMETER_NAME_hotshotcomments = "@hotshotcomments", PARAMETER_NAME_lastrequisitionnum = "@lastrequisitionnum", PARAMETER_NAME_lastvoidbrbatchnum = "@lastvoidbrbatchnum", PARAMETER_NAME_timeandattendancelicensekey = "@timeandattendancelicensekey", PARAMETER_NAME_schedulinglicensekey = "@schedulinglicensekey";
	
		internal const string _PK_COLUMN_NAME = COLUMN_NAME_storenum;
		internal const string _PK_PARAMETER_NAME = "@PK_PARAM";
		internal const string _TIMESTAMP_COLUMN_NAME = COLUMN_NAME_recstamp;
		internal const string _TIMESTAMP_PARAMETER_NAME = PARAMETER_NAME_recstamp;
		internal const string _DELETE = "DELETE FROM [dbo].[stores] WHERE [storenum] = @PK_PARAM";
		internal const string _INSERT = "insert into [dbo].[stores] ([storenum], [name], [addr1], [addr2], [city], [state], [zip], [phone], [fax], [manager], [squarefootage], [seats], [dateopened], [datereopened], [dateclosed], [storegroup1], [storegroup2], [openmondays], [opentuesdays], [openwednesdays], [openthursdays], [openfridays], [opensaturdays], [opensundays], [pos], [federalidnumber], [topmargin], [leftmargin], [bottommargin], [backgroundcolor], [lastinvoicebatchnum], [lastinvoicevouchernum], [lastcheckbatchnum], [lastcheckvouchernum], [lastgjbatchnum], [lastgjjournalctrlno], [lastinvbatchnum], [lastpaybatchnum], [lastponum], [lastpmtbatchcode], [lastpmtbatchpostnum], [lastreconcilebatchnum], [lastreconcilejournalnum], [lastvoidccbatchnum], [lastvoidmcbatchnum], [lastvoidinvbatchnum], [lasthcbatchnum], [lastprbatchnum], [lastmpbatchnum], [lastgcbatchnum], [greatplainsdbname], [greatplainsmchekbkid], [greatplainsmcglacctnum], [lastpayrollbatchnum], [lastepbatchnum], [lastvoidepbatchnum], [dynamicssystemdsn], [lastprepitemcostupdate], [externalstorenum], [lastcommbatchnum], [greatplainsmccurridx], [greatplainsmccurncyid], [lastvoidpyrbatchnum], [lastpradjustbatchnum], [lastistnum], [lastwastenum], [lastcustinvbatchnum], [lastprepbatchnum], [entitytype], [commissarynum], [allowdirecttransfers], [lastportioncutbatchnum], [shippingmethod], [lastcommorderbatchnum], [allowcommqtychange], [lasthcinvoicenum], [lastvoidgjbatchnum], [allowcomminvdelete], [lastistbatchnum], [lastunshipcommbatchnum], [lastunshipistbatchnum], [usfoodvendorcode], [lastoutsideordernum], [lastcomminvoicenum], [lastvoidarpaymentbatchnum], [lastpayliabbatchnum], [lastprepitemtreebuild], [metafileverticaladjust], [metafilehorizontaladjust], [esyscovendorcode], [allowoutsideorders], [allowuserstomodifylineitemdescriptions], [allowaddcustsoutorders], [commsalestax], [lastvoidagencyliabbatchnum], [adpstorenum], [bekvendorcode], [cheneybrosvendorcode], [fsavendorcode], [gfsvendorcode], [pfgvendorcode], [shamrockfoodsvendorcode], [efoodusavendorcode], [commprepaidsalesacct], [agarsupplyvendorcode], [edwarddonvendorcode], [mbmvendorcode], [forcedirecttransfers], [lastecabatchnum], [mobilelicensekey], [lastvoidpcbatchnum], [lastvoidwdbatchnum], [lastvoiddsrbatchnum], [lastbankrecloadbatchnum], [lastvoidctbatchnum], [lasttaxablewageadjbatchnum], [lastdsrbatchnum], [lastvoidpaybatchnum], [federalidnumberencrypt], [lastachnum], [lastloadarbatchcode], [consolidationentity], [isconsolidationentity], [currencyid], [countryid], [timezone], [adjustfordst], [backofficelicensekey], [payrolllicensekey], [laborlicensekey], [advantagelicensekey], [posmtpconfigid], [reqsmtpconfigid], [hotshotcomments], [lastrequisitionnum], [lastvoidbrbatchnum], [timeandattendancelicensekey], [schedulinglicensekey]) values (@storenum, @name, @addr1, @addr2, @city, @state, @zip, @phone, @fax, @manager, @squarefootage, @seats, @dateopened, @datereopened, @dateclosed, @storegroup1, @storegroup2, @openmondays, @opentuesdays, @openwednesdays, @openthursdays, @openfridays, @opensaturdays, @opensundays, @pos, @federalidnumber, @topmargin, @leftmargin, @bottommargin, @backgroundcolor, @lastinvoicebatchnum, @lastinvoicevouchernum, @lastcheckbatchnum, @lastcheckvouchernum, @lastgjbatchnum, @lastgjjournalctrlno, @lastinvbatchnum, @lastpaybatchnum, @lastponum, @lastpmtbatchcode, @lastpmtbatchpostnum, @lastreconcilebatchnum, @lastreconcilejournalnum, @lastvoidccbatchnum, @lastvoidmcbatchnum, @lastvoidinvbatchnum, @lasthcbatchnum, @lastprbatchnum, @lastmpbatchnum, @lastgcbatchnum, @greatplainsdbname, @greatplainsmchekbkid, @greatplainsmcglacctnum, @lastpayrollbatchnum, @lastepbatchnum, @lastvoidepbatchnum, @dynamicssystemdsn, @lastprepitemcostupdate, @externalstorenum, @lastcommbatchnum, @greatplainsmccurridx, @greatplainsmccurncyid, @lastvoidpyrbatchnum, @lastpradjustbatchnum, @lastistnum, @lastwastenum, @lastcustinvbatchnum, @lastprepbatchnum, @entitytype, @commissarynum, @allowdirecttransfers, @lastportioncutbatchnum, @shippingmethod, @lastcommorderbatchnum, @allowcommqtychange, @lasthcinvoicenum, @lastvoidgjbatchnum, @allowcomminvdelete, @lastistbatchnum, @lastunshipcommbatchnum, @lastunshipistbatchnum, @usfoodvendorcode, @lastoutsideordernum, @lastcomminvoicenum, @lastvoidarpaymentbatchnum, @lastpayliabbatchnum, @lastprepitemtreebuild, @metafileverticaladjust, @metafilehorizontaladjust, @esyscovendorcode, @allowoutsideorders, @allowuserstomodifylineitemdescriptions, @allowaddcustsoutorders, @commsalestax, @lastvoidagencyliabbatchnum, @adpstorenum, @bekvendorcode, @cheneybrosvendorcode, @fsavendorcode, @gfsvendorcode, @pfgvendorcode, @shamrockfoodsvendorcode, @efoodusavendorcode, @commprepaidsalesacct, @agarsupplyvendorcode, @edwarddonvendorcode, @mbmvendorcode, @forcedirecttransfers, @lastecabatchnum, @mobilelicensekey, @lastvoidpcbatchnum, @lastvoidwdbatchnum, @lastvoiddsrbatchnum, @lastbankrecloadbatchnum, @lastvoidctbatchnum, @lasttaxablewageadjbatchnum, @lastdsrbatchnum, @lastvoidpaybatchnum, @federalidnumberencrypt, @lastachnum, @lastloadarbatchcode, @consolidationentity, @isconsolidationentity, @currencyid, @countryid, @timezone, @adjustfordst, @backofficelicensekey, @payrolllicensekey, @laborlicensekey, @advantagelicensekey, @posmtpconfigid, @reqsmtpconfigid, @hotshotcomments, @lastrequisitionnum, @lastvoidbrbatchnum, @timeandattendancelicensekey, @schedulinglicensekey); select top 1 [recstamp] from [dbo].[stores] where [storenum] = @PK_PARAM;";
		internal const string _UPDATE = "update [dbo].[stores] set {0} where [storenum] = @PK_PARAM and [recstamp] = @recstamp;select top 1 [recstamp] from [dbo].[stores] where [storenum] = @PK_PARAM;";
		internal const string _UPDATE_FULL = "update [dbo].[stores] set [storenum]=@storenum, [name]=@name, [addr1]=@addr1, [addr2]=@addr2, [city]=@city, [state]=@state, [zip]=@zip, [phone]=@phone, [fax]=@fax, [manager]=@manager, [squarefootage]=@squarefootage, [seats]=@seats, [dateopened]=@dateopened, [datereopened]=@datereopened, [dateclosed]=@dateclosed, [storegroup1]=@storegroup1, [storegroup2]=@storegroup2, [openmondays]=@openmondays, [opentuesdays]=@opentuesdays, [openwednesdays]=@openwednesdays, [openthursdays]=@openthursdays, [openfridays]=@openfridays, [opensaturdays]=@opensaturdays, [opensundays]=@opensundays, [pos]=@pos, [federalidnumber]=@federalidnumber, [topmargin]=@topmargin, [leftmargin]=@leftmargin, [bottommargin]=@bottommargin, [backgroundcolor]=@backgroundcolor, [lastinvoicebatchnum]=@lastinvoicebatchnum, [lastinvoicevouchernum]=@lastinvoicevouchernum, [lastcheckbatchnum]=@lastcheckbatchnum, [lastcheckvouchernum]=@lastcheckvouchernum, [lastgjbatchnum]=@lastgjbatchnum, [lastgjjournalctrlno]=@lastgjjournalctrlno, [lastinvbatchnum]=@lastinvbatchnum, [lastpaybatchnum]=@lastpaybatchnum, [lastponum]=@lastponum, [lastpmtbatchcode]=@lastpmtbatchcode, [lastpmtbatchpostnum]=@lastpmtbatchpostnum, [lastreconcilebatchnum]=@lastreconcilebatchnum, [lastreconcilejournalnum]=@lastreconcilejournalnum, [lastvoidccbatchnum]=@lastvoidccbatchnum, [lastvoidmcbatchnum]=@lastvoidmcbatchnum, [lastvoidinvbatchnum]=@lastvoidinvbatchnum, [lasthcbatchnum]=@lasthcbatchnum, [lastprbatchnum]=@lastprbatchnum, [lastmpbatchnum]=@lastmpbatchnum, [lastgcbatchnum]=@lastgcbatchnum, [greatplainsdbname]=@greatplainsdbname, [greatplainsmchekbkid]=@greatplainsmchekbkid, [greatplainsmcglacctnum]=@greatplainsmcglacctnum, [lastpayrollbatchnum]=@lastpayrollbatchnum, [lastepbatchnum]=@lastepbatchnum, [lastvoidepbatchnum]=@lastvoidepbatchnum, [dynamicssystemdsn]=@dynamicssystemdsn, [lastprepitemcostupdate]=@lastprepitemcostupdate, [externalstorenum]=@externalstorenum, [lastcommbatchnum]=@lastcommbatchnum, [greatplainsmccurridx]=@greatplainsmccurridx, [greatplainsmccurncyid]=@greatplainsmccurncyid, [lastvoidpyrbatchnum]=@lastvoidpyrbatchnum, [lastpradjustbatchnum]=@lastpradjustbatchnum, [lastistnum]=@lastistnum, [lastwastenum]=@lastwastenum, [lastcustinvbatchnum]=@lastcustinvbatchnum, [lastprepbatchnum]=@lastprepbatchnum, [entitytype]=@entitytype, [commissarynum]=@commissarynum, [allowdirecttransfers]=@allowdirecttransfers, [lastportioncutbatchnum]=@lastportioncutbatchnum, [shippingmethod]=@shippingmethod, [lastcommorderbatchnum]=@lastcommorderbatchnum, [allowcommqtychange]=@allowcommqtychange, [lasthcinvoicenum]=@lasthcinvoicenum, [lastvoidgjbatchnum]=@lastvoidgjbatchnum, [allowcomminvdelete]=@allowcomminvdelete, [lastistbatchnum]=@lastistbatchnum, [lastunshipcommbatchnum]=@lastunshipcommbatchnum, [lastunshipistbatchnum]=@lastunshipistbatchnum, [usfoodvendorcode]=@usfoodvendorcode, [lastoutsideordernum]=@lastoutsideordernum, [lastcomminvoicenum]=@lastcomminvoicenum, [lastvoidarpaymentbatchnum]=@lastvoidarpaymentbatchnum, [lastpayliabbatchnum]=@lastpayliabbatchnum, [lastprepitemtreebuild]=@lastprepitemtreebuild, [metafileverticaladjust]=@metafileverticaladjust, [metafilehorizontaladjust]=@metafilehorizontaladjust, [esyscovendorcode]=@esyscovendorcode, [allowoutsideorders]=@allowoutsideorders, [allowuserstomodifylineitemdescriptions]=@allowuserstomodifylineitemdescriptions, [allowaddcustsoutorders]=@allowaddcustsoutorders, [commsalestax]=@commsalestax, [lastvoidagencyliabbatchnum]=@lastvoidagencyliabbatchnum, [adpstorenum]=@adpstorenum, [bekvendorcode]=@bekvendorcode, [cheneybrosvendorcode]=@cheneybrosvendorcode, [fsavendorcode]=@fsavendorcode, [gfsvendorcode]=@gfsvendorcode, [pfgvendorcode]=@pfgvendorcode, [shamrockfoodsvendorcode]=@shamrockfoodsvendorcode, [efoodusavendorcode]=@efoodusavendorcode, [commprepaidsalesacct]=@commprepaidsalesacct, [agarsupplyvendorcode]=@agarsupplyvendorcode, [edwarddonvendorcode]=@edwarddonvendorcode, [mbmvendorcode]=@mbmvendorcode, [forcedirecttransfers]=@forcedirecttransfers, [lastecabatchnum]=@lastecabatchnum, [mobilelicensekey]=@mobilelicensekey, [lastvoidpcbatchnum]=@lastvoidpcbatchnum, [lastvoidwdbatchnum]=@lastvoidwdbatchnum, [lastvoiddsrbatchnum]=@lastvoiddsrbatchnum, [lastbankrecloadbatchnum]=@lastbankrecloadbatchnum, [lastvoidctbatchnum]=@lastvoidctbatchnum, [lasttaxablewageadjbatchnum]=@lasttaxablewageadjbatchnum, [lastdsrbatchnum]=@lastdsrbatchnum, [lastvoidpaybatchnum]=@lastvoidpaybatchnum, [federalidnumberencrypt]=@federalidnumberencrypt, [lastachnum]=@lastachnum, [lastloadarbatchcode]=@lastloadarbatchcode, [consolidationentity]=@consolidationentity, [isconsolidationentity]=@isconsolidationentity, [currencyid]=@currencyid, [countryid]=@countryid, [timezone]=@timezone, [adjustfordst]=@adjustfordst, [backofficelicensekey]=@backofficelicensekey, [payrolllicensekey]=@payrolllicensekey, [laborlicensekey]=@laborlicensekey, [advantagelicensekey]=@advantagelicensekey, [posmtpconfigid]=@posmtpconfigid, [reqsmtpconfigid]=@reqsmtpconfigid, [hotshotcomments]=@hotshotcomments, [lastrequisitionnum]=@lastrequisitionnum, [lastvoidbrbatchnum]=@lastvoidbrbatchnum, [timeandattendancelicensekey]=@timeandattendancelicensekey, [schedulinglicensekey]=@schedulinglicensekey where [storenum] = @PK_PARAM and [recstamp] = @recstamp;select top 1 [recstamp] from [dbo].[stores] where [storenum] = @PK_PARAM;";
		#endregion
		
		/// <summary>
		/// Will Update, not skinny safe, meaning if an update is done, it will update all columns
		/// </summary>
		public storesDto() : this(true) {
			//not skinny safe
		}
			
		/// <summary>
		/// Will Insert
		/// </summary>
		public static Compeat.Demo.Data.storesDto create() {
			var newInstance = new Compeat.Demo.Data.storesDto();
			newInstance.CmpNew = true;
			return newInstance;
		}    
		/// <summary>
		/// skinny safe: meaning if an update is done, it will only update the fields that had their setters called.
		/// </summary>
		public storesDto(int my_pk, string my_timestamp) : base(){
			//skinny safe
			IsSkinnySafe = true;
			MyPk = my_pk;
			MyTimeStamp = my_timestamp;
		}

		internal storesDto(bool allow_default_set) : base() {
			//not skinny safe
			if(allow_default_set) {
				#region Gen'd DB defaults
				this.openmondays=true;
				this.opentuesdays=true;
				this.openwednesdays=true;
				this.openthursdays=true;
				this.openfridays=true;
				this.opensaturdays=true;
				this.opensundays=true;
				this.entitytype=1;
				this.allowdirecttransfers=false;
				this.shippingmethod=0;
				this.allowcommqtychange=true;
				this.allowcomminvdelete=true;
				this.allowoutsideorders=false;
				this.allowuserstomodifylineitemdescriptions=false;
				this.allowaddcustsoutorders=false;
				this.forcedirecttransfers=false;
				this.isconsolidationentity=false;
				this.adjustfordst=true;
				#endregion
	 
				SetDefaults();
			}
		}
   
		#region Loaders 		
		internal static Compeat.Demo.Data.storesDto GetFromReader(SqlDataReader dr) {
			var x = new Compeat.Demo.Data.storesDto(false);

			x._myPk = dr.GetInt32(COLUMN_INDEX_storenum);
			x._storenum = dr.GetInt32(COLUMN_INDEX_storenum);
			x._name = (dr.IsDBNull(COLUMN_INDEX_name) ? null : dr.GetString(COLUMN_INDEX_name));
			x._addr1 = (dr.IsDBNull(COLUMN_INDEX_addr1) ? null : dr.GetString(COLUMN_INDEX_addr1));
			x._addr2 = (dr.IsDBNull(COLUMN_INDEX_addr2) ? null : dr.GetString(COLUMN_INDEX_addr2));
			x._city = (dr.IsDBNull(COLUMN_INDEX_city) ? null : dr.GetString(COLUMN_INDEX_city));
			x._state = (dr.IsDBNull(COLUMN_INDEX_state) ? null : dr.GetString(COLUMN_INDEX_state));
			x._zip = (dr.IsDBNull(COLUMN_INDEX_zip) ? null : dr.GetString(COLUMN_INDEX_zip));
			x._phone = (dr.IsDBNull(COLUMN_INDEX_phone) ? null : dr.GetString(COLUMN_INDEX_phone));
			x._fax = (dr.IsDBNull(COLUMN_INDEX_fax) ? null : dr.GetString(COLUMN_INDEX_fax));
			x._manager = (dr.IsDBNull(COLUMN_INDEX_manager) ? null : dr.GetString(COLUMN_INDEX_manager));
			x._squarefootage = (dr.IsDBNull(COLUMN_INDEX_squarefootage) ? (int?)null : dr.GetInt32(COLUMN_INDEX_squarefootage));
			x._seats = (dr.IsDBNull(COLUMN_INDEX_seats) ? (int?)null : dr.GetInt32(COLUMN_INDEX_seats));
			x._dateopened = (dr.IsDBNull(COLUMN_INDEX_dateopened) ? (DateTime?)null : dr.GetDateTime(COLUMN_INDEX_dateopened));
			x._datereopened = (dr.IsDBNull(COLUMN_INDEX_datereopened) ? (DateTime?)null : dr.GetDateTime(COLUMN_INDEX_datereopened));
			x._dateclosed = (dr.IsDBNull(COLUMN_INDEX_dateclosed) ? (DateTime?)null : dr.GetDateTime(COLUMN_INDEX_dateclosed));
			x._storegroup1 = (dr.IsDBNull(COLUMN_INDEX_storegroup1) ? (int?)null : dr.GetInt32(COLUMN_INDEX_storegroup1));
			x._storegroup2 = (dr.IsDBNull(COLUMN_INDEX_storegroup2) ? (int?)null : dr.GetInt32(COLUMN_INDEX_storegroup2));
			x._openmondays = dr.GetBoolean(COLUMN_INDEX_openmondays);
			x._opentuesdays = dr.GetBoolean(COLUMN_INDEX_opentuesdays);
			x._openwednesdays = dr.GetBoolean(COLUMN_INDEX_openwednesdays);
			x._openthursdays = dr.GetBoolean(COLUMN_INDEX_openthursdays);
			x._openfridays = dr.GetBoolean(COLUMN_INDEX_openfridays);
			x._opensaturdays = dr.GetBoolean(COLUMN_INDEX_opensaturdays);
			x._opensundays = dr.GetBoolean(COLUMN_INDEX_opensundays);
			x._pos = (dr.IsDBNull(COLUMN_INDEX_pos) ? (int?)null : dr.GetInt32(COLUMN_INDEX_pos));
			x._federalidnumber = (dr.IsDBNull(COLUMN_INDEX_federalidnumber) ? null : dr.GetString(COLUMN_INDEX_federalidnumber));
			x._topmargin = (dr.IsDBNull(COLUMN_INDEX_topmargin) ? (double?)null : dr.GetDouble(COLUMN_INDEX_topmargin));
			x._leftmargin = (dr.IsDBNull(COLUMN_INDEX_leftmargin) ? (double?)null : dr.GetDouble(COLUMN_INDEX_leftmargin));
			x._bottommargin = (dr.IsDBNull(COLUMN_INDEX_bottommargin) ? (double?)null : dr.GetDouble(COLUMN_INDEX_bottommargin));
			x._backgroundcolor = (dr.IsDBNull(COLUMN_INDEX_backgroundcolor) ? (int?)null : dr.GetInt32(COLUMN_INDEX_backgroundcolor));
			x._lastinvoicebatchnum = (dr.IsDBNull(COLUMN_INDEX_lastinvoicebatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastinvoicebatchnum));
			x._lastinvoicevouchernum = (dr.IsDBNull(COLUMN_INDEX_lastinvoicevouchernum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastinvoicevouchernum));
			x._lastcheckbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastcheckbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastcheckbatchnum));
			x._lastcheckvouchernum = (dr.IsDBNull(COLUMN_INDEX_lastcheckvouchernum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastcheckvouchernum));
			x._lastgjbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastgjbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastgjbatchnum));
			x._lastgjjournalctrlno = (dr.IsDBNull(COLUMN_INDEX_lastgjjournalctrlno) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastgjjournalctrlno));
			x._lastinvbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastinvbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastinvbatchnum));
			x._lastpaybatchnum = (dr.IsDBNull(COLUMN_INDEX_lastpaybatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastpaybatchnum));
			x._lastponum = (dr.IsDBNull(COLUMN_INDEX_lastponum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastponum));
			x._lastpmtbatchcode = (dr.IsDBNull(COLUMN_INDEX_lastpmtbatchcode) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastpmtbatchcode));
			x._lastpmtbatchpostnum = (dr.IsDBNull(COLUMN_INDEX_lastpmtbatchpostnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastpmtbatchpostnum));
			x._lastreconcilebatchnum = (dr.IsDBNull(COLUMN_INDEX_lastreconcilebatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastreconcilebatchnum));
			x._lastreconcilejournalnum = (dr.IsDBNull(COLUMN_INDEX_lastreconcilejournalnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastreconcilejournalnum));
			x._lastvoidccbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastvoidccbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastvoidccbatchnum));
			x._lastvoidmcbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastvoidmcbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastvoidmcbatchnum));
			x._lastvoidinvbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastvoidinvbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastvoidinvbatchnum));
			x._lasthcbatchnum = (dr.IsDBNull(COLUMN_INDEX_lasthcbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lasthcbatchnum));
			x._lastprbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastprbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastprbatchnum));
			x._lastmpbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastmpbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastmpbatchnum));
			x._lastgcbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastgcbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastgcbatchnum));
			x._greatplainsdbname = (dr.IsDBNull(COLUMN_INDEX_greatplainsdbname) ? null : dr.GetString(COLUMN_INDEX_greatplainsdbname));
			x._greatplainsmchekbkid = (dr.IsDBNull(COLUMN_INDEX_greatplainsmchekbkid) ? null : dr.GetString(COLUMN_INDEX_greatplainsmchekbkid));
			x._greatplainsmcglacctnum = (dr.IsDBNull(COLUMN_INDEX_greatplainsmcglacctnum) ? null : dr.GetString(COLUMN_INDEX_greatplainsmcglacctnum));
			x._lastpayrollbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastpayrollbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastpayrollbatchnum));
			x._lastepbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastepbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastepbatchnum));
			x._lastvoidepbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastvoidepbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastvoidepbatchnum));
			x._dynamicssystemdsn = (dr.IsDBNull(COLUMN_INDEX_dynamicssystemdsn) ? null : dr.GetString(COLUMN_INDEX_dynamicssystemdsn));
			x._lastprepitemcostupdate = (dr.IsDBNull(COLUMN_INDEX_lastprepitemcostupdate) ? (DateTime?)null : dr.GetDateTime(COLUMN_INDEX_lastprepitemcostupdate));
			x._externalstorenum = (dr.IsDBNull(COLUMN_INDEX_externalstorenum) ? null : dr.GetString(COLUMN_INDEX_externalstorenum));
			x._lastcommbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastcommbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastcommbatchnum));
			x._greatplainsmccurridx = (dr.IsDBNull(COLUMN_INDEX_greatplainsmccurridx) ? (short?)null : dr.GetInt16(COLUMN_INDEX_greatplainsmccurridx));
			x._greatplainsmccurncyid = (dr.IsDBNull(COLUMN_INDEX_greatplainsmccurncyid) ? null : dr.GetString(COLUMN_INDEX_greatplainsmccurncyid));
			x._lastvoidpyrbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastvoidpyrbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastvoidpyrbatchnum));
			x._lastpradjustbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastpradjustbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastpradjustbatchnum));
			x._lastistnum = (dr.IsDBNull(COLUMN_INDEX_lastistnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastistnum));
			x._lastwastenum = (dr.IsDBNull(COLUMN_INDEX_lastwastenum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastwastenum));
			x._lastcustinvbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastcustinvbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastcustinvbatchnum));
			x._lastprepbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastprepbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastprepbatchnum));
			x._entitytype = dr.GetByte(COLUMN_INDEX_entitytype);
			x._commissarynum = (dr.IsDBNull(COLUMN_INDEX_commissarynum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_commissarynum));
			x._allowdirecttransfers = dr.GetBoolean(COLUMN_INDEX_allowdirecttransfers);
			x._lastportioncutbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastportioncutbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastportioncutbatchnum));
			x._shippingmethod = dr.GetByte(COLUMN_INDEX_shippingmethod);
			x._lastcommorderbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastcommorderbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastcommorderbatchnum));
			x._allowcommqtychange = dr.GetBoolean(COLUMN_INDEX_allowcommqtychange);
			x._lasthcinvoicenum = (dr.IsDBNull(COLUMN_INDEX_lasthcinvoicenum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lasthcinvoicenum));
			x._lastvoidgjbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastvoidgjbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastvoidgjbatchnum));
			x._allowcomminvdelete = dr.GetBoolean(COLUMN_INDEX_allowcomminvdelete);
			x._lastistbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastistbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastistbatchnum));
			x._lastunshipcommbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastunshipcommbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastunshipcommbatchnum));
			x._lastunshipistbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastunshipistbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastunshipistbatchnum));
			x._usfoodvendorcode = (dr.IsDBNull(COLUMN_INDEX_usfoodvendorcode) ? null : dr.GetString(COLUMN_INDEX_usfoodvendorcode));
			x._lastoutsideordernum = (dr.IsDBNull(COLUMN_INDEX_lastoutsideordernum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastoutsideordernum));
			x._lastcomminvoicenum = (dr.IsDBNull(COLUMN_INDEX_lastcomminvoicenum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastcomminvoicenum));
			x._lastvoidarpaymentbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastvoidarpaymentbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastvoidarpaymentbatchnum));
			x._lastpayliabbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastpayliabbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastpayliabbatchnum));
			x._lastprepitemtreebuild = (dr.IsDBNull(COLUMN_INDEX_lastprepitemtreebuild) ? (DateTime?)null : dr.GetDateTime(COLUMN_INDEX_lastprepitemtreebuild));
			x._metafileverticaladjust = (dr.IsDBNull(COLUMN_INDEX_metafileverticaladjust) ? (decimal?)null : dr.GetDecimal(COLUMN_INDEX_metafileverticaladjust));
			x._metafilehorizontaladjust = (dr.IsDBNull(COLUMN_INDEX_metafilehorizontaladjust) ? (decimal?)null : dr.GetDecimal(COLUMN_INDEX_metafilehorizontaladjust));
			x._esyscovendorcode = (dr.IsDBNull(COLUMN_INDEX_esyscovendorcode) ? null : dr.GetString(COLUMN_INDEX_esyscovendorcode));
			x._allowoutsideorders = dr.GetBoolean(COLUMN_INDEX_allowoutsideorders);
			x._allowuserstomodifylineitemdescriptions = dr.GetBoolean(COLUMN_INDEX_allowuserstomodifylineitemdescriptions);
			x._allowaddcustsoutorders = dr.GetBoolean(COLUMN_INDEX_allowaddcustsoutorders);
			x._commsalestax = (dr.IsDBNull(COLUMN_INDEX_commsalestax) ? (int?)null : dr.GetInt32(COLUMN_INDEX_commsalestax));
			x._lastvoidagencyliabbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastvoidagencyliabbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastvoidagencyliabbatchnum));
			x._adpstorenum = (dr.IsDBNull(COLUMN_INDEX_adpstorenum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_adpstorenum));
			x._recstamp = (byte[])dr.GetValue(COLUMN_INDEX_recstamp);
			x._bekvendorcode = (dr.IsDBNull(COLUMN_INDEX_bekvendorcode) ? null : dr.GetString(COLUMN_INDEX_bekvendorcode));
			x._cheneybrosvendorcode = (dr.IsDBNull(COLUMN_INDEX_cheneybrosvendorcode) ? null : dr.GetString(COLUMN_INDEX_cheneybrosvendorcode));
			x._fsavendorcode = (dr.IsDBNull(COLUMN_INDEX_fsavendorcode) ? null : dr.GetString(COLUMN_INDEX_fsavendorcode));
			x._gfsvendorcode = (dr.IsDBNull(COLUMN_INDEX_gfsvendorcode) ? null : dr.GetString(COLUMN_INDEX_gfsvendorcode));
			x._pfgvendorcode = (dr.IsDBNull(COLUMN_INDEX_pfgvendorcode) ? null : dr.GetString(COLUMN_INDEX_pfgvendorcode));
			x._shamrockfoodsvendorcode = (dr.IsDBNull(COLUMN_INDEX_shamrockfoodsvendorcode) ? null : dr.GetString(COLUMN_INDEX_shamrockfoodsvendorcode));
			x._efoodusavendorcode = (dr.IsDBNull(COLUMN_INDEX_efoodusavendorcode) ? null : dr.GetString(COLUMN_INDEX_efoodusavendorcode));
			x._commprepaidsalesacct = (dr.IsDBNull(COLUMN_INDEX_commprepaidsalesacct) ? null : dr.GetString(COLUMN_INDEX_commprepaidsalesacct));
			x._agarsupplyvendorcode = (dr.IsDBNull(COLUMN_INDEX_agarsupplyvendorcode) ? null : dr.GetString(COLUMN_INDEX_agarsupplyvendorcode));
			x._edwarddonvendorcode = (dr.IsDBNull(COLUMN_INDEX_edwarddonvendorcode) ? null : dr.GetString(COLUMN_INDEX_edwarddonvendorcode));
			x._mbmvendorcode = (dr.IsDBNull(COLUMN_INDEX_mbmvendorcode) ? null : dr.GetString(COLUMN_INDEX_mbmvendorcode));
			x._forcedirecttransfers = dr.GetBoolean(COLUMN_INDEX_forcedirecttransfers);
			x._lastecabatchnum = (dr.IsDBNull(COLUMN_INDEX_lastecabatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastecabatchnum));
			x._mobilelicensekey = (dr.IsDBNull(COLUMN_INDEX_mobilelicensekey) ? null : dr.GetString(COLUMN_INDEX_mobilelicensekey));
			x._lastvoidpcbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastvoidpcbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastvoidpcbatchnum));
			x._lastvoidwdbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastvoidwdbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastvoidwdbatchnum));
			x._lastvoiddsrbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastvoiddsrbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastvoiddsrbatchnum));
			x._lastbankrecloadbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastbankrecloadbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastbankrecloadbatchnum));
			x._lastvoidctbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastvoidctbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastvoidctbatchnum));
			x._lasttaxablewageadjbatchnum = (dr.IsDBNull(COLUMN_INDEX_lasttaxablewageadjbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lasttaxablewageadjbatchnum));
			x._lastdsrbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastdsrbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastdsrbatchnum));
			x._lastvoidpaybatchnum = (dr.IsDBNull(COLUMN_INDEX_lastvoidpaybatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastvoidpaybatchnum));
			x._federalidnumberencrypt = (dr.IsDBNull(COLUMN_INDEX_federalidnumberencrypt) ? null : dr.GetString(COLUMN_INDEX_federalidnumberencrypt));
			x._lastachnum = (dr.IsDBNull(COLUMN_INDEX_lastachnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastachnum));
			x._lastloadarbatchcode = (dr.IsDBNull(COLUMN_INDEX_lastloadarbatchcode) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastloadarbatchcode));
			x._consolidationentity = (dr.IsDBNull(COLUMN_INDEX_consolidationentity) ? (int?)null : dr.GetInt32(COLUMN_INDEX_consolidationentity));
			x._isconsolidationentity = dr.GetBoolean(COLUMN_INDEX_isconsolidationentity);
			x._currencyid = (dr.IsDBNull(COLUMN_INDEX_currencyid) ? (int?)null : dr.GetInt32(COLUMN_INDEX_currencyid));
			x._countryid = (dr.IsDBNull(COLUMN_INDEX_countryid) ? (int?)null : dr.GetInt32(COLUMN_INDEX_countryid));
			x._timezone = (dr.IsDBNull(COLUMN_INDEX_timezone) ? null : dr.GetString(COLUMN_INDEX_timezone));
			x._adjustfordst = dr.GetBoolean(COLUMN_INDEX_adjustfordst);
			x._backofficelicensekey = (dr.IsDBNull(COLUMN_INDEX_backofficelicensekey) ? null : dr.GetString(COLUMN_INDEX_backofficelicensekey));
			x._payrolllicensekey = (dr.IsDBNull(COLUMN_INDEX_payrolllicensekey) ? null : dr.GetString(COLUMN_INDEX_payrolllicensekey));
			x._laborlicensekey = (dr.IsDBNull(COLUMN_INDEX_laborlicensekey) ? null : dr.GetString(COLUMN_INDEX_laborlicensekey));
			x._advantagelicensekey = (dr.IsDBNull(COLUMN_INDEX_advantagelicensekey) ? null : dr.GetString(COLUMN_INDEX_advantagelicensekey));
			x._posmtpconfigid = (dr.IsDBNull(COLUMN_INDEX_posmtpconfigid) ? (int?)null : dr.GetInt32(COLUMN_INDEX_posmtpconfigid));
			x._reqsmtpconfigid = (dr.IsDBNull(COLUMN_INDEX_reqsmtpconfigid) ? (int?)null : dr.GetInt32(COLUMN_INDEX_reqsmtpconfigid));
			x._hotshotcomments = (dr.IsDBNull(COLUMN_INDEX_hotshotcomments) ? null : dr.GetString(COLUMN_INDEX_hotshotcomments));
			x._lastrequisitionnum = (dr.IsDBNull(COLUMN_INDEX_lastrequisitionnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastrequisitionnum));
			x._lastvoidbrbatchnum = (dr.IsDBNull(COLUMN_INDEX_lastvoidbrbatchnum) ? (int?)null : dr.GetInt32(COLUMN_INDEX_lastvoidbrbatchnum));
			x._timeandattendancelicensekey = (dr.IsDBNull(COLUMN_INDEX_timeandattendancelicensekey) ? null : dr.GetString(COLUMN_INDEX_timeandattendancelicensekey));
			x._schedulinglicensekey = (dr.IsDBNull(COLUMN_INDEX_schedulinglicensekey) ? null : dr.GetString(COLUMN_INDEX_schedulinglicensekey));
			//skinny safe since loaded from reader
			x.IsSkinnySafe = true;
			return x;
		}   
		
		internal void LoadChildProperty(SqlConnection conn, IEnumerable<string> collectionsToLoad)
		{
			ChildLoaderList<Compeat.Demo.Data.storesDto>.LoadProperty(conn, collectionsToLoad, AllChildCollections);
		}  
		
		#endregion Loaders   
		
		#region Writing
		
		
		protected override void Insert(SqlConnection conn) {
			SqlParameter[] parm_list = 
				new SqlParameter[] { 
				 MyPk_param_getter()
						
					, _storenum_param_getter()
					, _name_param_getter()
					, _addr1_param_getter()
					, _addr2_param_getter()
					, _city_param_getter()
					, _state_param_getter()
					, _zip_param_getter()
					, _phone_param_getter()
					, _fax_param_getter()
					, _manager_param_getter()
					, _squarefootage_param_getter()
					, _seats_param_getter()
					, _dateopened_param_getter()
					, _datereopened_param_getter()
					, _dateclosed_param_getter()
					, _storegroup1_param_getter()
					, _storegroup2_param_getter()
					, _openmondays_param_getter()
					, _opentuesdays_param_getter()
					, _openwednesdays_param_getter()
					, _openthursdays_param_getter()
					, _openfridays_param_getter()
					, _opensaturdays_param_getter()
					, _opensundays_param_getter()
					, _pos_param_getter()
					, _federalidnumber_param_getter()
					, _topmargin_param_getter()
					, _leftmargin_param_getter()
					, _bottommargin_param_getter()
					, _backgroundcolor_param_getter()
					, _lastinvoicebatchnum_param_getter()
					, _lastinvoicevouchernum_param_getter()
					, _lastcheckbatchnum_param_getter()
					, _lastcheckvouchernum_param_getter()
					, _lastgjbatchnum_param_getter()
					, _lastgjjournalctrlno_param_getter()
					, _lastinvbatchnum_param_getter()
					, _lastpaybatchnum_param_getter()
					, _lastponum_param_getter()
					, _lastpmtbatchcode_param_getter()
					, _lastpmtbatchpostnum_param_getter()
					, _lastreconcilebatchnum_param_getter()
					, _lastreconcilejournalnum_param_getter()
					, _lastvoidccbatchnum_param_getter()
					, _lastvoidmcbatchnum_param_getter()
					, _lastvoidinvbatchnum_param_getter()
					, _lasthcbatchnum_param_getter()
					, _lastprbatchnum_param_getter()
					, _lastmpbatchnum_param_getter()
					, _lastgcbatchnum_param_getter()
					, _greatplainsdbname_param_getter()
					, _greatplainsmchekbkid_param_getter()
					, _greatplainsmcglacctnum_param_getter()
					, _lastpayrollbatchnum_param_getter()
					, _lastepbatchnum_param_getter()
					, _lastvoidepbatchnum_param_getter()
					, _dynamicssystemdsn_param_getter()
					, _lastprepitemcostupdate_param_getter()
					, _externalstorenum_param_getter()
					, _lastcommbatchnum_param_getter()
					, _greatplainsmccurridx_param_getter()
					, _greatplainsmccurncyid_param_getter()
					, _lastvoidpyrbatchnum_param_getter()
					, _lastpradjustbatchnum_param_getter()
					, _lastistnum_param_getter()
					, _lastwastenum_param_getter()
					, _lastcustinvbatchnum_param_getter()
					, _lastprepbatchnum_param_getter()
					, _entitytype_param_getter()
					, _commissarynum_param_getter()
					, _allowdirecttransfers_param_getter()
					, _lastportioncutbatchnum_param_getter()
					, _shippingmethod_param_getter()
					, _lastcommorderbatchnum_param_getter()
					, _allowcommqtychange_param_getter()
					, _lasthcinvoicenum_param_getter()
					, _lastvoidgjbatchnum_param_getter()
					, _allowcomminvdelete_param_getter()
					, _lastistbatchnum_param_getter()
					, _lastunshipcommbatchnum_param_getter()
					, _lastunshipistbatchnum_param_getter()
					, _usfoodvendorcode_param_getter()
					, _lastoutsideordernum_param_getter()
					, _lastcomminvoicenum_param_getter()
					, _lastvoidarpaymentbatchnum_param_getter()
					, _lastpayliabbatchnum_param_getter()
					, _lastprepitemtreebuild_param_getter()
					, _metafileverticaladjust_param_getter()
					, _metafilehorizontaladjust_param_getter()
					, _esyscovendorcode_param_getter()
					, _allowoutsideorders_param_getter()
					, _allowuserstomodifylineitemdescriptions_param_getter()
					, _allowaddcustsoutorders_param_getter()
					, _commsalestax_param_getter()
					, _lastvoidagencyliabbatchnum_param_getter()
					, _adpstorenum_param_getter()
					, _bekvendorcode_param_getter()
					, _cheneybrosvendorcode_param_getter()
					, _fsavendorcode_param_getter()
					, _gfsvendorcode_param_getter()
					, _pfgvendorcode_param_getter()
					, _shamrockfoodsvendorcode_param_getter()
					, _efoodusavendorcode_param_getter()
					, _commprepaidsalesacct_param_getter()
					, _agarsupplyvendorcode_param_getter()
					, _edwarddonvendorcode_param_getter()
					, _mbmvendorcode_param_getter()
					, _forcedirecttransfers_param_getter()
					, _lastecabatchnum_param_getter()
					, _mobilelicensekey_param_getter()
					, _lastvoidpcbatchnum_param_getter()
					, _lastvoidwdbatchnum_param_getter()
					, _lastvoiddsrbatchnum_param_getter()
					, _lastbankrecloadbatchnum_param_getter()
					, _lastvoidctbatchnum_param_getter()
					, _lasttaxablewageadjbatchnum_param_getter()
					, _lastdsrbatchnum_param_getter()
					, _lastvoidpaybatchnum_param_getter()
					, _federalidnumberencrypt_param_getter()
					, _lastachnum_param_getter()
					, _lastloadarbatchcode_param_getter()
					, _consolidationentity_param_getter()
					, _isconsolidationentity_param_getter()
					, _currencyid_param_getter()
					, _countryid_param_getter()
					, _timezone_param_getter()
					, _adjustfordst_param_getter()
					, _backofficelicensekey_param_getter()
					, _payrolllicensekey_param_getter()
					, _laborlicensekey_param_getter()
					, _advantagelicensekey_param_getter()
					, _posmtpconfigid_param_getter()
					, _reqsmtpconfigid_param_getter()
					, _hotshotcomments_param_getter()
					, _lastrequisitionnum_param_getter()
					, _lastvoidbrbatchnum_param_getter()
					, _timeandattendancelicensekey_param_getter()
					, _schedulinglicensekey_param_getter()
				};
				
			InternalTools.ScriptRunReader(SqlEnums.SqlActivityType.INSERT, _INSERT, conn, parm_list
				, (sdr) => {	   
						if (!sdr.HasRows || !sdr.Read()) {
							throw new DbUpdateFailedNoChangesMade("Insert into stores, but now new rows were detected using PK or identity fields.", conn, null);
						}else{
							_recstamp = (byte[])sdr.GetValue(0);//refresh the timestamp
						}
					}
				, GetTimeout());
		
		}  
		
		protected override void Update(SqlConnection conn) {
			if(IsSkinnySafe && UpdatedProperties.Count() == 0) {
				throw new DbUpdateFailedNoChangesMade("Update to stores, but no values have changed. Verify InSavableState before calling.", conn, null);
			}
			if(MyPk == null) {
				throw new DbUpdateFailedPkMissing(_UPDATE, conn, null);
			}
			if(MyTimeStamp == null) {
				throw new DbUpdateFailedTimestampMissing(_UPDATE, conn, null);
			}
			
			  
			if(IsSkinnySafe) {
				AddChangedProperty(true, false, false, _PK_COLUMN_NAME, _PK_PARAMETER_NAME, this.MyPk_param_getter);    

				AddChangedProperty(false, false, true, _TIMESTAMP_COLUMN_NAME, _TIMESTAMP_PARAMETER_NAME, this.MyTimeStamp_param_getter);

				if(!UpdatedProperties.Any(s => !s.IsPrimaryKey && !s.IsIdentity && !s.IsTimestamp)) {
					return; //nothing changed
				}
				var parm_list = UpdatedProperties
									.Where(s => !s.IsIdentity && s.ParameterName != _PK_PARAMETER_NAME && !s.IsTimestamp && s.ParameterName != _TIMESTAMP_PARAMETER_NAME)
									.Select(s => s.MyParamGetter())
									.ToList();  
				parm_list.Add(MyPk_param_getter());
				string formatted_update = string.Format(_UPDATE, string.Join(",", UpdatedProperties.Where(s => !s.IsIdentity && !s.IsTimestamp).Select(s => s.UpdateCombo) ) );
				InternalTools.ScriptRunReader(SqlEnums.SqlActivityType.UPDATE, formatted_update, conn, parm_list.ToArray()
					, (sdr) => {	 
						if (!sdr.HasRows || !sdr.Read()) {
							throw new DbUpdateFailedNoChangesMade("Insert into stores, but now new rows were detected using PK or identity fields.", conn, null);
						}else{
							_recstamp = (byte[])sdr.GetValue(0);//refresh the timestamp
						}
					}
				, GetTimeout());
			}
			else {
				SqlParameter[] parm_list = 
					new SqlParameter[] { 
						MyPk_param_getter()
						, MyTimeStamp_param_getter()
						, _storenum_param_getter()
						, _name_param_getter()
						, _addr1_param_getter()
						, _addr2_param_getter()
						, _city_param_getter()
						, _state_param_getter()
						, _zip_param_getter()
						, _phone_param_getter()
						, _fax_param_getter()
						, _manager_param_getter()
						, _squarefootage_param_getter()
						, _seats_param_getter()
						, _dateopened_param_getter()
						, _datereopened_param_getter()
						, _dateclosed_param_getter()
						, _storegroup1_param_getter()
						, _storegroup2_param_getter()
						, _openmondays_param_getter()
						, _opentuesdays_param_getter()
						, _openwednesdays_param_getter()
						, _openthursdays_param_getter()
						, _openfridays_param_getter()
						, _opensaturdays_param_getter()
						, _opensundays_param_getter()
						, _pos_param_getter()
						, _federalidnumber_param_getter()
						, _topmargin_param_getter()
						, _leftmargin_param_getter()
						, _bottommargin_param_getter()
						, _backgroundcolor_param_getter()
						, _lastinvoicebatchnum_param_getter()
						, _lastinvoicevouchernum_param_getter()
						, _lastcheckbatchnum_param_getter()
						, _lastcheckvouchernum_param_getter()
						, _lastgjbatchnum_param_getter()
						, _lastgjjournalctrlno_param_getter()
						, _lastinvbatchnum_param_getter()
						, _lastpaybatchnum_param_getter()
						, _lastponum_param_getter()
						, _lastpmtbatchcode_param_getter()
						, _lastpmtbatchpostnum_param_getter()
						, _lastreconcilebatchnum_param_getter()
						, _lastreconcilejournalnum_param_getter()
						, _lastvoidccbatchnum_param_getter()
						, _lastvoidmcbatchnum_param_getter()
						, _lastvoidinvbatchnum_param_getter()
						, _lasthcbatchnum_param_getter()
						, _lastprbatchnum_param_getter()
						, _lastmpbatchnum_param_getter()
						, _lastgcbatchnum_param_getter()
						, _greatplainsdbname_param_getter()
						, _greatplainsmchekbkid_param_getter()
						, _greatplainsmcglacctnum_param_getter()
						, _lastpayrollbatchnum_param_getter()
						, _lastepbatchnum_param_getter()
						, _lastvoidepbatchnum_param_getter()
						, _dynamicssystemdsn_param_getter()
						, _lastprepitemcostupdate_param_getter()
						, _externalstorenum_param_getter()
						, _lastcommbatchnum_param_getter()
						, _greatplainsmccurridx_param_getter()
						, _greatplainsmccurncyid_param_getter()
						, _lastvoidpyrbatchnum_param_getter()
						, _lastpradjustbatchnum_param_getter()
						, _lastistnum_param_getter()
						, _lastwastenum_param_getter()
						, _lastcustinvbatchnum_param_getter()
						, _lastprepbatchnum_param_getter()
						, _entitytype_param_getter()
						, _commissarynum_param_getter()
						, _allowdirecttransfers_param_getter()
						, _lastportioncutbatchnum_param_getter()
						, _shippingmethod_param_getter()
						, _lastcommorderbatchnum_param_getter()
						, _allowcommqtychange_param_getter()
						, _lasthcinvoicenum_param_getter()
						, _lastvoidgjbatchnum_param_getter()
						, _allowcomminvdelete_param_getter()
						, _lastistbatchnum_param_getter()
						, _lastunshipcommbatchnum_param_getter()
						, _lastunshipistbatchnum_param_getter()
						, _usfoodvendorcode_param_getter()
						, _lastoutsideordernum_param_getter()
						, _lastcomminvoicenum_param_getter()
						, _lastvoidarpaymentbatchnum_param_getter()
						, _lastpayliabbatchnum_param_getter()
						, _lastprepitemtreebuild_param_getter()
						, _metafileverticaladjust_param_getter()
						, _metafilehorizontaladjust_param_getter()
						, _esyscovendorcode_param_getter()
						, _allowoutsideorders_param_getter()
						, _allowuserstomodifylineitemdescriptions_param_getter()
						, _allowaddcustsoutorders_param_getter()
						, _commsalestax_param_getter()
						, _lastvoidagencyliabbatchnum_param_getter()
						, _adpstorenum_param_getter()
						, _bekvendorcode_param_getter()
						, _cheneybrosvendorcode_param_getter()
						, _fsavendorcode_param_getter()
						, _gfsvendorcode_param_getter()
						, _pfgvendorcode_param_getter()
						, _shamrockfoodsvendorcode_param_getter()
						, _efoodusavendorcode_param_getter()
						, _commprepaidsalesacct_param_getter()
						, _agarsupplyvendorcode_param_getter()
						, _edwarddonvendorcode_param_getter()
						, _mbmvendorcode_param_getter()
						, _forcedirecttransfers_param_getter()
						, _lastecabatchnum_param_getter()
						, _mobilelicensekey_param_getter()
						, _lastvoidpcbatchnum_param_getter()
						, _lastvoidwdbatchnum_param_getter()
						, _lastvoiddsrbatchnum_param_getter()
						, _lastbankrecloadbatchnum_param_getter()
						, _lastvoidctbatchnum_param_getter()
						, _lasttaxablewageadjbatchnum_param_getter()
						, _lastdsrbatchnum_param_getter()
						, _lastvoidpaybatchnum_param_getter()
						, _federalidnumberencrypt_param_getter()
						, _lastachnum_param_getter()
						, _lastloadarbatchcode_param_getter()
						, _consolidationentity_param_getter()
						, _isconsolidationentity_param_getter()
						, _currencyid_param_getter()
						, _countryid_param_getter()
						, _timezone_param_getter()
						, _adjustfordst_param_getter()
						, _backofficelicensekey_param_getter()
						, _payrolllicensekey_param_getter()
						, _laborlicensekey_param_getter()
						, _advantagelicensekey_param_getter()
						, _posmtpconfigid_param_getter()
						, _reqsmtpconfigid_param_getter()
						, _hotshotcomments_param_getter()
						, _lastrequisitionnum_param_getter()
						, _lastvoidbrbatchnum_param_getter()
						, _timeandattendancelicensekey_param_getter()
						, _schedulinglicensekey_param_getter()
					};
				InternalTools.ScriptRunReader(SqlEnums.SqlActivityType.UPDATE, _UPDATE_FULL, conn, parm_list
					, (sdr) => {	 
						if (!sdr.HasRows || !sdr.Read()) {
							throw new DbUpdateFailedNoChangesMade("Insert into stores, but now new rows were detected using PK or identity fields.", conn, null);
						}else{
							_recstamp = (byte[])sdr.GetValue(0);//refresh the timestamp
						}
					}
				, GetTimeout());
			}
		}
		protected override void Delete(SqlConnection conn) {
			InternalTools.ScriptRun(SqlEnums.SqlActivityType.DELETE, _DELETE, conn, new[] { MyPk_param_getter() }, GetTimeout());
			
		}    

		#endregion Writing
		
		#region Gen'd Fields in table
		
		internal static Func<int?, SqlParameter> _myPk_param_getter { 
			get {
				return (pk_val) => { return InternalTools.MakeParam(_PK_PARAMETER_NAME, SqlDbType.Int, pk_val, false);};				
				
			}
		}
		
		internal Func<SqlParameter> MyPk_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(_PK_PARAMETER_NAME, SqlDbType.Int, MyPk, false);};
			}
		}
		
		internal int? _myPk{ get; set; }    
		protected override int? MyPk {
			get{ 
				if(IsSkinnySafe){
					return _myPk; 
				}else{
					return storenum; 
				}
			}
			set{ 
				if(IsSkinnySafe){
					_myPk = value; 
				}
				storenum = value;
				
			}
		}
		
		internal Func<SqlParameter> MyTimeStamp_param_getter { 
			get {
				return _recstamp_param_getter;
			}
		}
		protected override bool RequireTimeStamp { get{ return true; } }
		protected override string MyTimeStamp {
			get{ return recstamp; }
			set{ recstamp = value; }
		}
		
			
		internal int? _storenum{ get; set; }    
		internal Func<SqlParameter> _storenum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_storenum, SqlDbType.Int, _storenum, false);};
			}
		}   

		public virtual int? storenum { 
			get { return _storenum; } 
			set {
				_storenum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_storenum, PARAMETER_NAME_storenum, _storenum_param_getter);
				}
			}
		}			
		internal string _name{ get; set; }    
		internal Func<SqlParameter> _name_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_name, SqlDbType.VarChar, _name, true, 70);};
			}
		}   

		public virtual string name { 
			get { return _name; } 
			set {
				_name = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_name, PARAMETER_NAME_name, _name_param_getter);
				}
			}
		}			
		internal string _addr1{ get; set; }    
		internal Func<SqlParameter> _addr1_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_addr1, SqlDbType.VarChar, _addr1, true, 50);};
			}
		}   

		public virtual string addr1 { 
			get { return _addr1; } 
			set {
				_addr1 = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_addr1, PARAMETER_NAME_addr1, _addr1_param_getter);
				}
			}
		}			
		internal string _addr2{ get; set; }    
		internal Func<SqlParameter> _addr2_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_addr2, SqlDbType.VarChar, _addr2, true, 50);};
			}
		}   

		public virtual string addr2 { 
			get { return _addr2; } 
			set {
				_addr2 = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_addr2, PARAMETER_NAME_addr2, _addr2_param_getter);
				}
			}
		}			
		internal string _city{ get; set; }    
		internal Func<SqlParameter> _city_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_city, SqlDbType.VarChar, _city, true, 20);};
			}
		}   

		public virtual string city { 
			get { return _city; } 
			set {
				_city = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_city, PARAMETER_NAME_city, _city_param_getter);
				}
			}
		}			
		internal string _state{ get; set; }    
		internal Func<SqlParameter> _state_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_state, SqlDbType.VarChar, _state, true, 2);};
			}
		}   

		public virtual string state { 
			get { return _state; } 
			set {
				_state = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_state, PARAMETER_NAME_state, _state_param_getter);
				}
			}
		}			
		internal string _zip{ get; set; }    
		internal Func<SqlParameter> _zip_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_zip, SqlDbType.VarChar, _zip, true, 10);};
			}
		}   

		public virtual string zip { 
			get { return _zip; } 
			set {
				_zip = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_zip, PARAMETER_NAME_zip, _zip_param_getter);
				}
			}
		}			
		internal string _phone{ get; set; }    
		internal Func<SqlParameter> _phone_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_phone, SqlDbType.VarChar, _phone, true, 14);};
			}
		}   

		public virtual string phone { 
			get { return _phone; } 
			set {
				_phone = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_phone, PARAMETER_NAME_phone, _phone_param_getter);
				}
			}
		}			
		internal string _fax{ get; set; }    
		internal Func<SqlParameter> _fax_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_fax, SqlDbType.VarChar, _fax, true, 14);};
			}
		}   

		public virtual string fax { 
			get { return _fax; } 
			set {
				_fax = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_fax, PARAMETER_NAME_fax, _fax_param_getter);
				}
			}
		}			
		internal string _manager{ get; set; }    
		internal Func<SqlParameter> _manager_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_manager, SqlDbType.VarChar, _manager, true, 50);};
			}
		}   

		public virtual string manager { 
			get { return _manager; } 
			set {
				_manager = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_manager, PARAMETER_NAME_manager, _manager_param_getter);
				}
			}
		}			
		internal int? _squarefootage{ get; set; }    
		internal Func<SqlParameter> _squarefootage_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_squarefootage, SqlDbType.Int, _squarefootage, true);};
			}
		}   

		public virtual int? squarefootage { 
			get { return _squarefootage; } 
			set {
				_squarefootage = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_squarefootage, PARAMETER_NAME_squarefootage, _squarefootage_param_getter);
				}
			}
		}			
		internal int? _seats{ get; set; }    
		internal Func<SqlParameter> _seats_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_seats, SqlDbType.Int, _seats, true);};
			}
		}   

		public virtual int? seats { 
			get { return _seats; } 
			set {
				_seats = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_seats, PARAMETER_NAME_seats, _seats_param_getter);
				}
			}
		}			
		internal DateTime? _dateopened{ get; set; }    
		internal Func<SqlParameter> _dateopened_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_dateopened, SqlDbType.DateTime, _dateopened, true);};
			}
		}   

		public virtual DateTime? dateopened { 
			get { return _dateopened; } 
			set {
				_dateopened = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_dateopened, PARAMETER_NAME_dateopened, _dateopened_param_getter);
				}
			}
		}			
		internal DateTime? _datereopened{ get; set; }    
		internal Func<SqlParameter> _datereopened_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_datereopened, SqlDbType.DateTime, _datereopened, true);};
			}
		}   

		public virtual DateTime? datereopened { 
			get { return _datereopened; } 
			set {
				_datereopened = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_datereopened, PARAMETER_NAME_datereopened, _datereopened_param_getter);
				}
			}
		}			
		internal DateTime? _dateclosed{ get; set; }    
		internal Func<SqlParameter> _dateclosed_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_dateclosed, SqlDbType.DateTime, _dateclosed, true);};
			}
		}   

		public virtual DateTime? dateclosed { 
			get { return _dateclosed; } 
			set {
				_dateclosed = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_dateclosed, PARAMETER_NAME_dateclosed, _dateclosed_param_getter);
				}
			}
		}			
		internal int? _storegroup1{ get; set; }    
		internal Func<SqlParameter> _storegroup1_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_storegroup1, SqlDbType.Int, _storegroup1, true);};
			}
		}   

		public virtual int? storegroup1 { 
			get { return _storegroup1; } 
			set {
				_storegroup1 = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_storegroup1, PARAMETER_NAME_storegroup1, _storegroup1_param_getter);
				}
			}
		}			
		internal int? _storegroup2{ get; set; }    
		internal Func<SqlParameter> _storegroup2_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_storegroup2, SqlDbType.Int, _storegroup2, true);};
			}
		}   

		public virtual int? storegroup2 { 
			get { return _storegroup2; } 
			set {
				_storegroup2 = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_storegroup2, PARAMETER_NAME_storegroup2, _storegroup2_param_getter);
				}
			}
		}			
		internal bool _openmondays{ get; set; }    
		internal Func<SqlParameter> _openmondays_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_openmondays, SqlDbType.Bit, _openmondays, false);};
			}
		}   

		public virtual bool openmondays { 
			get { return _openmondays; } 
			set {
				_openmondays = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_openmondays, PARAMETER_NAME_openmondays, _openmondays_param_getter);
				}
			}
		}			
		internal bool _opentuesdays{ get; set; }    
		internal Func<SqlParameter> _opentuesdays_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_opentuesdays, SqlDbType.Bit, _opentuesdays, false);};
			}
		}   

		public virtual bool opentuesdays { 
			get { return _opentuesdays; } 
			set {
				_opentuesdays = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_opentuesdays, PARAMETER_NAME_opentuesdays, _opentuesdays_param_getter);
				}
			}
		}			
		internal bool _openwednesdays{ get; set; }    
		internal Func<SqlParameter> _openwednesdays_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_openwednesdays, SqlDbType.Bit, _openwednesdays, false);};
			}
		}   

		public virtual bool openwednesdays { 
			get { return _openwednesdays; } 
			set {
				_openwednesdays = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_openwednesdays, PARAMETER_NAME_openwednesdays, _openwednesdays_param_getter);
				}
			}
		}			
		internal bool _openthursdays{ get; set; }    
		internal Func<SqlParameter> _openthursdays_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_openthursdays, SqlDbType.Bit, _openthursdays, false);};
			}
		}   

		public virtual bool openthursdays { 
			get { return _openthursdays; } 
			set {
				_openthursdays = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_openthursdays, PARAMETER_NAME_openthursdays, _openthursdays_param_getter);
				}
			}
		}			
		internal bool _openfridays{ get; set; }    
		internal Func<SqlParameter> _openfridays_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_openfridays, SqlDbType.Bit, _openfridays, false);};
			}
		}   

		public virtual bool openfridays { 
			get { return _openfridays; } 
			set {
				_openfridays = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_openfridays, PARAMETER_NAME_openfridays, _openfridays_param_getter);
				}
			}
		}			
		internal bool _opensaturdays{ get; set; }    
		internal Func<SqlParameter> _opensaturdays_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_opensaturdays, SqlDbType.Bit, _opensaturdays, false);};
			}
		}   

		public virtual bool opensaturdays { 
			get { return _opensaturdays; } 
			set {
				_opensaturdays = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_opensaturdays, PARAMETER_NAME_opensaturdays, _opensaturdays_param_getter);
				}
			}
		}			
		internal bool _opensundays{ get; set; }    
		internal Func<SqlParameter> _opensundays_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_opensundays, SqlDbType.Bit, _opensundays, false);};
			}
		}   

		public virtual bool opensundays { 
			get { return _opensundays; } 
			set {
				_opensundays = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_opensundays, PARAMETER_NAME_opensundays, _opensundays_param_getter);
				}
			}
		}			
		internal int? _pos{ get; set; }    
		internal Func<SqlParameter> _pos_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_pos, SqlDbType.Int, _pos, true);};
			}
		}   

		public virtual int? pos { 
			get { return _pos; } 
			set {
				_pos = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_pos, PARAMETER_NAME_pos, _pos_param_getter);
				}
			}
		}			
		internal string _federalidnumber{ get; set; }    
		internal Func<SqlParameter> _federalidnumber_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_federalidnumber, SqlDbType.VarChar, _federalidnumber, true, 15);};
			}
		}   

		public virtual string federalidnumber { 
			get { return _federalidnumber; } 
			set {
				_federalidnumber = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_federalidnumber, PARAMETER_NAME_federalidnumber, _federalidnumber_param_getter);
				}
			}
		}			
		internal double? _topmargin{ get; set; }    
		internal Func<SqlParameter> _topmargin_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_topmargin, SqlDbType.Float, _topmargin, true, 53, 0);};
			}
		}   

		public virtual double? topmargin { 
			get { return _topmargin; } 
			set {
				_topmargin = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_topmargin, PARAMETER_NAME_topmargin, _topmargin_param_getter);
				}
			}
		}			
		internal double? _leftmargin{ get; set; }    
		internal Func<SqlParameter> _leftmargin_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_leftmargin, SqlDbType.Float, _leftmargin, true, 53, 0);};
			}
		}   

		public virtual double? leftmargin { 
			get { return _leftmargin; } 
			set {
				_leftmargin = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_leftmargin, PARAMETER_NAME_leftmargin, _leftmargin_param_getter);
				}
			}
		}			
		internal double? _bottommargin{ get; set; }    
		internal Func<SqlParameter> _bottommargin_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_bottommargin, SqlDbType.Float, _bottommargin, true, 53, 0);};
			}
		}   

		public virtual double? bottommargin { 
			get { return _bottommargin; } 
			set {
				_bottommargin = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_bottommargin, PARAMETER_NAME_bottommargin, _bottommargin_param_getter);
				}
			}
		}			
		internal int? _backgroundcolor{ get; set; }    
		internal Func<SqlParameter> _backgroundcolor_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_backgroundcolor, SqlDbType.Int, _backgroundcolor, true);};
			}
		}   

		public virtual int? backgroundcolor { 
			get { return _backgroundcolor; } 
			set {
				_backgroundcolor = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_backgroundcolor, PARAMETER_NAME_backgroundcolor, _backgroundcolor_param_getter);
				}
			}
		}			
		internal int? _lastinvoicebatchnum{ get; set; }    
		internal Func<SqlParameter> _lastinvoicebatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastinvoicebatchnum, SqlDbType.Int, _lastinvoicebatchnum, true);};
			}
		}   

		public virtual int? lastinvoicebatchnum { 
			get { return _lastinvoicebatchnum; } 
			set {
				_lastinvoicebatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastinvoicebatchnum, PARAMETER_NAME_lastinvoicebatchnum, _lastinvoicebatchnum_param_getter);
				}
			}
		}			
		internal int? _lastinvoicevouchernum{ get; set; }    
		internal Func<SqlParameter> _lastinvoicevouchernum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastinvoicevouchernum, SqlDbType.Int, _lastinvoicevouchernum, true);};
			}
		}   

		public virtual int? lastinvoicevouchernum { 
			get { return _lastinvoicevouchernum; } 
			set {
				_lastinvoicevouchernum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastinvoicevouchernum, PARAMETER_NAME_lastinvoicevouchernum, _lastinvoicevouchernum_param_getter);
				}
			}
		}			
		internal int? _lastcheckbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastcheckbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastcheckbatchnum, SqlDbType.Int, _lastcheckbatchnum, true);};
			}
		}   

		public virtual int? lastcheckbatchnum { 
			get { return _lastcheckbatchnum; } 
			set {
				_lastcheckbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastcheckbatchnum, PARAMETER_NAME_lastcheckbatchnum, _lastcheckbatchnum_param_getter);
				}
			}
		}			
		internal int? _lastcheckvouchernum{ get; set; }    
		internal Func<SqlParameter> _lastcheckvouchernum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastcheckvouchernum, SqlDbType.Int, _lastcheckvouchernum, true);};
			}
		}   

		public virtual int? lastcheckvouchernum { 
			get { return _lastcheckvouchernum; } 
			set {
				_lastcheckvouchernum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastcheckvouchernum, PARAMETER_NAME_lastcheckvouchernum, _lastcheckvouchernum_param_getter);
				}
			}
		}			
		internal int? _lastgjbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastgjbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastgjbatchnum, SqlDbType.Int, _lastgjbatchnum, true);};
			}
		}   

		public virtual int? lastgjbatchnum { 
			get { return _lastgjbatchnum; } 
			set {
				_lastgjbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastgjbatchnum, PARAMETER_NAME_lastgjbatchnum, _lastgjbatchnum_param_getter);
				}
			}
		}			
		internal int? _lastgjjournalctrlno{ get; set; }    
		internal Func<SqlParameter> _lastgjjournalctrlno_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastgjjournalctrlno, SqlDbType.Int, _lastgjjournalctrlno, true);};
			}
		}   

		public virtual int? lastgjjournalctrlno { 
			get { return _lastgjjournalctrlno; } 
			set {
				_lastgjjournalctrlno = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastgjjournalctrlno, PARAMETER_NAME_lastgjjournalctrlno, _lastgjjournalctrlno_param_getter);
				}
			}
		}			
		internal int? _lastinvbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastinvbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastinvbatchnum, SqlDbType.Int, _lastinvbatchnum, true);};
			}
		}   

		public virtual int? lastinvbatchnum { 
			get { return _lastinvbatchnum; } 
			set {
				_lastinvbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastinvbatchnum, PARAMETER_NAME_lastinvbatchnum, _lastinvbatchnum_param_getter);
				}
			}
		}			
		internal int? _lastpaybatchnum{ get; set; }    
		internal Func<SqlParameter> _lastpaybatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastpaybatchnum, SqlDbType.Int, _lastpaybatchnum, true);};
			}
		}   

		public virtual int? lastpaybatchnum { 
			get { return _lastpaybatchnum; } 
			set {
				_lastpaybatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastpaybatchnum, PARAMETER_NAME_lastpaybatchnum, _lastpaybatchnum_param_getter);
				}
			}
		}			
		internal int? _lastponum{ get; set; }    
		internal Func<SqlParameter> _lastponum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastponum, SqlDbType.Int, _lastponum, true);};
			}
		}   

		public virtual int? lastponum { 
			get { return _lastponum; } 
			set {
				_lastponum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastponum, PARAMETER_NAME_lastponum, _lastponum_param_getter);
				}
			}
		}			
		internal int? _lastpmtbatchcode{ get; set; }    
		internal Func<SqlParameter> _lastpmtbatchcode_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastpmtbatchcode, SqlDbType.Int, _lastpmtbatchcode, true);};
			}
		}   

		public virtual int? lastpmtbatchcode { 
			get { return _lastpmtbatchcode; } 
			set {
				_lastpmtbatchcode = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastpmtbatchcode, PARAMETER_NAME_lastpmtbatchcode, _lastpmtbatchcode_param_getter);
				}
			}
		}			
		internal int? _lastpmtbatchpostnum{ get; set; }    
		internal Func<SqlParameter> _lastpmtbatchpostnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastpmtbatchpostnum, SqlDbType.Int, _lastpmtbatchpostnum, true);};
			}
		}   

		public virtual int? lastpmtbatchpostnum { 
			get { return _lastpmtbatchpostnum; } 
			set {
				_lastpmtbatchpostnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastpmtbatchpostnum, PARAMETER_NAME_lastpmtbatchpostnum, _lastpmtbatchpostnum_param_getter);
				}
			}
		}			
		internal int? _lastreconcilebatchnum{ get; set; }    
		internal Func<SqlParameter> _lastreconcilebatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastreconcilebatchnum, SqlDbType.Int, _lastreconcilebatchnum, true);};
			}
		}   

		public virtual int? lastreconcilebatchnum { 
			get { return _lastreconcilebatchnum; } 
			set {
				_lastreconcilebatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastreconcilebatchnum, PARAMETER_NAME_lastreconcilebatchnum, _lastreconcilebatchnum_param_getter);
				}
			}
		}			
		internal int? _lastreconcilejournalnum{ get; set; }    
		internal Func<SqlParameter> _lastreconcilejournalnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastreconcilejournalnum, SqlDbType.Int, _lastreconcilejournalnum, true);};
			}
		}   

		public virtual int? lastreconcilejournalnum { 
			get { return _lastreconcilejournalnum; } 
			set {
				_lastreconcilejournalnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastreconcilejournalnum, PARAMETER_NAME_lastreconcilejournalnum, _lastreconcilejournalnum_param_getter);
				}
			}
		}			
		internal int? _lastvoidccbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastvoidccbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastvoidccbatchnum, SqlDbType.Int, _lastvoidccbatchnum, true);};
			}
		}   

		public virtual int? lastvoidccbatchnum { 
			get { return _lastvoidccbatchnum; } 
			set {
				_lastvoidccbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastvoidccbatchnum, PARAMETER_NAME_lastvoidccbatchnum, _lastvoidccbatchnum_param_getter);
				}
			}
		}			
		internal int? _lastvoidmcbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastvoidmcbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastvoidmcbatchnum, SqlDbType.Int, _lastvoidmcbatchnum, true);};
			}
		}   

		public virtual int? lastvoidmcbatchnum { 
			get { return _lastvoidmcbatchnum; } 
			set {
				_lastvoidmcbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastvoidmcbatchnum, PARAMETER_NAME_lastvoidmcbatchnum, _lastvoidmcbatchnum_param_getter);
				}
			}
		}			
		internal int? _lastvoidinvbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastvoidinvbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastvoidinvbatchnum, SqlDbType.Int, _lastvoidinvbatchnum, true);};
			}
		}   

		public virtual int? lastvoidinvbatchnum { 
			get { return _lastvoidinvbatchnum; } 
			set {
				_lastvoidinvbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastvoidinvbatchnum, PARAMETER_NAME_lastvoidinvbatchnum, _lastvoidinvbatchnum_param_getter);
				}
			}
		}			
		internal int? _lasthcbatchnum{ get; set; }    
		internal Func<SqlParameter> _lasthcbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lasthcbatchnum, SqlDbType.Int, _lasthcbatchnum, true);};
			}
		}   

		public virtual int? lasthcbatchnum { 
			get { return _lasthcbatchnum; } 
			set {
				_lasthcbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lasthcbatchnum, PARAMETER_NAME_lasthcbatchnum, _lasthcbatchnum_param_getter);
				}
			}
		}			
		internal int? _lastprbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastprbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastprbatchnum, SqlDbType.Int, _lastprbatchnum, true);};
			}
		}   

		public virtual int? lastprbatchnum { 
			get { return _lastprbatchnum; } 
			set {
				_lastprbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastprbatchnum, PARAMETER_NAME_lastprbatchnum, _lastprbatchnum_param_getter);
				}
			}
		}			
		internal int? _lastmpbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastmpbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastmpbatchnum, SqlDbType.Int, _lastmpbatchnum, true);};
			}
		}   

		public virtual int? lastmpbatchnum { 
			get { return _lastmpbatchnum; } 
			set {
				_lastmpbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastmpbatchnum, PARAMETER_NAME_lastmpbatchnum, _lastmpbatchnum_param_getter);
				}
			}
		}			
		internal int? _lastgcbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastgcbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastgcbatchnum, SqlDbType.Int, _lastgcbatchnum, true);};
			}
		}   

		public virtual int? lastgcbatchnum { 
			get { return _lastgcbatchnum; } 
			set {
				_lastgcbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastgcbatchnum, PARAMETER_NAME_lastgcbatchnum, _lastgcbatchnum_param_getter);
				}
			}
		}			
		internal string _greatplainsdbname{ get; set; }    
		internal Func<SqlParameter> _greatplainsdbname_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_greatplainsdbname, SqlDbType.VarChar, _greatplainsdbname, true, 128);};
			}
		}   

		public virtual string greatplainsdbname { 
			get { return _greatplainsdbname; } 
			set {
				_greatplainsdbname = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_greatplainsdbname, PARAMETER_NAME_greatplainsdbname, _greatplainsdbname_param_getter);
				}
			}
		}			
		internal string _greatplainsmchekbkid{ get; set; }    
		internal Func<SqlParameter> _greatplainsmchekbkid_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_greatplainsmchekbkid, SqlDbType.Char, _greatplainsmchekbkid, true, 15);};
			}
		}   

		public virtual string greatplainsmchekbkid { 
			get { return _greatplainsmchekbkid; } 
			set {
				_greatplainsmchekbkid = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_greatplainsmchekbkid, PARAMETER_NAME_greatplainsmchekbkid, _greatplainsmchekbkid_param_getter);
				}
			}
		}			
		internal string _greatplainsmcglacctnum{ get; set; }    
		internal Func<SqlParameter> _greatplainsmcglacctnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_greatplainsmcglacctnum, SqlDbType.VarChar, _greatplainsmcglacctnum, true, 8);};
			}
		}   

		public virtual string greatplainsmcglacctnum { 
			get { return _greatplainsmcglacctnum; } 
			set {
				_greatplainsmcglacctnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_greatplainsmcglacctnum, PARAMETER_NAME_greatplainsmcglacctnum, _greatplainsmcglacctnum_param_getter);
				}
			}
		}			
		internal int? _lastpayrollbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastpayrollbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastpayrollbatchnum, SqlDbType.Int, _lastpayrollbatchnum, true);};
			}
		}   

		public virtual int? lastpayrollbatchnum { 
			get { return _lastpayrollbatchnum; } 
			set {
				_lastpayrollbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastpayrollbatchnum, PARAMETER_NAME_lastpayrollbatchnum, _lastpayrollbatchnum_param_getter);
				}
			}
		}			
		internal int? _lastepbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastepbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastepbatchnum, SqlDbType.Int, _lastepbatchnum, true);};
			}
		}   

		public virtual int? lastepbatchnum { 
			get { return _lastepbatchnum; } 
			set {
				_lastepbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastepbatchnum, PARAMETER_NAME_lastepbatchnum, _lastepbatchnum_param_getter);
				}
			}
		}			
		internal int? _lastvoidepbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastvoidepbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastvoidepbatchnum, SqlDbType.Int, _lastvoidepbatchnum, true);};
			}
		}   

		public virtual int? lastvoidepbatchnum { 
			get { return _lastvoidepbatchnum; } 
			set {
				_lastvoidepbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastvoidepbatchnum, PARAMETER_NAME_lastvoidepbatchnum, _lastvoidepbatchnum_param_getter);
				}
			}
		}			
		internal string _dynamicssystemdsn{ get; set; }    
		internal Func<SqlParameter> _dynamicssystemdsn_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_dynamicssystemdsn, SqlDbType.VarChar, _dynamicssystemdsn, true, 50);};
			}
		}   

		public virtual string dynamicssystemdsn { 
			get { return _dynamicssystemdsn; } 
			set {
				_dynamicssystemdsn = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_dynamicssystemdsn, PARAMETER_NAME_dynamicssystemdsn, _dynamicssystemdsn_param_getter);
				}
			}
		}			
		internal DateTime? _lastprepitemcostupdate{ get; set; }    
		internal Func<SqlParameter> _lastprepitemcostupdate_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastprepitemcostupdate, SqlDbType.DateTime, _lastprepitemcostupdate, true);};
			}
		}   

		public virtual DateTime? lastprepitemcostupdate { 
			get { return _lastprepitemcostupdate; } 
			set {
				_lastprepitemcostupdate = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastprepitemcostupdate, PARAMETER_NAME_lastprepitemcostupdate, _lastprepitemcostupdate_param_getter);
				}
			}
		}			
		internal string _externalstorenum{ get; set; }    
		internal Func<SqlParameter> _externalstorenum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_externalstorenum, SqlDbType.VarChar, _externalstorenum, true, 10);};
			}
		}   

		public virtual string externalstorenum { 
			get { return _externalstorenum; } 
			set {
				_externalstorenum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_externalstorenum, PARAMETER_NAME_externalstorenum, _externalstorenum_param_getter);
				}
			}
		}			
		internal int? _lastcommbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastcommbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastcommbatchnum, SqlDbType.Int, _lastcommbatchnum, true);};
			}
		}   

		public virtual int? lastcommbatchnum { 
			get { return _lastcommbatchnum; } 
			set {
				_lastcommbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastcommbatchnum, PARAMETER_NAME_lastcommbatchnum, _lastcommbatchnum_param_getter);
				}
			}
		}			
		internal short? _greatplainsmccurridx{ get; set; }    
		internal Func<SqlParameter> _greatplainsmccurridx_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_greatplainsmccurridx, SqlDbType.SmallInt, _greatplainsmccurridx, true);};
			}
		}   

		public virtual short? greatplainsmccurridx { 
			get { return _greatplainsmccurridx; } 
			set {
				_greatplainsmccurridx = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_greatplainsmccurridx, PARAMETER_NAME_greatplainsmccurridx, _greatplainsmccurridx_param_getter);
				}
			}
		}			
		internal string _greatplainsmccurncyid{ get; set; }    
		internal Func<SqlParameter> _greatplainsmccurncyid_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_greatplainsmccurncyid, SqlDbType.VarChar, _greatplainsmccurncyid, true, 15);};
			}
		}   

		public virtual string greatplainsmccurncyid { 
			get { return _greatplainsmccurncyid; } 
			set {
				_greatplainsmccurncyid = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_greatplainsmccurncyid, PARAMETER_NAME_greatplainsmccurncyid, _greatplainsmccurncyid_param_getter);
				}
			}
		}			
		internal int? _lastvoidpyrbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastvoidpyrbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastvoidpyrbatchnum, SqlDbType.Int, _lastvoidpyrbatchnum, true);};
			}
		}   

		public virtual int? lastvoidpyrbatchnum { 
			get { return _lastvoidpyrbatchnum; } 
			set {
				_lastvoidpyrbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastvoidpyrbatchnum, PARAMETER_NAME_lastvoidpyrbatchnum, _lastvoidpyrbatchnum_param_getter);
				}
			}
		}			
		internal int? _lastpradjustbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastpradjustbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastpradjustbatchnum, SqlDbType.Int, _lastpradjustbatchnum, true);};
			}
		}   

		public virtual int? lastpradjustbatchnum { 
			get { return _lastpradjustbatchnum; } 
			set {
				_lastpradjustbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastpradjustbatchnum, PARAMETER_NAME_lastpradjustbatchnum, _lastpradjustbatchnum_param_getter);
				}
			}
		}			
		internal int? _lastistnum{ get; set; }    
		internal Func<SqlParameter> _lastistnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastistnum, SqlDbType.Int, _lastistnum, true);};
			}
		}   

		public virtual int? lastistnum { 
			get { return _lastistnum; } 
			set {
				_lastistnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastistnum, PARAMETER_NAME_lastistnum, _lastistnum_param_getter);
				}
			}
		}			
		internal int? _lastwastenum{ get; set; }    
		internal Func<SqlParameter> _lastwastenum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastwastenum, SqlDbType.Int, _lastwastenum, true);};
			}
		}   

		public virtual int? lastwastenum { 
			get { return _lastwastenum; } 
			set {
				_lastwastenum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastwastenum, PARAMETER_NAME_lastwastenum, _lastwastenum_param_getter);
				}
			}
		}			
		internal int? _lastcustinvbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastcustinvbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastcustinvbatchnum, SqlDbType.Int, _lastcustinvbatchnum, true);};
			}
		}   

		public virtual int? lastcustinvbatchnum { 
			get { return _lastcustinvbatchnum; } 
			set {
				_lastcustinvbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastcustinvbatchnum, PARAMETER_NAME_lastcustinvbatchnum, _lastcustinvbatchnum_param_getter);
				}
			}
		}			
		internal int? _lastprepbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastprepbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastprepbatchnum, SqlDbType.Int, _lastprepbatchnum, true);};
			}
		}   

		public virtual int? lastprepbatchnum { 
			get { return _lastprepbatchnum; } 
			set {
				_lastprepbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastprepbatchnum, PARAMETER_NAME_lastprepbatchnum, _lastprepbatchnum_param_getter);
				}
			}
		}			
		internal byte _entitytype{ get; set; }    
		internal Func<SqlParameter> _entitytype_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_entitytype, SqlDbType.TinyInt, _entitytype, false);};
			}
		}   

		public virtual byte entitytype { 
			get { return _entitytype; } 
			set {
				_entitytype = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_entitytype, PARAMETER_NAME_entitytype, _entitytype_param_getter);
				}
			}
		}			
		internal int? _commissarynum{ get; set; }    
		internal Func<SqlParameter> _commissarynum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_commissarynum, SqlDbType.Int, _commissarynum, true);};
			}
		}   

		public virtual int? commissarynum { 
			get { return _commissarynum; } 
			set {
				_commissarynum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_commissarynum, PARAMETER_NAME_commissarynum, _commissarynum_param_getter);
				}
			}
		}			
		internal bool _allowdirecttransfers{ get; set; }    
		internal Func<SqlParameter> _allowdirecttransfers_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_allowdirecttransfers, SqlDbType.Bit, _allowdirecttransfers, false);};
			}
		}   

		public virtual bool allowdirecttransfers { 
			get { return _allowdirecttransfers; } 
			set {
				_allowdirecttransfers = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_allowdirecttransfers, PARAMETER_NAME_allowdirecttransfers, _allowdirecttransfers_param_getter);
				}
			}
		}			
		internal int? _lastportioncutbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastportioncutbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastportioncutbatchnum, SqlDbType.Int, _lastportioncutbatchnum, true);};
			}
		}   

		public virtual int? lastportioncutbatchnum { 
			get { return _lastportioncutbatchnum; } 
			set {
				_lastportioncutbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastportioncutbatchnum, PARAMETER_NAME_lastportioncutbatchnum, _lastportioncutbatchnum_param_getter);
				}
			}
		}			
		internal byte _shippingmethod{ get; set; }    
		internal Func<SqlParameter> _shippingmethod_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_shippingmethod, SqlDbType.TinyInt, _shippingmethod, false);};
			}
		}   

		public virtual byte shippingmethod { 
			get { return _shippingmethod; } 
			set {
				_shippingmethod = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_shippingmethod, PARAMETER_NAME_shippingmethod, _shippingmethod_param_getter);
				}
			}
		}			
		internal int? _lastcommorderbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastcommorderbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastcommorderbatchnum, SqlDbType.Int, _lastcommorderbatchnum, true);};
			}
		}   

		public virtual int? lastcommorderbatchnum { 
			get { return _lastcommorderbatchnum; } 
			set {
				_lastcommorderbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastcommorderbatchnum, PARAMETER_NAME_lastcommorderbatchnum, _lastcommorderbatchnum_param_getter);
				}
			}
		}			
		internal bool _allowcommqtychange{ get; set; }    
		internal Func<SqlParameter> _allowcommqtychange_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_allowcommqtychange, SqlDbType.Bit, _allowcommqtychange, false);};
			}
		}   

		public virtual bool allowcommqtychange { 
			get { return _allowcommqtychange; } 
			set {
				_allowcommqtychange = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_allowcommqtychange, PARAMETER_NAME_allowcommqtychange, _allowcommqtychange_param_getter);
				}
			}
		}			
		internal int? _lasthcinvoicenum{ get; set; }    
		internal Func<SqlParameter> _lasthcinvoicenum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lasthcinvoicenum, SqlDbType.Int, _lasthcinvoicenum, true);};
			}
		}   

		public virtual int? lasthcinvoicenum { 
			get { return _lasthcinvoicenum; } 
			set {
				_lasthcinvoicenum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lasthcinvoicenum, PARAMETER_NAME_lasthcinvoicenum, _lasthcinvoicenum_param_getter);
				}
			}
		}			
		internal int? _lastvoidgjbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastvoidgjbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastvoidgjbatchnum, SqlDbType.Int, _lastvoidgjbatchnum, true);};
			}
		}   

		public virtual int? lastvoidgjbatchnum { 
			get { return _lastvoidgjbatchnum; } 
			set {
				_lastvoidgjbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastvoidgjbatchnum, PARAMETER_NAME_lastvoidgjbatchnum, _lastvoidgjbatchnum_param_getter);
				}
			}
		}			
		internal bool _allowcomminvdelete{ get; set; }    
		internal Func<SqlParameter> _allowcomminvdelete_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_allowcomminvdelete, SqlDbType.Bit, _allowcomminvdelete, false);};
			}
		}   

		public virtual bool allowcomminvdelete { 
			get { return _allowcomminvdelete; } 
			set {
				_allowcomminvdelete = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_allowcomminvdelete, PARAMETER_NAME_allowcomminvdelete, _allowcomminvdelete_param_getter);
				}
			}
		}			
		internal int? _lastistbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastistbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastistbatchnum, SqlDbType.Int, _lastistbatchnum, true);};
			}
		}   

		public virtual int? lastistbatchnum { 
			get { return _lastistbatchnum; } 
			set {
				_lastistbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastistbatchnum, PARAMETER_NAME_lastistbatchnum, _lastistbatchnum_param_getter);
				}
			}
		}			
		internal int? _lastunshipcommbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastunshipcommbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastunshipcommbatchnum, SqlDbType.Int, _lastunshipcommbatchnum, true);};
			}
		}   

		public virtual int? lastunshipcommbatchnum { 
			get { return _lastunshipcommbatchnum; } 
			set {
				_lastunshipcommbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastunshipcommbatchnum, PARAMETER_NAME_lastunshipcommbatchnum, _lastunshipcommbatchnum_param_getter);
				}
			}
		}			
		internal int? _lastunshipistbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastunshipistbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastunshipistbatchnum, SqlDbType.Int, _lastunshipistbatchnum, true);};
			}
		}   

		public virtual int? lastunshipistbatchnum { 
			get { return _lastunshipistbatchnum; } 
			set {
				_lastunshipistbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastunshipistbatchnum, PARAMETER_NAME_lastunshipistbatchnum, _lastunshipistbatchnum_param_getter);
				}
			}
		}			
		internal string _usfoodvendorcode{ get; set; }    
		internal Func<SqlParameter> _usfoodvendorcode_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_usfoodvendorcode, SqlDbType.Char, _usfoodvendorcode, true, 12);};
			}
		}   

		public virtual string usfoodvendorcode { 
			get { return _usfoodvendorcode; } 
			set {
				_usfoodvendorcode = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_usfoodvendorcode, PARAMETER_NAME_usfoodvendorcode, _usfoodvendorcode_param_getter);
				}
			}
		}			
		internal int? _lastoutsideordernum{ get; set; }    
		internal Func<SqlParameter> _lastoutsideordernum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastoutsideordernum, SqlDbType.Int, _lastoutsideordernum, true);};
			}
		}   

		public virtual int? lastoutsideordernum { 
			get { return _lastoutsideordernum; } 
			set {
				_lastoutsideordernum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastoutsideordernum, PARAMETER_NAME_lastoutsideordernum, _lastoutsideordernum_param_getter);
				}
			}
		}			
		internal int? _lastcomminvoicenum{ get; set; }    
		internal Func<SqlParameter> _lastcomminvoicenum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastcomminvoicenum, SqlDbType.Int, _lastcomminvoicenum, true);};
			}
		}   

		public virtual int? lastcomminvoicenum { 
			get { return _lastcomminvoicenum; } 
			set {
				_lastcomminvoicenum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastcomminvoicenum, PARAMETER_NAME_lastcomminvoicenum, _lastcomminvoicenum_param_getter);
				}
			}
		}			
		internal int? _lastvoidarpaymentbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastvoidarpaymentbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastvoidarpaymentbatchnum, SqlDbType.Int, _lastvoidarpaymentbatchnum, true);};
			}
		}   

		public virtual int? lastvoidarpaymentbatchnum { 
			get { return _lastvoidarpaymentbatchnum; } 
			set {
				_lastvoidarpaymentbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastvoidarpaymentbatchnum, PARAMETER_NAME_lastvoidarpaymentbatchnum, _lastvoidarpaymentbatchnum_param_getter);
				}
			}
		}			
		internal int? _lastpayliabbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastpayliabbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastpayliabbatchnum, SqlDbType.Int, _lastpayliabbatchnum, true);};
			}
		}   

		public virtual int? lastpayliabbatchnum { 
			get { return _lastpayliabbatchnum; } 
			set {
				_lastpayliabbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastpayliabbatchnum, PARAMETER_NAME_lastpayliabbatchnum, _lastpayliabbatchnum_param_getter);
				}
			}
		}			
		internal DateTime? _lastprepitemtreebuild{ get; set; }    
		internal Func<SqlParameter> _lastprepitemtreebuild_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastprepitemtreebuild, SqlDbType.DateTime, _lastprepitemtreebuild, true);};
			}
		}   

		public virtual DateTime? lastprepitemtreebuild { 
			get { return _lastprepitemtreebuild; } 
			set {
				_lastprepitemtreebuild = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastprepitemtreebuild, PARAMETER_NAME_lastprepitemtreebuild, _lastprepitemtreebuild_param_getter);
				}
			}
		}			
		internal decimal? _metafileverticaladjust{ get; set; }    
		internal Func<SqlParameter> _metafileverticaladjust_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_metafileverticaladjust, SqlDbType.Decimal, _metafileverticaladjust, true, 9, 2);};
			}
		}   

		public virtual decimal? metafileverticaladjust { 
			get { return _metafileverticaladjust; } 
			set {
				_metafileverticaladjust = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_metafileverticaladjust, PARAMETER_NAME_metafileverticaladjust, _metafileverticaladjust_param_getter);
				}
			}
		}			
		internal decimal? _metafilehorizontaladjust{ get; set; }    
		internal Func<SqlParameter> _metafilehorizontaladjust_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_metafilehorizontaladjust, SqlDbType.Decimal, _metafilehorizontaladjust, true, 9, 2);};
			}
		}   

		public virtual decimal? metafilehorizontaladjust { 
			get { return _metafilehorizontaladjust; } 
			set {
				_metafilehorizontaladjust = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_metafilehorizontaladjust, PARAMETER_NAME_metafilehorizontaladjust, _metafilehorizontaladjust_param_getter);
				}
			}
		}			
		internal string _esyscovendorcode{ get; set; }    
		internal Func<SqlParameter> _esyscovendorcode_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_esyscovendorcode, SqlDbType.VarChar, _esyscovendorcode, true, 12);};
			}
		}   

		public virtual string esyscovendorcode { 
			get { return _esyscovendorcode; } 
			set {
				_esyscovendorcode = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_esyscovendorcode, PARAMETER_NAME_esyscovendorcode, _esyscovendorcode_param_getter);
				}
			}
		}			
		internal bool _allowoutsideorders{ get; set; }    
		internal Func<SqlParameter> _allowoutsideorders_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_allowoutsideorders, SqlDbType.Bit, _allowoutsideorders, false);};
			}
		}   

		public virtual bool allowoutsideorders { 
			get { return _allowoutsideorders; } 
			set {
				_allowoutsideorders = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_allowoutsideorders, PARAMETER_NAME_allowoutsideorders, _allowoutsideorders_param_getter);
				}
			}
		}			
		internal bool _allowuserstomodifylineitemdescriptions{ get; set; }    
		internal Func<SqlParameter> _allowuserstomodifylineitemdescriptions_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_allowuserstomodifylineitemdescriptions, SqlDbType.Bit, _allowuserstomodifylineitemdescriptions, false);};
			}
		}   

		public virtual bool allowuserstomodifylineitemdescriptions { 
			get { return _allowuserstomodifylineitemdescriptions; } 
			set {
				_allowuserstomodifylineitemdescriptions = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_allowuserstomodifylineitemdescriptions, PARAMETER_NAME_allowuserstomodifylineitemdescriptions, _allowuserstomodifylineitemdescriptions_param_getter);
				}
			}
		}			
		internal bool _allowaddcustsoutorders{ get; set; }    
		internal Func<SqlParameter> _allowaddcustsoutorders_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_allowaddcustsoutorders, SqlDbType.Bit, _allowaddcustsoutorders, false);};
			}
		}   

		public virtual bool allowaddcustsoutorders { 
			get { return _allowaddcustsoutorders; } 
			set {
				_allowaddcustsoutorders = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_allowaddcustsoutorders, PARAMETER_NAME_allowaddcustsoutorders, _allowaddcustsoutorders_param_getter);
				}
			}
		}			
		internal int? _commsalestax{ get; set; }    
		internal Func<SqlParameter> _commsalestax_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_commsalestax, SqlDbType.Int, _commsalestax, true);};
			}
		}   

		public virtual int? commsalestax { 
			get { return _commsalestax; } 
			set {
				_commsalestax = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_commsalestax, PARAMETER_NAME_commsalestax, _commsalestax_param_getter);
				}
			}
		}			
		internal int? _lastvoidagencyliabbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastvoidagencyliabbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastvoidagencyliabbatchnum, SqlDbType.Int, _lastvoidagencyliabbatchnum, true);};
			}
		}   

		public virtual int? lastvoidagencyliabbatchnum { 
			get { return _lastvoidagencyliabbatchnum; } 
			set {
				_lastvoidagencyliabbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastvoidagencyliabbatchnum, PARAMETER_NAME_lastvoidagencyliabbatchnum, _lastvoidagencyliabbatchnum_param_getter);
				}
			}
		}			
		internal int? _adpstorenum{ get; set; }    
		internal Func<SqlParameter> _adpstorenum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_adpstorenum, SqlDbType.Int, _adpstorenum, true);};
			}
		}   

		public virtual int? adpstorenum { 
			get { return _adpstorenum; } 
			set {
				_adpstorenum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_adpstorenum, PARAMETER_NAME_adpstorenum, _adpstorenum_param_getter);
				}
			}
		}			
		internal byte[] _recstamp{ get; set; }    
		internal Func<SqlParameter> _recstamp_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_recstamp, SqlDbType.Timestamp, _recstamp, false);};
			}
		}   
		public virtual string recstamp { 
			get { 
				return _recstamp == null ? null : Convert.ToBase64String(_recstamp); 
			}
			set {
				if(string.IsNullOrWhiteSpace(value)){
					_recstamp = null;
				}
				else {
					_recstamp = Convert.FromBase64String(value);
				}
				if(IsSkinnySafe){
					AddChangedProperty(false, false, true, COLUMN_NAME_recstamp, PARAMETER_NAME_recstamp, _recstamp_param_getter);
				}
			}
		}			
		internal string _bekvendorcode{ get; set; }    
		internal Func<SqlParameter> _bekvendorcode_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_bekvendorcode, SqlDbType.Char, _bekvendorcode, true, 12);};
			}
		}   

		public virtual string bekvendorcode { 
			get { return _bekvendorcode; } 
			set {
				_bekvendorcode = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_bekvendorcode, PARAMETER_NAME_bekvendorcode, _bekvendorcode_param_getter);
				}
			}
		}			
		internal string _cheneybrosvendorcode{ get; set; }    
		internal Func<SqlParameter> _cheneybrosvendorcode_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_cheneybrosvendorcode, SqlDbType.Char, _cheneybrosvendorcode, true, 12);};
			}
		}   

		public virtual string cheneybrosvendorcode { 
			get { return _cheneybrosvendorcode; } 
			set {
				_cheneybrosvendorcode = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_cheneybrosvendorcode, PARAMETER_NAME_cheneybrosvendorcode, _cheneybrosvendorcode_param_getter);
				}
			}
		}			
		internal string _fsavendorcode{ get; set; }    
		internal Func<SqlParameter> _fsavendorcode_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_fsavendorcode, SqlDbType.Char, _fsavendorcode, true, 12);};
			}
		}   

		public virtual string fsavendorcode { 
			get { return _fsavendorcode; } 
			set {
				_fsavendorcode = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_fsavendorcode, PARAMETER_NAME_fsavendorcode, _fsavendorcode_param_getter);
				}
			}
		}			
		internal string _gfsvendorcode{ get; set; }    
		internal Func<SqlParameter> _gfsvendorcode_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_gfsvendorcode, SqlDbType.Char, _gfsvendorcode, true, 12);};
			}
		}   

		public virtual string gfsvendorcode { 
			get { return _gfsvendorcode; } 
			set {
				_gfsvendorcode = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_gfsvendorcode, PARAMETER_NAME_gfsvendorcode, _gfsvendorcode_param_getter);
				}
			}
		}			
		internal string _pfgvendorcode{ get; set; }    
		internal Func<SqlParameter> _pfgvendorcode_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_pfgvendorcode, SqlDbType.Char, _pfgvendorcode, true, 12);};
			}
		}   

		public virtual string pfgvendorcode { 
			get { return _pfgvendorcode; } 
			set {
				_pfgvendorcode = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_pfgvendorcode, PARAMETER_NAME_pfgvendorcode, _pfgvendorcode_param_getter);
				}
			}
		}			
		internal string _shamrockfoodsvendorcode{ get; set; }    
		internal Func<SqlParameter> _shamrockfoodsvendorcode_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_shamrockfoodsvendorcode, SqlDbType.Char, _shamrockfoodsvendorcode, true, 12);};
			}
		}   

		public virtual string shamrockfoodsvendorcode { 
			get { return _shamrockfoodsvendorcode; } 
			set {
				_shamrockfoodsvendorcode = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_shamrockfoodsvendorcode, PARAMETER_NAME_shamrockfoodsvendorcode, _shamrockfoodsvendorcode_param_getter);
				}
			}
		}			
		internal string _efoodusavendorcode{ get; set; }    
		internal Func<SqlParameter> _efoodusavendorcode_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_efoodusavendorcode, SqlDbType.Char, _efoodusavendorcode, true, 12);};
			}
		}   

		public virtual string efoodusavendorcode { 
			get { return _efoodusavendorcode; } 
			set {
				_efoodusavendorcode = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_efoodusavendorcode, PARAMETER_NAME_efoodusavendorcode, _efoodusavendorcode_param_getter);
				}
			}
		}			
		internal string _commprepaidsalesacct{ get; set; }    
		internal Func<SqlParameter> _commprepaidsalesacct_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_commprepaidsalesacct, SqlDbType.VarChar, _commprepaidsalesacct, true, 8);};
			}
		}   

		public virtual string commprepaidsalesacct { 
			get { return _commprepaidsalesacct; } 
			set {
				_commprepaidsalesacct = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_commprepaidsalesacct, PARAMETER_NAME_commprepaidsalesacct, _commprepaidsalesacct_param_getter);
				}
			}
		}			
		internal string _agarsupplyvendorcode{ get; set; }    
		internal Func<SqlParameter> _agarsupplyvendorcode_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_agarsupplyvendorcode, SqlDbType.Char, _agarsupplyvendorcode, true, 12);};
			}
		}   

		public virtual string agarsupplyvendorcode { 
			get { return _agarsupplyvendorcode; } 
			set {
				_agarsupplyvendorcode = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_agarsupplyvendorcode, PARAMETER_NAME_agarsupplyvendorcode, _agarsupplyvendorcode_param_getter);
				}
			}
		}			
		internal string _edwarddonvendorcode{ get; set; }    
		internal Func<SqlParameter> _edwarddonvendorcode_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_edwarddonvendorcode, SqlDbType.Char, _edwarddonvendorcode, true, 12);};
			}
		}   

		public virtual string edwarddonvendorcode { 
			get { return _edwarddonvendorcode; } 
			set {
				_edwarddonvendorcode = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_edwarddonvendorcode, PARAMETER_NAME_edwarddonvendorcode, _edwarddonvendorcode_param_getter);
				}
			}
		}			
		internal string _mbmvendorcode{ get; set; }    
		internal Func<SqlParameter> _mbmvendorcode_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_mbmvendorcode, SqlDbType.Char, _mbmvendorcode, true, 12);};
			}
		}   

		public virtual string mbmvendorcode { 
			get { return _mbmvendorcode; } 
			set {
				_mbmvendorcode = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_mbmvendorcode, PARAMETER_NAME_mbmvendorcode, _mbmvendorcode_param_getter);
				}
			}
		}			
		internal bool _forcedirecttransfers{ get; set; }    
		internal Func<SqlParameter> _forcedirecttransfers_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_forcedirecttransfers, SqlDbType.Bit, _forcedirecttransfers, false);};
			}
		}   

		public virtual bool forcedirecttransfers { 
			get { return _forcedirecttransfers; } 
			set {
				_forcedirecttransfers = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_forcedirecttransfers, PARAMETER_NAME_forcedirecttransfers, _forcedirecttransfers_param_getter);
				}
			}
		}			
		internal int? _lastecabatchnum{ get; set; }    
		internal Func<SqlParameter> _lastecabatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastecabatchnum, SqlDbType.Int, _lastecabatchnum, true);};
			}
		}   

		public virtual int? lastecabatchnum { 
			get { return _lastecabatchnum; } 
			set {
				_lastecabatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastecabatchnum, PARAMETER_NAME_lastecabatchnum, _lastecabatchnum_param_getter);
				}
			}
		}			
		internal string _mobilelicensekey{ get; set; }    
		internal Func<SqlParameter> _mobilelicensekey_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_mobilelicensekey, SqlDbType.VarChar, _mobilelicensekey, true, 256);};
			}
		}   

		public virtual string mobilelicensekey { 
			get { return _mobilelicensekey; } 
			set {
				_mobilelicensekey = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_mobilelicensekey, PARAMETER_NAME_mobilelicensekey, _mobilelicensekey_param_getter);
				}
			}
		}			
		internal int? _lastvoidpcbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastvoidpcbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastvoidpcbatchnum, SqlDbType.Int, _lastvoidpcbatchnum, true);};
			}
		}   

		public virtual int? lastvoidpcbatchnum { 
			get { return _lastvoidpcbatchnum; } 
			set {
				_lastvoidpcbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastvoidpcbatchnum, PARAMETER_NAME_lastvoidpcbatchnum, _lastvoidpcbatchnum_param_getter);
				}
			}
		}			
		internal int? _lastvoidwdbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastvoidwdbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastvoidwdbatchnum, SqlDbType.Int, _lastvoidwdbatchnum, true);};
			}
		}   

		public virtual int? lastvoidwdbatchnum { 
			get { return _lastvoidwdbatchnum; } 
			set {
				_lastvoidwdbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastvoidwdbatchnum, PARAMETER_NAME_lastvoidwdbatchnum, _lastvoidwdbatchnum_param_getter);
				}
			}
		}			
		internal int? _lastvoiddsrbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastvoiddsrbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastvoiddsrbatchnum, SqlDbType.Int, _lastvoiddsrbatchnum, true);};
			}
		}   

		public virtual int? lastvoiddsrbatchnum { 
			get { return _lastvoiddsrbatchnum; } 
			set {
				_lastvoiddsrbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastvoiddsrbatchnum, PARAMETER_NAME_lastvoiddsrbatchnum, _lastvoiddsrbatchnum_param_getter);
				}
			}
		}			
		internal int? _lastbankrecloadbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastbankrecloadbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastbankrecloadbatchnum, SqlDbType.Int, _lastbankrecloadbatchnum, true);};
			}
		}   

		public virtual int? lastbankrecloadbatchnum { 
			get { return _lastbankrecloadbatchnum; } 
			set {
				_lastbankrecloadbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastbankrecloadbatchnum, PARAMETER_NAME_lastbankrecloadbatchnum, _lastbankrecloadbatchnum_param_getter);
				}
			}
		}			
		internal int? _lastvoidctbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastvoidctbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastvoidctbatchnum, SqlDbType.Int, _lastvoidctbatchnum, true);};
			}
		}   

		public virtual int? lastvoidctbatchnum { 
			get { return _lastvoidctbatchnum; } 
			set {
				_lastvoidctbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastvoidctbatchnum, PARAMETER_NAME_lastvoidctbatchnum, _lastvoidctbatchnum_param_getter);
				}
			}
		}			
		internal int? _lasttaxablewageadjbatchnum{ get; set; }    
		internal Func<SqlParameter> _lasttaxablewageadjbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lasttaxablewageadjbatchnum, SqlDbType.Int, _lasttaxablewageadjbatchnum, true);};
			}
		}   

		public virtual int? lasttaxablewageadjbatchnum { 
			get { return _lasttaxablewageadjbatchnum; } 
			set {
				_lasttaxablewageadjbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lasttaxablewageadjbatchnum, PARAMETER_NAME_lasttaxablewageadjbatchnum, _lasttaxablewageadjbatchnum_param_getter);
				}
			}
		}			
		internal int? _lastdsrbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastdsrbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastdsrbatchnum, SqlDbType.Int, _lastdsrbatchnum, true);};
			}
		}   

		public virtual int? lastdsrbatchnum { 
			get { return _lastdsrbatchnum; } 
			set {
				_lastdsrbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastdsrbatchnum, PARAMETER_NAME_lastdsrbatchnum, _lastdsrbatchnum_param_getter);
				}
			}
		}			
		internal int? _lastvoidpaybatchnum{ get; set; }    
		internal Func<SqlParameter> _lastvoidpaybatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastvoidpaybatchnum, SqlDbType.Int, _lastvoidpaybatchnum, true);};
			}
		}   

		public virtual int? lastvoidpaybatchnum { 
			get { return _lastvoidpaybatchnum; } 
			set {
				_lastvoidpaybatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastvoidpaybatchnum, PARAMETER_NAME_lastvoidpaybatchnum, _lastvoidpaybatchnum_param_getter);
				}
			}
		}			
		internal string _federalidnumberencrypt{ get; set; }    
		internal Func<SqlParameter> _federalidnumberencrypt_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_federalidnumberencrypt, SqlDbType.VarChar, _federalidnumberencrypt, true, 100);};
			}
		}   

		public virtual string federalidnumberencrypt { 
			get { return _federalidnumberencrypt; } 
			set {
				_federalidnumberencrypt = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_federalidnumberencrypt, PARAMETER_NAME_federalidnumberencrypt, _federalidnumberencrypt_param_getter);
				}
			}
		}			
		internal int? _lastachnum{ get; set; }    
		internal Func<SqlParameter> _lastachnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastachnum, SqlDbType.Int, _lastachnum, true);};
			}
		}   

		public virtual int? lastachnum { 
			get { return _lastachnum; } 
			set {
				_lastachnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastachnum, PARAMETER_NAME_lastachnum, _lastachnum_param_getter);
				}
			}
		}			
		internal int? _lastloadarbatchcode{ get; set; }    
		internal Func<SqlParameter> _lastloadarbatchcode_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastloadarbatchcode, SqlDbType.Int, _lastloadarbatchcode, true);};
			}
		}   

		public virtual int? lastloadarbatchcode { 
			get { return _lastloadarbatchcode; } 
			set {
				_lastloadarbatchcode = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastloadarbatchcode, PARAMETER_NAME_lastloadarbatchcode, _lastloadarbatchcode_param_getter);
				}
			}
		}			
		internal int? _consolidationentity{ get; set; }    
		internal Func<SqlParameter> _consolidationentity_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_consolidationentity, SqlDbType.Int, _consolidationentity, true);};
			}
		}   

		public virtual int? consolidationentity { 
			get { return _consolidationentity; } 
			set {
				_consolidationentity = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_consolidationentity, PARAMETER_NAME_consolidationentity, _consolidationentity_param_getter);
				}
			}
		}			
		internal bool _isconsolidationentity{ get; set; }    
		internal Func<SqlParameter> _isconsolidationentity_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_isconsolidationentity, SqlDbType.Bit, _isconsolidationentity, false);};
			}
		}   

		public virtual bool isconsolidationentity { 
			get { return _isconsolidationentity; } 
			set {
				_isconsolidationentity = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_isconsolidationentity, PARAMETER_NAME_isconsolidationentity, _isconsolidationentity_param_getter);
				}
			}
		}			
		internal int? _currencyid{ get; set; }    
		internal Func<SqlParameter> _currencyid_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_currencyid, SqlDbType.Int, _currencyid, true);};
			}
		}   

		public virtual int? currencyid { 
			get { return _currencyid; } 
			set {
				_currencyid = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_currencyid, PARAMETER_NAME_currencyid, _currencyid_param_getter);
				}
			}
		}			
		internal int? _countryid{ get; set; }    
		internal Func<SqlParameter> _countryid_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_countryid, SqlDbType.Int, _countryid, true);};
			}
		}   

		public virtual int? countryid { 
			get { return _countryid; } 
			set {
				_countryid = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_countryid, PARAMETER_NAME_countryid, _countryid_param_getter);
				}
			}
		}			
		internal string _timezone{ get; set; }    
		internal Func<SqlParameter> _timezone_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_timezone, SqlDbType.VarChar, _timezone, true, 100);};
			}
		}   

		public virtual string timezone { 
			get { return _timezone; } 
			set {
				_timezone = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_timezone, PARAMETER_NAME_timezone, _timezone_param_getter);
				}
			}
		}			
		internal bool _adjustfordst{ get; set; }    
		internal Func<SqlParameter> _adjustfordst_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_adjustfordst, SqlDbType.Bit, _adjustfordst, false);};
			}
		}   

		public virtual bool adjustfordst { 
			get { return _adjustfordst; } 
			set {
				_adjustfordst = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_adjustfordst, PARAMETER_NAME_adjustfordst, _adjustfordst_param_getter);
				}
			}
		}			
		internal string _backofficelicensekey{ get; set; }    
		internal Func<SqlParameter> _backofficelicensekey_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_backofficelicensekey, SqlDbType.VarChar, _backofficelicensekey, true, 256);};
			}
		}   

		public virtual string backofficelicensekey { 
			get { return _backofficelicensekey; } 
			set {
				_backofficelicensekey = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_backofficelicensekey, PARAMETER_NAME_backofficelicensekey, _backofficelicensekey_param_getter);
				}
			}
		}			
		internal string _payrolllicensekey{ get; set; }    
		internal Func<SqlParameter> _payrolllicensekey_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_payrolllicensekey, SqlDbType.VarChar, _payrolllicensekey, true, 256);};
			}
		}   

		public virtual string payrolllicensekey { 
			get { return _payrolllicensekey; } 
			set {
				_payrolllicensekey = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_payrolllicensekey, PARAMETER_NAME_payrolllicensekey, _payrolllicensekey_param_getter);
				}
			}
		}			
		internal string _laborlicensekey{ get; set; }    
		internal Func<SqlParameter> _laborlicensekey_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_laborlicensekey, SqlDbType.VarChar, _laborlicensekey, true, 256);};
			}
		}   

		public virtual string laborlicensekey { 
			get { return _laborlicensekey; } 
			set {
				_laborlicensekey = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_laborlicensekey, PARAMETER_NAME_laborlicensekey, _laborlicensekey_param_getter);
				}
			}
		}			
		internal string _advantagelicensekey{ get; set; }    
		internal Func<SqlParameter> _advantagelicensekey_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_advantagelicensekey, SqlDbType.VarChar, _advantagelicensekey, true, 256);};
			}
		}   

		public virtual string advantagelicensekey { 
			get { return _advantagelicensekey; } 
			set {
				_advantagelicensekey = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_advantagelicensekey, PARAMETER_NAME_advantagelicensekey, _advantagelicensekey_param_getter);
				}
			}
		}			
		internal int? _posmtpconfigid{ get; set; }    
		internal Func<SqlParameter> _posmtpconfigid_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_posmtpconfigid, SqlDbType.Int, _posmtpconfigid, true);};
			}
		}   

		public virtual int? posmtpconfigid { 
			get { return _posmtpconfigid; } 
			set {
				_posmtpconfigid = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_posmtpconfigid, PARAMETER_NAME_posmtpconfigid, _posmtpconfigid_param_getter);
				}
			}
		}			
		internal int? _reqsmtpconfigid{ get; set; }    
		internal Func<SqlParameter> _reqsmtpconfigid_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_reqsmtpconfigid, SqlDbType.Int, _reqsmtpconfigid, true);};
			}
		}   

		public virtual int? reqsmtpconfigid { 
			get { return _reqsmtpconfigid; } 
			set {
				_reqsmtpconfigid = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_reqsmtpconfigid, PARAMETER_NAME_reqsmtpconfigid, _reqsmtpconfigid_param_getter);
				}
			}
		}			
		internal string _hotshotcomments{ get; set; }    
		internal Func<SqlParameter> _hotshotcomments_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_hotshotcomments, SqlDbType.VarChar, _hotshotcomments, true, 4000);};
			}
		}   

		public virtual string hotshotcomments { 
			get { return _hotshotcomments; } 
			set {
				_hotshotcomments = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_hotshotcomments, PARAMETER_NAME_hotshotcomments, _hotshotcomments_param_getter);
				}
			}
		}			
		internal int? _lastrequisitionnum{ get; set; }    
		internal Func<SqlParameter> _lastrequisitionnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastrequisitionnum, SqlDbType.Int, _lastrequisitionnum, true);};
			}
		}   

		public virtual int? lastrequisitionnum { 
			get { return _lastrequisitionnum; } 
			set {
				_lastrequisitionnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastrequisitionnum, PARAMETER_NAME_lastrequisitionnum, _lastrequisitionnum_param_getter);
				}
			}
		}			
		internal int? _lastvoidbrbatchnum{ get; set; }    
		internal Func<SqlParameter> _lastvoidbrbatchnum_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_lastvoidbrbatchnum, SqlDbType.Int, _lastvoidbrbatchnum, true);};
			}
		}   

		public virtual int? lastvoidbrbatchnum { 
			get { return _lastvoidbrbatchnum; } 
			set {
				_lastvoidbrbatchnum = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_lastvoidbrbatchnum, PARAMETER_NAME_lastvoidbrbatchnum, _lastvoidbrbatchnum_param_getter);
				}
			}
		}			
		internal string _timeandattendancelicensekey{ get; set; }    
		internal Func<SqlParameter> _timeandattendancelicensekey_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_timeandattendancelicensekey, SqlDbType.VarChar, _timeandattendancelicensekey, true, 256);};
			}
		}   

		public virtual string timeandattendancelicensekey { 
			get { return _timeandattendancelicensekey; } 
			set {
				_timeandattendancelicensekey = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_timeandattendancelicensekey, PARAMETER_NAME_timeandattendancelicensekey, _timeandattendancelicensekey_param_getter);
				}
			}
		}			
		internal string _schedulinglicensekey{ get; set; }    
		internal Func<SqlParameter> _schedulinglicensekey_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_schedulinglicensekey, SqlDbType.VarChar, _schedulinglicensekey, true, 256);};
			}
		}   

		public virtual string schedulinglicensekey { 
			get { return _schedulinglicensekey; } 
			set {
				_schedulinglicensekey = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_schedulinglicensekey, PARAMETER_NAME_schedulinglicensekey, _schedulinglicensekey_param_getter);
				}
			}
		} 
		#endregion  Gen'd Fields in table

		public override string GetTableName() { 
				return "dbo.stores";
		}
	
	
	}
	
	public partial class stores : BaseRepositoryTableReader<Repository, Compeat.Demo.Data.storesDto, int?>
	{

		#region Repo Turn Around
		 /// <summary>
		/// This will return the table object with the id that was passed in.
		/// </summary>
		/// <param name="conn">the open sql connection</param>
		/// <param name="pk_val">the Pk value for the desired row</param>
		/// <param name="collectionsToLoad">child collections to load. ex: new ChildLoaderList&lt;apiemployeesDto&gt;() { x => x.children_apiemployeeassignments, x => x.children_apiemployeecustomfields }</param>
		/// <param name="collectionToLoadUsingStrings">list of collection properties to load for earch returned item, similar to collectionsToLoad but delivered differently</param>
		/// <param name="recursiveDepth">children collection depth to load, 0 means no recursive loading.</param>
		/// <returns>a single instance of the table object</returns>
		public override Compeat.Demo.Data.storesDto Get(SqlConnection conn, int? pk_val, ChildLoaderList<Compeat.Demo.Data.storesDto> collectionsToLoad = null, IEnumerable<string> collectionToLoadUsingStrings = null, int recursiveDepth = 0)
		{
			var lst = _GetList(conn, _SELECT, new TableWhereParamsAndOrder(){ WhereClause = string.Format("[{0}] = {1}", Compeat.Demo.Data.storesDto._PK_COLUMN_NAME, Compeat.Demo.Data.storesDto._PK_PARAMETER_NAME), OrderBy = null, ParamList = new[] { Compeat.Demo.Data.storesDto._myPk_param_getter(pk_val) } }, 1, recursiveDepth > 0, recursiveDepth, collectionsToLoad, collectionToLoadUsingStrings);
			if (lst == null)
			{
				return null;
			}
			else { 
				return lst.FirstOrDefault();
			}			
		}   
		
		/// <summary>
		/// This will return the table object with the where clause that was passed in.
		/// </summary>
		/// <param name="conn">the open sql connection</param>
		/// <param name="whereClause">the where clause value for the desired row, the 'where' itself is not required here, it will be added</param>
		/// <param name="orderBy">the order by to pass through to sql, the 'order by' itself is not required here, it will be added </param>
		/// <param name="collectionsToLoad">child collections to load. ex: new ChildLoaderList&lt;apiemployeesDto&gt;() { x => x.children_apiemployeeassignments, x => x.children_apiemployeecustomfields }</param>
		/// <param name="collectionToLoadUsingStrings">list of collection properties to load for earch returned item, similar to collectionsToLoad but delivered differently</param>
		/// <param name="paramList">raw sql parameters  if needed </param>
		/// <param name="recursiveDepth">children collection depth to load, 0 means no recursive loading.</param>
		/// <returns>a single instance of the table object</returns>
		public override Compeat.Demo.Data.storesDto GetFirst(SqlConnection conn, string whereClause = null, string orderBy = null, ChildLoaderList<Compeat.Demo.Data.storesDto> collectionsToLoad = null, IEnumerable<string> collectionToLoadUsingStrings = null, SqlParameter[] paramList = null, int recursiveDepth = 0) {
			var lst = _GetList(conn, _SELECT, new TableWhereParamsAndOrder(){ WhereClause = whereClause, OrderBy = orderBy, ParamList = paramList }, 1, recursiveDepth > 0, recursiveDepth, collectionsToLoad, collectionToLoadUsingStrings);
			if (lst == null)
			{
				return null;
			}
			else { 
				return lst.FirstOrDefault();
			}			
		}
		
		/// <summary>
		/// This will return the table object list with the where clause that was passed in.
		/// </summary>
		/// <param name="conn">the open sql connection</param>
		/// <param name="whereClause">the where clause value for the desired row, the 'where' itself is not required here, it will be added</param>
		/// <param name="orderBy">the order by to pass through to sql, the 'order by' itself is not required here, it will be added </param>
		/// <param name="collectionsToLoad">child collections to load. ex: new ChildLoaderList&lt;apiemployeesDto&gt;() { x => x.children_apiemployeeassignments, x => x.children_apiemployeecustomfields }</param>
		/// <param name="collectionToLoadUsingStrings">list of collection properties to load for earch returned item, similar to collectionsToLoad but delivered differently</param>
		/// <param name="paramList">raw sql parameters  if needed </param>
		/// <param name="recursiveDepth">children collection depth to load, 0 means no recursive loading.</param>
		/// <returns>a single instance of the table object</returns>
		public override List<Compeat.Demo.Data.storesDto> GetList(SqlConnection conn, string whereClause = null, string orderBy = null, ChildLoaderList<Compeat.Demo.Data.storesDto> collectionsToLoad = null, IEnumerable<string> collectionToLoadUsingStrings = null, SqlParameter[] paramList = null, int recursiveDepth = 0) {
			return _GetList(conn, _SELECT, new TableWhereParamsAndOrder(){ WhereClause = whereClause, OrderBy = orderBy, ParamList = paramList }, ulong.MaxValue, recursiveDepth > 0, recursiveDepth, collectionsToLoad, collectionToLoadUsingStrings);
			
		}
		
		/// <summary>
		/// This will return the table object list with the where expression and information that was passed in.
		/// </summary>
		/// <param name="conn">the open sql connection</param>
		/// <param name="whereExpression">the lambda expression that will be used as the sql where clause, keep it simple for now. </param>
		/// <param name="orderBy">the order by to pass through to sql, the 'order by' itself is not required here, it will be added </param>
		/// <param name="additional_whereClause">THIS WILL BE 'AND'd after the whereExpression. the where clause value for the desired row, the 'where' itself is not required here, it will be added</param>
		/// <param name="collectionsToLoad">child collections to load. ex: new ChildLoaderList&lt;apiemployeesDto&gt;() { x => x.children_apiemployeeassignments, x => x.children_apiemployeecustomfields }</param>
		/// <param name="collectionToLoadUsingStrings">list of collection properties to load for earch returned item, similar to collectionsToLoad but delivered differently</param>
		/// <param name="paramList">raw sql parameters  if needed </param>
		/// <param name="recursiveDepth">children collection depth to load, 0 means no recursive loading.</param>
		/// <returns>a single instance of the table object</returns>
		public override List<Compeat.Demo.Data.storesDto> GetList(SqlConnection conn, Expression<Func<Compeat.Demo.Data.storesDto, bool>> whereExpression, string orderBy = null, string additional_whereClause = null, ChildLoaderList<Compeat.Demo.Data.storesDto> collectionsToLoad = null, IEnumerable<string> collectionToLoadUsingStrings = null, SqlParameter[] paramList = null, int recursiveDepth = 0) {
			return _GetList(conn, _SELECT, InternalTools.ProcessLambda<Compeat.Demo.Data.storesDto>("dbo.stores", whereExpression, additional_whereClause, orderBy, paramList), ulong.MaxValue, recursiveDepth > 0, recursiveDepth, collectionsToLoad, collectionToLoadUsingStrings);
		}   	
		#endregion
	
		#region Reading 
		internal const string _SELECT = "select{0} [storenum], [name], [addr1], [addr2], [city], [state], [zip], [phone], [fax], [manager], [squarefootage], [seats], [dateopened], [datereopened], [dateclosed], [storegroup1], [storegroup2], [openmondays], [opentuesdays], [openwednesdays], [openthursdays], [openfridays], [opensaturdays], [opensundays], [pos], [federalidnumber], [topmargin], [leftmargin], [bottommargin], [backgroundcolor], [lastinvoicebatchnum], [lastinvoicevouchernum], [lastcheckbatchnum], [lastcheckvouchernum], [lastgjbatchnum], [lastgjjournalctrlno], [lastinvbatchnum], [lastpaybatchnum], [lastponum], [lastpmtbatchcode], [lastpmtbatchpostnum], [lastreconcilebatchnum], [lastreconcilejournalnum], [lastvoidccbatchnum], [lastvoidmcbatchnum], [lastvoidinvbatchnum], [lasthcbatchnum], [lastprbatchnum], [lastmpbatchnum], [lastgcbatchnum], [greatplainsdbname], [greatplainsmchekbkid], [greatplainsmcglacctnum], [lastpayrollbatchnum], [lastepbatchnum], [lastvoidepbatchnum], [dynamicssystemdsn], [lastprepitemcostupdate], [externalstorenum], [lastcommbatchnum], [greatplainsmccurridx], [greatplainsmccurncyid], [lastvoidpyrbatchnum], [lastpradjustbatchnum], [lastistnum], [lastwastenum], [lastcustinvbatchnum], [lastprepbatchnum], [entitytype], [commissarynum], [allowdirecttransfers], [lastportioncutbatchnum], [shippingmethod], [lastcommorderbatchnum], [allowcommqtychange], [lasthcinvoicenum], [lastvoidgjbatchnum], [allowcomminvdelete], [lastistbatchnum], [lastunshipcommbatchnum], [lastunshipistbatchnum], [usfoodvendorcode], [lastoutsideordernum], [lastcomminvoicenum], [lastvoidarpaymentbatchnum], [lastpayliabbatchnum], [lastprepitemtreebuild], [metafileverticaladjust], [metafilehorizontaladjust], [esyscovendorcode], [allowoutsideorders], [allowuserstomodifylineitemdescriptions], [allowaddcustsoutorders], [commsalestax], [lastvoidagencyliabbatchnum], [adpstorenum], [recstamp], [bekvendorcode], [cheneybrosvendorcode], [fsavendorcode], [gfsvendorcode], [pfgvendorcode], [shamrockfoodsvendorcode], [efoodusavendorcode], [commprepaidsalesacct], [agarsupplyvendorcode], [edwarddonvendorcode], [mbmvendorcode], [forcedirecttransfers], [lastecabatchnum], [mobilelicensekey], [lastvoidpcbatchnum], [lastvoidwdbatchnum], [lastvoiddsrbatchnum], [lastbankrecloadbatchnum], [lastvoidctbatchnum], [lasttaxablewageadjbatchnum], [lastdsrbatchnum], [lastvoidpaybatchnum], [federalidnumberencrypt], [lastachnum], [lastloadarbatchcode], [consolidationentity], [isconsolidationentity], [currencyid], [countryid], [timezone], [adjustfordst], [backofficelicensekey], [payrolllicensekey], [laborlicensekey], [advantagelicensekey], [posmtpconfigid], [reqsmtpconfigid], [hotshotcomments], [lastrequisitionnum], [lastvoidbrbatchnum], [timeandattendancelicensekey], [schedulinglicensekey] from [dbo].[stores] {1} {2}; ";
		
		internal static List<Compeat.Demo.Data.storesDto> _GetList(SqlConnection conn, string statement, TableWhereParamsAndOrder where, ulong row_count, bool loadRecursive = false, int recursiveDepth = int.MaxValue, ChildLoaderList<Compeat.Demo.Data.storesDto> collectionsToLoad = null, IEnumerable<string> collectionToLoadUsingStrings = null) {
			var __retVal = new List<Compeat.Demo.Data.storesDto>();
			string sql = string.Format(
										statement
										, row_count == ulong.MaxValue ? "" : string.Format(" top {0}", row_count)
										, string.IsNullOrWhiteSpace(where.WhereClause) ? "" : String.Format("where {0}", where.WhereClause)
										, string.IsNullOrWhiteSpace(where.OrderBy) ? "" : String.Format("order by {0}", where.OrderBy)
								);
								
			InternalTools.ScriptRunReader(
				SqlEnums.SqlActivityType.SELECT 
				, sql
				, conn
				, where.ParamList
				, (sdr) => {
						if (sdr.HasRows) {
							while (sdr.Read())
							{
								__retVal.Add(Compeat.Demo.Data.storesDto.GetFromReader(sdr));
							}
						}
					}
				, Compeat.Demo.Data.storesDto.MyTimeout());

			if(__retVal != null){
				if(collectionsToLoad != null) {
					foreach(var __itm in __retVal){
						var properties = collectionsToLoad.Select(s => s.Body.ToString().Replace(string.Format("{0}.", s.Parameters[0].Name), ""));
						__itm.LoadChildProperty(conn, properties);
					}
				} 
				if(collectionToLoadUsingStrings != null) {
					foreach(var __itm in __retVal){
						__itm.LoadChildProperty(conn, collectionToLoadUsingStrings);
					}
				} 
				if(loadRecursive) {
					foreach(var __itm in __retVal){
						__itm.LoadChildren(conn, recursiveDepth);
					}
				}
			}
			
			return __retVal;
		}
		
		#endregion Reading

	}
	
	
	#region Repository needs
	
	public partial interface IRepository {
		Compeat.Demo.Data.stores stores { get; }
	}
	
	public partial class Repository {
		internal Compeat.Demo.Data.stores _stores  = null;
		public Compeat.Demo.Data.stores stores  {
			get{
				if(_stores == null){
					_stores = new Compeat.Demo.Data.stores ();
				}
				return _stores ;
			}
		}
	}
	#endregion Repository needs

}
