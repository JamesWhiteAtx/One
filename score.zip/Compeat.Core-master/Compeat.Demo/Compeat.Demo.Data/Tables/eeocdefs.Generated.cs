﻿using Compeat.Data.Framework;
using Compeat.Data.Framework.InternalUtils;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using Compeat.Demo.Data.Shared;
namespace Compeat.Demo.Data {
	[Serializable]
	public partial class eeocdefsDto : TableBase<Compeat.Demo.Data.eeocdefsDto, int?> {
		
	
	
		/// <summary>
		/// calls its private twin in cases where a static is needed
		/// </summary>
		/// <returns></returns>
		internal static int MyTimeout() {
			return (new Compeat.Demo.Data.eeocdefsDto()).GetTimeout();
		}
		
		#region Constants
		internal const int COLUMN_COUNT = 3;
		protected override int ColumnCount { get { return COLUMN_COUNT; } }
		public const int COLUMN_INDEX_id = 0, COLUMN_INDEX_description = 1, COLUMN_INDEX_recstamp = 2;
		public const string COLUMN_NAME_id = "id", COLUMN_NAME_description = "description", COLUMN_NAME_recstamp = "recstamp";
		public const string PARAMETER_NAME_id = "@id", PARAMETER_NAME_description = "@description", PARAMETER_NAME_recstamp = "@recstamp";
	
		internal const string _PK_COLUMN_NAME = COLUMN_NAME_id;
		internal const string _PK_PARAMETER_NAME = "@PK_PARAM";
		internal const string _TIMESTAMP_COLUMN_NAME = COLUMN_NAME_recstamp;
		internal const string _TIMESTAMP_PARAMETER_NAME = PARAMETER_NAME_recstamp;
		internal const string _DELETE = "DELETE FROM [dbo].[eeocdefs] WHERE [id] = @PK_PARAM";
		internal const string _INSERT = "insert into [dbo].[eeocdefs] ([description]) values (@description); select top 1 [recstamp], convert(bigint, [id]) from [dbo].[eeocdefs] where [id] = @@identity;";
		internal const string _UPDATE = "update [dbo].[eeocdefs] set {0} where [id] = @PK_PARAM and [recstamp] = @recstamp;select top 1 [recstamp] from [dbo].[eeocdefs] where [id] = @PK_PARAM;";
		internal const string _UPDATE_FULL = "update [dbo].[eeocdefs] set [description]=@description where [id] = @PK_PARAM and [recstamp] = @recstamp;select top 1 [recstamp] from [dbo].[eeocdefs] where [id] = @PK_PARAM;";
		#endregion
		
		/// <summary>
		/// Will Update, not skinny safe, meaning if an update is done, it will update all columns
		/// </summary>
		public eeocdefsDto() : this(true) {
			//not skinny safe
		}
			
		/// <summary>
		/// Will Insert
		/// </summary>
		public static Compeat.Demo.Data.eeocdefsDto create() {
			var newInstance = new Compeat.Demo.Data.eeocdefsDto();
			newInstance.CmpNew = true;
			return newInstance;
		}    
		/// <summary>
		/// skinny safe: meaning if an update is done, it will only update the fields that had their setters called.
		/// </summary>
		public eeocdefsDto(int my_pk, string my_timestamp) : base(){
			//skinny safe
			IsSkinnySafe = true;
			MyPk = my_pk;
			MyTimeStamp = my_timestamp;
		}

		internal eeocdefsDto(bool allow_default_set) : base() {
			//not skinny safe
			if(allow_default_set) {
				#region Gen'd DB defaults
				this.description=@"";
				#endregion
	 
				SetDefaults();
			}
		}
   
		#region Loaders 		
		internal static Compeat.Demo.Data.eeocdefsDto GetFromReader(SqlDataReader dr) {
			var x = new Compeat.Demo.Data.eeocdefsDto(false);

			x._myPk = dr.GetInt32(COLUMN_INDEX_id);
			x._id = dr.GetInt32(COLUMN_INDEX_id);
			x._description = dr.GetString(COLUMN_INDEX_description);
			x._recstamp = (byte[])dr.GetValue(COLUMN_INDEX_recstamp);
			//skinny safe since loaded from reader
			x.IsSkinnySafe = true;
			return x;
		}   
		
		internal void LoadChildProperty(SqlConnection conn, IEnumerable<string> collectionsToLoad)
		{
			ChildLoaderList<Compeat.Demo.Data.eeocdefsDto>.LoadProperty(conn, collectionsToLoad, AllChildCollections);
		}  
		
		#endregion Loaders   
		
		#region Writing
		
		
		protected override void Insert(SqlConnection conn) {
			SqlParameter[] parm_list = 
				new SqlParameter[] { 
				 MyPk_param_getter()
						
					, _description_param_getter()
				};
				
			InternalTools.ScriptRunReader(SqlEnums.SqlActivityType.INSERT, _INSERT, conn, parm_list
				, (sdr) => {	   
						if (!sdr.HasRows || !sdr.Read()) {
							throw new DbUpdateFailedNoChangesMade("Insert into eeocdefs, but now new rows were detected using PK or identity fields.", conn, null);
						}else{
							_recstamp = (byte[])sdr.GetValue(0);//refresh the timestamp
							_id = (int?)((long?)sdr.GetValue(1));//refresh the identity
						}
					}
				, GetTimeout());
		
		}  
		
		protected override void Update(SqlConnection conn) {
			if(IsSkinnySafe && UpdatedProperties.Count() == 0) {
				throw new DbUpdateFailedNoChangesMade("Update to eeocdefs, but no values have changed. Verify InSavableState before calling.", conn, null);
			}
			if(MyPk == null) {
				throw new DbUpdateFailedPkMissing(_UPDATE, conn, null);
			}
			if(MyTimeStamp == null) {
				throw new DbUpdateFailedTimestampMissing(_UPDATE, conn, null);
			}
			
			  
			if(IsSkinnySafe) {
				AddChangedProperty(true, true, false, _PK_COLUMN_NAME, _PK_PARAMETER_NAME, this.MyPk_param_getter);    

				AddChangedProperty(false, false, true, _TIMESTAMP_COLUMN_NAME, _TIMESTAMP_PARAMETER_NAME, this.MyTimeStamp_param_getter);

				if(!UpdatedProperties.Any(s => !s.IsPrimaryKey && !s.IsIdentity && !s.IsTimestamp)) {
					return; //nothing changed
				}
				var parm_list = UpdatedProperties
									.Where(s => !s.IsIdentity && s.ParameterName != _PK_PARAMETER_NAME && !s.IsTimestamp && s.ParameterName != _TIMESTAMP_PARAMETER_NAME)
									.Select(s => s.MyParamGetter())
									.ToList();  
				parm_list.Add(MyPk_param_getter());
				string formatted_update = string.Format(_UPDATE, string.Join(",", UpdatedProperties.Where(s => !s.IsIdentity && !s.IsTimestamp).Select(s => s.UpdateCombo) ) );
				InternalTools.ScriptRunReader(SqlEnums.SqlActivityType.UPDATE, formatted_update, conn, parm_list.ToArray()
					, (sdr) => {	 
						if (!sdr.HasRows || !sdr.Read()) {
							throw new DbUpdateFailedNoChangesMade("Insert into eeocdefs, but now new rows were detected using PK or identity fields.", conn, null);
						}else{
							_recstamp = (byte[])sdr.GetValue(0);//refresh the timestamp
						}
					}
				, GetTimeout());
			}
			else {
				SqlParameter[] parm_list = 
					new SqlParameter[] { 
						MyPk_param_getter()
						, MyTimeStamp_param_getter()
						, _description_param_getter()
					};
				InternalTools.ScriptRunReader(SqlEnums.SqlActivityType.UPDATE, _UPDATE_FULL, conn, parm_list
					, (sdr) => {	 
						if (!sdr.HasRows || !sdr.Read()) {
							throw new DbUpdateFailedNoChangesMade("Insert into eeocdefs, but now new rows were detected using PK or identity fields.", conn, null);
						}else{
							_recstamp = (byte[])sdr.GetValue(0);//refresh the timestamp
						}
					}
				, GetTimeout());
			}
		}
		protected override void Delete(SqlConnection conn) {
			InternalTools.ScriptRun(SqlEnums.SqlActivityType.DELETE, _DELETE, conn, new[] { MyPk_param_getter() }, GetTimeout());
			
		}    

		#endregion Writing
		
		#region Gen'd Fields in table
		
		internal static Func<int?, SqlParameter> _myPk_param_getter { 
			get {
				return (pk_val) => { return InternalTools.MakeParam(_PK_PARAMETER_NAME, SqlDbType.Int, pk_val, false);};				
				
			}
		}
		
		internal Func<SqlParameter> MyPk_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(_PK_PARAMETER_NAME, SqlDbType.Int, MyPk, false);};
			}
		}
		
		internal int? _myPk{ get; set; }    
		protected override int? MyPk {
			get{ 
				if(IsSkinnySafe){
					return _myPk; 
				}else{
					return id; 
				}
			}
			set{ 
				if(IsSkinnySafe){
					_myPk = value; 
				}
				id = value;
				
			}
		}
		
		internal Func<SqlParameter> MyTimeStamp_param_getter { 
			get {
				return _recstamp_param_getter;
			}
		}
		protected override bool RequireTimeStamp { get{ return true; } }
		protected override string MyTimeStamp {
			get{ return recstamp; }
			set{ recstamp = value; }
		}
		
			
		internal int? _id{ get; set; }    
		internal Func<SqlParameter> _id_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_id, SqlDbType.Int, _id, false);};
			}
		}   

		public virtual int? id { 
			get { return _id; } 
			set {
				_id = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, true, false, COLUMN_NAME_id, PARAMETER_NAME_id, _id_param_getter);
				}
			}
		}			
		internal string _description{ get; set; }    
		internal Func<SqlParameter> _description_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_description, SqlDbType.VarChar, _description, false, 25);};
			}
		}   

		public virtual string description { 
			get { return _description; } 
			set {
				_description = value;
				if(IsSkinnySafe) {
					AddChangedProperty(false, false, false, COLUMN_NAME_description, PARAMETER_NAME_description, _description_param_getter);
				}
			}
		}			
		internal byte[] _recstamp{ get; set; }    
		internal Func<SqlParameter> _recstamp_param_getter { 
			get {
				return () => { return InternalTools.MakeParam(PARAMETER_NAME_recstamp, SqlDbType.Timestamp, _recstamp, false);};
			}
		}   
		public virtual string recstamp { 
			get { 
				return _recstamp == null ? null : Convert.ToBase64String(_recstamp); 
			}
			set {
				if(string.IsNullOrWhiteSpace(value)){
					_recstamp = null;
				}
				else {
					_recstamp = Convert.FromBase64String(value);
				}
				if(IsSkinnySafe){
					AddChangedProperty(false, false, true, COLUMN_NAME_recstamp, PARAMETER_NAME_recstamp, _recstamp_param_getter);
				}
			}
		} 
		#endregion  Gen'd Fields in table

		public override string GetTableName() { 
				return "dbo.eeocdefs";
		}
	
	
	}
	
	public partial class eeocdefs : BaseRepositoryTableReader<Repository, Compeat.Demo.Data.eeocdefsDto, int?>
	{

		#region Repo Turn Around
		 /// <summary>
		/// This will return the table object with the id that was passed in.
		/// </summary>
		/// <param name="conn">the open sql connection</param>
		/// <param name="pk_val">the Pk value for the desired row</param>
		/// <param name="collectionsToLoad">child collections to load. ex: new ChildLoaderList&lt;apiemployeesDto&gt;() { x => x.children_apiemployeeassignments, x => x.children_apiemployeecustomfields }</param>
		/// <param name="collectionToLoadUsingStrings">list of collection properties to load for earch returned item, similar to collectionsToLoad but delivered differently</param>
		/// <param name="recursiveDepth">children collection depth to load, 0 means no recursive loading.</param>
		/// <returns>a single instance of the table object</returns>
		public override Compeat.Demo.Data.eeocdefsDto Get(SqlConnection conn, int? pk_val, ChildLoaderList<Compeat.Demo.Data.eeocdefsDto> collectionsToLoad = null, IEnumerable<string> collectionToLoadUsingStrings = null, int recursiveDepth = 0)
		{
			var lst = _GetList(conn, _SELECT, new TableWhereParamsAndOrder(){ WhereClause = string.Format("[{0}] = {1}", Compeat.Demo.Data.eeocdefsDto._PK_COLUMN_NAME, Compeat.Demo.Data.eeocdefsDto._PK_PARAMETER_NAME), OrderBy = null, ParamList = new[] { Compeat.Demo.Data.eeocdefsDto._myPk_param_getter(pk_val) } }, 1, recursiveDepth > 0, recursiveDepth, collectionsToLoad, collectionToLoadUsingStrings);
			if (lst == null)
			{
				return null;
			}
			else { 
				return lst.FirstOrDefault();
			}			
		}   
		
		/// <summary>
		/// This will return the table object with the where clause that was passed in.
		/// </summary>
		/// <param name="conn">the open sql connection</param>
		/// <param name="whereClause">the where clause value for the desired row, the 'where' itself is not required here, it will be added</param>
		/// <param name="orderBy">the order by to pass through to sql, the 'order by' itself is not required here, it will be added </param>
		/// <param name="collectionsToLoad">child collections to load. ex: new ChildLoaderList&lt;apiemployeesDto&gt;() { x => x.children_apiemployeeassignments, x => x.children_apiemployeecustomfields }</param>
		/// <param name="collectionToLoadUsingStrings">list of collection properties to load for earch returned item, similar to collectionsToLoad but delivered differently</param>
		/// <param name="paramList">raw sql parameters  if needed </param>
		/// <param name="recursiveDepth">children collection depth to load, 0 means no recursive loading.</param>
		/// <returns>a single instance of the table object</returns>
		public override Compeat.Demo.Data.eeocdefsDto GetFirst(SqlConnection conn, string whereClause = null, string orderBy = null, ChildLoaderList<Compeat.Demo.Data.eeocdefsDto> collectionsToLoad = null, IEnumerable<string> collectionToLoadUsingStrings = null, SqlParameter[] paramList = null, int recursiveDepth = 0) {
			var lst = _GetList(conn, _SELECT, new TableWhereParamsAndOrder(){ WhereClause = whereClause, OrderBy = orderBy, ParamList = paramList }, 1, recursiveDepth > 0, recursiveDepth, collectionsToLoad, collectionToLoadUsingStrings);
			if (lst == null)
			{
				return null;
			}
			else { 
				return lst.FirstOrDefault();
			}			
		}
		
		/// <summary>
		/// This will return the table object list with the where clause that was passed in.
		/// </summary>
		/// <param name="conn">the open sql connection</param>
		/// <param name="whereClause">the where clause value for the desired row, the 'where' itself is not required here, it will be added</param>
		/// <param name="orderBy">the order by to pass through to sql, the 'order by' itself is not required here, it will be added </param>
		/// <param name="collectionsToLoad">child collections to load. ex: new ChildLoaderList&lt;apiemployeesDto&gt;() { x => x.children_apiemployeeassignments, x => x.children_apiemployeecustomfields }</param>
		/// <param name="collectionToLoadUsingStrings">list of collection properties to load for earch returned item, similar to collectionsToLoad but delivered differently</param>
		/// <param name="paramList">raw sql parameters  if needed </param>
		/// <param name="recursiveDepth">children collection depth to load, 0 means no recursive loading.</param>
		/// <returns>a single instance of the table object</returns>
		public override List<Compeat.Demo.Data.eeocdefsDto> GetList(SqlConnection conn, string whereClause = null, string orderBy = null, ChildLoaderList<Compeat.Demo.Data.eeocdefsDto> collectionsToLoad = null, IEnumerable<string> collectionToLoadUsingStrings = null, SqlParameter[] paramList = null, int recursiveDepth = 0) {
			return _GetList(conn, _SELECT, new TableWhereParamsAndOrder(){ WhereClause = whereClause, OrderBy = orderBy, ParamList = paramList }, ulong.MaxValue, recursiveDepth > 0, recursiveDepth, collectionsToLoad, collectionToLoadUsingStrings);
			
		}
		
		/// <summary>
		/// This will return the table object list with the where expression and information that was passed in.
		/// </summary>
		/// <param name="conn">the open sql connection</param>
		/// <param name="whereExpression">the lambda expression that will be used as the sql where clause, keep it simple for now. </param>
		/// <param name="orderBy">the order by to pass through to sql, the 'order by' itself is not required here, it will be added </param>
		/// <param name="additional_whereClause">THIS WILL BE 'AND'd after the whereExpression. the where clause value for the desired row, the 'where' itself is not required here, it will be added</param>
		/// <param name="collectionsToLoad">child collections to load. ex: new ChildLoaderList&lt;apiemployeesDto&gt;() { x => x.children_apiemployeeassignments, x => x.children_apiemployeecustomfields }</param>
		/// <param name="collectionToLoadUsingStrings">list of collection properties to load for earch returned item, similar to collectionsToLoad but delivered differently</param>
		/// <param name="paramList">raw sql parameters  if needed </param>
		/// <param name="recursiveDepth">children collection depth to load, 0 means no recursive loading.</param>
		/// <returns>a single instance of the table object</returns>
		public override List<Compeat.Demo.Data.eeocdefsDto> GetList(SqlConnection conn, Expression<Func<Compeat.Demo.Data.eeocdefsDto, bool>> whereExpression, string orderBy = null, string additional_whereClause = null, ChildLoaderList<Compeat.Demo.Data.eeocdefsDto> collectionsToLoad = null, IEnumerable<string> collectionToLoadUsingStrings = null, SqlParameter[] paramList = null, int recursiveDepth = 0) {
			return _GetList(conn, _SELECT, InternalTools.ProcessLambda<Compeat.Demo.Data.eeocdefsDto>("dbo.eeocdefs", whereExpression, additional_whereClause, orderBy, paramList), ulong.MaxValue, recursiveDepth > 0, recursiveDepth, collectionsToLoad, collectionToLoadUsingStrings);
		}   	
		#endregion
	
		#region Reading 
		internal const string _SELECT = "select{0} [id], [description], [recstamp] from [dbo].[eeocdefs] {1} {2}; ";
		
		internal static List<Compeat.Demo.Data.eeocdefsDto> _GetList(SqlConnection conn, string statement, TableWhereParamsAndOrder where, ulong row_count, bool loadRecursive = false, int recursiveDepth = int.MaxValue, ChildLoaderList<Compeat.Demo.Data.eeocdefsDto> collectionsToLoad = null, IEnumerable<string> collectionToLoadUsingStrings = null) {
			var __retVal = new List<Compeat.Demo.Data.eeocdefsDto>();
			string sql = string.Format(
										statement
										, row_count == ulong.MaxValue ? "" : string.Format(" top {0}", row_count)
										, string.IsNullOrWhiteSpace(where.WhereClause) ? "" : String.Format("where {0}", where.WhereClause)
										, string.IsNullOrWhiteSpace(where.OrderBy) ? "" : String.Format("order by {0}", where.OrderBy)
								);
								
			InternalTools.ScriptRunReader(
				SqlEnums.SqlActivityType.SELECT 
				, sql
				, conn
				, where.ParamList
				, (sdr) => {
						if (sdr.HasRows) {
							while (sdr.Read())
							{
								__retVal.Add(Compeat.Demo.Data.eeocdefsDto.GetFromReader(sdr));
							}
						}
					}
				, Compeat.Demo.Data.eeocdefsDto.MyTimeout());

			if(__retVal != null){
				if(collectionsToLoad != null) {
					foreach(var __itm in __retVal){
						var properties = collectionsToLoad.Select(s => s.Body.ToString().Replace(string.Format("{0}.", s.Parameters[0].Name), ""));
						__itm.LoadChildProperty(conn, properties);
					}
				} 
				if(collectionToLoadUsingStrings != null) {
					foreach(var __itm in __retVal){
						__itm.LoadChildProperty(conn, collectionToLoadUsingStrings);
					}
				} 
				if(loadRecursive) {
					foreach(var __itm in __retVal){
						__itm.LoadChildren(conn, recursiveDepth);
					}
				}
			}
			
			return __retVal;
		}
		
		#endregion Reading

	}
	
	
	#region Repository needs
	
	public partial interface IRepository {
		Compeat.Demo.Data.eeocdefs eeocdefs { get; }
	}
	
	public partial class Repository {
		internal Compeat.Demo.Data.eeocdefs _eeocdefs  = null;
		public Compeat.Demo.Data.eeocdefs eeocdefs  {
			get{
				if(_eeocdefs == null){
					_eeocdefs = new Compeat.Demo.Data.eeocdefs ();
				}
				return _eeocdefs ;
			}
		}
	}
	#endregion Repository needs

}
