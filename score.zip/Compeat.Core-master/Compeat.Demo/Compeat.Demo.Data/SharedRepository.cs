﻿using Compeat.Data.Framework.InternalUtils;

namespace Compeat.Demo.Data.Shared
{
	/// <summary>
	/// This repository houses the data elements in the 'shr' schema only
	/// </summary>
	public partial class SharedRepository : RepositoryBase, ISharedRepository
	{
		public SharedRepository()
		{ }
	}
}
