﻿using Compeat.Data;

namespace Compeat.Demo.Data.Shared
{
	public partial interface ISharedRepository : ISavableRepository
	{ }
}
