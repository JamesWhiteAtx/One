﻿using Compeat.Demo.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using SimpleInjector;
using Compeat.Service;
using Compeat.Data;
using Compeat.Mvc;
using Compeat.Demo.Service.Services;
using Compeat.Demo.Service;
using System.Configuration;
using Microsoft.Owin;
using Owin;
using Microsoft.Owin.Security.Cookies;
using System.Threading.Tasks;
using Microsoft.AspNet.Identity;
using Compeat.Demo.Reports.Library;
using Compeat.Service.Interfaces;
using Compeat.Demo.Service.Services.Crud;
using Compeat.Demo.Service.Models.Crud;
using Elmah;
using System.IO;
using System.Net;
using Compeat.Demo.Service.Exceptions;
using Compeat.Service.BaseServices;
using System.Reflection;

[assembly: OwinStartup(typeof(Compeat.Demo.Mvc.Application))]
namespace Compeat.Demo.Mvc
{
	public class Application : BaseApplication<ApplicationInfo, ConnectionManager, ConnectionStringProvider, IdentityManager, ReportCacheService>
	{

		protected override void CmpPreInjection()
		{
			RouteConfig.RegisterRoutes(RouteTable.Routes);
		}

		protected override void CmpInjection()
		{
			//core related
			Container.Register<IRepository, Repository>(Lifestyle.Singleton);
			Container.Register<IApplicationLevelCrudService, ApplicationLevelCrudService>(Lifestyle.Singleton);
			

			// the session service is per-request scopped
			Container.Register<ISessionService<DemoRights>, SessionService>(Lifestyle.Scoped);

			// register all Compeat.Demo.Service services
			var demoServiceTypes = Assembly.GetAssembly(typeof(Compeat.Demo.Service.ApplicationInfo)).GetExportedTypes()
				.Where(x => x.IsClass 
					&& Attribute.GetCustomAttribute(x, typeof(AutoIocRegisterAttribute)) != null);
			foreach (var service in demoServiceTypes)
			{
				Container.Register(service, service, Lifestyle.Transient);
			}


			// all container usage (GetInstance) has to be last

			//manually inject report context
			ReportContext.inject(Container.GetInstance<IConnectionManager>(), Container.GetInstance<IRepository>(), Container.GetInstance<IIdentityManager>());
		}

		protected override void CmpPostInjection()
		{

		}

		protected override bool CmpValidateCookie(CookieValidateIdentityContext context)
		{
			var userId = IdentityManager.GetUserIdFromClaims(context.Identity.Claims);
			var securityToken = IdentityManager.GetSecurityTokenFromClaims(context.Identity.Claims);
			var customer = IdentityManager.GetCustomerFromClaims(context.Identity.Claims);

			// the containerized auth service requires web request scopped items which are not valid
			// at this stage, construct one manually
			var authService = new AuthenticationService(Container.GetInstance<IRepository>(),
				new ConnectionManager(Container.GetInstance<IConnectionStringProvider>()));

			return authService.ValidateSecurityToken(userId, securityToken, customer);
		}

		// The name of this method must be fixed, the 'ErrorLog_' portion must match 
		// the key/name of the Elmah.ErrorLogModule defined in the web.config system.webServer/System.Web sections.
		protected void ErrorLog_Filtering(object sender, ExceptionFilterEventArgs e)
		{
			if (ErrorShouldBeFiltered(e))
			{
				e.Dismiss();
			}
		}

		// add some additional exception logging filtering here
		protected override bool ErrorShouldBeFiltered(ExceptionFilterEventArgs e)
		{
			return base.ErrorShouldBeFiltered(e)
				|| e.Exception.GetBaseException() is InvalidCustomerException;
		}

	}
}
