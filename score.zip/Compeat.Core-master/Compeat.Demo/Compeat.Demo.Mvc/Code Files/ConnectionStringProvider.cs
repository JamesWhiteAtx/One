﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using Compeat.Demo.Service.Exceptions;
using Compeat.Data;
using Compeat.Service.Interfaces;

namespace Compeat.Demo.Mvc
{
    public class ConnectionStringProvider : IConnectionStringProvider
    {
        private IIdentityManager _identityManager { get; set; }
        public ConnectionStringProvider(IIdentityManager _identityManager)
        {
            this._identityManager = _identityManager;

        }
        /// <summary>
        /// Fetches the connection string for the provided customer (web.config connection string key)
        /// </summary>
        public string GetConnectionString(string customer)
        {
            if (customer == null)
            {
                customer = _identityManager.IsInitialized ? _identityManager.Customer : string.Empty;
            }

            if (ConfigurationManager.ConnectionStrings[customer] == null)
            {
                throw new InvalidCustomerException();
            }
            else
            {
                return (ConfigurationManager.ConnectionStrings[customer].ConnectionString);
            }
        }

    }
}