﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Web;
using Compeat.Mvc;
using Microsoft.AspNet.Identity;
using Microsoft.Owin.Security;
using Compeat.SharedLib.Utilities;
using Compeat.Demo.Service.Services;
using Compeat.Demo.Service.Exceptions;
using Compeat.Service.Authentication;
using Compeat.Service;
using Compeat.Service.Interfaces;

namespace Compeat.Demo.Mvc
{
    public class IdentityManager : IIdentityManager
    {
        private const string USER_ID_KEY = "1";
        private const string CUSTOMER_KEY = "2";
        private const string SECURITY_TOKEN_KEY = "3";
        private const string USER_NAME_KEY = "4";

        /// <summary>
        /// The manager associated with the current OWIN context
        /// </summary>
        private IAuthenticationManager AuthenticationManager
        {
            get { return HttpContext.Current.GetOwinContext().Authentication; }
        }

		/// <summary>
		/// Returns true if the authentication manager is in a useable state
		/// </summary>
		public bool IsInitialized
		{
			get
			{
				try
				{
					return HttpContext.Current != null
						&& HttpContext.Current.GetOwinContext() != null;
				}
				catch (Exception)
				{
					return false;
				}
			}

		}

        /// <summary>
        /// Userid for current authenticated user
        /// </summary>
        public int? UserId
        {
            get
            {
                return GetUserIdFromClaims(AuthenticationManager.User.Claims);
            }
        }


        /// <summary>
        /// Username for the current authenticated user
        /// </summary>
        public string UserName
        {
            get
            {
                return GetUserNameFromClaims(AuthenticationManager.User.Claims);
            }
        }

        /// <summary>
        /// Currently logged in customer site for current authenticated user
        /// </summary>
        public string Customer
        {
            get
            {
				return IsInitialized ? GetCustomerFromClaims(AuthenticationManager.User.Claims) : null;
            }
        }

        /// <summary>
        /// Returns the token assigned to the user on last successful authentication
        /// </summary>
        public Guid SecurityToken
        {
            get
            {
                return GetSecurityTokenFromClaims(AuthenticationManager.User.Claims);
            }
        }

        /// <summary>
        /// True if the owin context is initialized with an authenticated identity.
        /// </summary>
        public bool IsAuthenticated
        {
            get
            {
                return IsInitialized
					&& AuthenticationManager.User != null
                    && AuthenticationManager.User.Identity != null
                    && AuthenticationManager.User.Identity.IsAuthenticated;
            }
        }

        /// <summary>
        /// returns a token to be used for Csrf protection
        /// </summary>
        public string CsrfToken
        {
            get
            {
                if (IsAuthenticated)
                {
                    return GetCsrfToken(UserName, Customer);
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        /// <summary>
        /// Authenticates a user with the provided credentials and returns 
        /// </summary>
        public AuthResultTypes AuthenticateUser(AuthenticationService service, string username, string password, string customer, bool rememberMe)
        {

            var result = AuthResultTypes.UsernameNotFound;
            AuthServiceResult authResult = null;
            try
            {
                authResult = service.AuthenticateUser(username, password, customer, rememberMe);
                result = authResult.AuthResult;
            }
            catch (InvalidCustomerException)
            {
                result = AuthResultTypes.InvalidCustomer;
            }

            if (AuthResult.IsResultAuthenticated(result))
            {
                // fill userid, database here
                var identity = new ClaimsIdentity(new[]
                    {
                        new Claim(USER_ID_KEY, (authResult.UserId ?? 0).ToString()),
                        new Claim(USER_NAME_KEY, username.ToStringSafe()),
                        new Claim(CUSTOMER_KEY, customer.ToStringSafe()),
						new Claim(SECURITY_TOKEN_KEY, authResult.SecurityToken.ToStringSafe())
                    }, DefaultAuthenticationTypes.ApplicationCookie,
                    USER_NAME_KEY, CUSTOMER_KEY);

                // sign in with the verified claim
                AuthenticationManager.SignIn(
                    new AuthenticationProperties
                    {
                        IsPersistent = rememberMe
                    }, identity);
            }

            return result;
        }

        /// <summary>
        /// Signs the currently authenticated user out of the application
        /// </summary>
        public void SignOut()
        {
            AuthenticationManager.SignOut(DefaultAuthenticationTypes.ApplicationCookie);
        }

        /// <summary>
        /// Pull the user id from the supplied Owin claims.
        /// </summary>
        internal static int? GetUserIdFromClaims(IEnumerable<Claim> claims)
        {

            var claim = claims.FirstOrDefault(x => x.Type == USER_ID_KEY);
            return (claim != null) ? (int?)claim.Value.ToInt32() : null;
        }

        /// <summary>
        /// Pull the user name from the supplied Owin claims.
        /// </summary>
        internal static string GetUserNameFromClaims(IEnumerable<Claim> claims)
        {

            var claim = claims.FirstOrDefault(x => x.Type == USER_NAME_KEY);
            return (claim != null) ? claim.Value : string.Empty;
        }

        /// <summary>
        /// Pull the customer from the supplied Owin claims.
        /// </summary>
        internal static string GetCustomerFromClaims(IEnumerable<Claim> claims)
        {

            var claim = claims.FirstOrDefault(x => x.Type == CUSTOMER_KEY);
            return (claim != null) ? claim.Value : string.Empty;
        }

        /// <summary>
        /// Pull the security token from the supplied Owin claims.
        /// </summary>
        internal static Guid GetSecurityTokenFromClaims(IEnumerable<Claim> claims)
        {

            var claim = claims.FirstOrDefault(x => x.Type == SECURITY_TOKEN_KEY);
            return (claim != null) ? new Guid(claim.Value) : Guid.Empty;
        }
        /// <summary>
        /// Provides an expected cross-site forgery token for the given username and customer
        /// </summary>
        public string GetCsrfToken(string userName, string customer)
        {
            return Crypt.HashString(userName.ToStringSafe().ToLower() + "!_^" + customer.ToStringSafe().ToLower());
        }

    }
}