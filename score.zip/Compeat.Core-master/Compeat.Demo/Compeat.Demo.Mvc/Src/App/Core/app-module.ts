﻿/// <reference path="../common-refs.d.ts" />

namespace App {

	angular.module('app', [
	//3rd party
		'ui.router',
		'ngMessages',
        'pascalprecht.translate',
        'kendo.directives',
        'ngAnimate',
		'ngSanitize',
        'door3.css', // route based css
        'ui.bootstrap',
        'angularUtils.directives.dirPagination',
	//core
		'cmp.ui.components',
		'cmp.ui.directives',
		'cmp.ui.providers',
		'cmp.ui.services',
		'cmp.ui.factories',
		'cmp.ui.templates',
	//app
		'app.templates',
		'app.services',
		'app.shell',
		'app.login',
	// features
		'app.riiCrit',
		'app.birthdaysCrit',
		'app.eeocdefs',
		'app.masterinventory',
		'app.userProfile'
	])
	.constant('toastr', toastr);
}
