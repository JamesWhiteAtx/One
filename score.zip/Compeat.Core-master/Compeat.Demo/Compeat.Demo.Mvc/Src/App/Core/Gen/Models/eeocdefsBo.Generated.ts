﻿/// <reference path="../../../common-refs.d.ts" />
namespace App.Gen.Models.Generated
{
	export class eeocdefsBoGenerated extends Cmp.Ui.Bases.BaseGenBoModel
	{
        
		private _id: number;
		public get id(): number {
			return this._id;
		}
		public set id(value: number) {
            this.CheckSetNotify("id", value);
		}
        
		private _description: string;
		public get description(): string {
			return this._description;
		}
		public set description(value: string) {
            this.CheckSetNotify("description", value);
		}
        
		private _recstamp: string;
		public get recstamp(): string {
			return this._recstamp;
		}
		public set recstamp(value: string) {
            this.CheckSetNotify("recstamp", value);
		}
        
        
		
        private static _fieldMembers : string[] = ['id','description','recstamp','CmpNew','CmpDel'];
        private static _dateFieldMembers : string[] = [];
        private static _colMembers : string[] = [];
		
        /** generated fields that will be serialized */
		public get FieldMembers(): string[] {
			return eeocdefsBoGenerated._fieldMembers;
		}
        
        /** all known date fields, used for conversion */
		public get DateFieldMembers(): string[] {
			return eeocdefsBoGenerated._dateFieldMembers;
		}
        
		/** returns the names of all known collection properties */
		public get CollectionMembers(): string[] {
			return eeocdefsBoGenerated._colMembers;
		}
        
		constructor(baseTools: Cmp.Ui.Services.IBaseTools) {
			super(baseTools);
		}

	}
}

