﻿/// <reference path="../../../common-refs.d.ts" />
namespace App.Gen.Models.Generated
{
	export class userstorelinksBoGenerated extends Cmp.Ui.Bases.BaseGenBoModel
	{
        
		private _userid: number;
		public get userid(): number {
			return this._userid;
		}
		public set userid(value: number) {
            this.CheckSetNotify("userid", value);
		}
        
		private _storenum: number;
		public get storenum(): number {
			return this._storenum;
		}
		public set storenum(value: number) {
            this.CheckSetNotify("storenum", value);
		}
        
		private _uniquefield: number;
		public get uniquefield(): number {
			return this._uniquefield;
		}
		public set uniquefield(value: number) {
            this.CheckSetNotify("uniquefield", value);
		}
        
        
		
        private static _fieldMembers : string[] = ['userid','storenum','uniquefield','CmpNew','CmpDel'];
        private static _dateFieldMembers : string[] = [];
        private static _colMembers : string[] = [];
		
        /** generated fields that will be serialized */
		public get FieldMembers(): string[] {
			return userstorelinksBoGenerated._fieldMembers;
		}
        
        /** all known date fields, used for conversion */
		public get DateFieldMembers(): string[] {
			return userstorelinksBoGenerated._dateFieldMembers;
		}
        
		/** returns the names of all known collection properties */
		public get CollectionMembers(): string[] {
			return userstorelinksBoGenerated._colMembers;
		}
        
		constructor(baseTools: Cmp.Ui.Services.IBaseTools) {
			super(baseTools);
		}

	}
}

