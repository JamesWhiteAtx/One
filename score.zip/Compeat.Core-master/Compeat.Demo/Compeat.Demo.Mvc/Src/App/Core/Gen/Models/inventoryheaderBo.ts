﻿/// <reference path="../../../common-refs.d.ts" />
/// <reference path="inventoryheaderBo.Generated.ts" />
namespace App.Gen.Models {
	export class inventoryheaderBo extends App.Gen.Models.Generated.inventoryheaderBoGenerated {

		public ClassDesc: string;

		/*@ngInject*/
		constructor(baseTools: Cmp.Ui.Services.IBaseTools) {
			super(baseTools);
		}
		public GetRules = (): Promise<Array<Cmp.Ui.Rules.CmpRule>> => {
						return this.GetBaseTools().CmpPromise.Resolve<Array<Cmp.Ui.Rules.CmpRule>>();
			
			/* --example:
							var self = this;
				return self.GetBaseTools().CmpPromise.Promise<Array<Cmp.Ui.Rules.CmpRule>>((resolve): void => {
					var rules = new Array<Cmp.Ui.Rules.CmpRule>();
					self._$translate(["App$Login_UsernameRequired",
						"App$Login_PasswordRequired",
						"App$Login_CustomerRequired"]).then((translation: any): void => {

							rules.push(new Cmp.Ui.Rules.StringRequiredRule('userName', translation.App$Login_UsernameRequired, Cmp.Ui.Rules.NgMessageTypes.Required));
							rules.push(new Cmp.Ui.Rules.StringRequiredRule('password', translation.App$Login_PasswordRequired, Cmp.Ui.Rules.NgMessageTypes.Required));
							rules.push(new Cmp.Ui.Rules.StringRequiredRule('customer', translation.App$Login_CustomerRequired, Cmp.Ui.Rules.NgMessageTypes.Required));
							resolve(rules);
						});
				});			
			*/

		}
		
		/** runs before filled from the raw object, override to do custom filling */
		public BeforeLoadFromRaw = (fromUrl: string, rawObj: any) => {

		}
		
		/** runs after filled from the raw object, override to do custom filling */
		public AfterLoadFromRaw = (fromUrl: string, rawObj: any) => {
			this.ClassDesc = rawObj.ClassDesc;
		}
	}
}
