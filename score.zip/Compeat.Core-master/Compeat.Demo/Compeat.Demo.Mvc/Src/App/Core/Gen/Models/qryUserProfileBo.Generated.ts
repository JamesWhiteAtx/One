﻿/// <reference path="../../../common-refs.d.ts" />

namespace App.Gen.Models.Generated
{
	export class qryUserProfileBoGenerated extends Cmp.Ui.Bases.BaseGenBoModel
	{
		private _userid: number;
		public get userid(): number {
			return this._userid;
		}
		public set userid(value: number) {
            this.CheckSetNotify("userid", value);
		}
		private _recstamp: string;
		public get recstamp(): string {
			return this._recstamp;
		}
		public set recstamp(value: string) {
            this.CheckSetNotify("recstamp", value);
		}
		private _username: string;
		public get username(): string {
			return this._username;
		}
		public set username(value: string) {
            this.CheckSetNotify("username", value);
		}
		private _fullname: string;
		public get fullname(): string {
			return this._fullname;
		}
		public set fullname(value: string) {
            this.CheckSetNotify("fullname", value);
		}
		private _description: string;
		public get description(): string {
			return this._description;
		}
		public set description(value: string) {
            this.CheckSetNotify("description", value);
		}
		private _password: string;
		public get password(): string {
			return this._password;
		}
		public set password(value: string) {
            this.CheckSetNotify("password", value);
		}
		private _lang: string;
		public get lang(): string {
			return this._lang;
		}
		public set lang(value: string) {
            this.CheckSetNotify("lang", value);
		}
        private static _fieldMembers : string[] = ['userid','recstamp','username','fullname','description','password','lang','CmpNew','CmpDel'];
        private static _dateFieldMembers : string[] = [];		
        
        /** generated fields that will be serialized */
		public get FieldMembers(): string[] {
			return qryUserProfileBoGenerated._fieldMembers;
		}
        
        /** all known date fields, used for conversion */
		public get DateFieldMembers(): string[] {
			return qryUserProfileBoGenerated._dateFieldMembers;
		}

		constructor(baseTools: Cmp.Ui.Services.IBaseTools) {
			super(baseTools);
		}	
		
    }
}
