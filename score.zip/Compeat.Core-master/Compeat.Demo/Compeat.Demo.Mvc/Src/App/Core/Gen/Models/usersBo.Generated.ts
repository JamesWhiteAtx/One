﻿/// <reference path="../../../common-refs.d.ts" />
/// <reference path="userstorelinksBo.ts" />
namespace App.Gen.Models.Generated
{
	export class usersBoGenerated extends Cmp.Ui.Bases.BaseGenBoModel
	{
        
		private _userid: number;
		public get userid(): number {
			return this._userid;
		}
		public set userid(value: number) {
            this.CheckSetNotify("userid", value);
		}
        
		private _username: string;
		public get username(): string {
			return this._username;
		}
		public set username(value: string) {
            this.CheckSetNotify("username", value);
		}
        
		private _fullname: string;
		public get fullname(): string {
			return this._fullname;
		}
		public set fullname(value: string) {
            this.CheckSetNotify("fullname", value);
		}
        
		private _description: string;
		public get description(): string {
			return this._description;
		}
		public set description(value: string) {
            this.CheckSetNotify("description", value);
		}
        
		private _defaultstore: number;
		public get defaultstore(): number {
			return this._defaultstore;
		}
		public set defaultstore(value: number) {
            this.CheckSetNotify("defaultstore", value);
		}
        
		private _promptforrestaurant: boolean;
		public get promptforrestaurant(): boolean {
			return this._promptforrestaurant;
		}
		public set promptforrestaurant(value: boolean) {
            this.CheckSetNotify("promptforrestaurant", value);
		}
        
		private _recstamp: string;
		public get recstamp(): string {
			return this._recstamp;
		}
		public set recstamp(value: string) {
            this.CheckSetNotify("recstamp", value);
		}
        
		private _password: string;
		public get password(): string {
			return this._password;
		}
		public set password(value: string) {
            this.CheckSetNotify("password", value);
		}
        
		private _email: string;
		public get email(): string {
			return this._email;
		}
		public set email(value: string) {
            this.CheckSetNotify("email", value);
		}
        
		private _failedpasswordattemptstart: Date;
		public get failedpasswordattemptstart(): Date {
			return this._failedpasswordattemptstart;
		}
		public set failedpasswordattemptstart(value: Date) {
            this.CheckSetNotify("failedpasswordattemptstart", value);
		}
        
		private _failedpasswordattemptcount: number;
		public get failedpasswordattemptcount(): number {
			return this._failedpasswordattemptcount;
		}
		public set failedpasswordattemptcount(value: number) {
            this.CheckSetNotify("failedpasswordattemptcount", value);
		}
        
		private _lastpasswordchange: Date;
		public get lastpasswordchange(): Date {
			return this._lastpasswordchange;
		}
		public set lastpasswordchange(value: Date) {
            this.CheckSetNotify("lastpasswordchange", value);
		}
        
		private _mustchangepassword: boolean;
		public get mustchangepassword(): boolean {
			return this._mustchangepassword;
		}
		public set mustchangepassword(value: boolean) {
            this.CheckSetNotify("mustchangepassword", value);
		}
        
		private _active: boolean;
		public get active(): boolean {
			return this._active;
		}
		public set active(value: boolean) {
            this.CheckSetNotify("active", value);
		}
        
		private _theme: number;
		public get theme(): number {
			return this._theme;
		}
		public set theme(value: number) {
            this.CheckSetNotify("theme", value);
		}
        
		private _defaultgroup: number;
		public get defaultgroup(): number {
			return this._defaultgroup;
		}
		public set defaultgroup(value: number) {
            this.CheckSetNotify("defaultgroup", value);
		}
        
		private _promptformenu: boolean;
		public get promptformenu(): boolean {
			return this._promptformenu;
		}
		public set promptformenu(value: boolean) {
            this.CheckSetNotify("promptformenu", value);
		}
        
		private _showscheduledcostsummary: boolean;
		public get showscheduledcostsummary(): boolean {
			return this._showscheduledcostsummary;
		}
		public set showscheduledcostsummary(value: boolean) {
            this.CheckSetNotify("showscheduledcostsummary", value);
		}
        
		private _scheduledcostsummaryorder: number;
		public get scheduledcostsummaryorder(): number {
			return this._scheduledcostsummaryorder;
		}
		public set scheduledcostsummaryorder(value: number) {
            this.CheckSetNotify("scheduledcostsummaryorder", value);
		}
        
		private _showscheduledhoursfordeptsummary: boolean;
		public get showscheduledhoursfordeptsummary(): boolean {
			return this._showscheduledhoursfordeptsummary;
		}
		public set showscheduledhoursfordeptsummary(value: boolean) {
            this.CheckSetNotify("showscheduledhoursfordeptsummary", value);
		}
        
		private _scheduledhoursfordeptsummaryorder: number;
		public get scheduledhoursfordeptsummaryorder(): number {
			return this._scheduledhoursfordeptsummaryorder;
		}
		public set scheduledhoursfordeptsummaryorder(value: number) {
            this.CheckSetNotify("scheduledhoursfordeptsummaryorder", value);
		}
        
		private _showforecastedsalessummary: boolean;
		public get showforecastedsalessummary(): boolean {
			return this._showforecastedsalessummary;
		}
		public set showforecastedsalessummary(value: boolean) {
            this.CheckSetNotify("showforecastedsalessummary", value);
		}
        
		private _forecastedsalessummaryorder: number;
		public get forecastedsalessummaryorder(): number {
			return this._forecastedsalessummaryorder;
		}
		public set forecastedsalessummaryorder(value: number) {
            this.CheckSetNotify("forecastedsalessummaryorder", value);
		}
        
		private _showscheduledhourssummary: boolean;
		public get showscheduledhourssummary(): boolean {
			return this._showscheduledhourssummary;
		}
		public set showscheduledhourssummary(value: boolean) {
            this.CheckSetNotify("showscheduledhourssummary", value);
		}
        
		private _scheduledhourssummaryorder: number;
		public get scheduledhourssummaryorder(): number {
			return this._scheduledhourssummaryorder;
		}
		public set scheduledhourssummaryorder(value: number) {
            this.CheckSetNotify("scheduledhourssummaryorder", value);
		}
        
		private _showallscheduledhourssummary: boolean;
		public get showallscheduledhourssummary(): boolean {
			return this._showallscheduledhourssummary;
		}
		public set showallscheduledhourssummary(value: boolean) {
            this.CheckSetNotify("showallscheduledhourssummary", value);
		}
        
		private _allscheduledhourssummaryorder: number;
		public get allscheduledhourssummaryorder(): number {
			return this._allscheduledhourssummaryorder;
		}
		public set allscheduledhourssummaryorder(value: number) {
            this.CheckSetNotify("allscheduledhourssummaryorder", value);
		}
        
		private _showsalesperlaborhoursummary: boolean;
		public get showsalesperlaborhoursummary(): boolean {
			return this._showsalesperlaborhoursummary;
		}
		public set showsalesperlaborhoursummary(value: boolean) {
            this.CheckSetNotify("showsalesperlaborhoursummary", value);
		}
        
		private _salesperlaborhoursummaryorder: number;
		public get salesperlaborhoursummaryorder(): number {
			return this._salesperlaborhoursummaryorder;
		}
		public set salesperlaborhoursummaryorder(value: number) {
            this.CheckSetNotify("salesperlaborhoursummaryorder", value);
		}
        
		private _showallscheduledcostsummary: boolean;
		public get showallscheduledcostsummary(): boolean {
			return this._showallscheduledcostsummary;
		}
		public set showallscheduledcostsummary(value: boolean) {
            this.CheckSetNotify("showallscheduledcostsummary", value);
		}
        
		private _allscheduledcostsummaryorder: number;
		public get allscheduledcostsummaryorder(): number {
			return this._allscheduledcostsummaryorder;
		}
		public set allscheduledcostsummaryorder(value: number) {
            this.CheckSetNotify("allscheduledcostsummaryorder", value);
		}
        
		private _showscheduledcostpercentsummary: boolean;
		public get showscheduledcostpercentsummary(): boolean {
			return this._showscheduledcostpercentsummary;
		}
		public set showscheduledcostpercentsummary(value: boolean) {
            this.CheckSetNotify("showscheduledcostpercentsummary", value);
		}
        
		private _scheduledcostpercentsummaryorder: number;
		public get scheduledcostpercentsummaryorder(): number {
			return this._scheduledcostpercentsummaryorder;
		}
		public set scheduledcostpercentsummaryorder(value: number) {
            this.CheckSetNotify("scheduledcostpercentsummaryorder", value);
		}
        
		private _showallscheduledcostpercentsummary: boolean;
		public get showallscheduledcostpercentsummary(): boolean {
			return this._showallscheduledcostpercentsummary;
		}
		public set showallscheduledcostpercentsummary(value: boolean) {
            this.CheckSetNotify("showallscheduledcostpercentsummary", value);
		}
        
		private _allscheduledcostpercentsummaryorder: number;
		public get allscheduledcostpercentsummaryorder(): number {
			return this._allscheduledcostpercentsummaryorder;
		}
		public set allscheduledcostpercentsummaryorder(value: number) {
            this.CheckSetNotify("allscheduledcostpercentsummaryorder", value);
		}
        
		private _showscheduledcostsfordeptsummary: boolean;
		public get showscheduledcostsfordeptsummary(): boolean {
			return this._showscheduledcostsfordeptsummary;
		}
		public set showscheduledcostsfordeptsummary(value: boolean) {
            this.CheckSetNotify("showscheduledcostsfordeptsummary", value);
		}
        
		private _scheduledcostsfordeptsummaryorder: number;
		public get scheduledcostsfordeptsummaryorder(): number {
			return this._scheduledcostsfordeptsummaryorder;
		}
		public set scheduledcostsfordeptsummaryorder(value: number) {
            this.CheckSetNotify("scheduledcostsfordeptsummaryorder", value);
		}
        
		private _securitytoken: string;
		public get securitytoken(): string {
			return this._securitytoken;
		}
		public set securitytoken(value: string) {
            this.CheckSetNotify("securitytoken", value);
		}
        
		private _showscheduledshiftcountssummary: boolean;
		public get showscheduledshiftcountssummary(): boolean {
			return this._showscheduledshiftcountssummary;
		}
		public set showscheduledshiftcountssummary(value: boolean) {
            this.CheckSetNotify("showscheduledshiftcountssummary", value);
		}
        
		private _scheduledshiftcountssummaryorder: number;
		public get scheduledshiftcountssummaryorder(): number {
			return this._scheduledshiftcountssummaryorder;
		}
		public set scheduledshiftcountssummaryorder(value: number) {
            this.CheckSetNotify("scheduledshiftcountssummaryorder", value);
		}
        
		private _lang: string;
		public get lang(): string {
			return this._lang;
		}
		public set lang(value: string) {
            this.CheckSetNotify("lang", value);
		}
        
		private _mgrtimeoffalerts: boolean;
		public get mgrtimeoffalerts(): boolean {
			return this._mgrtimeoffalerts;
		}
		public set mgrtimeoffalerts(value: boolean) {
            this.CheckSetNotify("mgrtimeoffalerts", value);
		}
        
		private _mgrswapalerts: boolean;
		public get mgrswapalerts(): boolean {
			return this._mgrswapalerts;
		}
		public set mgrswapalerts(value: boolean) {
            this.CheckSetNotify("mgrswapalerts", value);
		}
        
		private _mgrdroppickupalerts: boolean;
		public get mgrdroppickupalerts(): boolean {
			return this._mgrdroppickupalerts;
		}
		public set mgrdroppickupalerts(value: boolean) {
            this.CheckSetNotify("mgrdroppickupalerts", value);
		}
        
		private _mgrautocheckinout: boolean;
		public get mgrautocheckinout(): boolean {
			return this._mgrautocheckinout;
		}
		public set mgrautocheckinout(value: boolean) {
            this.CheckSetNotify("mgrautocheckinout", value);
		}
        
		private _mobilephone: string;
		public get mobilephone(): string {
			return this._mobilephone;
		}
		public set mobilephone(value: string) {
            this.CheckSetNotify("mobilephone", value);
		}
        
		private _alertviaemail: boolean;
		public get alertviaemail(): boolean {
			return this._alertviaemail;
		}
		public set alertviaemail(value: boolean) {
            this.CheckSetNotify("alertviaemail", value);
		}
        
		private _alertviasms: boolean;
		public get alertviasms(): boolean {
			return this._alertviasms;
		}
		public set alertviasms(value: boolean) {
            this.CheckSetNotify("alertviasms", value);
		}
        
        
		public userStoreLinks: Array<App.Gen.Models.userstorelinksBo>;
		
        private static _fieldMembers : string[] = ['userid','username','fullname','description','defaultstore','promptforrestaurant','recstamp','password','email','failedpasswordattemptstart','failedpasswordattemptcount','lastpasswordchange','mustchangepassword','active','theme','defaultgroup','promptformenu','showscheduledcostsummary','scheduledcostsummaryorder','showscheduledhoursfordeptsummary','scheduledhoursfordeptsummaryorder','showforecastedsalessummary','forecastedsalessummaryorder','showscheduledhourssummary','scheduledhourssummaryorder','showallscheduledhourssummary','allscheduledhourssummaryorder','showsalesperlaborhoursummary','salesperlaborhoursummaryorder','showallscheduledcostsummary','allscheduledcostsummaryorder','showscheduledcostpercentsummary','scheduledcostpercentsummaryorder','showallscheduledcostpercentsummary','allscheduledcostpercentsummaryorder','showscheduledcostsfordeptsummary','scheduledcostsfordeptsummaryorder','securitytoken','showscheduledshiftcountssummary','scheduledshiftcountssummaryorder','lang','mgrtimeoffalerts','mgrswapalerts','mgrdroppickupalerts','mgrautocheckinout','mobilephone','alertviaemail','alertviasms','CmpNew','CmpDel'];
        private static _dateFieldMembers : string[] = ['_failedpasswordattemptstart','_lastpasswordchange'];
        private static _colMembers : string[] = ['userStoreLinks'];
		
        /** generated fields that will be serialized */
		public get FieldMembers(): string[] {
			return usersBoGenerated._fieldMembers;
		}
        
        /** all known date fields, used for conversion */
		public get DateFieldMembers(): string[] {
			return usersBoGenerated._dateFieldMembers;
		}
        
		/** returns the names of all known collection properties */
		public get CollectionMembers(): string[] {
			return usersBoGenerated._colMembers;
		}
        
		constructor(baseTools: Cmp.Ui.Services.IBaseTools) {
			super(baseTools);
		}
		/** takes a raw object and copies like named values from it into this instance */
		public LoadChildrenFromRaw = (fromUrl: string, rawObj: any) => {
			var self = this;
			if(rawObj.userStoreLinks && rawObj.userStoreLinks.length){
				if(!self.userStoreLinks){
					self.userStoreLinks = new Array<App.Gen.Models.userstorelinksBo>();
				}
				for(var userStoreLinksCounter = 0; userStoreLinksCounter < rawObj.userStoreLinks.length; userStoreLinksCounter++){
					var userStoreLinksInstance = self.GetBaseTools().CreateInstance<App.Gen.Models.userstorelinksBo>(App.Gen.Models.userstorelinksBo);
					userStoreLinksInstance.LoadFromRaw(fromUrl, rawObj.userStoreLinks[userStoreLinksCounter]);
					self.userStoreLinks.push(userStoreLinksInstance);
				}
			}
		}   

	}
}

