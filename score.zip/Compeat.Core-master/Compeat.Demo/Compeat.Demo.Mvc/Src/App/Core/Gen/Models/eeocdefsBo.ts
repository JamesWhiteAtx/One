﻿/// <reference path="../../../common-refs.d.ts" />
/// <reference path="eeocdefsBo.Generated.ts" />

namespace App.Gen.Models {

	export class eeocdefsBo extends App.Gen.Models.Generated.eeocdefsBoGenerated {
		private _$translate: angular.translate.ITranslateService;


		public description_Changed = (oldValue: string, newValue: string) => {
			console.log("description changed from '" + oldValue + "' to '" + newValue + "'");
		}

		/*@ngInject*/
		constructor(baseTools: Cmp.Ui.Services.IBaseTools, $translate: angular.translate.ITranslateService) {
			super(baseTools);
			this._$translate = $translate;
		}

		public GetRules = (): Promise<Array<Cmp.Ui.Rules.CmpRule>> => {
			//return this.BaseTools.CmpPromise.Resolve<Array<Cmp.Ui.Rules.CmpRule>>();
			var self = this;

			return self.GetBaseTools().CmpPromise.Promise<Array<Cmp.Ui.Rules.CmpRule>>((resolve): void => {
				var rules = new Array<Cmp.Ui.Rules.CmpRule>();
				rules.push(new Cmp.Ui.Rules.StringRequiredRule('description', "", Cmp.Ui.Rules.NgMessageTypes.Required));
				resolve(rules);
			});
		}
		
		/** runs before filled from the raw object, override to do custom filling */
		public BeforeLoadFromRaw = (fromUrl: string, rawObj: any) => {

		}
		
		/** runs after filled from the raw object, override to do custom filling */
		public AfterLoadFromRaw = (fromUrl: string, rawObj: any) => {

		}
	}
}
