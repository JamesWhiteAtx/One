﻿/// <reference path="../../../common-refs.d.ts" />
namespace App.Gen.Models.Generated
{
	export class inventoryheaderBoGenerated extends Cmp.Ui.Bases.BaseGenBoModel
	{
        
		private _id: number;
		public get id(): number {
			return this._id;
		}
		public set id(value: number) {
            this.CheckSetNotify("id", value);
		}
        
		private _description: string;
		public get description(): string {
			return this._description;
		}
		public set description(value: string) {
            this.CheckSetNotify("description", value);
		}
        
		private _description2: string;
		public get description2(): string {
			return this._description2;
		}
		public set description2(value: string) {
            this.CheckSetNotify("description2", value);
		}
        
		private _upccode: string;
		public get upccode(): string {
			return this._upccode;
		}
		public set upccode(value: string) {
            this.CheckSetNotify("upccode", value);
		}
        
		private _xclass: number;
		public get xclass(): number {
			return this._xclass;
		}
		public set xclass(value: number) {
            this.CheckSetNotify("xclass", value);
		}
        
		private _shelf: number;
		public get shelf(): number {
			return this._shelf;
		}
		public set shelf(value: number) {
            this.CheckSetNotify("shelf", value);
		}
        
		private _available: boolean;
		public get available(): boolean {
			return this._available;
		}
		public set available(value: boolean) {
            this.CheckSetNotify("available", value);
		}
        
		private _invclass: number;
		public get invclass(): number {
			return this._invclass;
		}
		public set invclass(value: number) {
            this.CheckSetNotify("invclass", value);
		}
        
		private _convbasenum: number;
		public get convbasenum(): number {
			return this._convbasenum;
		}
		public set convbasenum(value: number) {
            this.CheckSetNotify("convbasenum", value);
		}
        
		private _convbaseuom: number;
		public get convbaseuom(): number {
			return this._convbaseuom;
		}
		public set convbaseuom(value: number) {
            this.CheckSetNotify("convbaseuom", value);
		}
        
		private _convinvnum: number;
		public get convinvnum(): number {
			return this._convinvnum;
		}
		public set convinvnum(value: number) {
            this.CheckSetNotify("convinvnum", value);
		}
        
		private _convinvuom: number;
		public get convinvuom(): number {
			return this._convinvuom;
		}
		public set convinvuom(value: number) {
            this.CheckSetNotify("convinvuom", value);
		}
        
		private _convbaseunitsperinvunit: number;
		public get convbaseunitsperinvunit(): number {
			return this._convbaseunitsperinvunit;
		}
		public set convbaseunitsperinvunit(value: number) {
            this.CheckSetNotify("convbaseunitsperinvunit", value);
		}
        
		private _level1: number;
		public get level1(): number {
			return this._level1;
		}
		public set level1(value: number) {
            this.CheckSetNotify("level1", value);
		}
        
		private _level2: number;
		public get level2(): number {
			return this._level2;
		}
		public set level2(value: number) {
            this.CheckSetNotify("level2", value);
		}
        
		private _level3: number;
		public get level3(): number {
			return this._level3;
		}
		public set level3(value: number) {
            this.CheckSetNotify("level3", value);
		}
        
		private _recipe: string;
		public get recipe(): string {
			return this._recipe;
		}
		public set recipe(value: string) {
            this.CheckSetNotify("recipe", value);
		}
        
		private _prepitem: boolean;
		public get prepitem(): boolean {
			return this._prepitem;
		}
		public set prepitem(value: boolean) {
            this.CheckSetNotify("prepitem", value);
		}
        
		private _prepitemproduom: number;
		public get prepitemproduom(): number {
			return this._prepitemproduom;
		}
		public set prepitemproduom(value: number) {
            this.CheckSetNotify("prepitemproduom", value);
		}
        
		private _prepiteminvuom: number;
		public get prepiteminvuom(): number {
			return this._prepiteminvuom;
		}
		public set prepiteminvuom(value: number) {
            this.CheckSetNotify("prepiteminvuom", value);
		}
        
		private _prepiteminvunitsperprodunit: number;
		public get prepiteminvunitsperprodunit(): number {
			return this._prepiteminvunitsperprodunit;
		}
		public set prepiteminvunitsperprodunit(value: number) {
            this.CheckSetNotify("prepiteminvunitsperprodunit", value);
		}
        
		private _modified: Date;
		public get modified(): Date {
			return this._modified;
		}
		public set modified(value: Date) {
            this.CheckSetNotify("modified", value);
		}
        
		private _modifiedby: string;
		public get modifiedby(): string {
			return this._modifiedby;
		}
		public set modifiedby(value: string) {
            this.CheckSetNotify("modifiedby", value);
		}
        
		private _catchweight: boolean;
		public get catchweight(): boolean {
			return this._catchweight;
		}
		public set catchweight(value: boolean) {
            this.CheckSetNotify("catchweight", value);
		}
        
		private _limitcountstoinvunit: boolean;
		public get limitcountstoinvunit(): boolean {
			return this._limitcountstoinvunit;
		}
		public set limitcountstoinvunit(value: boolean) {
            this.CheckSetNotify("limitcountstoinvunit", value);
		}
        
		private _prepprodfactor: number;
		public get prepprodfactor(): number {
			return this._prepprodfactor;
		}
		public set prepprodfactor(value: number) {
            this.CheckSetNotify("prepprodfactor", value);
		}
        
		private _prepprodlaborminutes: number;
		public get prepprodlaborminutes(): number {
			return this._prepprodlaborminutes;
		}
		public set prepprodlaborminutes(value: number) {
            this.CheckSetNotify("prepprodlaborminutes", value);
		}
        
		private _recstamp: string;
		public get recstamp(): string {
			return this._recstamp;
		}
		public set recstamp(value: string) {
            this.CheckSetNotify("recstamp", value);
		}
        
		private _couponvalue: number;
		public get couponvalue(): number {
			return this._couponvalue;
		}
		public set couponvalue(value: number) {
            this.CheckSetNotify("couponvalue", value);
		}
        
		private _notes: string;
		public get notes(): string {
			return this._notes;
		}
		public set notes(value: string) {
            this.CheckSetNotify("notes", value);
		}
        
		private _approved: boolean;
		public get approved(): boolean {
			return this._approved;
		}
		public set approved(value: boolean) {
            this.CheckSetNotify("approved", value);
		}
        
		private _unitcostsellingprice: number;
		public get unitcostsellingprice(): number {
			return this._unitcostsellingprice;
		}
		public set unitcostsellingprice(value: number) {
            this.CheckSetNotify("unitcostsellingprice", value);
		}
        
		private _royaltypercent: number;
		public get royaltypercent(): number {
			return this._royaltypercent;
		}
		public set royaltypercent(value: number) {
            this.CheckSetNotify("royaltypercent", value);
		}
        
		private _modifier1: number;
		public get modifier1(): number {
			return this._modifier1;
		}
		public set modifier1(value: number) {
            this.CheckSetNotify("modifier1", value);
		}
        
		private _modifier2: number;
		public get modifier2(): number {
			return this._modifier2;
		}
		public set modifier2(value: number) {
            this.CheckSetNotify("modifier2", value);
		}
        
		private _modifier3: number;
		public get modifier3(): number {
			return this._modifier3;
		}
		public set modifier3(value: number) {
            this.CheckSetNotify("modifier3", value);
		}
        
		private _custlevelsmodifydesc: boolean;
		public get custlevelsmodifydesc(): boolean {
			return this._custlevelsmodifydesc;
		}
		public set custlevelsmodifydesc(value: boolean) {
            this.CheckSetNotify("custlevelsmodifydesc", value);
		}
        
		private _instructionsuri: string;
		public get instructionsuri(): string {
			return this._instructionsuri;
		}
		public set instructionsuri(value: string) {
            this.CheckSetNotify("instructionsuri", value);
		}
        
		private _itemtype: number;
		public get itemtype(): number {
			return this._itemtype;
		}
		public set itemtype(value: number) {
            this.CheckSetNotify("itemtype", value);
		}
        
        
		
        private static _fieldMembers : string[] = ['id','description','description2','upccode','xclass','shelf','available','invclass','convbasenum','convbaseuom','convinvnum','convinvuom','convbaseunitsperinvunit','level1','level2','level3','recipe','prepitem','prepitemproduom','prepiteminvuom','prepiteminvunitsperprodunit','modified','modifiedby','catchweight','limitcountstoinvunit','prepprodfactor','prepprodlaborminutes','recstamp','couponvalue','notes','approved','unitcostsellingprice','royaltypercent','modifier1','modifier2','modifier3','custlevelsmodifydesc','instructionsuri','itemtype','CmpNew','CmpDel'];
        private static _dateFieldMembers : string[] = ['_modified'];
        private static _colMembers : string[] = [];
		
        /** generated fields that will be serialized */
		public get FieldMembers(): string[] {
			return inventoryheaderBoGenerated._fieldMembers;
		}
        
        /** all known date fields, used for conversion */
		public get DateFieldMembers(): string[] {
			return inventoryheaderBoGenerated._dateFieldMembers;
		}
        
		/** returns the names of all known collection properties */
		public get CollectionMembers(): string[] {
			return inventoryheaderBoGenerated._colMembers;
		}
        
		constructor(baseTools: Cmp.Ui.Services.IBaseTools) {
			super(baseTools);
		}

	}
}

