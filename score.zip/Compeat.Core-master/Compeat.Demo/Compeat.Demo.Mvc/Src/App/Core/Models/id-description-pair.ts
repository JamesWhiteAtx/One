﻿/// <reference path="../../common-refs.d.ts" />

namespace App.Models {
    /** simple KvP class  */
	export class IdDescriptionPair {
		constructor(public description: string, public id: number|string) { }
	}
}