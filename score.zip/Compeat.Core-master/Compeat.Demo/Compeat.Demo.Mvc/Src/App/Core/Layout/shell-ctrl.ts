﻿/// <reference path="../services/app-services-module.ts" />
/// <reference path="../../common-refs.d.ts" />
/// <reference path="../services/user-session.ts" />
/// <reference path="../services/user-entities.ts" />
/// <reference path="shell-module.ts" />

namespace App.Shell {

    export class ShellController extends Cmp.Ui.Bases.BaseController {

        public CurrentYear: number;
        public UserMenu: Cmp.Ui.Bases.MenuNode[] = [];
        public ExternalApps: Cmp.Ui.Bases.ExternalApp[] = []
        public MenuRefreshToggle: boolean = false;
        
        /** Postpones first time menu rendering until the translation strings are available */
        public SessionLoaded: boolean = false;

        private _dataService: Cmp.Ui.Services.IDataService;
        private _$state: angular.ui.IStateService;
        private _$translate: angular.translate.ITranslateService;
        private _$timeout: angular.ITimeoutService;



        /*@ngInject*/
        constructor(baseTools: Cmp.Ui.Services.IBaseTools,
            public userEntities: App.Services.UserEntitiesService,
            dataService: Cmp.Ui.Services.IDataService,
            $state: angular.ui.IStateService,
            // refreshToken is provided by the resolve promise on the state setup for the shell route
            refreshToken: Cmp.Ui.Services.CheckTokenResult,
            public userSessionService: App.Services.UserSessionService,
            $translate: angular.translate.ITranslateService,
            $timeout: angular.ITimeoutService) {

            super(baseTools);
            var self = this;
            self._dataService = dataService;
            self._$state = $state;
            self._$translate = $translate;
            self._$timeout = $timeout;


            self.CurrentYear = new Date().getFullYear();

            if (refreshToken.Success) {
                self.LoadUserSession();
            }
            else {
                self._$state.transitionTo('login');
            }
        }

        RefreshUserMenu = (): void => {
            this._$timeout(() => {
                this.MenuRefreshToggle = !this.MenuRefreshToggle;
            });
        }

        LoadUserSession() {
            var self = this;
            self.userEntities.RefillList()
                .then(() => {
                    self.userEntities.SetCurrent(1);
                })
                .then(() => { return self.userSessionService.GetUserSession(true) })
                .then((settings: App.Services.UserSession): void => {
                    if (settings) {
                        if (settings.Language) {
                            self._$translate.use(settings.Language);
                        }

                        self.UserMenu = settings.UserMenu;
                        self.ExternalApps = settings.ExternalApps;
                    }
                    // menu should now draw for the first time
                    self.SessionLoaded = true;
                });
        }

        LogOff() {
            var self = this;
            self._dataService
                .SendData('Authentication/LogOff', null)
                .then((): void => {
                    self._$state.transitionTo('login');
                });
        }

        MenuClickAction = (actionType: number, actionId: number): void => {
            var self = this;
            if (actionType === Cmp.Ui.Bases.NodeTypes.Feature) {
                if (actionId === -100 || actionId === -101) {
                    self.LogOff();
                }
                else if (actionId === 1) {
                    self._$state.go('app.riiCrit');
                }
                else if (actionId === 2) {
                    self._$state.go('app.eeocdefs');
                }
                else if (actionId === 3) {
                    self._$state.go('app.userProfile');
                }
                else if (actionId === 4) {
                    self._$state.go('app.birthdaysCrit');
                }
                else if (actionId === 5) {
									self._$state.go('app.masterinventory');
                }
                else {
                    console.log("Unrecognized feature");
                }
            }
            else {
                console.log("Unrecognized action type");
            }
        };

        EntityClickAction = (storeNum: number): void => {
            this.userEntities.SetCurrent(storeNum);
            this.RefreshUserMenu();
        };

    }

    angular.module('app.shell').controller('ShellController', ShellController);


}
