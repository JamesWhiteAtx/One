﻿/// <reference path="../services/app-services-module.ts" />
/// <reference path="../../common-refs.d.ts" />

namespace App.Shell {

	angular.module('app.shell', ['app.services', 'pascalprecht.translate']);

}
