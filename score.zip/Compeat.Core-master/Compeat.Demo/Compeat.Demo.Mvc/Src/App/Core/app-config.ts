﻿/// <reference path="../common-refs.d.ts" />
/// <reference path="app-module.ts" />
/// <reference path="layout/shell-ctrl.ts" />

namespace App {

	angular.module('app')
		.config(config)
		.run(run);

	/*@ngInject*/
	function run(
		$rootScope: angular.IRootScopeService,
        $state: angular.ui.IStateService,
		cmpVersion: Cmp.Ui.Providers.VersionProvider) {

		$rootScope.$on(Cmp.Ui.Services.AuthInterceptor.AUTH401_BROADCAST, () => {
			$state.go('login');
		});
	}

	/*@ngInject*/
	function config(cmpStateProvider: Cmp.Ui.Providers.CmpStateProvider,
		$urlRouterProvider: angular.ui.IUrlRouterProvider,
		$translateProvider: angular.translate.ITranslateProvider,
		$provide: angular.auto.IProvideService,
		toastr: Toastr,
		$httpProvider: angular.IHttpProvider) {
		$translateProvider.preferredLanguage('en');
		$translateProvider.useLoader('cmpLanguageLoader', {});

		$urlRouterProvider
			.otherwise('/home');

		cmpStateProvider
			.DefineState("app", {
				abstract: true,
				url: '',
				templateUrl: 'app/Layout/shell.html',
                controllerAs: Cmp.Ui.Constants.StandardControllerName,
				controller: 'ShellController',
				resolve: {
					/* @ngInject */
					refreshToken: (cmpHttpToken: Cmp.Ui.Services.IHttpToken) => {
						return cmpHttpToken.CheckToken();
					}
				}
			})
			.DefineState('app.home', {
				url: '/home',
				template: ''
				//...more
			});
		
		// toastr options
		toastr.options.timeOut = 4000;
		toastr.options.positionClass = 'toast-bottom-right';

		$httpProvider.interceptors.push('authInterceptor');
        $httpProvider.interceptors.push('loadingInterceptor'); 
	}
}
