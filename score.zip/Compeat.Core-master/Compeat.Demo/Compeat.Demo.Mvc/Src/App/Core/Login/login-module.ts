﻿/// <reference path="../../common-refs.d.ts" />

namespace App.Login {

	angular.module('app.login', ['cmp.ui.components']);
}
