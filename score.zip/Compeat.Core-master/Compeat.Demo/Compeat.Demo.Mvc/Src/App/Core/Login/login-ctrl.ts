﻿/// <reference path="../../common-refs.d.ts" />
/// <reference path="login-module.ts" />
/// <reference path="login-data-service.ts" />

namespace App.Login {

	/**
	 * Interface for objects holding Remember Me login values.
	 * @interface
	 */
	interface IRememebered {
		userName: string;
		customer: string;
	}

	/** 
	 * Key string of the expected Remember Me cookie
	 * @constant
	 * @type {string}
	 */
	const REMEMBERED_COOKIE = "Remembered";

    /** this is the controller for the login screen */
	export class LoginController extends Cmp.Ui.Bases.BaseBoController<App.Login.LoginModel> {
        public LoginForm: angular.IFormController;//defined in templates

        private _$state: angular.ui.IStateService;
        private _$translate: angular.translate.ITranslateService;
        private _loginService: LoginService;
        private _cookieReader: Cmp.Ui.Services.CookieReaderService;

		/*@ngInject*/
		constructor(baseTools: Cmp.Ui.Services.IBaseTools,
			$state: angular.ui.IStateService,
			$translate: angular.translate.ITranslateService,
			public cmpHttpToken: Cmp.Ui.Services.IHttpToken, //public for testing
			loginService: LoginService,
            cookieReader: Cmp.Ui.Services.CookieReaderService) {

			super(baseTools);
            var self = this;
            self._$state = $state;
            self._$translate = $translate;
            self._loginService = loginService;
            self._cookieReader = cookieReader;
			self.Model = new LoginModel(baseTools, $translate);
            self.LoadRemembered(REMEMBERED_COOKIE);
		}
        /** tells angular translate to use the language passed in */
		public ChangeLang = (desiredLanguage: string) => {
			this._$translate.use(desiredLanguage && desiredLanguage.length ? desiredLanguage : "en");
		}

		private ProcessLoginResults = (data: AuthResult, translation: any) => {
			if (data) {
				var token = data.Token;
                switch (data.Result) {
					case AuthResultTypes.UsernameNotFound:
					case AuthResultTypes.InvalidPassword:
						this.AddGeneralError(translation.App$Login_BadUsernamePasswordResult, Cmp.Ui.Rules.BrokenRuleSeverities.Error);
						break;
					case AuthResultTypes.AccountDisabled:
						this.AddGeneralError(translation.App$Login_AccountDisabledResult, Cmp.Ui.Rules.BrokenRuleSeverities.Error);
						break;
					case AuthResultTypes.AccountLocked:
						this.AddGeneralError(translation.App$Login_AccountLockedResult, Cmp.Ui.Rules.BrokenRuleSeverities.Error);
						break;
					case AuthResultTypes.Authenticated:
					case AuthResultTypes.AuthenticatedMustChangePassword:
						this.cmpHttpToken.SetToken(token);
						this._$state.go('app.home');
						break;
					case AuthResultTypes.InvalidCustomer:
						this.AddGeneralError(translation.App$Login_InvalidCustomerResult, Cmp.Ui.Rules.BrokenRuleSeverities.Error);
						break;
					default:
						this.AddGeneralError(translation.App$Login_UnexpectedLoginFailureResult, Cmp.Ui.Rules.BrokenRuleSeverities.Error);
						break;
				}
			} else {
				this.AddGeneralError(translation.App$Login_UnexpectedLoginFailureResult, Cmp.Ui.Rules.BrokenRuleSeverities.Error);
			}
		}
        /** processes a login that has been validated, exposed for testing */
		public _performLogin = (validationResult: boolean): cmp.IPromise<any> => {
			var self = this;
            if (validationResult) {
                return this._$translate(["App$Login_BadUsernamePasswordResult",
                    "App$Login_AccountDisabledResult",
                    "App$Login_AccountLockedResult",
                    "App$Login_InvalidCustomerResult",
                    "App$Login_UnexpectedLoginFailureResult"]).then((translation: any): void => {

                        self._loginService.Login(self.Model).then((data: AuthResult): void => {
                            self.ProcessLoginResults(data, translation);
                        }, (): void => {
                            self.AddGeneralError(translation.App$Login_UnexpectedLoginFailureResult, Cmp.Ui.Rules.BrokenRuleSeverities.Error);
                        });
                    });
            } else {
							return self.BaseTools.CmpPromise.Resolve();
            }
		}
        /** checks if the login was valid, if so calls the PerformLogin function */
		public Login = () => {
            this.IsValid(this.LoginForm).then(this._performLogin);
		}

		/**
		 * Attempts to read a cookie and convert it to an object of IRememebered. If
		 * the object is obtained, the remembered values are assigned to the model.
		 * @method
		 * @param {string} key - name of the cookie.
		 * @returns {void} 
		 */
		public LoadRemembered = (key: string) => {
			var remembered = this._cookieReader.GetObject<IRememebered>(key);
			if (angular.isObject(remembered)) {
				this.Model.userName = remembered.userName;
				this.Model.customer = remembered.customer;
				this.Model.rememberMe = true;
			}
		}
	}
	angular.module('app.login').controller('LoginController', LoginController);

}
