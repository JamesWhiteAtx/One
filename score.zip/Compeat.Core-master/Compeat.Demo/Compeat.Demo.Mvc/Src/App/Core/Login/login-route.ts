﻿/// <reference path="../../common-refs.d.ts" />
/// <reference path="login-module.ts" />
/// <reference path="login-ctrl.ts" />

namespace App.Login {

	angular.module('app.login').config(config);

	/*@ngInject*/
	function config(cmpStateProvider: Cmp.Ui.Providers.CmpStateProvider,
		$urlRouterProvider: angular.ui.IUrlRouterProvider) {
		cmpStateProvider.DefineState("login", {
			url: '/login',
			templateUrl: 'app/Login/login.html',
            controllerAs: Cmp.Ui.Constants.StandardControllerName,
			controller: 'LoginController'
		});
	}

}
