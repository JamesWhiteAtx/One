﻿/// <reference path="../../common-refs.d.ts" />

namespace App.Login {
    /** service for the login screen to use to communicate with the server */
    export class LoginService {
		
        private _dataService: Cmp.Ui.Services.IDataService;

        /*@ngInject*/
        constructor(dataService: Cmp.Ui.Services.IDataService) {
            this._dataService = dataService;
        }
        /** tells the server the login info and returns the promise for it */
        public Login(args: LoginModel): cmp.IPromise<AuthResult> {
            return this._dataService.SendModel<AuthResult>('Authentication/login', args);
        }
    }

    angular
        .module('app.login')
        .service('loginService', LoginService);

    export class AuthResult {
        constructor(public Result?: AuthResultTypes, public Token?: string) { }
    }

    export enum AuthResultTypes {
        UsernameNotFound = 1,
        InvalidPassword = 2,
        AccountDisabled = 3,
        AccountLocked = 4,
        Authenticated = 5,
        AuthenticatedMustChangePassword = 6,
        InvalidCustomer = 7
    }
    /** this contains the information needed to login to the server as well as its business rules */
    export class LoginModel extends Cmp.Ui.Bases.BaseBoModel implements Cmp.Ui.Interfaces.IJsonable {
        public userName: string;
        public password: string;
        public customer: string;
        public rememberMe: boolean;

        private _$translate: angular.translate.ITranslateService

        constructor(baseTools: Cmp.Ui.Services.IBaseTools, $translate: angular.translate.ITranslateService) {
            super(baseTools);
            this._$translate = $translate;
        }

        public GetRules = (): cmp.IPromise<Array<Cmp.Ui.Rules.CmpRule>> => {
            var self = this;
            return self.GetBaseTools().CmpPromise.Promise<Array<Cmp.Ui.Rules.CmpRule>>((resolve): void => {
                var rules = new Array<Cmp.Ui.Rules.CmpRule>();
                self._$translate(["App$Login_UsernameRequired",
                    "App$Login_PasswordRequired",
                    "App$Login_CustomerRequired"]).then((translation: any): void => {

                        rules.push(new Cmp.Ui.Rules.StringRequiredRule('userName', translation.App$Login_UsernameRequired, Cmp.Ui.Rules.NgMessageTypes.Required));
                        rules.push(new Cmp.Ui.Rules.StringRequiredRule('password', translation.App$Login_PasswordRequired, Cmp.Ui.Rules.NgMessageTypes.Required));
                        rules.push(new Cmp.Ui.Rules.StringRequiredRule('customer', translation.App$Login_CustomerRequired, Cmp.Ui.Rules.NgMessageTypes.Required));
                        resolve(rules);
                    });
            });
        }

        public ToJson() : Object {
            return Cmp.Js.Jsonify(this, ['userName', 'password', 'customer', 'rememberMe']);
        }
    }

}

