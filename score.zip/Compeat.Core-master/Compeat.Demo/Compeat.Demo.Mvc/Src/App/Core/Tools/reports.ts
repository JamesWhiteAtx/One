﻿/// <reference path="../../common-refs.d.ts" />

namespace App.ToolsDelete {

	var stockReportRequires = ['ui.router', 'cmp.ui.providers'];
	var reportControllerKey = 'ReportController';
	var reportControllerProviderKey = 'advNgControllerProvider';
	var reportProvideKey = 'advNgProvide';

	export interface IReportModule {
		RegisterController(controllerConstructor: Function): void;
		RegisterService(serviceName: string, serviceConstructor: Function): void;
		ReportControllerKey: string;
	}

	class ReportModule implements IReportModule {

		constructor(private _ngModule: angular.IModule) {
        }

        /** registers the report controller with the angular provider*/
        public RegisterController = (controllerConstructor: Function) => {
			var provider = <angular.IControllerProvider>(<any>this._ngModule)[reportControllerProviderKey];
			provider.register(reportControllerKey, controllerConstructor);
		}

        /** registers the report service with the angular provider*/
		public RegisterService = (serviceName: string, serviceConstructor: Function) => {
			var provider = <angular.auto.IProvideService>(<any>this._ngModule)[reportProvideKey];
			provider.service(serviceName, serviceConstructor);
		}

		//** property access reportControllerKey value, used in testing, for now */
		get ReportControllerKey(): string {
			return reportControllerKey;
		} 

	}
    
    /** registers the report with the router and with the angular provider*/
	export function CreateReportModule(moduleName: string, extraRequires?: string[]) {

		var moduleDependencies: string[];
		if (extraRequires && extraRequires.length > 0) {
			moduleDependencies = stockReportRequires.concat(extraRequires);
		}
		else {
			moduleDependencies = stockReportRequires;
		}

		var newNgModule = angular.module(moduleName, moduleDependencies)
			.config(config);

		/*@ngInject*/
		function config(cmpStateProvider: Cmp.Ui.Providers.CmpStateProvider,
			$controllerProvider: angular.IControllerProvider,
			$provide: angular.auto.IProvideService) {

			var featureName = moduleName.replace('app.', '');

			(<any>newNgModule)[reportControllerProviderKey] = $controllerProvider;
			(<any>newNgModule)[reportProvideKey] = $provide;

			cmpStateProvider.DefineFeatureState(moduleName, {
				url: '/' + featureName,
				templateUrl: 'Assets/Features/' + featureName + '/' + featureName.replace('Crit', '-crit.html'),
                controllerAs: Cmp.Ui.Constants.StandardControllerName,
				controller: reportControllerKey,
				resolve: {
                    lazySource: (scriptLoader: Cmp.Ui.Services.IScriptLoaderService) => {
                        return scriptLoader.LoadScript('Assets/Features/' + featureName + '/source.js');
					}
				}
			});
		}
	}
    
    /** returns the wrapped angular module setup needs for a report */
    export function GetReportModule(moduleName: string): IReportModule {
		return new ReportModule(angular.module(moduleName));
	}

}