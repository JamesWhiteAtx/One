﻿/// <reference path="../../common-refs.d.ts" />
/// <reference path="app-services-module.ts" />

namespace App.Services {

	export class DemoModalFormController extends Cmp.Ui.Bases.CmpModalTemplateController {
		private _clown: string;

		/*@ngInject*/
		constructor(
			baseTools: Cmp.Ui.Services.IBaseTools,
			$modalInstance: angular.ui.bootstrap.IModalServiceInstance) {

			super(baseTools, $modalInstance);
			var self = this;

			self.TitleText = 'Pick a Clown';
			self.HideOk = true;

		}

		//overriden
		protected OkResult = (): any => {
			return this._clown;
		}

		public PickBozo = () => {
			var self = this;
			self._clown = 'Bozo';
			self.Ok();
		}

		public PickCanio = () => {
			var self = this;
			self._clown = 'Canio';
			self.Ok();
		}

	}

	export interface IDemoModalForm {
		Show(): cmp.IPromise<any>;
	}

	export class _DemoModalForm extends Cmp.Ui.Bases.BaseModalService implements IDemoModalForm {

		/*@ngInject*/
		constructor(
			$uibModal: angular.ui.bootstrap.IModalService,
			private cmpPromise: Cmp.Ui.Services.IPromiseService) {
			super($uibModal);
		}

		public Show(): cmp.IPromise<any> {
			var self = this;

			return self.cmpPromise.Promise<any>((resolve, reject) => {

				var modalInst = self.Open({
					size: 'lg',
					templateUrl: 'app/Services/demo-modal-template.html',
					controller: App.Services.DemoModalFormController,
					controllerAs: Cmp.Ui.Constants.StandardControllerName
				});

				modalInst.result.then((result) => {
					resolve(result);
				}, (error) => {
					reject(error);
				});
				
			});
		}

	}

	angular.module('app.services').service('demoModal', _DemoModalForm);

} 

