﻿/// <reference path="../../common-refs.d.ts" />
/// <reference path="app-services-module.ts" />
/// <reference path="local-cache.ts" />


namespace App.Services {
    /** this service maintains a list of entities in the system and the current entity selected */
	export class UserEntitiesService {
		
        private _appLocalCache: App.Services.AppLocalCache;

		/*@ngInject*/
        constructor(appLocalCache: App.Services.AppLocalCache) {
            this._appLocalCache = appLocalCache;
        }

        public List: Array<Cmp.Ui.Models.UserStorePair>;
        public Current: Cmp.Ui.Models.UserStorePair;

        /** refills the entity list from the server */
        public RefillList = (): cmp.IPromise<any> => {
			var self = this;
			return this._appLocalCache.GetUserEntities().then((vals: Array<any>): void => {
                self.List = new Array<Cmp.Ui.Models.UserStorePair>();
				if (vals && vals.length) {
					vals.forEach((val): void => {
                        self.List.push(new Cmp.Ui.Models.UserStorePair(val.storename, val.storenum, false));
					});
				}
			});
		}
        /** sets the current selected entity in the menu */
		public SetCurrent = (currentId: number = null) => {
            var curEnt: Cmp.Ui.Models.UserStorePair = null;
			if (this.List && this.List.length) {
				this.List.forEach((ent): void => {
					if (angular.isDefined(currentId)) {
						ent.Current = (ent.StoreNum == currentId);
						if (ent.Current) {
							curEnt = ent;
						}
					} else if (ent.StoreNum == currentId) {
						curEnt = ent;
					}
				});

				if (curEnt) {
					this.Current = curEnt;
				} else if (this.List && this.List.length) {
					this.Current = this.List[0];
				}
			}
		}
	}
	angular.module('app.services').service('userEntities', UserEntitiesService);

} 