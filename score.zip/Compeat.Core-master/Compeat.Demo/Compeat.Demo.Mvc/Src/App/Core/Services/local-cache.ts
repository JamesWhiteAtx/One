﻿/// <reference path="../../common-refs.d.ts" />
/// <reference path="app-services-module.ts" />

namespace App.Services {

	export enum CacheTypes {
		UserEntities,
		InvLevelAllLookup
	}
    /** this class provides the tools needed to support client side promise based caching */
	export class AppLocalCache implements Cmp.Ui.Services.ILocalCachePaths<CacheTypes> {
        private _cmpLocalCache: Cmp.Ui.Services.ILocalCache<CacheTypes>;
		/*@ngInject*/
        constructor(cmpLocalCache: Cmp.Ui.Services.ILocalCache<CacheTypes>) {
            this._cmpLocalCache = cmpLocalCache;
        }

		/** converts the CacheTypes enum to a controller/action. these must be setup as POSTS server side */
		public GetPromisePath = (key: Cmp.Ui.Services.CacheKey<CacheTypes>): string => {
			switch (key.CacheType) {
				case CacheTypes.UserEntities:
					return 'UserEntities/GetUserEntities';
				case CacheTypes.InvLevelAllLookup:
					return 'Lookup/GetInvLevelLookups';
				default:
					return undefined;
			}
		}

		/** returns entities available to the user logged in */
        public GetUserEntities = (): cmp.IPromise<any> => {
			return this._cmpLocalCache.GetCachePromise(this, new Cmp.Ui.Services.CacheKey(CacheTypes.UserEntities));
		}

		//returns inventory lookup level lists (1,2,3)
		public GetInvLevelLookups = (): Promise<any> => {
			return this._cmpLocalCache.GetCachePromise(this, new Cmp.Ui.Services.CacheKey(CacheTypes.InvLevelAllLookup));
		}
	}
	angular.module('app.services').service('appLocalCache', AppLocalCache);


}