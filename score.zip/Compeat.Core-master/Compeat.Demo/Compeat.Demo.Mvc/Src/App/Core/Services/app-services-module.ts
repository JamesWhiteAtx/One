﻿/// <reference path="../../common-refs.d.ts" />

namespace App.Services {
	angular.module('app.services', [
		'pascalprecht.translate'
	]);
}