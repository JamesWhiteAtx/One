﻿/// <reference path="../../common-refs.d.ts" />
/// <reference path="app-services-module.ts" />

namespace App.Services {

    /** Provides information realted to the current user's session */
    export class UserSessionService {

        private _dataService: Cmp.Ui.Services.IDataService;
		
        private _userSession: cmp.IPromise<UserSession>;

        /*@ngInject*/
        constructor(dataService: Cmp.Ui.Services.IDataService) {
            this._dataService = dataService;
        }
        
        /** asks the server for this users settings  */
        public GetUserSession = (clearCache: boolean): cmp.IPromise<UserSession> => {
            if (!clearCache || !this._userSession) {

                this._userSession = this._dataService.GetData<any>('Session/GetUserSession', null)
                    .then((result: any) => {

                        var typedResult = new UserSession();
                        typedResult.UserDisplayName = result.UserDisplayName;
                        typedResult.UserId = result.UserId;
                        typedResult.Language = result.Language;
                        typedResult.InitializeRights(result.UserRights);
                        typedResult.UserMenu = result.UserMenu;
                        typedResult.ExternalApps = result.ExternalApps;
                        return typedResult;
                    });
            }
            return this._userSession;
		}
	}

	angular
		.module('app.services')
        .service('userSessionService', UserSessionService);

    /** application specific implementation of BaseSession */
    export class UserSession extends Cmp.Ui.Bases.BaseSession {
		
	}

} 