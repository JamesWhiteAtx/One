﻿/// <reference path="../../common-refs.d.ts" />
/// <reference path="app-services-module.ts" />
/// <reference path="../models/id-description-pair.ts" />

namespace App.Services {

	export class StaticCollections {
        private _$translate: angular.translate.ITranslateService;
        private _cmpPromise: Cmp.Ui.Services.PromiseService;
		/*@ngInject*/
        constructor($translate: angular.translate.ITranslateService, cmpPromise: Cmp.Ui.Services.PromiseService) {
            var self = this;
            self._$translate = $translate;
            self._cmpPromise = cmpPromise;
        }

        private _monthList: Array<App.Models.IdDescriptionPair>;
        /**  returns a promise with a list of translated month names */
        public MonthList = (): cmp.IPromise<Array<App.Models.IdDescriptionPair>> => {

			var self = this;
			return self._cmpPromise.Promise<Array<App.Models.IdDescriptionPair>>((resolve: ng.IQResolveReject<Array<App.Models.IdDescriptionPair>>, reject: any): void => {
				if (self._monthList && self._monthList.length) {
					resolve(self._monthList.slice());//slice to clone rather than send original
				} else {
					var list = new Array<App.Models.IdDescriptionPair>();
					self._$translate(["App$MonthJanuary",
						"App$MonthFebruary",
						"App$MonthMarch",
						"App$MonthApril",
						"App$MonthMay",
						"App$MonthJune",
						"App$MonthJuly",
						"App$MonthAugust",
						"App$MonthSeptember",
						"App$MonthOctober",
						"App$MonthNovember",
						"App$MonthDecember"]).then((translation: any): void => {
							list.push(new App.Models.IdDescriptionPair(translation.App$MonthJanuary, 1));
							list.push(new App.Models.IdDescriptionPair(translation.App$MonthFebruary, 2));
							list.push(new App.Models.IdDescriptionPair(translation.App$MonthMarch, 3));
							list.push(new App.Models.IdDescriptionPair(translation.App$MonthApril, 4));
							list.push(new App.Models.IdDescriptionPair(translation.App$MonthMay, 5));
							list.push(new App.Models.IdDescriptionPair(translation.App$MonthJune, 6));
							list.push(new App.Models.IdDescriptionPair(translation.App$MonthJuly, 7));
							list.push(new App.Models.IdDescriptionPair(translation.App$MonthAugust, 8));
							list.push(new App.Models.IdDescriptionPair(translation.App$MonthSeptember, 9));
							list.push(new App.Models.IdDescriptionPair(translation.App$MonthOctober, 10));
							list.push(new App.Models.IdDescriptionPair(translation.App$MonthNovember, 11));
							list.push(new App.Models.IdDescriptionPair(translation.App$MonthDecember, 12));
							self._monthList = list;
							resolve(list.slice());//slice to clone rather than send original
                        }, reject);
				}
			});
		}
	}
	angular.module('app.services').service('staticCollections', StaticCollections);


}