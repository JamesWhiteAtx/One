﻿/// <reference path="../feature-refs.d.ts" />
/// <reference path="eeocdefs-module.ts" />

namespace App.EeocDefs {

    class EeocDefsEditController extends Cmp.Ui.Bases.BaseDeController<App.Gen.Models.eeocdefsBo, App.Gen.Models.eeocdefsBo> {

		/*@ngInject*/
        constructor(baseTools: Cmp.Ui.Services.IBaseTools, $scope: angular.IScope) {

			super(baseTools, App.Gen.Models.eeocdefsBo, $scope);

			console.log('Edit Controller');

			var self = this;

			self.SetRouteAndTableName("eeocdefs");

			self.GetRecord();
		}

	} // class EeocDefsEditController extends Cmp.Ui.Bases.BaseBoController<App.Gen.Models.eeocdefsBo> {

    Cmp.Ui.Features.GetFeatureModule('app.eeocdefs').RegisterDataEntryController(EeocDefsEditController);
} // namespace App.EeocDefs {
