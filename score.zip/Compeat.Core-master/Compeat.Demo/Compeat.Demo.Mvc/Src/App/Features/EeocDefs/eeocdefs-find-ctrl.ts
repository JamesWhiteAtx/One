﻿/// <reference path="../feature-refs.d.ts" />
/// <reference path="eeocdefs-module.ts" />
/// <reference path="../core-refs-generated.d.ts" />

namespace App.EeocDefs {

    export class EeocDefsFindController extends Cmp.Ui.Bases.BaseFindController<App.Gen.Models.eeocdefsBo, App.Gen.Models.eeocdefsBo> {

		/*@ngInject*/
		constructor(baseTools: Cmp.Ui.Services.IBaseTools) {
			super(baseTools);

			console.log('Find Controller');

			var self = this;

			self.SetRouteAndTableName("eeocdefs");
            self.FindOptions = {
                FindCols: {
                    Columns: <Array<Cmp.Ui.Components.ICmpGridColumn>>[
                        {
                            PropertyName: "description",
                            PropertyType: Cmp.Js.Enums.CmpGridPropertyType.String,
                            ColumnHeaderText: self.$translate.instant("Core$NameU")
                        }, {
                            PropertyName: "id",
                            PropertyType: Cmp.Js.Enums.CmpGridPropertyType.Number,
                            ColumnHeaderText: self.$translate.instant("Core$IdU")
                        }
                    ],
                    KeyPropertyName: "id",
                    EnableClientSidePaging: true,
                    PageSize: 25
                },
                DeleteRecord: self.DeleteRecord,
                UpdateFindList: self.UpdateFindList,
                RouteName: self.RouteName
            };
			self.GetFindData(App.Gen.Models.eeocdefsBo);
        } // constructor

        public UpdateFindList = (objectAfterBeingUpdated: App.Gen.Models.eeocdefsBo, findListIndex: number): cmp.IPromise<App.Gen.Models.eeocdefsBo> => {
            var self = this;
            if (findListIndex >= 0) {
                var existingItem = self.FindList.Data[findListIndex];
                existingItem.description = objectAfterBeingUpdated.description;
            } else {
							var newItem = self.BaseTools.CreateInstance<App.Gen.Models.eeocdefsBo>(App.Gen.Models.eeocdefsBo);
                newItem.id = objectAfterBeingUpdated.id;
                newItem.description = objectAfterBeingUpdated.description;
                self.FindList.AddItem(newItem);
            }
            return self.BaseTools.CmpPromise.Resolve(objectAfterBeingUpdated);
        }
	} // class EeocDefsFindController extends Cmp.Ui.Bases.BaseBoController<any>

    Cmp.Ui.Features.GetFeatureModule('app.eeocdefs').RegisterFindController(EeocDefsFindController);
}
