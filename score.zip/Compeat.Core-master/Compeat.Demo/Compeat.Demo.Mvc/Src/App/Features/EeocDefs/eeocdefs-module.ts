﻿/// <reference path="../feature-refs.d.ts" />

namespace App.EeocDefs {
    Cmp.Ui.Features.CreateFindAndEditFeatureModule('app.eeocdefs');
}
