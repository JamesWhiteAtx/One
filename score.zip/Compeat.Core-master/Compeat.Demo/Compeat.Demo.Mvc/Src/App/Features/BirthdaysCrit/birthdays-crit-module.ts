﻿/// <reference path="../feature-refs.d.ts" />

namespace App.BirthdaysCrit {

	Cmp.Ui.Reports.CreateReportModule('app.birthdaysCrit');
}
