﻿/// <reference path="../feature-refs.d.ts" />
/// <reference path="birthdays-crit-module.ts" />

namespace App.BirthdaysCrit {

		class BirthdayReportController extends Cmp.Ui.Bases.BaseController {
				public ReportForm: angular.IFormController;//defined in templates
				public Month: number = null;
				public MonthList: Array<App.Models.IdDescriptionPair> = null;

				private _cmpHttpToken: Cmp.Ui.Services.IHttpToken;
				private _$translate: angular.translate.ITranslateService;
				private _cmpReportLoader: Cmp.Ui.Services.ReportLoader;
				private _staticCollections: App.Services.StaticCollections;


				/*@ngInject*/
				constructor(baseTools: Cmp.Ui.Services.IBaseTools,
						cmpHttpToken: Cmp.Ui.Services.IHttpToken,
						$translate: angular.translate.ITranslateService,
						cmpReportLoader: Cmp.Ui.Services.ReportLoader,
						staticCollections: App.Services.StaticCollections) {

						super(baseTools);
						var self = this;
						self._cmpHttpToken = cmpHttpToken;
						self._$translate = $translate;
						self._cmpReportLoader = cmpReportLoader;
						self._staticCollections = staticCollections;
						self.FillMonthList();
				}
				/** runs this report */
				public RunReport = (): void => {
						var self = this;

						var requestModel = new Cmp.Ui.ReportModels.ReportRequestModel(
								"Birthdays",
								[
										new Cmp.Ui.ReportModels.ReportParameter("storeNum", 1),
										new Cmp.Ui.ReportModels.ReportParameter("storeName", "Test Store"),
										new Cmp.Ui.ReportModels.ReportParameter("month", self.Month ? self.Month : 0)
								],
								self._cmpHttpToken.Token);

						self._cmpReportLoader.OpenReportLoaderWindow(requestModel);
				}

				private FillMonthList = () => {
						var self = this;

						return self._staticCollections.MonthList().then((list: Array<App.Models.IdDescriptionPair>): void => {
				self.MonthList = list;
				self.BaseTools.RefreshObservers();
						});
				}

		}

		Cmp.Ui.Reports.GetReportModule('app.birthdaysCrit').RegisterController(BirthdayReportController);

}
