﻿using Compeat.Mvc;
using Compeat.Demo.Service.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Compeat.Mvc.BaseControllers;
using Compeat.Service.Interfaces;

namespace Compeat.Demo.Mvc.Controllers
{
	public class ResourcesController : BaseController
    {

		private AppResourceService ResourceService { get; set; }

        public ResourcesController(IInjectionContainer injectionContainer, AppResourceService resourceService): base(injectionContainer)
        {
			ResourceService = resourceService;
		}

		/// <summary>
		/// Returns to the caller a jsonified version of the ResourceService result for the given language code.
		/// </summary>
		[AllowAnonymous]
		[HttpPost]
#if !DEBUG
		[OutputCache(Duration=300, VaryByParam="*")]
#endif
		public ActionResult GetAppResourceStrings(string languageCode)
		{
			try
			{
				return Json(ResourceService.GetResources(languageCode));
			}
			catch
			{
				return new HttpNotFoundResult();
			}
		}
    }
}