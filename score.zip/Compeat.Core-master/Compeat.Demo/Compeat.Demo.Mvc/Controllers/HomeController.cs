﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Compeat.Demo.Service.Services;
using Compeat.Service;
using Compeat.Mvc;
using Compeat.Mvc.BaseControllers;
using Compeat.Service.Interfaces;

namespace Compeat.Demo.Mvc.Controllers
{
	public class HomeController : BaseController
	{
		public HomeController(IInjectionContainer injectionContainer) : base(injectionContainer)
		{

		}
		[AllowAnonymous]
		public ActionResult Index()
		{
			return View();
		}
	}
}
