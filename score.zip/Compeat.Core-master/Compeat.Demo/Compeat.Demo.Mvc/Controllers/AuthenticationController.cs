﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Compeat.Demo.Service.Models;
using Compeat.Demo.Service.Services;
using Compeat.Mvc;
using Compeat.Service.Authentication;
using Compeat.Mvc.BaseControllers;
using Newtonsoft.Json;
using Compeat.Service.Interfaces;

namespace Compeat.Demo.Mvc.Controllers
{
	public class AuthenticationController : BaseAuthenticationController<LoginModel>
	{
		// key value for the Rememeber Me cookie
		private const string REMEMBERED_COOKIE = "Remembered";

		private IdentityManager _identityManager { get; set; }
		private AuthenticationService _service { get; set; }

		public AuthenticationController(IInjectionContainer injectionContainer, IdentityManager identityManager, AuthenticationService service)
			: base(injectionContainer, identityManager)
		{
			this._identityManager = identityManager;
			this._service = service;
		}

		protected override AuthResultTypes ProcessLogin(LoginModel model)
		{
			AuthResultTypes resultType;

			resultType = _identityManager.AuthenticateUser(_service, model.userName, model.password, model.customer, model.rememberMe);

			// if the login was autenticated, update the Rememeber Me
			if (resultType == AuthResultTypes.Authenticated)
			{
				UpdateRememberedCookie(model);
			}

			return resultType;
		}
		protected override string GetCsrfToken(LoginModel model)
		{
			return _identityManager.GetCsrfToken(model.userName, model.customer);
		}

		//Anonymous Endpoints: 

		//public ActionResult getToken();

		//[HttpPost]
		//public ActionResult login(TModel model);

		//[HttpPost]
		//public ActionResult logOff();

		/// <summary>
		/// Update the Remember Me cookie based on the rememberMe value of the passed login model.
		/// Store the value of cookie as json because it will consumed by javascript code on the client.
		/// </summary>
		/// <param name="model"></param>
		private void UpdateRememberedCookie(LoginModel model)
		{
			if (model.rememberMe)
			{
				var rememberedCookie = new HttpCookie(REMEMBERED_COOKIE);
				rememberedCookie.Expires = DateTime.Now.AddDays(30);

				var json = JsonConvert.SerializeObject(new { userName = model.userName, customer = model.customer });
				rememberedCookie.Value = json;

				Response.Cookies.Set(rememberedCookie);
			}
			else
			{
				if (Request.Cookies[REMEMBERED_COOKIE] != null)
				{
					HttpCookie myCookie = new HttpCookie(REMEMBERED_COOKIE);
					// set to expire in the past, cookie will be removed
					myCookie.Expires = DateTime.Now.AddDays(-1d);

					// adding the expired cookie to both request and response fixed issue with duplicate cookies appearing on the response
					Request.Cookies.Add(myCookie);
					Response.Cookies.Add(myCookie);
				}
			}
		}
	}
}