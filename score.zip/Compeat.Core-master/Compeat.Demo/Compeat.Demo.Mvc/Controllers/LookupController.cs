﻿using System.Web.Mvc;
using Compeat.Demo.Service.Services;
using Compeat.Mvc.BaseControllers;
using Compeat.Service.Interfaces;

namespace Compeat.Demo.Mvc.Controllers
{
    public class LookupController : BaseController
	{
		private LookupService _service { get; set; }

		public LookupController(IInjectionContainer injectionContainer, LookupService service)
			: base(injectionContainer)
		{
			this._service = service;
		}

		[HttpPost]
		public ActionResult GetInvLevelLookups()
		{
			return Json(_service.GetInvLevelLookups());
		}
	}
}