﻿using Compeat.Demo.Data;
using Compeat.Demo.Service.Models;
using Compeat.Demo.Service.Services;
using Compeat.Demo.Service.Services.Crud;
using Compeat.Mvc.BaseControllers;
using Compeat.Service.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace Compeat.Demo.Mvc.Controllers.Crud
{
	public partial class eeocdefsController
	{
		public eeocdefsController(IInjectionContainer injectionContainer, eeocdefsService service)
			: base(injectionContainer, service)
		{ }

		[HttpPost]
		[AllowAnonymous]
		public ActionResult GetList()
		{
			return Json(CrudService.GetList());
		}

	}
}
