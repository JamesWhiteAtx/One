﻿using Compeat.Demo.Data;
using Compeat.Demo.Service.Models;
using Compeat.Demo.Service.Services;
using Compeat.Demo.Service.Services.Crud;
using Compeat.Mvc.BaseControllers;
using Compeat.Service.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace Compeat.Demo.Mvc.Controllers.Crud
{
	public partial class usersController
	{
		public usersController(IInjectionContainer injectionContainer, usersService service)
			: base(injectionContainer, service)
		{ }

		[HttpPost]
		public ActionResult GetList()
		{
			return Json(CrudService.GetList());
		}

	}
}
