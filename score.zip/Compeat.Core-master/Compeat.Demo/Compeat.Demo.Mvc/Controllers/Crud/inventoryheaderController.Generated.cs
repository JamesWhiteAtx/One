﻿using Compeat.Demo.Data;
using Compeat.Demo.Service.Models.Crud;
using Compeat.Demo.Service.Services.Crud;
using Compeat.Mvc.BaseControllers;

namespace Compeat.Demo.Mvc.Controllers.Crud
{
	public partial class inventoryheaderController : BaseCrudController<inventoryheaderBo, int?, inventoryheaderDto, inventoryheaderService, Compeat.Demo.Service.DemoRights>
	{ }
}

