﻿using Compeat.Demo.Data;
using Compeat.Demo.Service.Models.Crud;
using Compeat.Demo.Service.Services.Crud;
using Compeat.Mvc.BaseControllers;

namespace Compeat.Demo.Mvc.Controllers.Crud
{
	public partial class qryUserProfileController : BaseSavableController<qryUserProfileBo, qryUserProfileDto, qryUserProfileService, Compeat.Demo.Service.DemoRights>
	{ }
}

