﻿using Compeat.Mvc;
using Compeat.Demo.Reports.Library;
using Compeat.Demo.Service.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Compeat.Mvc.BaseControllers;
using Compeat.Demo.Service;
using Compeat.Service.Interfaces;

namespace Compeat.Demo.Mvc.Controllers
{
    public class ReportsController : BaseReportsController<ReportBase, DemoRights>
    {
		private SessionService _sessionService;

        public ReportsController(IdentityManager identityManager, IReportCacheService cacheService,
			ISessionService<DemoRights> sessionService)
            : base(identityManager, cacheService)
        {
			_sessionService = (SessionService)sessionService;
        }

		/// <summary>
		/// Add new reports and their required rights to this registration stub.
		/// </summary>
		protected override Dictionary<string, ReportRegistration> RegisteredReports
		{
			get
			{
				return new Dictionary<string, BaseReportsController<ReportBase, DemoRights>.ReportRegistration>()
				{
					{ "Birthdays", new BaseReportsController<ReportBase, DemoRights>.ReportRegistration(typeof(Birthdays), DemoRights.BirthdaysReport) },
					{ "MasterInventoryItems", new BaseReportsController<ReportBase, DemoRights>.ReportRegistration(typeof(MasterInventoryItems), DemoRights.MasterInventoryItemsReport) },
					{ "RestaurantInventoryListing", new BaseReportsController<ReportBase, DemoRights>.ReportRegistration(typeof(RestaurantInventoryListing), DemoRights.RestaurantInventoryListingReport) }
				};
			}
		}

		protected override bool HasRight(DemoRights right)
		{
			return true;
			//return _sessionService.HasRight(right);
		}
	}
}

